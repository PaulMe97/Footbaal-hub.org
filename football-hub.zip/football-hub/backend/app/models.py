"""
FootballHub – Database Schema
===============================
Πλήρες relational schema. Στη Φάση 1 είναι ενεργά συνδεδεμένα με API endpoints:
Users, Teams, Players, PlayerTeamHistory.

Οι υπόλοιποι πίνακες (Matches, Trainings, Injuries, Tactical*, Notifications,
CalendarEvents, AIReports, Documents, MediaFiles) ορίζονται ήδη εδώ ώστε το schema
να είναι σωστό εξ αρχής και οι επόμενες φάσεις να προσθέτουν μόνο routers/UI,
όχι migrations from scratch.
"""
import enum
import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.types import TypeDecorator

from app.database import Base
from app.services.crypto_service import decrypt, encrypt


def gen_uuid() -> str:
    return str(uuid.uuid4())


class EncryptedString(TypeDecorator):
    """Κρυπτογραφεί/αποκρυπτογραφεί διαφανώς μια στήλη String — η τιμή
    κρυπτογραφείται πριν αποθηκευτεί στη βάση, και αποκρυπτογραφείται
    αυτόματα κάθε φορά που διαβάζεται μέσω του ORM. Backward-compatible με
    ήδη υπάρχουσες, μη-κρυπτογραφημένες τιμές στη βάση (βλ.
    crypto_service.decrypt)."""

    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return value
        return encrypt(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        return decrypt(value)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
class UserRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"
    ADMIN = "admin"
    PRESIDENT = "president"
    TECHNICAL_DIRECTOR = "technical_director"
    HEAD_COACH = "head_coach"
    ASSISTANT_COACH = "assistant_coach"
    FITNESS_COACH = "fitness_coach"
    ANALYST = "analyst"
    SCOUT = "scout"
    PLAYER = "player"


class PlayerPosition(str, enum.Enum):
    GK = "GK"
    CB = "CB"
    LB = "LB"
    RB = "RB"
    LWB = "LWB"
    RWB = "RWB"
    DM = "DM"
    CM = "CM"
    AM = "AM"
    LW = "LW"
    RW = "RW"
    ST = "ST"


class PreferredFoot(str, enum.Enum):
    LEFT = "left"
    RIGHT = "right"
    BOTH = "both"


class PlayerStatus(str, enum.Enum):
    FIT = "fit"
    INJURED = "injured"
    SUSPENDED = "suspended"
    UNAVAILABLE = "unavailable"
    DOUBTFUL = "doubtful"


class MatchStatus(str, enum.Enum):
    SCHEDULED = "scheduled"
    LIVE = "live"
    FINISHED = "finished"
    POSTPONED = "postponed"
    CANCELLED = "cancelled"


class AttendanceStatus(str, enum.Enum):
    PRESENT = "present"
    ABSENT = "absent"
    LATE = "late"
    INJURED = "injured"
    EXCUSED = "excused"


class InjuryStatus(str, enum.Enum):
    ACTIVE = "active"
    RECOVERING = "recovering"
    RECOVERED = "recovered"


class NotificationType(str, enum.Enum):
    UPCOMING_MATCH = "upcoming_match"
    UPCOMING_TRAINING = "upcoming_training"
    PLAYER_INJURY = "player_injury"
    PLAYER_RETURN = "player_return"
    LOW_ATTENDANCE = "low_attendance"
    TEAM_EVENT = "team_event"
    MATCH_REPORT_PENDING = "match_report_pending"
    AI_REPORT_READY = "ai_report_ready"
    RENEWAL_ON_HOLD = "renewal_on_hold"
    CONTRACT_OFFER = "contract_offer"
    NEW_APPLICATION = "new_application"
    CRM_TOPIC = "crm_topic"
    NEW_LEADERSHIP_REGISTRATION = "new_leadership_registration"


# ---------------------------------------------------------------------------
# Users & Auth
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_uuid)
    email = Column(String, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    role = Column(Enum(UserRole), default=UserRole.SUPER_ADMIN, nullable=False)
    is_active = Column(Boolean, default=True)
    # Συνδέει έναν λογαριασμό ρόλου Player με την πραγματική εγγραφή του στο
    # ρόστερ — ώστε να μπορεί να διαχειριστεί μόνο τη δική του κατάσταση
    # μεταγραφής. Ρυθμίζεται από coach/admin, όχι από τον ίδιο τον παίκτη.
    linked_player_id = Column(String, ForeignKey("players.id"), nullable=True)

    # --- Επικοινωνία (CRM directory) ---------------------------------------
    phone = Column(String, nullable=True)
    date_of_birth = Column(Date, nullable=True)

    # --- Προφίλ / Staff Scouting ------------------------------------------
    avatar_path = Column(String, nullable=True)
    bio = Column(Text, nullable=True)
    is_staff_visible = Column(Boolean, default=False)
    # not_listed | available | open_to_offers — αντίστοιχο του transfer_status
    # των παικτών, αλλά για coach/staff ρόλους.
    staff_availability = Column(String, nullable=False, default="not_listed")
    # Ρόλος που αναζητά ο ίδιος ο χρήστης (π.χ. head_coach, technical_director,
    # scout) — ανεξάρτητο από το UserRole του λογαριασμού, δηλωμένο από τον
    # ίδιο στο "Ψάχνω για..." του προφίλ του.
    desired_staff_role = Column(String, nullable=True)
    # Από πού είναι — μία ΕΠΣ (νομός).
    origin_federation_id = Column(String, ForeignKey("federations.id"), nullable=True)
    # Σε ποιες ΕΠΣ (νομούς) επιθυμεί να εργαστεί — comma-separated λίστα από
    # federation ids, ίδιο pattern με το TeamListing.role_needed.
    desired_federation_ids = Column(String, nullable=True)

    # --- LinkedIn -----------------------------------------------------------
    linkedin_url = Column(String, nullable=True)
    show_linkedin = Column(Boolean, default=False)

    # --- Επαλήθευση αξιοπιστίας (grey/blue/green) --------------------------
    # 0 = γκρι (μη επαληθευμένος), 1 = μπλε (μερικώς), 2 = πράσινο (πλήρως)
    verification_level = Column(Integer, nullable=False, default=0)
    document_consent_at = Column(DateTime, nullable=True)
    # True όταν ο σύλλογος του χρήστη έχει επαληθευτεί ως γνήσιος (μέσω
    # εγκεκριμένου επίσημου εγγράφου συλλόγου) — αφορά ΜΟΝΟ Πρόεδρο/Τεχνικό
    # Διευθυντή. Όσο είναι False, οι ομάδες τους ΔΕΝ εμφανίζονται στο
    # Scouting Hub και δεν μπορούν να δημοσιεύσουν αγγελίες — δεν εμποδίζει
    # τη δημιουργία/διαχείριση ομάδων (ήπιο gating, όχι σκληρό μπλοκάρισμα).
    club_verified = Column(Boolean, nullable=False, default=False)

    # True ΜΟΝΟ όταν ο admin έχει προσωπικά επιβεβαιώσει (εκτός εφαρμογής,
    # π.χ. μέσω email) την ταυτότητα ενός Προέδρου/Τεχνικού Διευθυντή και
    # του δώσει ρητά «OK» — αφορά ΜΟΝΟ αυτούς τους δύο ρόλους. Όσο είναι
    # False, ΔΕΝ μπορούν να δημιουργήσουν ΚΑΜΙΑ ομάδα (σκληρό μπλοκάρισμα,
    # σε αντίθεση με το club_verified που είναι ήπιο gating). Ποτέ δεν
    # γίνεται True αυτόματα (ούτε από AI) — μόνο με ρητή ενέργεια admin.
    leadership_approved = Column(Boolean, nullable=False, default=False)

    # --- Πρόεδρος/Τεχνικός Διευθυντής: ΑΦΜ ομάδας — ιδιωτικό στοιχείο,
    # ορατό ΜΟΝΟ στο προφίλ του ίδιου του χρήστη, πουθενά αλλού μέσα στην
    # εφαρμογή. Κρυπτογραφημένο στη βάση (EncryptedString) — διαβάζεται ως
    # απλό κείμενο μόνο σε επίπεδο εφαρμογής (Python), ποτέ στη βάση.
    team_tax_id = Column(EncryptedString, nullable=True)

    # --- GDPR συναίνεση κατά την εγγραφή ------------------------------------
    gdpr_consent_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    token = Column(String, unique=True, index=True, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Προφίλ χρήστη (Staff Scouting) — πτυχία, εργασιακή εμπειρία, κατακτήσεις
# ---------------------------------------------------------------------------
class Qualification(Base):
    """Πτυχίο/πιστοποίηση, π.χ. 'UEFA B', 'Scouting & Analysis'."""

    __tablename__ = "qualifications"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String, nullable=False)
    year = Column(Integer, nullable=True)


class WorkExperience(Base):
    """Εργασιακή εμπειρία — πού και πότε έχει δουλέψει."""

    __tablename__ = "work_experiences"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    organization = Column(String, nullable=False)
    role_title = Column(String, nullable=True)
    start_year = Column(Integer, nullable=True)
    end_year = Column(Integer, nullable=True)  # None = τρέχουσα θέση
    description = Column(Text, nullable=True)


class Achievement(Base):
    """Κατακτήσεις/τίτλοι."""

    __tablename__ = "achievements"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String, nullable=False)
    year = Column(Integer, nullable=True)
    description = Column(Text, nullable=True)


class TeamStaffMember(Base):
    """Τεχνικό επιτελείο ομάδας — ποιοι χρήστες της πλατφόρμας συνδέονται με
    ποια ομάδα και με ποιον ρόλο (π.χ. Βοηθός Προπονητή, Αναλυτής)."""

    __tablename__ = "team_staff_members"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    role_title = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Scouting Hub — Αιτήσεις συνεργασίας (coach/staff -> ομάδα) &
# πρόσβαση διαχείρισης χωρίς ιδιοκτησία (πολλαπλοί σύλλογοι ανά coach)
# ---------------------------------------------------------------------------
class TeamJoinRequest(Base):
    """Αίτηση ενός coach/staff να αναλάβει μια ομάδα. Λήγει σε 3 ημέρες αν
    δεν απαντήσει ο ιδιοκτήτης της ομάδας."""

    __tablename__ = "team_join_requests"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    applicant_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    message = Column(Text, nullable=True)
    # pending | accepted | rejected | expired
    status = Column(String, nullable=False, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    responded_at = Column(DateTime, nullable=True)
    responded_by = Column(String, ForeignKey("users.id"), nullable=True)


class TeamAccessGrant(Base):
    """Δίνει σε έναν coach δικαίωμα διαχείρισης μιας ομάδας που ΔΕΝ κατέχει
    ο ίδιος (owner_id) — προκύπτει από αποδοχή TeamJoinRequest. Ένας coach
    μπορεί να έχει grants σε ομάδες πολλών διαφορετικών συλλόγων/owners
    ταυτόχρονα."""

    __tablename__ = "team_access_grants"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    role_title = Column(String, nullable=True)
    granted_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class PlayerJoinRequest(Base):
    """Αίτηση παίκτη να ενταχθεί σε μια ομάδα. Λήγει σε 3 ημέρες. Με την
    αποδοχή, ο παίκτης (ή νέα εγγραφή παίκτη γι' αυτόν) μπαίνει σε αυτή την
    ομάδα — ένας παίκτης έχει δικαίωμα σε ΜΙΑ ομάδα κάθε φορά."""

    __tablename__ = "player_join_requests"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    applicant_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    message = Column(Text, nullable=True)
    # Χρησιμοποιείται ΜΟΝΟ τη στιγμή της αποδοχής, για να ταιριάξει σωστά με
    # υπάρχουσα εγγραφή παίκτη στο ρόστερ (π.χ. σε περίπτωση συνωνυμίας) —
    # ίδια λογική με το ταίριασμα κατά την εγγραφή λογαριασμού.
    date_of_birth = Column(Date, nullable=True)
    status = Column(String, nullable=False, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    responded_at = Column(DateTime, nullable=True)
    responded_by = Column(String, ForeignKey("users.id"), nullable=True)


# ---------------------------------------------------------------------------
# Αγγελίες (Scouting Hub job listings) — ο σύλλογος ψάχνει staff ή παίκτη,
# οι υποψήφιοι βλέπουν τη λίστα και αιτούνται
# ---------------------------------------------------------------------------
class TeamListing(Base):
    __tablename__ = "team_listings"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    posted_by = Column(String, ForeignKey("users.id"), nullable=False)
    listing_type = Column(String, nullable=False)  # staff | player
    status = Column(String, nullable=False, default="open")  # open | closed | expired

    # Staff listing — role_needed μπορεί να είναι comma-separated λίστα (έως 5 ρόλων)
    role_needed = Column(String, nullable=True)
    season = Column(String, nullable=True)
    employment_type = Column(String, nullable=True)  # paid | unpaid

    # Player listing — position_needed μπορεί να είναι comma-separated λίστα (έως 5 θέσεων)
    position_needed = Column(String, nullable=True)
    min_age = Column(Integer, nullable=True)
    max_age = Column(Integer, nullable=True)

    # Ποιες ΕΠΣ (νομούς) στοχεύει η αγγελία — comma-separated λίστα από
    # federation ids. Κενό/None = οπουδήποτε (χωρίς γεωγραφικό περιορισμό).
    target_federation_ids = Column(String, nullable=True)

    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)  # 3 μέρες μετά τη δημιουργία


class ListingApplication(Base):
    __tablename__ = "listing_applications"

    id = Column(String, primary_key=True, default=gen_uuid)
    listing_id = Column(String, ForeignKey("team_listings.id"), nullable=False, index=True)
    applicant_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    message = Column(Text, nullable=True)
    status = Column(String, nullable=False, default="pending")  # pending|accepted|rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime, nullable=True)
    responded_by = Column(String, ForeignKey("users.id"), nullable=True)


# ---------------------------------------------------------------------------
# Συνομιλίες — ξεκινούν αυτόματα μόλις γίνει αποδεκτή μια αίτηση (αγγελία,
# ανάληψη ομάδας ή ένταξη παίκτη), ώστε οι δύο πλευρές να συνεννοηθούν.
# ---------------------------------------------------------------------------
class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_a_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    user_b_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    related_team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    related_listing_id = Column(String, ForeignKey("team_listings.id"), nullable=True)
    context_label = Column(String, nullable=True)  # π.χ. "Αγγελία: Γυμναστής"
    created_at = Column(DateTime, default=datetime.utcnow)


class Message(Base):
    __tablename__ = "messages"

    id = Column(String, primary_key=True, default=gen_uuid)
    conversation_id = Column(String, ForeignKey("conversations.id"), nullable=False, index=True)
    sender_id = Column(String, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    read_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# Ομαδικές συνομιλίες — ξεχωριστό, παράλληλο σύστημα από το 1-προς-1
# Conversation/Message παραπάνω (το οποίο έχει σκόπιμα ΜΟΝΟ user_a_id/
# user_b_id — δεν αλλάζει, ώστε να μη σπάσει κανένα από τα πολλά σημεία
# που ήδη το χρησιμοποιούν). Καλύπτει: (α) συγκεκριμένα επιλεγμένα άτομα
# μαζί, ή (β) μια μόνιμη συνομιλία για όλη μια ομάδα (related_team_id).
# ---------------------------------------------------------------------------
class GroupConversation(Base):
    __tablename__ = "group_conversations"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String, nullable=True)
    # Αν έχει τιμή, πρόκειται για τη "μόνιμη" ομαδική συνομιλία μιας
    # συγκεκριμένης ομάδας — το backend φροντίζει να υπάρχει μόνο μία ανά
    # ομάδα (έλεγχος πριν τη δημιουργία, βλ. get_or_create_team_group_chat
    # στο routers/group_messages.py). None για μια ελεύθερη ομαδική
    # συνομιλία με επιλεγμένα άτομα.
    related_team_id = Column(String, ForeignKey("teams.id"), nullable=True, index=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class GroupConversationParticipant(Base):
    __tablename__ = "group_conversation_participants"

    id = Column(String, primary_key=True, default=gen_uuid)
    group_conversation_id = Column(String, ForeignKey("group_conversations.id"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    joined_at = Column(DateTime, default=datetime.utcnow)
    # Πότε διάβασε τελευταία φορά ΑΥΤΟΣ ο συμμετέχων — σε αντίθεση με το
    # 1-προς-1 Message.read_at (ένα μοναδικό read state αρκεί εκεί, αφού
    # υπάρχουν μόνο 2 άτομα), εδώ κάθε συμμετέχων χρειάζεται το δικό του.
    last_read_at = Column(DateTime, nullable=True)


class GroupMessage(Base):
    __tablename__ = "group_messages"

    id = Column(String, primary_key=True, default=gen_uuid)
    group_conversation_id = Column(String, ForeignKey("group_conversations.id"), nullable=False, index=True)
    sender_id = Column(String, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Ετήσια ανανέωση σεζόν — κάθε 30 Ιουνίου ρωτάμε όσους έχουν σχέση με μια
# ομάδα (μέσω TeamAccessGrant ή ως παίκτης) αν θα συνεχίσουν την επόμενη
# σεζόν. 3 απαντήσεις: accepted | on_hold (με αιτιολογία, 30 μέρες προθεσμία
# και για τις 2 πλευρές) | released (ελεύθερος).
# ---------------------------------------------------------------------------
class RenewalRequest(Base):
    __tablename__ = "renewal_requests"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    current_season = Column(String, nullable=False)  # π.χ. "2025-2026"
    next_season = Column(String, nullable=False)  # π.χ. "2026-2027"
    # pending | accepted | on_hold | released
    status = Column(String, nullable=False, default="pending")
    hold_reason = Column(Text, nullable=True)
    hold_started_at = Column(DateTime, nullable=True)
    hold_deadline = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class ContractOffer(Base):
    """Πρόεδρος/Τεχνικός Διευθυντής στέλνει επίσημη προσφορά σε παίκτη —
    χρόνια συμβολαίου, οικονομικοί όροι, bonus/παροχές (π.χ. μετακινήσεις,
    σπίτι)."""

    __tablename__ = "contract_offers"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    sender_id = Column(String, ForeignKey("users.id"), nullable=False)
    player_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    years = Column(Integer, nullable=True)
    salary_details = Column(Text, nullable=True)
    bonus_details = Column(Text, nullable=True)
    status = Column(String, nullable=False, default="pending")  # pending | accepted | rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime, nullable=True)


class StaffAssignmentOffer(Base):
    """Πρόεδρος/Τεχνικός Διευθυντής προτείνει σε ΥΠΑΡΧΟΝ μέλος επιτελείου (ή
    ακόμα και σε παίκτη) όρους συνεργασίας — μπορεί να είναι: ανάληψη
    επιπλέον/νέας ομάδας, ανανέωση στην ίδια θέση για επόμενη σεζόν,
    καλύτερη προσφορά στην ίδια θέση φέτος, ή αναβάθμιση/αλλαγή σε άλλο
    ρόλο (π.χ. παίκτης -> Βοηθός Προπονητή, Προπονητής -> Τεχνικός
    Διευθυντής). Στην αποδοχή ενημερώνεται/δημιουργείται το TeamAccessGrant
    και, αν δόθηκε new_role, αλλάζει και ο ρόλος του λογαριασμού — πάντα με
    τη ρητή συναίνεση του παραλήπτη μέσω αποδοχής, ποτέ μονομερώς."""

    __tablename__ = "staff_assignment_offers"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    sender_id = Column(String, ForeignKey("users.id"), nullable=False)
    recipient_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    role_title = Column(String, nullable=True)
    new_role = Column(String, nullable=True)  # αν δίνεται, αλλάζει το User.role στην αποδοχή
    season = Column(String, nullable=True)
    incentive_details = Column(Text, nullable=True)
    message = Column(Text, nullable=True)
    status = Column(String, nullable=False, default="pending")  # pending | accepted | rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    responded_at = Column(DateTime, nullable=True)


class StaffEvaluation(Base):
    """Αξιολόγηση μέλους επιτελείου από την ηγεσία της ομάδας (Πρόεδρος/
    Τεχνικός Διευθυντής/Προπονητής, ανάλογα με την ιεραρχία). Κρατάμε
    ιστορικό — πολλαπλές αξιολογήσεις στον χρόνο, όχι μόνο η τελευταία."""

    __tablename__ = "staff_evaluations"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    staff_user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    evaluator_id = Column(String, ForeignKey("users.id"), nullable=False)
    rating = Column(Integer, nullable=False)  # 1-5
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class VerificationDocument(Base):
    """Έγγραφο που ανεβάζει ένας coach/technical director για να αυξήσει το
    επίπεδο επαλήθευσης (grey -> blue -> green). Εγκρίνεται από Admin/Super
    Admin — η πιστότητα δεν αυξάνεται αυτόματα μόνο επειδή κάτι ανέβηκε,
    ώστε να μην μπορεί κάποιος να "ξεγελάσει" το σύστημα ανεβάζοντας άσχετα
    αρχεία."""

    __tablename__ = "verification_documents"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    # id_document | coaching_license | reference_letter
    document_type = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    # Πραγματικός, server-verified τύπος αρχείου (βάσει magic bytes, ΠΟΤΕ
    # από το Content-Type header του client) — χρησιμοποιείται όταν
    # σερβίρεται το αρχείο, ώστε να μην μπορεί να "ξεγελαστεί" ο browser
    # να το ερμηνεύσει σαν κάτι άλλο (π.χ. HTML).
    content_type = Column(String, nullable=True)
    status = Column(String, nullable=False, default="pending")  # pending | approved | rejected
    rejection_reason = Column(Text, nullable=True)
    reviewed_by = Column(String, ForeignKey("users.id"), nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    # True όταν η έγκριση έγινε αυτόματα από το AI (π.χ. αναγνωρίστηκε
    # έγκυρο UEFA C/B/A/PRO πτυχίο προπονητικής με όνομα που ταιριάζει στον
    # λογαριασμό) — ΟΧΙ από ανθρώπινο Admin. reviewed_by παραμένει None σε
    # αυτή την περίπτωση.
    auto_verified = Column(Boolean, default=False)


# ---------------------------------------------------------------------------
# Συνδρομές Ακαδημιών — οικονομική/διοικητική διαχείριση παικτών ακαδημίας
# (εγγραφή, μηνιαία/ετήσια συνδρομή, ρουχισμός, ενημερώσεις γονέων).
# Διαχειρίζονται Πρόεδρος/Τεχνικός Διευθυντής/Προπονητής. Ευαίσθητα
# δεδομένα (τηλέφωνο γονέα, οικονομικά στοιχεία) — ορατά ΜΟΝΟ σε αυτούς
# τους ρόλους, ποτέ δημόσια ή σε Scouting Hub.
# ---------------------------------------------------------------------------
class AcademyFeeSettings(Base):
    """Ρυθμίσεις συνδρομών ΜΙΑΣ ομάδας ακαδημίας — τιμές, προθεσμία
    πληρωμής μηνιαίας δόσης."""

    __tablename__ = "academy_fee_settings"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, unique=True, index=True)
    monthly_fee = Column(Float, nullable=True)
    annual_fee = Column(Float, nullable=True)
    registration_fee = Column(Float, nullable=True)
    # Μέχρι πόσο του μήνα πρέπει να γίνει η πληρωμή της δόσης (π.χ. 10)
    payment_due_day = Column(Integer, nullable=False, default=10)
    # Πρότυπο ρουχισμού της ομάδας — comma-separated είδη (π.χ.
    # "Φανέλα,Σορτς,Κάλτσες,Φόρμα") — εφαρμόζεται με ένα κλικ σε όλο το
    # ρόστερ, ώστε να μη γράφεται το ίδιο όνομα είδους παίκτη-παίκτη.
    kit_template = Column(String, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AcademyPlayerAccount(Base):
    """Οικονομικό/διοικητικό προφίλ ενός παίκτη ακαδημίας — τύπος
    συνδρομής, στοιχεία επικοινωνίας γονέα, ημερομηνία εγγραφής (βάση για
    υπολογισμό οφειλών)."""

    __tablename__ = "academy_player_accounts"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, unique=True, index=True)
    plan_type = Column(String, nullable=False, default="monthly")  # monthly | annual
    parent_name = Column(String, nullable=True)
    parent_phone = Column(String, nullable=True)
    enrollment_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AcademyPayment(Base):
    """Καταγραφή μιας πληρωμής — μηνιαία δόση συγκεκριμένου μήνα, ετήσιο
    πακέτο, ή εγγραφή. Πλήρες ιστορικό/λογιστήριο, όχι απλά flag, ώστε να
    υπάρχει πλήρης διαφάνεια."""

    __tablename__ = "academy_payments"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, index=True)
    payment_type = Column(String, nullable=False)  # monthly | annual | registration
    period_year = Column(Integer, nullable=True)
    period_month = Column(Integer, nullable=True)  # 1-12, μόνο για monthly
    amount = Column(Float, nullable=False)
    paid_date = Column(Date, nullable=False, default=date.today)
    recorded_by = Column(String, ForeignKey("users.id"), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AcademyKitItem(Base):
    """Ένα είδος ρουχισμού που πρέπει να παραλάβει ο παίκτης (φανέλα,
    σορτς, κάλτσες, φόρμα κ.λπ.) — παραλαβή και πληρωμή παρακολουθούνται
    ξεχωριστά, ανά είδος."""

    __tablename__ = "academy_kit_items"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, index=True)
    item_name = Column(String, nullable=False)
    received = Column(Boolean, default=False)
    paid = Column(Boolean, default=False)
    price = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AcademyAnnouncement(Base):
    """Ενημέρωση προς τους γονείς μιας ομάδας ακαδημίας — π.χ. εκδήλωση ή
    αγώνας, με τοποθεσία (σύνδεσμος Google Maps)."""

    __tablename__ = "academy_announcements"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    event_date = Column(Date, nullable=True)
    event_time = Column(String, nullable=True)
    location_name = Column(String, nullable=True)
    location_maps_url = Column(String, nullable=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# CRM — εσωτερικό directory επαφών + θέματα/προβλήματα προς συζήτηση
# (τεχνικά προβλήματα γηπέδου, θέματα με γονείς, εκδηλώσεις κ.λπ.)
# ---------------------------------------------------------------------------
class CrmTopic(Base):
    """Ένα θέμα/πρόβλημα/ανακοίνωση που δημιουργεί μέλος του επιτελείου —
    με προτεραιότητα, κατηγορία, προαιρετική προθεσμία λήξης, και κύκλο
    ζωής (open -> in_progress -> resolved). Σκοπίμως δεμένο σε ΜΙΑ ομάδα
    (team_id) ώστε να ισχύει το ίδιο μοντέλο απομόνωσης δεδομένων με όλη
    την υπόλοιπη εφαρμογή — ορατό σε όποιον έχει πρόσβαση σε αυτή την
    ομάδα."""

    __tablename__ = "crm_topics"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String, nullable=False, default="general")  # general|stadium|parents|event|other
    priority = Column(String, nullable=False, default="normal")  # urgent|normal|low
    status = Column(String, nullable=False, default="open")  # open|in_progress|resolved
    expires_at = Column(DateTime, nullable=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)


class CrmTopicComment(Base):
    """Σχόλιο/απάντηση πάνω σε ένα CrmTopic — απλό thread συζήτησης."""

    __tablename__ = "crm_topic_comments"

    id = Column(String, primary_key=True, default=gen_uuid)
    topic_id = Column(String, ForeignKey("crm_topics.id"), nullable=False, index=True)
    author_id = Column(String, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class AppSetting(Base):
    """Απλό key-value store για ρυθμίσεις που αλλάζουν από το UI (π.χ. AI config)
    χωρίς να χρειάζεται επεξεργασία του .env."""

    __tablename__ = "app_settings"

    key = Column(String, primary_key=True)
    value = Column(Text, nullable=True)


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------
class Team(Base):
    __tablename__ = "teams"

    id = Column(String, primary_key=True, default=gen_uuid)
    owner_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    name = Column(String, nullable=False, index=True)
    logo_path = Column(String, nullable=True)
    category = Column(String, nullable=True)  # π.χ. Ανδρικό, Ακαδημία
    division = Column(String, nullable=True)
    league = Column(String, nullable=True)
    season = Column(String, nullable=True)  # π.χ. "2025-2026"
    description = Column(Text, nullable=True)
    home_stadium = Column(String, nullable=True)
    primary_color = Column(String, nullable=True)  # hex
    secondary_color = Column(String, nullable=True)  # hex
    coach_name = Column(String, nullable=True)
    notes = Column(Text, nullable=True)

    # --- Scouting Hub ---------------------------------------------------------
    country_id = Column(String, ForeignKey("countries.id"), nullable=True, index=True)
    federation_id = Column(String, ForeignKey("federations.id"), nullable=True, index=True)
    league_level_id = Column(String, ForeignKey("league_levels.id"), nullable=True, index=True)
    league_group_id = Column(String, ForeignKey("league_groups.id"), nullable=True, index=True)
    # top_division | second_division | third_division | regional | u19
    league_tier = Column(String, nullable=False, default="regional")
    # Μόνο για ομάδες σε top_division/second_division/third_division: αν η
    # ομάδα είναι η ίδια η ανδρική (πρώτη) ομάδα του συλλόγου, μένει NULL.
    # Αν είναι ακαδημία του ΙΔΙΟΥ συλλόγου, κρατάει την ηλικιακή κατηγορία
    # (π.χ. "K19", "K17", ..., "K5") — έτσι μια ακαδημία μεγάλου συλλόγου
    # παραμένει συνδεδεμένη με το εθνικό επίπεδο του πρώτου συγκροτήματος,
    # ξεχωριστά από τις ανεξάρτητες ακαδημίες (league_tier="academy").
    academy_age_group = Column(String, nullable=True)
    is_public_scouting = Column(Boolean, default=True)

    # --- Δημόσια Σελίδα Ομάδας (Club Page) -------------------------------------
    is_publicly_shared = Column(Boolean, default=False)
    public_slug = Column(String, unique=True, nullable=True, index=True)
    public_show_roster = Column(Boolean, default=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    player_links = relationship(
        "PlayerTeamHistory", back_populates="team", cascade="all, delete-orphan"
    )
    trainings = relationship("TrainingSession", back_populates="team", cascade="all, delete-orphan")
    home_matches = relationship(
        "Match", back_populates="home_team", foreign_keys="Match.home_team_id"
    )
    away_matches = relationship(
        "Match", back_populates="away_team", foreign_keys="Match.away_team_id"
    )


# ---------------------------------------------------------------------------
# Scouting Hub — Χώρα / Περιφέρεια / ΕΠΣ ιεραρχία
# ---------------------------------------------------------------------------
class Country(Base):
    __tablename__ = "countries"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String, nullable=False, unique=True)
    code = Column(String, nullable=True)  # π.χ. "GR"


class Region(Base):
    """13 επίσημες Περιφέρειες Ελλάδας (ή ισοδύναμο διοικητικό επίπεδο άλλης χώρας)."""

    __tablename__ = "regions"

    id = Column(String, primary_key=True, default=gen_uuid)
    country_id = Column(String, ForeignKey("countries.id"), nullable=False, index=True)
    name = Column(String, nullable=False)


class Federation(Base):
    """ΕΠΣ — Ένωση Ποδοσφαιρικών Σωματείων (τοπική ομοσπονδία)."""

    __tablename__ = "federations"

    id = Column(String, primary_key=True, default=gen_uuid)
    region_id = Column(String, ForeignKey("regions.id"), nullable=False, index=True)
    name = Column(String, nullable=False)


class LeagueLevel(Base):
    """Επίπεδο πρωταθλήματος ΕΝΤΟΣ μιας ΕΠΣ — π.χ. Α1, Α' Ερασιτεχνική, Β'
    Ερασιτεχνική, Γ' Ερασιτεχνική (ή, για ακαδημίες, Κ8/Κ10/.../Κ19). Κάθε
    ΕΠΣ ορίζει τα δικά της επίπεδα — δεν είναι ίδια πανελλαδικά. Ο αριθμός
    ομίλων ανά επίπεδο αλλάζει κάθε σεζόν με απόφαση της κάθε ΕΠΣ, γι' αυτό
    διαχειρίζεται ρητά (δεν είναι σκληρά κωδικοποιημένος)."""

    __tablename__ = "league_levels"

    id = Column(String, primary_key=True, default=gen_uuid)
    federation_id = Column(String, ForeignKey("federations.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    order_index = Column(Integer, nullable=False, default=0)
    applies_to = Column(String, nullable=False, default="regional")  # regional | academy


class LeagueGroup(Base):
    """Όμιλος εντός ενός επιπέδου — π.χ. "1ος Όμιλος", "2ος Όμιλος"."""

    __tablename__ = "league_groups"

    id = Column(String, primary_key=True, default=gen_uuid)
    league_level_id = Column(String, ForeignKey("league_levels.id"), nullable=False, index=True)
    name = Column(String, nullable=False)


# ---------------------------------------------------------------------------
# Scouting shortlist — προσωπική λίστα παρακολούθησης ανά χρήστη
# ---------------------------------------------------------------------------
class ScoutingShortlistItem(Base):
    __tablename__ = "scouting_shortlist"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Scout Reports — αναλυτικές αναφορές παρατήρησης παικτών (δικών μας ή
# αντιπάλων/υποψήφιων μεταγραφών). Ελεύθερο κείμενο στα βασικά στοιχεία,
# ώστε ένας scout να μπορεί να καταγράψει ΟΠΟΙΟΝΔΗΠΟΤΕ παίκτη — ακόμα κι αν
# δεν υπάρχει ήδη στη βάση κάποιας ομάδας.
# ---------------------------------------------------------------------------
class ScoutReport(Base):
    __tablename__ = "scout_reports"

    id = Column(String, primary_key=True, default=gen_uuid)

    # --- Βασικά στοιχεία παίκτη ---
    full_name = Column(String, nullable=False)
    club_name = Column(String, nullable=True)
    age = Column(Integer, nullable=True)
    position = Column(String, nullable=True)  # GK/CB/LB/RB/LWB/RWB/DM/CM/AM/LW/RW/ST
    role = Column(String, nullable=True)
    league = Column(String, nullable=True)
    jersey_number = Column(Integer, nullable=True)
    nationality = Column(String, nullable=True)
    strong_foot = Column(String, nullable=True)  # right | left | both
    goals_per_season = Column(Integer, nullable=True)
    photo_path = Column(String, nullable=True)

    # --- Star-rated ενότητες (1-5) ---
    positive_rating = Column(Integer, nullable=True)
    positive_notes = Column(Text, nullable=True)
    negative_rating = Column(Integer, nullable=True)
    negative_notes = Column(Text, nullable=True)
    physical_mental_rating = Column(Integer, nullable=True)
    physical_mental_notes = Column(Text, nullable=True)

    # --- Αναλυτικά χαρακτηριστικά ανά κατηγορία θέσης (1-10 έκαστο) —
    # αποθηκεύονται ως JSON string, μιας που το σύνολο των χαρακτηριστικών
    # διαφέρει ανά κατηγορία (τερματοφύλακας/αμυντικός/μέσος/επιθετικός).
    detailed_attributes = Column(Text, nullable=True)

    # --- Συμπέρασμα ---
    conclusion_text = Column(Text, nullable=True)
    recommended = Column(Boolean, nullable=True)
    potential_rating = Column(Integer, nullable=True)  # 1-10

    # --- Μεταδεδομένα ---
    team_id = Column(String, ForeignKey("teams.id"), nullable=True, index=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # --- Δημόσια κοινοποίηση (χωρίς login, ακόμα και σε εξωτερικό άτομο) ---
    is_publicly_shared = Column(Boolean, default=False)
    public_slug = Column(String, unique=True, nullable=True, index=True)


class ScoutReportShortlistItem(Base):
    """«Η λίστα μου» — προσωπική συλλογή scout reports ανά χρήστη (μπορεί
    να περιλαμβάνει reports που έφτιαξε ο ίδιος ή reports άλλων scouts που
    θέλει να παρακολουθεί)."""

    __tablename__ = "scout_report_shortlist_items"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    scout_report_id = Column(String, ForeignKey("scout_reports.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Video Editing — ανέβασμα αγωνιστικού βίντεο (έως 15') και ανάλυση πάνω σε
# αυτό (κύκλοι, βέλη, φωταγώγηση κ.λπ.) σαν το Hudl Studio.
#
# ΣΗΜΑΝΤΙΚΟ: τα ίδια τα video bytes ΔΕΝ αποθηκεύονται ποτέ στη βάση μας ούτε
# μόνιμα στον δικό μας δίσκο — μόνο ένα «storage_key» αναφοράς προς ένα
# S3-συμβατό 3ο πρόγραμμα αποθήκευσης (AWS S3, Cloudflare R2, Backblaze B2,
# MinIO κ.λπ., ρυθμιζόμενο από τον admin στις Ρυθμίσεις — ίδιο μοτίβο με το
# AI Configuration). Το backend τα στέλνει εκεί σε ροή (streaming upload),
# χωρίς να τα γράφει ποτέ σε μόνιμο αρχείο ή στήλη της βάσης μας.
# ---------------------------------------------------------------------------
class VideoAnalysisStatus(str, enum.Enum):
    UPLOADING = "uploading"
    READY = "ready"
    FAILED = "failed"


class VideoAnalysis(Base):
    __tablename__ = "video_analyses"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    # Κλειδί αντικειμένου στο 3ο πρόγραμμα αποθήκευσης — ΠΟΤΕ τα ίδια τα
    # video bytes.
    storage_key = Column(String, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    file_size_bytes = Column(Integer, nullable=True)
    status = Column(String, nullable=False, default=VideoAnalysisStatus.UPLOADING.value)
    uploaded_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class VideoAnnotation(Base):
    """Μία σχεδιαστική σημείωση (κύκλος/βέλος/γραμμή/ορθογώνιο/ελεύθερο
    σχέδιο/φωταγώγηση/κείμενο) πάνω στο βίντεο, ορατή μόνο στο χρονικό
    παράθυρο [start_time, end_time] (δευτερόλεπτα) — telestrator-style."""

    __tablename__ = "video_annotations"

    id = Column(String, primary_key=True, default=gen_uuid)
    video_id = Column(String, ForeignKey("video_analyses.id"), nullable=False, index=True)
    shape_type = Column(String, nullable=False)  # circle|arrow|line|rectangle|freehand|spotlight|text
    shape_data = Column(Text, nullable=False)  # JSON: σημεία, χρώμα, πάχος γραμμής, κείμενο κ.λπ.
    start_time = Column(Float, nullable=False)
    end_time = Column(Float, nullable=False)
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Ασφάλεια — αυτόματη ανίχνευση & μπλοκάρισμα κακόβουλης δραστηριότητας
# (SQL injection, XSS, γνωστά εργαλεία επίθεσης, rate limiting, αποτυχημένα
# logins) — βλ. app/middleware/security_middleware.py και
# app/services/security_service.py.
# ---------------------------------------------------------------------------
class BannedIP(Base):
    __tablename__ = "banned_ips"

    id = Column(String, primary_key=True, default=gen_uuid)
    ip_address = Column(String, nullable=False, unique=True, index=True)
    reason = Column(String, nullable=False)
    strike_count = Column(Integer, nullable=False, default=1)
    is_permanent = Column(Boolean, nullable=False, default=False)
    banned_at = Column(DateTime, default=datetime.utcnow)
    banned_until = Column(DateTime, nullable=True)  # None + is_permanent=False -> ήδη λήξει, καθαρίζεται
    banned_by = Column(String, ForeignKey("users.id"), nullable=True)  # None = αυτόματο μπλοκάρισμα


class SecurityEvent(Base):
    """Καταγραφή ύποπτης δραστηριότητας — κάθε φορά που ανιχνεύεται κάτι
    (πριν ή ανεξάρτητα από το αν οδήγησε τελικά σε μπλοκάρισμα)."""

    __tablename__ = "security_events"

    id = Column(String, primary_key=True, default=gen_uuid)
    ip_address = Column(String, nullable=False, index=True)
    event_type = Column(String, nullable=False)
    # sql_injection_attempt | xss_attempt | path_traversal_attempt |
    # known_attack_tool | rate_limit_exceeded | failed_login
    detail = Column(Text, nullable=True)
    endpoint = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class LoginAttempt(Base):
    __tablename__ = "login_attempts"

    id = Column(String, primary_key=True, default=gen_uuid)
    ip_address = Column(String, nullable=False, index=True)
    username_attempted = Column(String, nullable=True)
    success = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# Players
# ---------------------------------------------------------------------------
class Player(Base):
    __tablename__ = "players"

    id = Column(String, primary_key=True, default=gen_uuid)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    photo_path = Column(String, nullable=True)
    date_of_birth = Column(Date, nullable=True)
    nationality = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    email = Column(String, nullable=True)
    player_number = Column(Integer, nullable=True)
    preferred_foot = Column(Enum(PreferredFoot), nullable=True)
    height_cm = Column(Float, nullable=True)
    weight_kg = Column(Float, nullable=True)
    position = Column(Enum(PlayerPosition), nullable=True)
    secondary_position = Column(Enum(PlayerPosition), nullable=True)

    # Football info
    current_team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    contract_notes = Column(Text, nullable=True)
    status = Column(Enum(PlayerStatus), default=PlayerStatus.FIT)
    availability_notes = Column(Text, nullable=True)

    # Medical / injury (current snapshot; full history in Injury table)
    injury_status = Column(String, nullable=True)
    injury_type = Column(String, nullable=True)
    injury_date = Column(Date, nullable=True)
    expected_return = Column(Date, nullable=True)
    medical_notes = Column(Text, nullable=True)

    # --- Scouting Hub: transfer market status ------------------------------
    # not_listed | free_agent | for_transfer | loan_listed
    transfer_status = Column(String, nullable=False, default="not_listed")
    transfer_notes = Column(Text, nullable=True)
    # Self-service rate limit (μέχρι 3 αλλαγές ανά ομάδα/σεζόν από τον ίδιο τον παίκτη)
    transfer_status_change_count = Column(Integer, default=0)
    transfer_status_season_key = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    current_team = relationship("Team", foreign_keys=[current_team_id])
    team_history = relationship(
        "PlayerTeamHistory", back_populates="player", cascade="all, delete-orphan"
    )
    statistics = relationship(
        "PlayerStatistics", back_populates="player", cascade="all, delete-orphan"
    )
    injuries = relationship("Injury", back_populates="player", cascade="all, delete-orphan")
    attendances = relationship(
        "TrainingAttendance", back_populates="player", cascade="all, delete-orphan"
    )
    match_performances = relationship(
        "MatchPlayer", back_populates="player", cascade="all, delete-orphan"
    )


class PlayerAttributes(Base):
    """FM-style βαθμολόγηση παίκτη από τον προπονητή, 1.0-10.0 ανά χαρακτηριστικό."""

    __tablename__ = "player_attributes"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, unique=True, index=True)
    potential = Column(Float, nullable=True)
    passing = Column(Float, nullable=True)
    shooting = Column(Float, nullable=True)
    dribbling = Column(Float, nullable=True)
    defending = Column(Float, nullable=True)
    attacking = Column(Float, nullable=True)
    physical = Column(Float, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PlayerTeamHistory(Base):
    """Ιστορικό ομάδων ενός παίκτη (προηγούμενες + τρέχουσα ομάδα)."""

    __tablename__ = "player_team_history"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False)
    joined_date = Column(Date, nullable=True)
    left_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)

    player = relationship("Player", back_populates="team_history")
    team = relationship("Team", back_populates="player_links")


# ---------------------------------------------------------------------------
# Player statistics (aggregated, manually editable, per season/team)
# ---------------------------------------------------------------------------
class PlayerStatistics(Base):
    __tablename__ = "player_statistics"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    season = Column(String, nullable=True)

    matches_played = Column(Integer, default=0)
    starts = Column(Integer, default=0)
    substitute_appearances = Column(Integer, default=0)
    minutes_played = Column(Integer, default=0)
    goals = Column(Integer, default=0)
    assists = Column(Integer, default=0)
    yellow_cards = Column(Integer, default=0)
    red_cards = Column(Integer, default=0)
    fouls_committed = Column(Integer, default=0)
    fouls_suffered = Column(Integer, default=0)
    shots = Column(Integer, default=0)
    shots_on_target = Column(Integer, default=0)
    passes = Column(Integer, default=0)
    tackles = Column(Integer, default=0)
    interceptions = Column(Integer, default=0)
    clearances = Column(Integer, default=0)
    saves = Column(Integer, default=0)
    clean_sheets = Column(Integer, default=0)

    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    player = relationship("Player", back_populates="statistics")


# ---------------------------------------------------------------------------
# Injuries (full history, separate from Player's current snapshot)
# ---------------------------------------------------------------------------
class Injury(Base):
    __tablename__ = "injuries"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    injury_type = Column(String, nullable=True)
    status = Column(Enum(InjuryStatus), default=InjuryStatus.ACTIVE)
    injury_date = Column(Date, nullable=True)
    expected_return = Column(Date, nullable=True)
    actual_return = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    player = relationship("Player", back_populates="injuries")


class AbsenceReason(str, enum.Enum):
    """Λόγος απουσίας παίκτη — ΟΛΟΙ οι λόγοι εκτός από ιατρικό τραυματισμό
    (αυτός καταγράφεται στο ξεχωριστό, πιο λεπτομερές μοντέλο Injury, με
    δικό του ιατρικό ιστορικό/expected return). Η ενότητα "Τραυματισμοί /
    Απουσίες" συνδυάζει ΚΑΙ τα δύο μοντέλα σε ενιαία, χρονολογική προβολή."""

    RED_CARD = "red_card"
    SUSPENSION = "suspension"
    TRAVEL = "travel"
    UNEXCUSED = "unexcused"
    TUTORING = "tutoring"
    ILLNESS = "illness"
    PERSONAL = "personal"
    FAMILY = "family"
    SCHOOL = "school"
    MILITARY = "military"
    NATIONAL_TEAM = "national_team"
    OTHER = "other"


class PlayerAbsence(Base):
    """Ενοποιημένο ημερολόγιο απουσιών παίκτη — κόκκινη κάρτα/ποινή,
    ταξίδι, αδικαιολόγητος, φροντιστήριο, ασθένεια, προσωπικοί/οικογενειακοί
    λόγοι, σχολικές/στρατιωτικές υποχρεώσεις, εθνική ομάδα, ή άλλο. Μόνο
    Πρόεδρος/Τεχνικός Διευθυντής/Head Coach μπορούν να δημιουργήσουν/
    επεξεργαστούν/διαγράψουν (βλ. permissions.require_absence_editor)."""

    __tablename__ = "player_absences"

    id = Column(String, primary_key=True, default=gen_uuid)
    player_id = Column(String, ForeignKey("players.id"), nullable=False, index=True)
    team_id = Column(String, ForeignKey("teams.id"), nullable=True, index=True)
    reason = Column(String, nullable=False)  # AbsenceReason value
    start_date = Column(Date, nullable=False)
    # None = εν εξελίξει/αόριστης διάρκειας απουσία (π.χ. αδικαιολόγητος
    # χωρίς γνωστή επιστροφή).
    end_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    player = relationship("Player")
    team = relationship("Team")


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------
class TrainingSession(Base):
    __tablename__ = "training_sessions"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=False)
    date = Column(Date, nullable=False)
    time = Column(String, nullable=True)
    location = Column(String, nullable=True)
    training_type = Column(String, nullable=True)
    duration_minutes = Column(Integer, nullable=True)
    objectives = Column(Text, nullable=True)
    exercises = Column(Text, nullable=True)
    coach_notes = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    team = relationship("Team", back_populates="trainings")
    attendances = relationship(
        "TrainingAttendance", back_populates="session", cascade="all, delete-orphan"
    )


class TrainingAttendance(Base):
    __tablename__ = "training_attendance"

    id = Column(String, primary_key=True, default=gen_uuid)
    session_id = Column(String, ForeignKey("training_sessions.id"), nullable=False)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    status = Column(Enum(AttendanceStatus), default=AttendanceStatus.PRESENT)
    notes = Column(String, nullable=True)

    session = relationship("TrainingSession", back_populates="attendances")
    player = relationship("Player", back_populates="attendances")


# ---------------------------------------------------------------------------
# Matches
# ---------------------------------------------------------------------------
class Match(Base):
    __tablename__ = "matches"

    id = Column(String, primary_key=True, default=gen_uuid)
    home_team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    away_team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    home_team_name_external = Column(String, nullable=True)  # για αντίπαλο εκτός συστήματος
    away_team_name_external = Column(String, nullable=True)
    date = Column(Date, nullable=False)
    time = Column(String, nullable=True)
    stadium = Column(String, nullable=True)
    competition = Column(String, nullable=True)
    season = Column(String, nullable=True)
    home_score = Column(Integer, nullable=True)
    away_score = Column(Integer, nullable=True)
    half_time_home_score = Column(Integer, nullable=True)
    half_time_away_score = Column(Integer, nullable=True)
    status = Column(Enum(MatchStatus), default=MatchStatus.SCHEDULED)

    # Match report free-text fields
    team_performance_notes = Column(Text, nullable=True)
    opponent_analysis = Column(Text, nullable=True)
    coach_notes = Column(Text, nullable=True)
    general_description = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    home_team = relationship("Team", foreign_keys=[home_team_id], back_populates="home_matches")
    away_team = relationship("Team", foreign_keys=[away_team_id], back_populates="away_matches")
    player_performances = relationship(
        "MatchPlayer", back_populates="match", cascade="all, delete-orphan"
    )
    tactical_boards = relationship(
        "TacticalBoard", back_populates="match", cascade="all, delete-orphan"
    )
    player_movements = relationship(
        "PlayerMovement", back_populates="match", cascade="all, delete-orphan"
    )
    ai_reports = relationship("AIReport", back_populates="match", cascade="all, delete-orphan")


class MatchPlayer(Base):
    """Player match performance (starting XI/sub, minutes, goals, rating, notes)."""

    __tablename__ = "match_players"

    id = Column(String, primary_key=True, default=gen_uuid)
    match_id = Column(String, ForeignKey("matches.id"), nullable=False)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    is_starting = Column(Boolean, default=False)
    position_played = Column(Enum(PlayerPosition), nullable=True)
    minutes_played = Column(Integer, nullable=True)
    goals = Column(Integer, default=0)
    assists = Column(Integer, default=0)
    yellow_cards = Column(Integer, default=0)
    red_cards = Column(Integer, default=0)
    fouls = Column(Integer, default=0)
    rating = Column(Float, nullable=True)
    coach_rating = Column(Float, nullable=True)
    is_mvp = Column(Boolean, default=False)
    notes = Column(Text, nullable=True)

    match = relationship("Match", back_populates="player_performances")
    player = relationship("Player", back_populates="match_performances")


# ---------------------------------------------------------------------------
# Tactical board / pitch / player movement analysis
# ---------------------------------------------------------------------------
class TacticalBoard(Base):
    """Αποθηκευμένο tactical setup: formation + starting XI ή free scenario."""

    __tablename__ = "tactical_boards"

    id = Column(String, primary_key=True, default=gen_uuid)
    team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    match_id = Column(String, ForeignKey("matches.id"), nullable=True)
    training_session_id = Column(String, ForeignKey("training_sessions.id"), nullable=True)
    name = Column(String, nullable=False)
    formation = Column(String, nullable=True)  # π.χ. "4-3-3"
    scenario_type = Column(String, nullable=True)  # build-up, pressing, corner κλπ.
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    match = relationship("Match", back_populates="tactical_boards")
    objects = relationship(
        "TacticalObject", back_populates="board", cascade="all, delete-orphan"
    )


class TacticalObject(Base):
    """Ένα αντικείμενο πάνω στο tactical board: player marker, arrow, zone, text."""

    __tablename__ = "tactical_objects"

    id = Column(String, primary_key=True, default=gen_uuid)
    board_id = Column(String, ForeignKey("tactical_boards.id"), nullable=False)
    object_type = Column(String, nullable=False)  # player | arrow | line | zone | text
    player_id = Column(String, ForeignKey("players.id"), nullable=True)
    # Συντεταγμένες αποθηκεύονται ως JSON string (π.χ. [{"x":10,"y":20}, ...])
    coordinates_json = Column(Text, nullable=True)
    color = Column(String, nullable=True)
    label = Column(String, nullable=True)

    board = relationship("TacticalBoard", back_populates="objects")


class PlayerMovement(Base):
    """Καταγραφή κίνησης συγκεκριμένου παίκτη μέσα σε συγκεκριμένο αγώνα."""

    __tablename__ = "player_movements"

    id = Column(String, primary_key=True, default=gen_uuid)
    match_id = Column(String, ForeignKey("matches.id"), nullable=False)
    player_id = Column(String, ForeignKey("players.id"), nullable=False)
    movement_type = Column(String, nullable=True)  # defensive, offensive, pressing, overlap...
    path_json = Column(Text, nullable=True)  # λίστα σημείων [{"x":..,"y":..}]
    description = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    match = relationship("Match", back_populates="player_movements")


# ---------------------------------------------------------------------------
# Notifications & Calendar
# ---------------------------------------------------------------------------
class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    type = Column(Enum(NotificationType), nullable=False)
    title = Column(String, nullable=False)
    message = Column(Text, nullable=True)
    is_read = Column(Boolean, default=False)
    related_entity_type = Column(String, nullable=True)  # "match" | "player" | ...
    related_entity_id = Column(String, nullable=True)
    # Επιτρέπει στο frontend να πλοηγηθεί απευθείας στη σχετική ομάδα όταν
    # γίνεται κλικ στην ειδοποίηση (π.χ. νέα αίτηση σε αγγελία).
    related_team_id = Column(String, ForeignKey("teams.id"), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)


class CalendarEvent(Base):
    __tablename__ = "calendar_events"

    id = Column(String, primary_key=True, default=gen_uuid)
    title = Column(String, nullable=False)
    event_type = Column(String, nullable=False)  # match | training | injury | other
    date = Column(Date, nullable=False)
    time = Column(String, nullable=True)
    team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    related_entity_type = Column(String, nullable=True)
    related_entity_id = Column(String, nullable=True)
    notes = Column(Text, nullable=True)


# ---------------------------------------------------------------------------
# AI reports, documents, media
# ---------------------------------------------------------------------------
class AIReport(Base):
    __tablename__ = "ai_reports"

    id = Column(String, primary_key=True, default=gen_uuid)
    report_type = Column(String, nullable=False)  # match_summary | player_analysis | ...
    match_id = Column(String, ForeignKey("matches.id"), nullable=True)
    player_id = Column(String, ForeignKey("players.id"), nullable=True)
    team_id = Column(String, ForeignKey("teams.id"), nullable=True)
    content = Column(Text, nullable=False)
    model_used = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    match = relationship("Match", back_populates="ai_reports")


class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=gen_uuid)
    title = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    document_type = Column(String, nullable=True)  # match_document | pdf_report | other
    related_entity_type = Column(String, nullable=True)
    related_entity_id = Column(String, nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)


class MediaFile(Base):
    __tablename__ = "media_files"

    id = Column(String, primary_key=True, default=gen_uuid)
    file_path = Column(String, nullable=False)
    file_type = Column(String, nullable=True)  # image | document
    related_entity_type = Column(String, nullable=True)  # player | team
    related_entity_id = Column(String, nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
