from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import FRONTEND_ORIGIN, STORAGE_DIR
from app.database import Base, SessionLocal, engine, run_light_migrations
from app.middleware.security_middleware import SecurityMiddleware
from app.routers import (
    academy,
    absences,
    auth,
    backup,
    calendar,
    contracts,
    crm,
    dashboard,
    group_messages,
    listings,
    matches,
    melie,
    messages,
    notifications,
    performance,
    players,
    profile,
    public,
    renewals,
    reports,
    requests,
    scouting,
    scout_reports,
    security,
    settings,
    staff,
    staff_offers,
    tactical,
    teams,
    trainings,
    verification,
    video_analysis,
)
from app.services.scouting_seed import ensure_greek_hierarchy

# Δημιουργεί όλους τους πίνακες αν δεν υπάρχουν ήδη (dev convenience).
# Σε production προτιμήστε Alembic migrations.
Base.metadata.create_all(bind=engine)
run_light_migrations()

_seed_db = SessionLocal()
try:
    ensure_greek_hierarchy(_seed_db)
finally:
    _seed_db.close()

app = FastAPI(
    title="FootballHub API",
    description="Football Manager & Analysis Platform – REST API",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN, "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Προστίθεται ΜΕΤΑ το CORS ώστε να εκτελείται ΠΡΩΤΟ σε κάθε request
# (Starlette: το τελευταίο add_middleware είναι το πιο εξωτερικό) — ένας
# μπλοκαρισμένος επιτιθέμενος δεν πρέπει να φτάνει καν στο CORS handling.
app.add_middleware(SecurityMiddleware)

app.mount("/media", StaticFiles(directory=str(STORAGE_DIR)), name="media")

app.include_router(auth.router)
app.include_router(teams.router)
app.include_router(players.router)
app.include_router(trainings.router)
app.include_router(matches.router)
app.include_router(calendar.router)
app.include_router(tactical.router)
app.include_router(notifications.router)
app.include_router(reports.router)
app.include_router(performance.router)
app.include_router(settings.router)
app.include_router(backup.router)
app.include_router(scouting.router)
app.include_router(public.router)
app.include_router(profile.router)
app.include_router(requests.router)
app.include_router(listings.router)
app.include_router(messages.router)
app.include_router(group_messages.router)
app.include_router(renewals.router)
app.include_router(contracts.router)
app.include_router(verification.router)
app.include_router(staff.router)
app.include_router(staff_offers.router)
app.include_router(academy.router)
app.include_router(crm.router)
app.include_router(dashboard.router)
app.include_router(melie.router)
app.include_router(absences.router)
app.include_router(scout_reports.router)
app.include_router(video_analysis.router)
app.include_router(security.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}
