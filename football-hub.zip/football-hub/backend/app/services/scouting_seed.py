"""
Seed δεδομένα αναφοράς για το Scouting Hub: Ελλάδα -> 13 Περιφέρειες ->
~51 ΕΠΣ (Ενώσεις Ποδοσφαιρικών Σωματείων). Τρέχει αυτόματα στο startup του
backend (idempotent — αν υπάρχει ήδη η Ελλάδα, δεν κάνει τίποτα).
"""
from sqlalchemy.orm import Session

from app.models import Country, Federation, LeagueGroup, LeagueLevel, Region

GREECE_HIERARCHY = {
    "Αττική": [
        "ΕΠΣ Αθηνών",
        "ΕΠΣ Πειραιά",
        "ΕΠΣ Ανατολικής Αττικής",
        "ΕΠΣ Δυτικής Αττικής",
    ],
    "Κεντρική Μακεδονία": [
        "ΕΠΣ Μακεδονίας",
        "ΕΠΣ Ημαθίας",
        "ΕΠΣ Πέλλας",
        "ΕΠΣ Κιλκίς",
        "ΕΠΣ Σερρών",
        "ΕΠΣ Πιερίας",
        "ΕΠΣ Χαλκιδικής",
    ],
    "Ανατολική Μακεδονία και Θράκη": [
        "ΕΠΣ Δράμας",
        "ΕΠΣ Καβάλας",
        "ΕΠΣ Ξάνθης",
        "ΕΠΣ Ροδόπης",
        "ΕΠΣ Έβρου",
    ],
    "Δυτική Μακεδονία": [
        "ΕΠΣ Κοζάνης",
        "ΕΠΣ Καστοριάς",
        "ΕΠΣ Φλώρινας",
        "ΕΠΣ Γρεβενών",
    ],
    "Ήπειρος": [
        "ΕΠΣ Ιωαννίνων",
        "ΕΠΣ Άρτας",
        "ΕΠΣ Πρέβεζας-Λευκάδας",
        "ΕΠΣ Θεσπρωτίας",
    ],
    "Θεσσαλία": [
        "ΕΠΣ Λάρισας",
        "ΕΠΣ Τρικάλων",
        "ΕΠΣ Καρδίτσας",
        "ΕΠΣ Μαγνησίας",
    ],
    "Στερεά Ελλάδα": [
        "ΕΠΣ Φθιώτιδας",
        "ΕΠΣ Ευρυτανίας",
        "ΕΠΣ Βοιωτίας",
        "ΕΠΣ Εύβοιας",
        "ΕΠΣ Φωκίδας",
    ],
    "Δυτική Ελλάδα": [
        "ΕΠΣ Αιτωλοακαρνανίας",
        "ΕΠΣ Αχαΐας",
        "ΕΠΣ Ηλείας",
    ],
    "Πελοπόννησος": [
        "ΕΠΣ Κορινθίας",
        "ΕΠΣ Αργολίδας",
        "ΕΠΣ Αρκαδίας",
        "ΕΠΣ Μεσσηνίας",
        "ΕΠΣ Λακωνίας",
    ],
    "Ιόνια Νησιά": [
        "ΕΠΣ Ζακύνθου",
        "ΕΠΣ Κέρκυρας",
        "ΕΠΣ Κεφαλληνίας-Ιθάκης",
    ],
    "Βόρειο Αιγαίο": [
        "ΕΠΣ Σάμου",
        "ΕΠΣ Χίου",
        "ΕΠΣ Λέσβου",
    ],
    "Νότιο Αιγαίο": [
        "ΕΠΣ Κυκλάδων",
        "ΕΠΣ Δωδεκανήσου",
    ],
    "Κρήτη": [
        "ΕΠΣ Ηρακλείου",
        "ΕΠΣ Χανίων",
        "ΕΠΣ Ρεθύμνου",
        "ΕΠΣ Λασιθίου",
    ],
}

# Ηλικιακές κατηγορίες ακαδημιών — τυποποιημένες πανελλαδικά (ίδια δομή σε
# κάθε ΕΠΣ), γι' αυτό σπέρνονται αυτόματα για ΚΑΘΕ ΕΠΣ ώστε η πλοήγηση
# ακαδημιών να δουλεύει παντού εξ αρχής.
ACADEMY_AGE_LEVELS = ["Κ8", "Κ9", "Κ10", "Κ11", "Κ12", "Κ13", "Κ14", "Κ15", "Κ16", "Κ17"]

# 4 στάνταρ επίπεδα ερασιτεχνικού πρωταθλήματος — σπέρνονται σε ΚΑΘΕ ΕΠΣ ως
# σημείο εκκίνησης (τα ονόματα των επιπέδων είναι κοινά σε όλη τη χώρα).
# ΧΩΡΙΣ ομίλους από προεπιλογή — ο αριθμός ομίλων ανά επίπεδο διαφέρει ανά
# ΕΠΣ *και* αλλάζει κάθε σεζόν, οπότε δεν μπορεί να είναι σκληρά
# κωδικοποιημένος για τις ~51 ΕΠΣ. Οι διαχειριστές τους προσθέτουν από το
# Scouting Hub -> Διαχείριση.
STANDARD_REGIONAL_LEVEL_NAMES = ["Α1 Ερασιτεχνική", "Α' Ερασιτεχνική", "Β' Ερασιτεχνική", "Γ' Ερασιτεχνική"]

# Πλήρες, επιβεβαιωμένο παράδειγμα ομίλων — ΕΠΣ Μακεδονίας (Θεσσαλονίκη),
# βάσει της σεζόν 2024-2025 (epsm.gr).
EPSM_REGIONAL_GROUPS = {
    "Α1 Ερασιτεχνική": ["Ενιαίος Όμιλος"],
    "Α' Ερασιτεχνική": ["1ος Όμιλος", "2ος Όμιλος", "3ος Όμιλος"],
    "Β' Ερασιτεχνική": ["1ος Όμιλος", "2ος Όμιλος", "3ος Όμιλος"],
    "Γ' Ερασιτεχνική": ["1ος Όμιλος", "2ος Όμιλος", "3ος Όμιλος", "4ος Όμιλος", "5ος Όμιλος"],
}


def _seed_academy_levels(db: Session, federation: Federation) -> None:
    for idx, level_name in enumerate(ACADEMY_AGE_LEVELS):
        db.add(
            LeagueLevel(federation_id=federation.id, name=level_name, order_index=idx, applies_to="academy")
        )


def _seed_regional_levels(db: Session, federation: Federation) -> None:
    for idx, level_name in enumerate(STANDARD_REGIONAL_LEVEL_NAMES):
        level = LeagueLevel(federation_id=federation.id, name=level_name, order_index=idx, applies_to="regional")
        db.add(level)
        db.flush()
        if federation.name == "ΕΠΣ Μακεδονίας":
            for group_name in EPSM_REGIONAL_GROUPS.get(level_name, []):
                db.add(LeagueGroup(league_level_id=level.id, name=group_name))


def _seed_league_levels(db: Session, federation: Federation) -> None:
    _seed_academy_levels(db, federation)
    _seed_regional_levels(db, federation)


def _backfill_missing_academy_levels(db: Session, federation: Federation) -> bool:
    """Προσθέτει ΜΟΝΟ τα ονόματα κατηγοριών που λείπουν συγκεκριμένα από
    αυτή την ΕΠΣ — σωστά idempotent ανεξαρτήτως τι είχε ήδη σπαρθεί σε
    προηγούμενες εκδόσεις (π.χ. ΕΠΣ που είχε ήδη Κ8/Κ10/... θα πάρει τώρα
    και τα ενδιάμεσα Κ9/Κ11/... που προστέθηκαν αργότερα)."""
    existing = {
        row[0]
        for row in db.query(LeagueLevel.name)
        .filter(LeagueLevel.federation_id == federation.id, LeagueLevel.applies_to == "academy")
        .all()
    }
    missing = [name for name in ACADEMY_AGE_LEVELS if name not in existing]
    for name in missing:
        db.add(
            LeagueLevel(
                federation_id=federation.id,
                name=name,
                order_index=ACADEMY_AGE_LEVELS.index(name),
                applies_to="academy",
            )
        )
    return bool(missing)


def _backfill_missing_regional_levels(db: Session, federation: Federation) -> bool:
    existing = {
        row[0]
        for row in db.query(LeagueLevel.name)
        .filter(LeagueLevel.federation_id == federation.id, LeagueLevel.applies_to == "regional")
        .all()
    }
    missing = [name for name in STANDARD_REGIONAL_LEVEL_NAMES if name not in existing]
    for name in missing:
        level = LeagueLevel(
            federation_id=federation.id,
            name=name,
            order_index=STANDARD_REGIONAL_LEVEL_NAMES.index(name),
            applies_to="regional",
        )
        db.add(level)
        db.flush()
        if federation.name == "ΕΠΣ Μακεδονίας":
            for group_name in EPSM_REGIONAL_GROUPS.get(name, []):
                db.add(LeagueGroup(league_level_id=level.id, name=group_name))
    return bool(missing)


def ensure_greek_hierarchy(db: Session) -> None:
    from app.models import Team  # local import to avoid a circular import at module load time

    greece = db.query(Country).filter(Country.name == "Ελλάδα").first()

    if not greece:
        greece = Country(name="Ελλάδα", code="GR")
        db.add(greece)
        db.flush()

        for region_name, federation_names in GREECE_HIERARCHY.items():
            region = Region(country_id=greece.id, name=region_name)
            db.add(region)
            db.flush()
            for fed_name in federation_names:
                federation = Federation(region_id=region.id, name=fed_name)
                db.add(federation)
                db.flush()
                _seed_league_levels(db, federation)

        db.commit()

    # Backfill: προσθέτει σε ΚΑΘΕ ΕΠΣ ό,τι κατηγορίες/επίπεδα λείπουν
    # ΣΥΓΚΕΚΡΙΜΕΝΑ (όχι απλά "δεν έχει τίποτα") — καλύπτει εγκαταστάσεις
    # που είχαν ήδη σπαρμένη Ελλάδα πριν προστεθούν τα Επίπεδα/Όμιλοι, ΚΑΙ
    # εγκαταστάσεις που είχαν ήδη ένα παλιότερο, αραιότερο σετ ηλικιακών
    # κατηγοριών ακαδημίας.
    all_federations = db.query(Federation).all()
    changed = False
    for federation in all_federations:
        if _backfill_missing_academy_levels(db, federation):
            changed = True
        if _backfill_missing_regional_levels(db, federation):
            changed = True
    if changed:
        db.commit()

    # Καθαρισμός παλιωμένων ηλικιακών κατηγοριών ακαδημίας (η λίστα έγινε πιο
    # αναλυτική — Κ8 έως Κ17, ανά έτος — αντί για το αραιότερο πρώιμο σετ,
    # π.χ. το παλιό "Κ19" δεν υπάρχει πια). Αποσυνδέει πρώτα τυχόν ομάδες
    # που τα χρησιμοποιούν, για ασφάλεια.
    stale_levels = (
        db.query(LeagueLevel)
        .filter(LeagueLevel.applies_to == "academy", ~LeagueLevel.name.in_(ACADEMY_AGE_LEVELS))
        .all()
    )
    if stale_levels:
        stale_ids = [lvl.id for lvl in stale_levels]
        db.query(Team).filter(Team.league_level_id.in_(stale_ids)).update(
            {Team.league_level_id: None, Team.league_group_id: None}, synchronize_session=False
        )
        db.query(LeagueGroup).filter(LeagueGroup.league_level_id.in_(stale_ids)).delete(
            synchronize_session=False
        )
        for lvl in stale_levels:
            db.delete(lvl)
        db.commit()

    # Backfill: ομάδες που δημιουργήθηκαν πριν υπάρχει η επιλογή Χώρας (ή απλά
    # δεν ορίστηκε ρητά) δεν είχαν country_id — αυτό τις έκανε αόρατες στο
    # Scouting Hub, αφού η σελίδα φιλτράρει προεπιλεγμένα με "Ελλάδα". Τρέχει
    # σε ΚΑΘΕ εκκίνηση (όχι μόνο την πρώτη φορά), ώστε να καλύπτει και ομάδες
    # που δημιουργήθηκαν αργότερα χωρίς country_id.
    db.query(Team).filter(Team.country_id.is_(None)).update({Team.country_id: greece.id})
    db.commit()
