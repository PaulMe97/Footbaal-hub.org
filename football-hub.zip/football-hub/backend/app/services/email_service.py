"""
Αποστολή email (καλωσόρισμα κατά την εγγραφή, επαναφορά κωδικού) μέσω
SMTP — ρυθμίζεται από τον admin στις Ρυθμίσεις (ίδιο μοτίβο με AI/S3/
CAPTCHA config). Χρησιμοποιεί το built-in smtplib της Python — καμία
επιπλέον εξάρτηση.

Η αποστολή email είναι πάντα best-effort: ποτέ δεν σηκώνει exception προς
τα έξω, ώστε ένα πρόβλημα SMTP να μην μπλοκάρει ποτέ μια κύρια λειτουργία
όπως η εγγραφή.
"""
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from sqlalchemy.orm import Session

from app.services.settings_service import get_setting

logger = logging.getLogger(__name__)


def get_smtp_config(db: Session) -> dict:
    return {
        "host": get_setting(db, "smtp_host") or "",
        "port": get_setting(db, "smtp_port") or "587",
        "username": get_setting(db, "smtp_username") or "",
        "password": get_setting(db, "smtp_password") or "",
        "from_email": get_setting(db, "smtp_from_email") or "",
        "from_name": get_setting(db, "smtp_from_name") or "FootballHub",
    }


def is_configured(db: Session) -> bool:
    cfg = get_smtp_config(db)
    return bool(cfg["host"] and cfg["username"] and cfg["password"] and cfg["from_email"])


def send_email(db: Session, to_email: str, subject: str, html_body: str, text_body: str | None = None) -> bool:
    """Στέλνει ένα email. Επιστρέφει True/False — δεν σηκώνει exception."""
    if not is_configured(db):
        return False
    cfg = get_smtp_config(db)
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f'{cfg["from_name"]} <{cfg["from_email"]}>'
        msg["To"] = to_email
        if text_body:
            msg.attach(MIMEText(text_body, "plain", "utf-8"))
        msg.attach(MIMEText(html_body, "html", "utf-8"))

        port = int(cfg["port"])
        if port == 465:
            with smtplib.SMTP_SSL(cfg["host"], port, timeout=10) as server:
                server.login(cfg["username"], cfg["password"])
                server.sendmail(cfg["from_email"], [to_email], msg.as_string())
        else:
            with smtplib.SMTP(cfg["host"], port, timeout=10) as server:
                server.starttls()
                server.login(cfg["username"], cfg["password"])
                server.sendmail(cfg["from_email"], [to_email], msg.as_string())
        return True
    except Exception as exc:  # noqa: BLE001 — η αποστολή email είναι πάντα best-effort
        logger.warning("Αποτυχία αποστολής email σε %s: %s", to_email, exc)
        return False


def _wrap_html(inner_html: str) -> str:
    return f"""\
<!DOCTYPE html>
<html lang="el">
  <body style="margin:0;padding:0;background-color:#f4f4f5;font-family:Arial,Helvetica,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f5;padding:32px 0;">
      <tr>
        <td align="center">
          <table role="presentation" width="480" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;">
            <tr>
              <td style="background-color:#111827;padding:20px 32px;">
                <span style="color:#ffffff;font-size:18px;font-weight:bold;">FootballHub</span>
              </td>
            </tr>
            <tr>
              <td style="padding:32px;color:#1f2937;font-size:14px;line-height:1.6;">
                {inner_html}
              </td>
            </tr>
            <tr>
              <td style="padding:16px 32px;background-color:#f4f4f5;color:#9ca3af;font-size:11px;">
                Αυτό είναι ένα αυτόματο email από το FootballHub. Αν δεν έκανες εσύ αυτή την ενέργεια, αγνόησέ το.
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>
"""


def send_welcome_email(db: Session, to_email: str, display_name: str) -> bool:
    inner = f"""
    <p style="font-size:16px;font-weight:bold;margin:0 0 16px;">Καλώς ήρθες, {display_name}!</p>
    <p style="margin:0 0 16px;">Ο λογαριασμός σου στο FootballHub δημιουργήθηκε επιτυχώς.</p>
    <p style="margin:0;">Μπορείς τώρα να συνδεθείς και να ξεκινήσεις.</p>
    """
    return send_email(db, to_email, "Καλώς ήρθες στο FootballHub", _wrap_html(inner))


def send_password_reset_email(db: Session, to_email: str, display_name: str, reset_token: str) -> bool:
    inner = f"""
    <p style="font-size:16px;font-weight:bold;margin:0 0 16px;">Επαναφορά κωδικού πρόσβασης</p>
    <p style="margin:0 0 16px;">Γεια σου {display_name}, ζητήθηκε επαναφορά κωδικού για τον λογαριασμό σου.</p>
    <p style="margin:0 0 8px;">Ο κωδικός επαναφοράς σου είναι:</p>
    <p style="margin:0 0 16px;padding:12px 16px;background-color:#f4f4f5;border-radius:6px;font-family:monospace;font-size:15px;letter-spacing:0.5px;word-break:break-all;">
      {reset_token}
    </p>
    <p style="margin:0 0 16px;">Αντέγραψε τον κωδικό αυτό στη φόρμα επαναφοράς κωδικού. Ισχύει για 1 ώρα.</p>
    <p style="margin:0;color:#6b7280;">Αν δεν ζήτησες εσύ επαναφορά κωδικού, αγνόησε αυτό το email — ο κωδικός σου παραμένει ασφαλής.</p>
    """
    return send_email(db, to_email, "Επαναφορά κωδικού — FootballHub", _wrap_html(inner))
