"""
Excel export service. Χρησιμοποιεί openpyxl για δημιουργία μορφοποιημένων
.xlsx αρχείων (ρόστερ ομάδας, οικονομική εικόνα ακαδημίας).
"""
import io
from datetime import date

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill(start_color="1A2320", end_color="1A2320", fill_type="solid")
HEADER_FONT = Font(bold=True, color="D8FF5C")
DEBT_FONT = Font(color="C0392B", bold=True)
OK_FONT = Font(color="1E8449")

POSITION_LABELS = {
    "GK": "Τερματοφύλακας",
    "CB": "Κεντρικός Αμυντικός",
    "LB": "Αριστερός Μπακ",
    "RB": "Δεξιός Μπακ",
    "DM": "Αμυντικός Χαφ",
    "CM": "Κεντρικός Χαφ",
    "AM": "Επιθετικός Χαφ",
    "LW": "Αριστερό Άκρο",
    "RW": "Δεξί Άκρο",
    "ST": "Επιθετικός",
}
STATUS_LABELS = {
    "fit": "Διαθέσιμος",
    "injured": "Τραυματίας",
    "doubtful": "Αμφίβολος",
    "suspended": "Τιμωρημένος",
    "unavailable": "Μη Διαθέσιμος",
}
TRANSFER_STATUS_LABELS = {
    "not_listed": "—",
    "free_agent": "Ελεύθερος",
    "for_transfer": "Προς Μεταγραφή",
    "loan_listed": "Προς Δανεισμό",
}


def _autosize(ws, max_width: int = 40) -> None:
    for col_cells in ws.columns:
        length = max((len(str(c.value)) for c in col_cells if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(col_cells[0].column)].width = min(max_width, length + 3)


def _header_row(ws, headers: list, row: int = 1) -> None:
    for idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=row, column=idx, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")


def _today_str() -> str:
    return date.today().strftime("%d/%m/%Y")


def _save(wb: Workbook) -> bytes:
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.read()


def generate_team_roster_excel(team, players: list) -> bytes:
    """players: λίστα Player ORM objects (ή αντίστοιχα) με τα συνήθη πεδία."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Ρόστερ"

    ws.cell(row=1, column=1, value=f"Ρόστερ — {team.name}").font = Font(bold=True, size=14)
    ws.cell(row=2, column=1, value=f"Σεζόν: {team.season or '—'}  ·  Εξήχθη: {_today_str()}")
    headers = [
        "Αρ.",
        "Ονοματεπώνυμο",
        "Θέση",
        "Ημ. Γέννησης",
        "Εθνικότητα",
        "Κατάσταση",
        "Κατάσταση Μεταγραφής",
        "Τηλέφωνο",
        "Email",
    ]
    _header_row(ws, headers, row=4)
    row = 5
    for p in players:
        ws.cell(row=row, column=1, value=p.player_number)
        ws.cell(row=row, column=2, value=f"{p.first_name} {p.last_name}")
        ws.cell(row=row, column=3, value=POSITION_LABELS.get(p.position, p.position))
        ws.cell(row=row, column=4, value=p.date_of_birth.isoformat() if p.date_of_birth else None)
        ws.cell(row=row, column=5, value=p.nationality)
        ws.cell(row=row, column=6, value=STATUS_LABELS.get(p.status, p.status))
        ws.cell(row=row, column=7, value=TRANSFER_STATUS_LABELS.get(p.transfer_status, p.transfer_status))
        ws.cell(row=row, column=8, value=p.phone)
        ws.cell(row=row, column=9, value=p.email)
        row += 1

    _autosize(ws)
    return _save(wb)


def generate_academy_debts_excel(team, player_summaries: list, settings) -> bytes:
    """player_summaries: λίστα AcademyPlayerSummaryOut (ή ισοδύναμα dict-like
    αντικείμενα) με τα υπολογισμένα οικονομικά στοιχεία."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Συνδρομές"

    ws.cell(row=1, column=1, value=f"Συνδρομές Ακαδημίας — {team.name}").font = Font(bold=True, size=14)
    fee_line = []
    if settings and settings.monthly_fee:
        fee_line.append(f"Μηνιαία: €{settings.monthly_fee}")
    if settings and settings.annual_fee:
        fee_line.append(f"Ετήσια: €{settings.annual_fee}")
    if settings and settings.registration_fee:
        fee_line.append(f"Εγγραφή: €{settings.registration_fee}")
    ws.cell(row=2, column=1, value=(" · ".join(fee_line) or "—") + f"  ·  Εξήχθη: {_today_str()}")

    headers = [
        "Ονοματεπώνυμο",
        "Τύπος Συνδρομής",
        "Εγγραφή",
        "Ετήσιο Πακέτο",
        "Ανεξόφλητοι Μήνες",
        "Οφειλή Συνδρομής (€)",
        "Οφειλή Ρουχισμού (€)",
        "Σύνολο Οφειλής (€)",
        "Εκπρόθεσμο",
        "Γονέας",
        "Τηλέφωνο Γονέα",
    ]
    _header_row(ws, headers, row=4)
    row = 5
    total_all = 0.0
    for s in player_summaries:
        total = round(s.total_owed + s.kit_owed, 2)
        total_all += total
        ws.cell(row=row, column=1, value=s.player_name)
        ws.cell(row=row, column=2, value="Ετήσια" if s.plan_type == "annual" else "Μηνιαία")
        ws.cell(row=row, column=3, value="✓" if s.registration_paid else "Εκκρεμεί")
        ws.cell(
            row=row,
            column=4,
            value=("✓" if s.annual_paid_in_full else "Εκκρεμεί") if s.plan_type == "annual" else "—",
        )
        ws.cell(row=row, column=5, value=len(s.unpaid_months))
        ws.cell(row=row, column=6, value=s.total_owed)
        ws.cell(row=row, column=7, value=s.kit_owed)
        total_cell = ws.cell(row=row, column=8, value=total)
        total_cell.font = DEBT_FONT if total > 0 else OK_FONT
        ws.cell(row=row, column=9, value="⚠ Ναι" if s.is_overdue else "Όχι")
        ws.cell(row=row, column=10, value=s.parent_name)
        ws.cell(row=row, column=11, value=s.parent_phone)
        row += 1

    row += 1
    ws.cell(row=row, column=7, value="Σύνολο:").font = Font(bold=True)
    total_all_cell = ws.cell(row=row, column=8, value=round(total_all, 2))
    total_all_cell.font = Font(bold=True, color="C0392B" if total_all > 0 else "1E8449")

    _autosize(ws)
    return _save(wb)
