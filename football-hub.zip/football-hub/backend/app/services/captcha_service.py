"""
Επαλήθευση CAPTCHA (hCaptcha) — προστασία από αυτοματοποιημένες (bot)
εγγραφές. Προαιρετικό: αν ο admin δεν το ρυθμίσει στις Ρυθμίσεις, η
εγγραφή συνεχίζει κανονικά χωρίς CAPTCHA (μόνο με το honeypot πεδίο).
"""
import httpx
from sqlalchemy.orm import Session

from app.services.settings_service import get_setting

HCAPTCHA_VERIFY_URL = "https://hcaptcha.com/siteverify"


def get_captcha_config(db: Session) -> dict:
    return {
        "site_key": get_setting(db, "hcaptcha_site_key") or "",
        "secret_key": get_setting(db, "hcaptcha_secret_key") or "",
    }


def is_configured(db: Session) -> bool:
    cfg = get_captcha_config(db)
    return bool(cfg["site_key"] and cfg["secret_key"])


def verify_captcha(db: Session, token: str, remote_ip: str | None = None) -> bool:
    """Επαληθεύει ένα hCaptcha token με το hCaptcha API. Επιστρέφει False
    αν η επαλήθευση αποτύχει ή αν προκύψει σφάλμα δικτύου (fail-closed —
    προτιμάμε να μπλοκάρουμε παρά να αφήσουμε bots να περάσουν)."""
    cfg = get_captcha_config(db)
    if not cfg["secret_key"] or not token:
        return False
    data = {"secret": cfg["secret_key"], "response": token}
    if remote_ip:
        data["remoteip"] = remote_ip
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.post(HCAPTCHA_VERIFY_URL, data=data)
            result = resp.json()
            return bool(result.get("success"))
    except (httpx.HTTPError, ValueError):
        return False
