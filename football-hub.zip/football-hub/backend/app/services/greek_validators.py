"""Επικύρωση ελληνικού ΑΦΜ (checksum) — καθαρά μορφολογικός έλεγχος.

ΔΕΝ επιβεβαιώνει ότι το ΑΦΜ ανήκει σε πραγματικό, ενεργό σύλλογο — μόνο ότι
είναι μαθηματικά έγκυρο 9ψήφιο ΑΦΜ (φιλτράρει προφανώς ψεύτικα/τυχαία
νούμερα χωρίς κόστος ή καθυστέρηση). Η ουσιαστική επαλήθευση γίνεται με το
επίσημο έγγραφο συλλόγου (βλ. routers/verification.py, club_registration).
"""


def validate_afm(afm: str | None) -> bool:
    if not afm:
        return False
    afm = afm.strip()
    if not afm.isdigit() or len(afm) != 9:
        return False
    digits = [int(c) for c in afm]
    weighted_sum = sum(d * (2 ** (8 - i)) for i, d in enumerate(digits[:8]))
    check_digit = (weighted_sum % 11) % 10
    return check_digit == digits[8]
