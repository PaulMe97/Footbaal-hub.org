"""
Modular AI service layer.

Σχεδιασμένο ώστε να μπορεί να συνδεθεί με διαφορετικούς AI providers χωρίς
αλλαγές στους routers που το καλούν. Το config (provider/api key/model)
μπορεί να ρυθμιστεί είτε από το .env είτε από το UI (Ρυθμίσεις -> AI, 
αποθηκεύεται στη βάση — βλ. settings_service). Αν δεν υπάρχει ρυθμισμένο
API key, επιστρέφει ξεκάθαρο μήνυμα ότι το AI δεν είναι ρυθμισμένο — ΔΕΝ
επινοεί ποτέ περιεχόμενο.
"""
import base64

import httpx
from sqlalchemy.orm import Session

from app.services.settings_service import get_ai_config

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"


class AINotConfiguredError(Exception):
    pass


def is_configured(db: Session) -> bool:
    provider, api_key, _ = get_ai_config(db)
    return bool(api_key) and provider in ("anthropic", "openai")


def generate_text(db: Session, system_prompt: str, user_prompt: str, max_tokens: int = 1000) -> str:
    """Καλεί τον ρυθμισμένο AI provider και επιστρέφει το κείμενο απάντησης.
    Ρίχνει AINotConfiguredError αν δεν υπάρχει API key — ο caller πρέπει να
    το χειριστεί δείχνοντας ξεκάθαρο μήνυμα στον χρήστη, ποτέ fake δεδομένα."""
    provider, api_key, model = get_ai_config(db)
    if not api_key or provider not in ("anthropic", "openai"):
        raise AINotConfiguredError(
            "Το AI δεν έχει ρυθμιστεί. Πήγαινε στις Ρυθμίσεις -> AI Configuration και "
            "πρόσθεσε το API key σου (ή όρισε AI_PROVIDER/AI_API_KEY στο backend/.env)."
        )

    if provider == "anthropic":
        return _call_anthropic(api_key, model, system_prompt, user_prompt, max_tokens)
    if provider == "openai":
        return _call_openai(api_key, model, system_prompt, user_prompt, max_tokens)
    raise AINotConfiguredError(f"Άγνωστος AI provider: {provider}")


def _call_anthropic(api_key: str, model: str, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
    headers = {
        "x-api-key": api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }
    body = {
        "model": model or "claude-sonnet-4-6",
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(ANTHROPIC_API_URL, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()
    parts = [block["text"] for block in data.get("content", []) if block.get("type") == "text"]
    return "\n".join(parts).strip() or "(Το AI δεν επέστρεψε περιεχόμενο)"


def generate_vision_text(
    db: Session,
    system_prompt: str,
    user_prompt: str,
    image_bytes: bytes,
    media_type: str,
    max_tokens: int = 500,
) -> str:
    """Ίδιο με το generate_text, αλλά επισυνάπτει ΚΑΙ μια εικόνα στο μήνυμα
    (multimodal) — χρησιμοποιείται π.χ. για αυτόματη ανάγνωση/επαλήθευση
    εγγράφων. Ρίχνει AINotConfiguredError αν δεν υπάρχει API key."""
    provider, api_key, model = get_ai_config(db)
    if not api_key or provider not in ("anthropic", "openai"):
        raise AINotConfiguredError("Το AI δεν έχει ρυθμιστεί.")

    if provider == "anthropic":
        return _call_anthropic_vision(api_key, model, system_prompt, user_prompt, image_bytes, media_type, max_tokens)
    if provider == "openai":
        return _call_openai_vision(api_key, model, system_prompt, user_prompt, image_bytes, media_type, max_tokens)
    raise AINotConfiguredError(f"Άγνωστος AI provider: {provider}")


def _call_anthropic_vision(
    api_key: str,
    model: str,
    system_prompt: str,
    user_prompt: str,
    image_bytes: bytes,
    media_type: str,
    max_tokens: int,
) -> str:
    image_b64 = base64.b64encode(image_bytes).decode("ascii")
    headers = {
        "x-api-key": api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }
    body = {
        "model": model or "claude-sonnet-4-6",
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {"type": "base64", "media_type": media_type, "data": image_b64},
                    },
                    {"type": "text", "text": user_prompt},
                ],
            }
        ],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(ANTHROPIC_API_URL, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()
    parts = [block["text"] for block in data.get("content", []) if block.get("type") == "text"]
    return "\n".join(parts).strip()


def _call_openai_vision(
    api_key: str,
    model: str,
    system_prompt: str,
    user_prompt: str,
    image_bytes: bytes,
    media_type: str,
    max_tokens: int,
) -> str:
    image_b64 = base64.b64encode(image_bytes).decode("ascii")
    headers = {"Authorization": f"Bearer {api_key}", "content-type": "application/json"}
    body = {
        "model": model or "gpt-4o-mini",
        "max_tokens": max_tokens,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {"type": "image_url", "image_url": {"url": f"data:{media_type};base64,{image_b64}"}},
                ],
            },
        ],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(
            "https://api.openai.com/v1/chat/completions", headers=headers, json=body
        )
        response.raise_for_status()
        data = response.json()
    return data["choices"][0]["message"]["content"].strip()


def _call_openai(api_key: str, model: str, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
    headers = {"Authorization": f"Bearer {api_key}", "content-type": "application/json"}
    body = {
        "model": model or "gpt-4o-mini",
        "max_tokens": max_tokens,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(
            "https://api.openai.com/v1/chat/completions", headers=headers, json=body
        )
        response.raise_for_status()
        data = response.json()
    return data["choices"][0]["message"]["content"].strip()


def generate_chat_reply(db: Session, system_prompt: str, history: list[dict], max_tokens: int = 700) -> str:
    """Multi-turn συνομιλία (π.χ. για τον βοηθό Melie). Το `history` είναι
    λίστα από {"role": "user"|"assistant", "content": str}, με το τελευταίο
    μήνυμα του χρήστη ήδη μέσα. Ρίχνει AINotConfiguredError αν δεν υπάρχει
    API key."""
    provider, api_key, model = get_ai_config(db)
    if not api_key or provider not in ("anthropic", "openai"):
        raise AINotConfiguredError("Το AI δεν έχει ρυθμιστεί.")

    if provider == "anthropic":
        return _call_anthropic_chat(api_key, model, system_prompt, history, max_tokens)
    if provider == "openai":
        return _call_openai_chat(api_key, model, system_prompt, history, max_tokens)
    raise AINotConfiguredError(f"Άγνωστος AI provider: {provider}")


def _call_anthropic_chat(api_key: str, model: str, system_prompt: str, history: list[dict], max_tokens: int) -> str:
    headers = {
        "x-api-key": api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }
    body = {
        "model": model or "claude-sonnet-4-6",
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": m["role"], "content": m["content"]} for m in history],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(ANTHROPIC_API_URL, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()
    parts = [block["text"] for block in data.get("content", []) if block.get("type") == "text"]
    return "\n".join(parts).strip() or "(Το AI δεν επέστρεψε περιεχόμενο)"


def _call_openai_chat(api_key: str, model: str, system_prompt: str, history: list[dict], max_tokens: int) -> str:
    headers = {"Authorization": f"Bearer {api_key}", "content-type": "application/json"}
    body = {
        "model": model or "gpt-4o-mini",
        "max_tokens": max_tokens,
        "messages": [{"role": "system", "content": system_prompt}]
        + [{"role": m["role"], "content": m["content"]} for m in history],
    }
    with httpx.Client(timeout=60.0) as client:
        response = client.post(
            "https://api.openai.com/v1/chat/completions", headers=headers, json=body
        )
        response.raise_for_status()
        data = response.json()
    return data["choices"][0]["message"]["content"].strip()


def build_match_summary_prompt(match, performances) -> tuple[str, str]:
    """Χτίζει το prompt για AI Match Summary χρησιμοποιώντας ΜΟΝΟ πραγματικά
    δεδομένα του αγώνα — καμία επινόηση στατιστικών."""
    system_prompt = (
        "Είσαι βοηθός ανάλυσης ποδοσφαίρου για έναν προπονητή ερασιτεχνικής/ακαδημίας ομάδας. "
        "Χρησιμοποίησε ΜΟΝΟ τα δεδομένα που σου δίνονται. Αν κάτι λείπει, μην το επινοήσεις — "
        "ανάφερε ότι δεν υπάρχουν αρκετά δεδομένα γι' αυτό. Απάντησε στα Ελληνικά, δομημένα με "
        "τους εξής τίτλους: Περίληψη Αγώνα, Δυνατά Σημεία, Αδυναμίες, Τακτικές Παρατηρήσεις, "
        "Ξεχωριστές Εμφανίσεις, Σημεία Βελτίωσης, Προτεινόμενες Προτεραιότητες Προπόνησης."
    )

    lines = [
        f"Αγώνας: {match.home_team_name or '—'} vs {match.away_team_name or '—'}",
        f"Ημερομηνία: {match.date}",
        f"Διοργάνωση: {match.competition or '—'}",
        f"Κατάσταση: {match.status}",
    ]
    if match.status == "finished":
        lines.append(f"Σκορ: {match.home_score if match.home_score is not None else '—'} - {match.away_score if match.away_score is not None else '—'}")
    if match.general_description:
        lines.append(f"Γενική περιγραφή (από τον προπονητή): {match.general_description}")
    if match.team_performance_notes:
        lines.append(f"Σημειώσεις απόδοσης ομάδας: {match.team_performance_notes}")
    if match.opponent_analysis:
        lines.append(f"Ανάλυση αντιπάλου: {match.opponent_analysis}")
    if match.coach_notes:
        lines.append(f"Σημειώσεις προπονητή: {match.coach_notes}")

    if performances:
        lines.append("\nΣυμμετοχές παικτών:")
        for p in performances:
            role = "Βασικός" if p.is_starting else "Αναπληρωματικός"
            stats_parts = [role]
            if p.minutes_played is not None:
                stats_parts.append(f"{p.minutes_played}'")
            if p.goals:
                stats_parts.append(f"{p.goals} γκολ")
            if p.assists:
                stats_parts.append(f"{p.assists} ασίστ")
            if p.yellow_cards:
                stats_parts.append(f"{p.yellow_cards} κίτρινη")
            if p.red_cards:
                stats_parts.append(f"{p.red_cards} κόκκινη")
            if p.rating is not None:
                stats_parts.append(f"rating {p.rating}")
            line = f"- {p.player_name}: " + ", ".join(stats_parts)
            if p.notes:
                line += f" — Σημείωση προπονητή: {p.notes}"
            lines.append(line)
    else:
        lines.append("\nΔεν έχουν καταγραφεί συμμετοχές παικτών για αυτόν τον αγώνα.")

    user_prompt = "\n".join(lines)
    return system_prompt, user_prompt
