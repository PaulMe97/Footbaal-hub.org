"""
Βοηθητικές συναρτήσεις για δημιουργία notifications.
Καλείται από άλλα routers (matches, trainings, players) όταν συμβαίνει κάτι
που αξίζει ειδοποίηση — δεν είναι ξεχωριστό background job, δημιουργείται
in-line τη στιγμή του σχετικού event (π.χ. δημιουργία αγώνα).
"""
from sqlalchemy.orm import Session

from app.models import Notification, NotificationType, Team, TeamAccessGrant, User, UserRole


def notify(
    db: Session,
    type_: NotificationType,
    title: str,
    message: str | None = None,
    related_entity_type: str | None = None,
    related_entity_id: str | None = None,
    user_id: str | None = None,
    related_team_id: str | None = None,
) -> Notification:
    """ΠΑΝΤΑ δίνε user_id — οι ειδοποιήσεις είναι προσωπικές. Χωρίς user_id
    μια ειδοποίηση θα φαινόταν σε ΟΛΟΥΣ τους χρήστες της πλατφόρμας
    (ιστορικά αυτό ήταν bug, όχι σκόπιμη συμπεριφορά). Για ειδοποίηση σχετική
    με ομάδα, χρησιμοποίησε το notify_team() παρακάτω αντί να καλέσεις αυτό
    απευθείας χωρίς user_id. Δίνε related_team_id όταν είναι διαθέσιμο, ώστε
    το frontend να μπορεί να πλοηγηθεί απευθείας εκεί με ένα κλικ."""
    notification = Notification(
        user_id=user_id,
        type=type_,
        title=title,
        message=message,
        related_entity_type=related_entity_type,
        related_entity_id=related_entity_id,
        related_team_id=related_team_id,
    )
    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification


def _team_recipient_ids(db: Session, team_id: str) -> set[str]:
    """Owner της ομάδας + όσοι έχουν TeamAccessGrant σε αυτήν — δηλαδή όλοι
    όσοι πραγματικά τη διαχειρίζονται."""
    recipient_ids: set[str] = set()
    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id:
        recipient_ids.add(team.owner_id)
    grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.team_id == team_id).all()
    for g in grants:
        recipient_ids.add(g.user_id)
    return recipient_ids


def notify_team(
    db: Session,
    team_id: str | None,
    type_: NotificationType,
    title: str,
    message: str | None = None,
    related_entity_type: str | None = None,
    related_entity_id: str | None = None,
) -> list[Notification]:
    """Ειδοποιεί ΜΟΝΟ όσους πραγματικά σχετίζονται με μια ομάδα (owner +
    access grants) — ποτέ όλη την πλατφόρμα. Αν το team_id είναι κενό/None
    (π.χ. εξωτερική ομάδα σε αγώνα) δεν στέλνεται τίποτα."""
    if not team_id:
        return []
    results = []
    for uid in _team_recipient_ids(db, team_id):
        results.append(
            notify(
                db,
                type_,
                title,
                message=message,
                related_entity_type=related_entity_type,
                related_entity_id=related_entity_id,
                user_id=uid,
                related_team_id=team_id,
            )
        )
    return results


def notify_eligible_approvers(
    db: Session,
    team_id: str,
    applicant_role,
    title: str,
    message: str | None = None,
    related_entity_type: str | None = None,
    related_entity_id: str | None = None,
) -> list[Notification]:
    """Ειδοποιεί ΜΟΝΟ όσους θα μπορούσαν πραγματικά να εγκρίνουν μια αίτηση
    — χρησιμοποιεί την ίδια ιεραρχία έγκρισης (get_allowed_approver_roles)
    που ήδη αποφασίζει ποιος μπορεί να απαντήσει. Έτσι π.χ. μια αίτηση
    παίκτη ειδοποιεί Προπονητή/Πρόεδρο/Τεχνικό Διευθυντή (όποιον από αυτούς
    υπάρχει στην ομάδα), ενώ μια αίτηση Βοηθού Προπονητή ειδοποιεί και τον
    Προπονητή."""
    from app.permissions import get_allowed_approver_roles, get_team_member_roles
    from app.models import User

    team_member_roles = get_team_member_roles(db, team_id)
    allowed_roles = get_allowed_approver_roles(applicant_role, team_member_roles)

    recipient_ids: set[str] = set()
    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id:
        owner = db.query(User).filter(User.id == team.owner_id).first()
        if owner and owner.role in allowed_roles:
            recipient_ids.add(owner.id)
    grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.team_id == team_id).all()
    for g in grants:
        u = db.query(User).filter(User.id == g.user_id).first()
        if u and u.role in allowed_roles:
            recipient_ids.add(u.id)

    results = []
    for uid in recipient_ids:
        results.append(
            notify(
                db,
                NotificationType.NEW_APPLICATION,
                title,
                message=message,
                related_entity_type=related_entity_type,
                related_entity_id=related_entity_id,
                user_id=uid,
                related_team_id=team_id,
            )
        )
    return results


def notify_admins(
    db: Session,
    type_: NotificationType,
    title: str,
    message: str | None = None,
    related_entity_type: str | None = None,
    related_entity_id: str | None = None,
) -> list[Notification]:
    """Ειδοποιεί ΟΛΟΥΣ τους Admin/Super Admin της πλατφόρμας — χρησιμοποιείται
    για γεγονότα που χρειάζονται εποπτεία της διαχείρισης, όχι κάποιας
    συγκεκριμένης ομάδας (π.χ. νέα εγγραφή Προέδρου/Τεχνικού Διευθυντή προς
    επαλήθευση)."""
    admin_ids = [
        u.id for u in db.query(User).filter(User.role.in_([UserRole.SUPER_ADMIN, UserRole.ADMIN])).all()
    ]
    results = []
    for uid in admin_ids:
        results.append(
            notify(
                db,
                type_,
                title,
                message=message,
                related_entity_type=related_entity_type,
                related_entity_id=related_entity_id,
                user_id=uid,
            )
        )
    return results
