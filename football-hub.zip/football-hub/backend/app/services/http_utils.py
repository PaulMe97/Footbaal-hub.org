"""Βοηθητικές συναρτήσεις για HTTP responses."""
import re
import unicodedata
from urllib.parse import quote


def content_disposition_filename(filename: str) -> str:
    """Φτιάχνει την τιμή ενός header Content-Disposition που δουλεύει
    σωστά με ελληνικά (ή οποιαδήποτε non-ASCII) ονόματα αρχείων.

    Τα HTTP headers επιτρέπονται μόνο σε Latin-1 bytes — ένα raw ελληνικό
    filename μέσα σε ένα header σπάει την ίδια την απόκριση
    (UnicodeEncodeError, 500 Internal Server Error). Η λύση (RFC 6266)
    είναι να δοθεί ΚΑΙ ένα ASCII-only fallback (filename=, για πολύ
    παλιούς browsers) ΚΑΙ η πλήρης, σωστή έκδοση με UTF-8 percent-
    encoding (filename*=, που χρησιμοποιούν όλοι οι σύγχρονοι browsers)."""
    if "." in filename:
        stem, ext = filename.rsplit(".", 1)
        ext = "." + ext
    else:
        stem, ext = filename, ""
    ascii_stem = unicodedata.normalize("NFKD", stem).encode("ascii", "ignore").decode("ascii")
    ascii_stem = re.sub(r"[^A-Za-z0-9._-]+", "-", ascii_stem).strip("-") or "download"
    ascii_fallback = f"{ascii_stem}{ext}"
    encoded = quote(filename, safe="")
    return f"attachment; filename=\"{ascii_fallback}\"; filename*=UTF-8''{encoded}"
