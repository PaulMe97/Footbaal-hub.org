"""
Ταίριασμα λογαριασμού Player με υπάρχουσα εγγραφή παίκτη στο ρόστερ, βάσει
ονοματεπώνυμου (και ημερομηνίας γέννησης σε περίπτωση συνωνυμίας) — ίδια
λογική με το auto-link που γίνεται στην εγγραφή λογαριασμού, εδώ όμως
περιορισμένη σε συγκεκριμένη ομάδα (χρησιμοποιείται όταν γίνεται αποδεκτή
μια αίτηση ένταξης παίκτη).
"""
from datetime import date
from typing import Optional

from sqlalchemy.orm import Session

from app.models import Player, User


def _normalize(name: str) -> str:
    return " ".join(name.strip().lower().split())


def find_unlinked_player_match(
    db: Session,
    full_name: str,
    team_id: str,
    date_of_birth: Optional[date] = None,
) -> Optional[Player]:
    """Ψάχνει στο ρόστερ ΜΙΑΣ ομάδας για παίκτη που δεν είναι ήδη
    συνδεδεμένος με κανέναν λογαριασμό και του οποίου το ονοματεπώνυμο
    ταιριάζει. Αν βρεθούν πολλαπλά ταιριάσματα (συνωνυμία) και δοθεί
    ημερομηνία γέννησης, τη χρησιμοποιεί για να καταλήξει σε ΕΝΑ. Επιστρέφει
    None αν δεν υπάρχει σαφές, μοναδικό ταίριασμα — ποτέ δεν μαντεύει."""
    if not full_name:
        return None
    normalized = _normalize(full_name)

    linked_ids = {
        u.linked_player_id for u in db.query(User).filter(User.linked_player_id.isnot(None))
    }

    candidates = [
        p
        for p in db.query(Player).filter(Player.current_team_id == team_id).all()
        if p.id not in linked_ids and _normalize(f"{p.first_name} {p.last_name}") == normalized
    ]

    if len(candidates) > 1 and date_of_birth:
        candidates = [p for p in candidates if p.date_of_birth == date_of_birth]

    return candidates[0] if len(candidates) == 1 else None
