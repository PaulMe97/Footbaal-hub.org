"""
Wrapper για S3-συμβατό 3ο πρόγραμμα αποθήκευσης βίντεο (AWS S3, Cloudflare
R2, Backblaze B2, MinIO κ.λπ.) — ρυθμίζεται από τον admin στις Ρυθμίσεις
(ίδιο μοτίβο με το AI Configuration). Τα ίδια τα video bytes ΔΕΝ αγγίζουν
ποτέ τη δική μας βάση δεδομένων ή μόνιμο δίσκο — μόνο στέλνονται σε ροή
(streaming) προς το εξωτερικό αποθηκευτικό πρόγραμμα, και το playback
γίνεται μέσω προσωρινών (presigned) URLs, ώστε τα διαπιστευτήρια να μην
εκτίθενται ποτέ στον browser.
"""
import boto3
from botocore.client import Config as BotoConfig
from botocore.exceptions import BotoCoreError, ClientError
from sqlalchemy.orm import Session

from app.services.settings_service import get_s3_config


class VideoStorageError(Exception):
    pass


def is_configured(db: Session) -> bool:
    cfg = get_s3_config(db)
    return bool(cfg["endpoint_url"] and cfg["bucket_name"] and cfg["access_key_id"] and cfg["secret_access_key"])


def _get_client(db: Session):
    if not is_configured(db):
        raise VideoStorageError(
            "Δεν έχει ρυθμιστεί ακόμα το 3ο πρόγραμμα αποθήκευσης βίντεο — "
            "ζήτησε από τον admin να το ρυθμίσει στις Ρυθμίσεις."
        )
    cfg = get_s3_config(db)
    return boto3.client(
        "s3",
        endpoint_url=cfg["endpoint_url"],
        aws_access_key_id=cfg["access_key_id"],
        aws_secret_access_key=cfg["secret_access_key"],
        region_name=cfg["region"] or "auto",
        config=BotoConfig(signature_version="s3v4"),
    )


def upload_video_stream(db: Session, file_obj, key: str, content_type: str = "video/mp4") -> None:
    """Στέλνει το αρχείο σε ροή (multipart streaming upload) απευθείας στο
    S3-συμβατό αποθηκευτικό πρόγραμμα — δεν γράφεται ποτέ μόνιμα στον δικό
    μας δίσκο ή στη βάση δεδομένων μας."""
    client = _get_client(db)
    cfg = get_s3_config(db)
    try:
        client.upload_fileobj(file_obj, cfg["bucket_name"], key, ExtraArgs={"ContentType": content_type})
    except (BotoCoreError, ClientError) as exc:
        raise VideoStorageError(f"Αποτυχία μεταφόρτωσης στο 3ο πρόγραμμα αποθήκευσης: {exc}") from exc


def get_playback_url(db: Session, key: str, expires_in: int = 3600) -> str:
    """Δημιουργεί ένα προσωρινό (presigned) URL αναπαραγωγής — τα
    διαπιστευτήρια του αποθηκευτικού προγράμματος ποτέ δεν εκτίθενται στον
    browser."""
    client = _get_client(db)
    cfg = get_s3_config(db)
    try:
        return client.generate_presigned_url(
            "get_object",
            Params={"Bucket": cfg["bucket_name"], "Key": key},
            ExpiresIn=expires_in,
        )
    except (BotoCoreError, ClientError) as exc:
        raise VideoStorageError(f"Αποτυχία δημιουργίας URL αναπαραγωγής: {exc}") from exc


def delete_video(db: Session, key: str) -> None:
    """Best-effort διαγραφή — αν το αντικείμενο έχει ήδη διαγραφεί ή δεν
    βρεθεί, δεν χρειάζεται να αποτύχει ολόκληρο το request."""
    try:
        client = _get_client(db)
    except VideoStorageError:
        return
    cfg = get_s3_config(db)
    try:
        client.delete_object(Bucket=cfg["bucket_name"], Key=key)
    except (BotoCoreError, ClientError):
        pass
