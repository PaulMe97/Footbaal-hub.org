"""
Συμμετρική κρυπτογράφηση (Fernet) για ευαίσθητα δεδομένα που αποθηκεύονται
στη βάση — π.χ. ΑΦΜ, κλειδιά API τρίτων προγραμμάτων (AI, S3-συμβατή
αποθήκευση βίντεο). Το κλειδί έρχεται από το ENCRYPTION_KEY env var· αν
λείπει (μόνο για local development), δημιουργείται αυτόματα ένα και
αποθηκεύεται σε τοπικό αρχείο ώστε να παραμείνει σταθερό μεταξύ
επανεκκινήσεων — αλλιώς τα ήδη κρυπτογραφημένα δεδομένα θα γίνονταν
αδιάβαστα μετά από κάθε restart.
"""
import logging

from cryptography.fernet import Fernet, InvalidToken

from app.config import BASE_DIR, ENCRYPTION_KEY

logger = logging.getLogger(__name__)

_DEV_KEY_FILE = BASE_DIR / ".encryption_key.local"


def _load_or_create_key() -> bytes:
    if ENCRYPTION_KEY:
        return ENCRYPTION_KEY.encode()
    # Development fallback: persist σε τοπικό αρχείο ώστε να ΜΗΝ αλλάζει σε
    # κάθε επανεκκίνηση (αλλιώς χάνεται η πρόσβαση σε ήδη κρυπτογραφημένα
    # δεδομένα με το προηγούμενο, τυχαίο κλειδί).
    if _DEV_KEY_FILE.exists():
        return _DEV_KEY_FILE.read_text().strip().encode()
    logger.warning(
        "ENCRYPTION_KEY δεν έχει οριστεί — δημιουργήθηκε αυτόματο κλειδί μόνο "
        "για development, αποθηκευμένο στο %s. Όρισε ENCRYPTION_KEY μέσω "
        ".env πριν το production deployment.",
        _DEV_KEY_FILE,
    )
    key = Fernet.generate_key()
    _DEV_KEY_FILE.write_text(key.decode())
    return key


_fernet = Fernet(_load_or_create_key())


def encrypt(plaintext: str) -> str:
    """Κρυπτογραφεί ένα string· επιστρέφει ένα ασφαλές-για-αποθήκευση token."""
    return _fernet.encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str) -> str:
    """Αποκρυπτογραφεί ένα token που δημιουργήθηκε από την encrypt().

    Αν η τιμή δεν είναι έγκυρο κρυπτογραφημένο token (π.χ. παλιά, plaintext
    δεδομένα αποθηκευμένα πριν ενεργοποιηθεί η κρυπτογράφηση), επιστρέφεται
    ως έχει — ώστε να μην σπάσει η ανάγνωση ήδη υπαρχουσών εγγραφών."""
    try:
        return _fernet.decrypt(ciphertext.encode()).decode()
    except (InvalidToken, ValueError):
        return ciphertext
