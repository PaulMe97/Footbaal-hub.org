"""
Ανίχνευση & μπλοκάρισμα κακόβουλης δραστηριότητας — SQL injection, XSS,
path traversal, γνωστά εργαλεία επίθεσης (sqlmap, nikto κ.λπ.), rate
limiting, αποτυχημένα logins. Βλ. app/middleware/security_middleware.py
για το πώς εφαρμόζονται αυτά σε κάθε request.
"""
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta
import ipaddress

from sqlalchemy.orm import Session

from app.models import BannedIP, LoginAttempt, SecurityEvent

# --- Ρυθμίσεις ---------------------------------------------------------------
STRIKE_THRESHOLD = 6  # πόσα ύποπτα events μέσα στο STRIKE_WINDOW πριν αυτόματο ban
STRIKE_WINDOW_MINUTES = 20
AUTO_BAN_DURATION_HOURS = 3
KNOWN_ATTACK_TOOL_IMMEDIATE_BAN = True  # γνωστό εργαλείο επίθεσης -> ban κατευθείαν, χωρίς strikes
KNOWN_ATTACK_TOOL_BAN_HOURS = 720  # 30 μέρες, όχι μόνιμο -> αυτο-λύνεται χωρίς χειροκίνητο unban

FAILED_LOGIN_THRESHOLD = 10
FAILED_LOGIN_WINDOW_MINUTES = 15
FAILED_LOGIN_BAN_HOURS = 1

RATE_LIMIT_MAX_REQUESTS = 600
RATE_LIMIT_WINDOW_SECONDS = 60

# --- Patterns -----------------------------------------------------------------
SQL_INJECTION_PATTERNS = [
    re.compile(r"\bunion\b.{1,40}\bselect\b", re.IGNORECASE),
    re.compile(r"\bselect\b.{1,60}\bfrom\b.{1,60}\binformation_schema\b", re.IGNORECASE),
    re.compile(r"'\s*or\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+", re.IGNORECASE),
    re.compile(r"\bdrop\b\s+\btable\b", re.IGNORECASE),
    re.compile(r"\bxp_cmdshell\b", re.IGNORECASE),
    re.compile(r";\s*(drop|delete|update|insert)\s+", re.IGNORECASE),
    re.compile(r"\bsleep\s*\(\s*\d+\s*\)", re.IGNORECASE),
    re.compile(r"\bbenchmark\s*\(", re.IGNORECASE),
]

XSS_PATTERNS = [
    re.compile(r"<\s*script", re.IGNORECASE),
    re.compile(r"javascript\s*:", re.IGNORECASE),
    re.compile(r"on(error|load|click|mouseover|focus)\s*=", re.IGNORECASE),
    re.compile(r"<\s*iframe", re.IGNORECASE),
]

PATH_TRAVERSAL_PATTERNS = [
    re.compile(r"\.\./"),
    re.compile(r"\.\.\\"),
    re.compile(r"%2e%2e%2f", re.IGNORECASE),
    re.compile(r"/etc/passwd", re.IGNORECASE),
    re.compile(r"windows[\\/]system32", re.IGNORECASE),
]

KNOWN_ATTACK_USER_AGENTS = [
    "sqlmap", "nikto", "nmap", "masscan", "dirbuster", "gobuster",
    "wpscan", "acunetix", "nessus", "openvas", "metasploit", "hydra",
    "burpsuite", "havij", "zaproxy", "w3af", "netsparker", "nuclei",
]


def get_client_ip(headers: dict, fallback_ip: str) -> str:
    """Εξάγει το πραγματικό IP του client, λαμβάνοντας υπόψη reverse proxy
    (X-Forwarded-For) — αν η εφαρμογή τρέχει πίσω από nginx/Caddy/Cloudflare."""
    forwarded = headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return fallback_ip or "unknown"


def is_private_or_loopback_ip(ip: str) -> bool:
    """True αν το IP είναι loopback (127.0.0.1, ::1) ή ιδιωτικού δικτύου
    (10.x, 172.16-31.x, 192.168.x) — σχεδόν σίγουρα ο ίδιος ο
    admin/developer (π.χ. τοπική ανάπτυξη), όχι πραγματικός εξωτερικός
    επιτιθέμενος (τέτοιες διευθύνσεις δεν είναι καν προσβάσιμες από το
    internet). Χρησιμοποιείται ΜΟΝΟ για να εξαιρεθούν από το ΑΥΤΟΜΑΤΟ
    μπλοκάρισμα strikes — ο admin μπορεί πάντα να μπλοκάρει χειροκίνητα
    οποιοδήποτε IP από τις Ρυθμίσεις αν χρειαστεί."""
    try:
        addr = ipaddress.ip_address(ip)
        return addr.is_loopback or addr.is_private
    except ValueError:
        return False


def check_malicious_patterns(path: str, query_string: str) -> str | None:
    """Ελέγχει το path + query string ενός request για γνωστά patterns
    επίθεσης. Επιστρέφει τον τύπο (string) αν βρεθεί κάτι, αλλιώς None."""
    target = f"{path}?{query_string}" if query_string else path
    for pattern in SQL_INJECTION_PATTERNS:
        if pattern.search(target):
            return "sql_injection_attempt"
    for pattern in XSS_PATTERNS:
        if pattern.search(target):
            return "xss_attempt"
    for pattern in PATH_TRAVERSAL_PATTERNS:
        if pattern.search(target):
            return "path_traversal_attempt"
    return None


def check_malicious_user_agent(user_agent: str | None) -> bool:
    if not user_agent:
        return False
    ua_lower = user_agent.lower()
    return any(tool in ua_lower for tool in KNOWN_ATTACK_USER_AGENTS)


def is_banned(db: Session, ip: str) -> BannedIP | None:
    """Επιστρέφει την ενεργή εγγραφή μπλοκαρίσματος για αυτό το IP, ή None
    αν δεν είναι μπλοκαρισμένο (καθαρίζει αυτόματα ληγμένα προσωρινά bans)."""
    row = db.query(BannedIP).filter(BannedIP.ip_address == ip).first()
    if not row:
        return None
    if row.is_permanent:
        return row
    if row.banned_until and row.banned_until > datetime.utcnow():
        return row
    # Έληξε το προσωρινό ban — καθάρισέ το.
    db.delete(row)
    db.commit()
    return None


def ban_ip(
    db: Session,
    ip: str,
    reason: str,
    permanent: bool = False,
    duration_hours: int = AUTO_BAN_DURATION_HOURS,
    banned_by: str | None = None,
    strike_count: int = 1,
) -> BannedIP:
    row = db.query(BannedIP).filter(BannedIP.ip_address == ip).first()
    banned_until = None if permanent else datetime.utcnow() + timedelta(hours=duration_hours)
    if row:
        row.reason = reason
        row.is_permanent = permanent
        row.banned_until = banned_until
        row.banned_at = datetime.utcnow()
        row.strike_count = strike_count
        row.banned_by = banned_by
    else:
        row = BannedIP(
            ip_address=ip,
            reason=reason,
            is_permanent=permanent,
            banned_until=banned_until,
            banned_by=banned_by,
            strike_count=strike_count,
        )
        db.add(row)
    db.commit()
    db.refresh(row)
    return row


def unban_ip(db: Session, ip: str) -> bool:
    row = db.query(BannedIP).filter(BannedIP.ip_address == ip).first()
    if not row:
        return False
    db.delete(row)
    db.commit()
    return True


def record_security_event(
    db: Session,
    ip: str,
    event_type: str,
    detail: str | None = None,
    endpoint: str | None = None,
    user_agent: str | None = None,
) -> None:
    """Καταγράφει ένα ύποπτο event και, αν ξεπεραστεί το όριο strikes μέσα
    στο χρονικό παράθυρο, μπλοκάρει αυτόματα το IP.

    Δύο εξαιρέσεις από το ΑΥΤΟΜΑΤΟ (strike-based ή immediate) μπλοκάρισμα —
    το ίδιο το event καταγράφεται πάντα, για ορατότητα στις Ρυθμίσεις:
      1. IPs τοπικού/ιδιωτικού δικτύου (127.0.0.1 κ.λπ.) — σχεδόν σίγουρα ο
         ίδιος ο developer/admin, όχι εξωτερικός επιτιθέμενος.
      2. "rate_limit_exceeded" — ένα SPA με πολλά ταυτόχρονα polling
         requests (ειδοποιήσεις, μηνύματα) μπορεί νόμιμα να ξεπεράσει το
         όριο περιοδικά· το ίδιο το 429 λειτουργεί ήδη ως προσωρινό
         throttling, δεν χρειάζεται να κλιμακώνεται σε πολύωρο μπλοκάρισμα.
    """
    db.add(
        SecurityEvent(
            ip_address=ip,
            event_type=event_type,
            detail=detail,
            endpoint=endpoint,
            user_agent=user_agent,
        )
    )
    db.commit()

    if is_private_or_loopback_ip(ip) or event_type == "rate_limit_exceeded":
        return

    if event_type == "known_attack_tool" and KNOWN_ATTACK_TOOL_IMMEDIATE_BAN:
        ban_ip(
            db,
            ip,
            reason="Ανιχνεύθηκε γνωστό εργαλείο επίθεσης (π.χ. sqlmap, nikto).",
            permanent=False,
            duration_hours=KNOWN_ATTACK_TOOL_BAN_HOURS,
        )
        return

    window_start = datetime.utcnow() - timedelta(minutes=STRIKE_WINDOW_MINUTES)
    recent_count = (
        db.query(SecurityEvent)
        .filter(SecurityEvent.ip_address == ip, SecurityEvent.created_at >= window_start)
        .count()
    )
    if recent_count >= STRIKE_THRESHOLD:
        ban_ip(
            db,
            ip,
            reason=f"Αυτόματο μπλοκάρισμα: {recent_count} ύποπτες ενέργειες μέσα σε {STRIKE_WINDOW_MINUTES} λεπτά.",
            permanent=False,
            duration_hours=AUTO_BAN_DURATION_HOURS,
            strike_count=recent_count,
        )


def record_login_attempt(db: Session, ip: str, username: str | None, success: bool) -> None:
    db.add(LoginAttempt(ip_address=ip, username_attempted=username, success=success))
    db.commit()

    if success:
        return

    window_start = datetime.utcnow() - timedelta(minutes=FAILED_LOGIN_WINDOW_MINUTES)
    recent_failures = (
        db.query(LoginAttempt)
        .filter(
            LoginAttempt.ip_address == ip,
            LoginAttempt.success.is_(False),
            LoginAttempt.created_at >= window_start,
        )
        .count()
    )
    if recent_failures >= FAILED_LOGIN_THRESHOLD:
        ban_ip(
            db,
            ip,
            reason=f"Αυτόματο μπλοκάρισμα: {recent_failures} αποτυχημένες προσπάθειες σύνδεσης.",
            permanent=False,
            duration_hours=FAILED_LOGIN_BAN_HOURS,
            strike_count=recent_failures,
        )


# --- Rate limiting (in-memory sliding window — δεν χρειάζεται persistence
# ανάμεσα σε επανεκκινήσεις, μόνο κατά τη διάρκεια λειτουργίας) --------------
_request_log: dict[str, deque] = defaultdict(deque)


def check_rate_limit(ip: str) -> bool:
    """Επιστρέφει True αν το IP ξεπέρασε το όριο αιτημάτων — καλείται σε
    κάθε request, εντελώς ανεξάρτητα από τη βάση δεδομένων (πολύ γρήγορο)."""
    now = time.monotonic()
    window = _request_log[ip]
    window.append(now)
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    while window and window[0] < cutoff:
        window.popleft()
    return len(window) > RATE_LIMIT_MAX_REQUESTS
