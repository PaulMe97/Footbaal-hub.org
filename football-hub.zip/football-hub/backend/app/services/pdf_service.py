"""
PDF export service. Χρησιμοποιεί reportlab (pure Python, χωρίς εξωτερικά
system dependencies) ώστε να δουλεύει out-of-the-box σε Windows.

Χρησιμοποιεί τη γραμματοσειρά DejaVu Sans (bundled στο app/assets/fonts) αντί
για την προεπιλεγμένη Helvetica, γιατί η Helvetica δεν υποστηρίζει Ελληνικούς
χαρακτήρες στο reportlab και εμφανίζει μαύρα τετράγωνα.
"""
import io
import math
from pathlib import Path

from app.config import SCOUT_REPORT_PHOTOS_DIR
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as pdfcanvas
from reportlab.platypus import (
    Flowable,
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

FONTS_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"
FONT_REGULAR = "DejaVuSans"
FONT_BOLD = "DejaVuSans-Bold"

pdfmetrics.registerFont(TTFont(FONT_REGULAR, str(FONTS_DIR / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont(FONT_BOLD, str(FONTS_DIR / "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFontFamily(
    FONT_REGULAR, normal=FONT_REGULAR, bold=FONT_BOLD, italic=FONT_REGULAR, boldItalic=FONT_BOLD
)

PITCH_GREEN = colors.HexColor("#2C5A3C")
CHALK = colors.HexColor("#3E7D52")
DARK = colors.HexColor("#0A0F0D")
MUTED = colors.HexColor("#555555")


def generate_match_rating_pdf(match_out, performances) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleFH", parent=styles["Title"], textColor=DARK, fontSize=18, spaceAfter=4,
        fontName=FONT_BOLD,
    )
    subtitle_style = ParagraphStyle(
        "SubtitleFH", parent=styles["Normal"], textColor=MUTED, fontSize=10, spaceAfter=14,
        fontName=FONT_REGULAR,
    )
    section_style = ParagraphStyle(
        "SectionFH", parent=styles["Heading2"], textColor=PITCH_GREEN, spaceBefore=14, spaceAfter=6,
        fontName=FONT_BOLD,
    )
    body_style = ParagraphStyle(
        "BodyFH", parent=styles["Normal"], fontSize=9.5, leading=13, fontName=FONT_REGULAR
    )

    elements = []
    elements.append(Paragraph("FootballHub — Αναφορά Βαθμολογιών Αγώνα", title_style))

    home = match_out.home_team_name or "—"
    away = match_out.away_team_name or "—"
    score = (
        f"{match_out.home_score} - {match_out.away_score}"
        if match_out.status == "finished" and match_out.home_score is not None
        else "—"
    )
    meta_line = f"{home} vs {away} &nbsp;|&nbsp; {match_out.date}"
    if match_out.competition:
        meta_line += f" &nbsp;|&nbsp; {match_out.competition}"
    if score != "—":
        meta_line += f" &nbsp;|&nbsp; Σκορ: {score}"
    elements.append(Paragraph(meta_line, subtitle_style))

    elements.append(Paragraph("Βαθμολογίες Παικτών", section_style))

    table_data = [["#", "Παίκτης", "Θέση", "Λεπτά", "Γκολ", "Ασίστ", "ΚΚ/ΚΟΚ", "Rating", "MVP"]]
    for p in performances:
        position_label = "-"
        if p.position_played is not None:
            position_label = getattr(p.position_played, "value", p.position_played)
        table_data.append(
            [
                str(p.player_number) if p.player_number is not None else "-",
                p.player_name,
                position_label,
                str(p.minutes_played) if p.minutes_played is not None else "-",
                str(p.goals),
                str(p.assists),
                f"{p.yellow_cards}/{p.red_cards}",
                f"{p.rating:.1f}" if p.rating is not None else "-",
                "★" if p.is_mvp else "",
            ]
        )

    table = Table(
        table_data,
        colWidths=[10 * mm, 42 * mm, 16 * mm, 16 * mm, 14 * mm, 14 * mm, 16 * mm, 16 * mm, 12 * mm],
        repeatRows=1,
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), DARK),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("FONTNAME", (0, 0), (-1, 0), FONT_BOLD),
                ("FONTNAME", (0, 1), (-1, -1), FONT_REGULAR),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("ALIGN", (1, 1), (1, -1), "LEFT"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CCCCCC")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5F3")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elements.append(table)

    mvp = next((p for p in performances if p.is_mvp), None)
    if mvp:
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(f"★ MVP Αγώνα: <b>{mvp.player_name}</b>", body_style))

    if match_out.general_description or match_out.coach_notes:
        elements.append(Paragraph("Σημειώσεις Αγώνα", section_style))
        if match_out.general_description:
            elements.append(Paragraph(match_out.general_description, body_style))
            elements.append(Spacer(1, 6))
        if match_out.coach_notes:
            elements.append(Paragraph(f"<b>Προπονητής:</b> {match_out.coach_notes}", body_style))

    doc.build(elements)
    buffer.seek(0)
    return buffer.read()


# ---------------------------------------------------------------------------
# Εξαγωγή Ρόστερ Ομάδας (PDF)
# ---------------------------------------------------------------------------
def generate_team_roster_pdf(team, players: list) -> bytes:
    from app.services.excel_service import POSITION_LABELS, STATUS_LABELS, TRANSFER_STATUS_LABELS

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, topMargin=18 * mm, bottomMargin=18 * mm, leftMargin=16 * mm, rightMargin=16 * mm
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleFH2", parent=styles["Title"], textColor=DARK, fontSize=18, spaceAfter=4, fontName=FONT_BOLD
    )
    subtitle_style = ParagraphStyle(
        "SubtitleFH2", parent=styles["Normal"], textColor=MUTED, fontSize=10, spaceAfter=14, fontName=FONT_REGULAR
    )

    elements = [
        Paragraph(f"FootballHub — Ρόστερ: {team.name}", title_style),
        Paragraph(f"Σεζόν: {team.season or '—'}", subtitle_style),
    ]

    table_data = [["Αρ.", "Ονοματεπώνυμο", "Θέση", "Κατάσταση", "Μεταγραφή"]]
    for p in players:
        table_data.append(
            [
                str(p.player_number) if p.player_number is not None else "-",
                f"{p.first_name} {p.last_name}",
                POSITION_LABELS.get(p.position, p.position) or "-",
                STATUS_LABELS.get(p.status, p.status) or "-",
                TRANSFER_STATUS_LABELS.get(p.transfer_status, p.transfer_status) or "-",
            ]
        )

    table = Table(table_data, colWidths=[14 * mm, 60 * mm, 38 * mm, 30 * mm, 32 * mm], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), DARK),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("FONTNAME", (0, 0), (-1, 0), FONT_BOLD),
                ("FONTNAME", (0, 1), (-1, -1), FONT_REGULAR),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("ALIGN", (1, 1), (1, -1), "LEFT"),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CCCCCC")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5F3")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    elements.append(table)
    doc.build(elements)
    buffer.seek(0)
    return buffer.read()


# ---------------------------------------------------------------------------
# Εξαγωγή Συνδρομών/Οφειλών Ακαδημίας (PDF)
# ---------------------------------------------------------------------------
def generate_academy_debts_pdf(team, player_summaries: list, settings) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, topMargin=18 * mm, bottomMargin=18 * mm, leftMargin=16 * mm, rightMargin=16 * mm
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleFH3", parent=styles["Title"], textColor=DARK, fontSize=18, spaceAfter=4, fontName=FONT_BOLD
    )
    subtitle_style = ParagraphStyle(
        "SubtitleFH3", parent=styles["Normal"], textColor=MUTED, fontSize=10, spaceAfter=14, fontName=FONT_REGULAR
    )

    fee_line = []
    if settings and settings.monthly_fee:
        fee_line.append(f"Μηνιαία: €{settings.monthly_fee}")
    if settings and settings.annual_fee:
        fee_line.append(f"Ετήσια: €{settings.annual_fee}")
    if settings and settings.registration_fee:
        fee_line.append(f"Εγγραφή: €{settings.registration_fee}")

    elements = [
        Paragraph(f"FootballHub — Συνδρομές Ακαδημίας: {team.name}", title_style),
        Paragraph(" · ".join(fee_line) or "—", subtitle_style),
    ]

    table_data = [["Ονοματεπώνυμο", "Τύπος", "Εγγραφή", "Μήνες", "Οφειλή (€)", "Εκπρόθεσμο"]]
    total_all = 0.0
    for s in player_summaries:
        total = round(s.total_owed + s.kit_owed, 2)
        total_all += total
        table_data.append(
            [
                s.player_name,
                "Ετήσια" if s.plan_type == "annual" else "Μηνιαία",
                "✓" if s.registration_paid else "Εκκρεμεί",
                str(len(s.unpaid_months)),
                f"{total:.2f}",
                "⚠ Ναι" if s.is_overdue else "Όχι",
            ]
        )
    table_data.append(["", "", "", "Σύνολο:", f"{total_all:.2f}", ""])

    table = Table(table_data, colWidths=[50 * mm, 22 * mm, 22 * mm, 20 * mm, 24 * mm, 26 * mm], repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (-1, 0), FONT_BOLD),
        ("FONTNAME", (0, 1), (-1, -1), FONT_REGULAR),
        ("FONTNAME", (0, -1), (-1, -1), FONT_BOLD),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("ALIGN", (0, 1), (0, -1), "LEFT"),
        ("GRID", (0, 0), (-1, -2), 0.4, colors.HexColor("#CCCCCC")),
        ("LINEABOVE", (0, -1), (-1, -1), 0.8, DARK),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#F2F5F3")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    table.setStyle(TableStyle(style_cmds))
    elements.append(table)
    doc.build(elements)
    buffer.seek(0)
    return buffer.read()


# ---------------------------------------------------------------------------
# Tactical Board PDF (pitch drawing with players / arrows / zones / cones / text)
# ---------------------------------------------------------------------------
CONE_COLOR = colors.HexColor("#E0A83E")
ARROW_COLOR = colors.HexColor("#2C5A3C")
ZONE_COLOR = colors.HexColor("#3E7D52")
MARKER_FILL = colors.HexColor("#3E7D52")
MARKER_EMPTY = colors.HexColor("#B7C4BC")
TEXT_CHIP_BG = colors.HexColor("#0A0F0D")


def _draw_arrowhead(c, x, y, angle_rad, color, size=7):
    a1 = angle_rad + math.radians(150)
    a2 = angle_rad - math.radians(150)
    p1 = (x + size * math.cos(a1), y + size * math.sin(a1))
    p2 = (x + size * math.cos(a2), y + size * math.sin(a2))
    path = c.beginPath()
    path.moveTo(x, y)
    path.lineTo(*p1)
    path.lineTo(*p2)
    path.close()
    c.setFillColor(color)
    c.drawPath(path, fill=1, stroke=0)


def _draw_cone(c, x, y):
    size = 6
    path = c.beginPath()
    path.moveTo(x, y + size)
    path.lineTo(x - size * 0.85, y - size * 0.55)
    path.lineTo(x + size * 0.85, y - size * 0.55)
    path.close()
    c.setFillColor(CONE_COLOR)
    c.drawPath(path, fill=1, stroke=0)
    c.setStrokeColor(colors.white)
    c.setLineWidth(0.5)
    c.line(x - size * 0.4, y - size * 0.1, x + size * 0.4, y - size * 0.1)


def generate_tactical_board_pdf(board) -> bytes:
    """board: TacticalBoardDetailOut (name, team_name, training_label, formation,
    scenario_type, notes, objects[...]). Ζωγραφίζει το γήπεδο με όλα τα
    αντικείμενα (παίκτες, βέλη, ζώνες, κώνους, κείμενο) απευθείας σε reportlab
    canvas — χωρίς εξάρτηση από SVG-to-image βιβλιοθήκες."""
    buffer = io.BytesIO()
    page_w, page_h = A4
    c = pdfcanvas.Canvas(buffer, pagesize=A4)
    margin = 40

    # --- Header -------------------------------------------------------------
    c.setFillColor(colors.HexColor("#0A0F0D"))
    c.setFont(FONT_BOLD, 16)
    c.drawString(margin, page_h - margin, "FootballHub — Tactical Board")

    c.setFont(FONT_BOLD, 12)
    c.drawString(margin, page_h - margin - 20, board.name)

    subtitle_parts = []
    if board.team_name:
        subtitle_parts.append(board.team_name)
    if board.formation:
        subtitle_parts.append(f"Formation: {board.formation}")
    if board.scenario_type:
        subtitle_parts.append(board.scenario_type)
    if board.training_label:
        subtitle_parts.append(board.training_label)
    c.setFillColor(colors.HexColor("#555555"))
    c.setFont(FONT_REGULAR, 9.5)
    c.drawString(margin, page_h - margin - 36, "  ·  ".join(subtitle_parts) or "—")

    # --- Pitch geometry -------------------------------------------------------
    pitch_width = 260
    pitch_height = pitch_width * 105 / 68
    pitch_x = (page_w - pitch_width) / 2
    header_height = 70
    pitch_top_y = page_h - margin - header_height
    pitch_bottom_y = pitch_top_y - pitch_height
    inset = 4

    def px(x_pct):
        return pitch_x + (x_pct / 100.0) * pitch_width

    def py(y_pct):
        return pitch_top_y - (y_pct / 100.0) * pitch_height

    # Pitch background
    c.setFillColor(PITCH_GREEN)
    c.rect(pitch_x, pitch_bottom_y, pitch_width, pitch_height, fill=1, stroke=0)

    # Pitch lines
    c.setStrokeColor(colors.white)
    c.setLineWidth(1)
    c.rect(pitch_x + inset, pitch_bottom_y + inset, pitch_width - 2 * inset, pitch_height - 2 * inset, fill=0, stroke=1)
    mid_y = py(50)
    c.line(pitch_x + inset, mid_y, pitch_x + pitch_width - inset, mid_y)
    c.circle(px(50), mid_y, 22, fill=0, stroke=1)
    c.circle(px(50), mid_y, 1.4, fill=1, stroke=0)

    box_w = pitch_width * 0.5
    box_h = pitch_height * 0.16
    box_x = pitch_x + (pitch_width - box_w) / 2
    six_w = pitch_width * 0.24
    six_h = pitch_height * 0.06
    six_x = pitch_x + (pitch_width - six_w) / 2

    c.rect(box_x, pitch_bottom_y + inset, box_w, box_h, fill=0, stroke=1)
    c.rect(six_x, pitch_bottom_y + inset, six_w, six_h, fill=0, stroke=1)
    c.circle(px(50), py(88), 1.4, fill=1, stroke=0)

    c.rect(box_x, pitch_top_y - inset - box_h, box_w, box_h, fill=0, stroke=1)
    c.rect(six_x, pitch_top_y - inset - six_h, six_w, six_h, fill=0, stroke=1)
    c.circle(px(50), py(12), 1.4, fill=1, stroke=0)

    objects = board.objects or []

    # Zones (drawn first, behind everything else)
    for obj in objects:
        if obj.object_type != "zone" or len(obj.coordinates) < 2:
            continue
        p1, p2 = obj.coordinates[0], obj.coordinates[1]
        x1, y_top = px(p1["x"]), py(p1["y"])
        x2, y_bottom = px(p2["x"]), py(p2["y"])
        rx, ry = min(x1, x2), min(y_top, y_bottom)
        rw, rh = abs(x2 - x1), abs(y_top - y_bottom)
        c.saveState()
        try:
            c.setFillAlpha(0.18)
        except AttributeError:
            pass
        c.setFillColor(ZONE_COLOR)
        c.setStrokeColor(ZONE_COLOR)
        c.setDash([3, 2])
        c.rect(rx, ry, rw, rh, fill=1, stroke=1)
        c.restoreState()

    # Arrows
    for obj in objects:
        if obj.object_type != "arrow" or len(obj.coordinates) < 2:
            continue
        p1, p2 = obj.coordinates[0], obj.coordinates[1]
        x1, y1 = px(p1["x"]), py(p1["y"])
        x2, y2 = px(p2["x"]), py(p2["y"])
        c.setStrokeColor(ARROW_COLOR)
        c.setLineWidth(1.8)
        c.setDash([])
        c.line(x1, y1, x2, y2)
        angle = math.atan2(y2 - y1, x2 - x1)
        _draw_arrowhead(c, x2, y2, angle, ARROW_COLOR)

    # Cones
    for obj in objects:
        if obj.object_type != "cone" or not obj.coordinates:
            continue
        p = obj.coordinates[0]
        _draw_cone(c, px(p["x"]), py(p["y"]))

    # Text annotations
    c.setFont(FONT_REGULAR, 6)
    for obj in objects:
        if obj.object_type != "text" or not obj.coordinates or not obj.label:
            continue
        p = obj.coordinates[0]
        x, y = px(p["x"]), py(p["y"])
        text_w = max(16, len(obj.label) * 3.4)
        c.setFillColor(TEXT_CHIP_BG)
        c.roundRect(x - 2, y - 5, text_w, 9, 2, fill=1, stroke=0)
        c.setFillColor(colors.white)
        c.drawString(x, y - 2.5, obj.label)

    # Player markers (drawn last, on top)
    for obj in objects:
        if obj.object_type != "player" or not obj.coordinates:
            continue
        p = obj.coordinates[0]
        x, y = px(p["x"]), py(p["y"])
        has_player = bool(obj.player_name)
        c.setFillColor(MARKER_FILL if has_player else MARKER_EMPTY)
        c.setStrokeColor(colors.HexColor("#0A0F0D"))
        c.setLineWidth(0.6)
        c.circle(x, y, 8, fill=1, stroke=1)
        number = obj.label or (str(obj.player_number) if obj.player_number is not None else "?")
        c.setFillColor(colors.white if has_player else colors.HexColor("#555555"))
        c.setFont(FONT_BOLD, 7)
        c.drawCentredString(x, y - 2.5, str(number))
        if obj.player_name:
            c.setFillColor(colors.HexColor("#0A0F0D"))
            c.setFont(FONT_REGULAR, 5.5)
            last_name = obj.player_name.split()[-1]
            c.drawCentredString(x, y - 15, last_name)

    # --- Σύνθεση list below the pitch -----------------------------------------
    list_y = pitch_bottom_y - 20
    players_in_lineup = [o for o in objects if o.object_type == "player" and o.player_name]
    if players_in_lineup:
        c.setFillColor(colors.HexColor("#0A0F0D"))
        c.setFont(FONT_BOLD, 10)
        c.drawString(margin, list_y, "Σύνθεση")
        list_y -= 14
        c.setFont(FONT_REGULAR, 8.5)
        col_x = [margin, margin + 170]
        col = 0
        row_start_y = list_y
        for i, o in enumerate(players_in_lineup):
            number = f"#{o.player_number}" if o.player_number is not None else "-"
            line = f"{number}  {o.player_name}"
            c.drawString(col_x[col], row_start_y, line)
            if col == 0:
                col = 1
            else:
                col = 0
                row_start_y -= 12
            if row_start_y < margin + 30:
                break
        list_y = row_start_y - 20

    if board.notes:
        c.setFont(FONT_BOLD, 10)
        c.setFillColor(colors.HexColor("#0A0F0D"))
        c.drawString(margin, list_y, "Σημειώσεις")
        list_y -= 13
        c.setFont(FONT_REGULAR, 8.5)
        c.setFillColor(colors.HexColor("#333333"))
        for line in _wrap_text(board.notes, 95):
            c.drawString(margin, list_y, line)
            list_y -= 11
            if list_y < margin:
                break

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.read()


def _wrap_text(text: str, width: int) -> list:
    words = text.split()
    lines: list = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) > width:
            if current:
                lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


# ---------------------------------------------------------------------------
# Scout Report PDF
# ---------------------------------------------------------------------------
STAR_FULL = "\u2605"  # ★
STAR_EMPTY = "\u2606"  # ☆

_STRONG_FOOT_LABELS = {"right": "Δεξί", "left": "Αριστερό", "both": "Και τα δύο"}


def _stars(value) -> str:
    value = value or 0
    return STAR_FULL * value + STAR_EMPTY * (5 - value)


class AttributeBarFlowable(Flowable):
    """Οριζόντια μπάρα βαθμολογίας 1-10 με ετικέτα αριστερά και αριθμό
    δεξιά — ίδια οπτική λογική με τα sliders της εφαρμογής."""

    def __init__(self, label: str, value: int, width: float = 470, height: float = 14, max_value: int = 10):
        Flowable.__init__(self)
        self.label = label
        self.value = value
        self.max_value = max_value
        self.width = width
        self.height = height

    def wrap(self, avail_width, avail_height):
        return (self.width, self.height + 5)

    def draw(self):
        c = self.canv
        label_w = 150
        bar_x = label_w
        bar_w = self.width - label_w - 34
        c.setFont(FONT_REGULAR, 8.5)
        c.setFillColor(DARK)
        c.drawString(0, 3, self.label)
        c.setFillColor(colors.HexColor("#E1E6E3"))
        c.roundRect(bar_x, 1, bar_w, 10, 2, fill=1, stroke=0)
        fill_w = max(2, bar_w * (self.value / self.max_value))
        c.setFillColor(CHALK)
        c.roundRect(bar_x, 1, fill_w, 10, 2, fill=1, stroke=0)
        c.setFont(FONT_BOLD, 8.5)
        c.setFillColor(DARK)
        c.drawString(bar_x + bar_w + 6, 3, f"{self.value}/{self.max_value}")


def _scout_report_footer(canvas_obj, doc):
    canvas_obj.saveState()
    canvas_obj.setFont(FONT_BOLD, 8)
    canvas_obj.setFillColor(colors.HexColor("#9AA69E"))
    canvas_obj.drawRightString(A4[0] - 16 * mm, 10 * mm, "FootballHub")
    canvas_obj.restoreState()


def generate_scout_report_pdf(report) -> bytes:
    """report: ScoutReportOut (full_name, club_name, age, position, role,
    league, jersey_number, nationality, strong_foot, goals_per_season,
    photo_path, positive/negative/physical_mental rating+notes,
    detailed_attributes dict, conclusion_text, recommended, potential_rating,
    created_by_name)."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=16 * mm,
        bottomMargin=20 * mm,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "ScoutTitle", parent=styles["Title"], textColor=DARK, fontSize=18, spaceAfter=2, fontName=FONT_BOLD
    )
    subtitle_style = ParagraphStyle(
        "ScoutSubtitle", parent=styles["Normal"], textColor=MUTED, fontSize=10, spaceAfter=10, fontName=FONT_REGULAR
    )
    section_style = ParagraphStyle(
        "ScoutSection", parent=styles["Heading2"], textColor=PITCH_GREEN, spaceBefore=14, spaceAfter=6,
        fontName=FONT_BOLD, fontSize=12,
    )
    body_style = ParagraphStyle(
        "ScoutBody", parent=styles["Normal"], fontSize=9.5, leading=13, fontName=FONT_REGULAR
    )
    stars_style = ParagraphStyle(
        "ScoutStars", parent=styles["Normal"], fontSize=13, textColor=colors.HexColor("#D9A62E"),
        fontName=FONT_REGULAR, spaceAfter=4,
    )

    elements = []

    header_cells = []
    if report.photo_path:
        try:
            filename = report.photo_path.rsplit("/", 1)[-1]
            photo_fs_path = SCOUT_REPORT_PHOTOS_DIR / filename
            if photo_fs_path.exists():
                img = Image(str(photo_fs_path), width=32 * mm, height=32 * mm)
                header_cells.append(img)
        except Exception:
            pass

    title_block = [
        Paragraph("FootballHub — Scout Report", title_style),
        Paragraph(report.full_name, ParagraphStyle("NameFH", parent=title_style, fontSize=14, spaceAfter=2)),
    ]
    subtitle_bits = [x for x in [report.club_name, report.position, report.league] if x]
    title_block.append(Paragraph(" · ".join(subtitle_bits) or "—", subtitle_style))

    if header_cells:
        header_table = Table([[header_cells[0], title_block]], colWidths=[36 * mm, None])
        header_table.setStyle(
            TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (0, 0), 0)])
        )
        elements.append(header_table)
    else:
        elements.extend(title_block)

    elements.append(Spacer(1, 8))

    info_rows = [
        ["Ηλικία", str(report.age) if report.age is not None else "—", "Νούμερο", str(report.jersey_number) if report.jersey_number is not None else "—"],
        ["Εθνικότητα", report.nationality or "—", "Δυνατό Πόδι", _STRONG_FOOT_LABELS.get(report.strong_foot, "—")],
        ["Γκολ/Σεζόν", str(report.goals_per_season) if report.goals_per_season is not None else "—", "Ρόλος", report.role or "—"],
        ["Scout", report.created_by_name or "—", "Ημ/νία", report.created_at.strftime("%d/%m/%Y") if report.created_at else "—"],
    ]
    info_table = Table(info_rows, colWidths=[30 * mm, 62 * mm, 30 * mm, 56 * mm])
    info_table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (0, -1), FONT_BOLD),
                ("FONTNAME", (2, 0), (2, -1), FONT_BOLD),
                ("FONTNAME", (1, 0), (1, -1), FONT_REGULAR),
                ("FONTNAME", (3, 0), (3, -1), FONT_REGULAR),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("TEXTCOLOR", (0, 0), (0, -1), MUTED),
                ("TEXTCOLOR", (2, 0), (2, -1), MUTED),
                ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#DDDDDD")),
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F2F5F3")),
                ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#F2F5F3")),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
        )
    )
    elements.append(info_table)

    if report.positive_rating or report.positive_notes:
        elements.append(Paragraph("Θετικά Στοιχεία", section_style))
        elements.append(Paragraph(_stars(report.positive_rating), stars_style))
        if report.positive_notes:
            elements.append(Paragraph(report.positive_notes, body_style))

    if report.negative_rating or report.negative_notes:
        elements.append(Paragraph("Αρνητικά Στοιχεία", section_style))
        elements.append(Paragraph(_stars(report.negative_rating), stars_style))
        if report.negative_notes:
            elements.append(Paragraph(report.negative_notes, body_style))

    if report.physical_mental_rating or report.physical_mental_notes:
        elements.append(Paragraph("Φυσική & Ψυχολογική Κατάσταση", section_style))
        elements.append(Paragraph(_stars(report.physical_mental_rating), stars_style))
        if report.physical_mental_notes:
            elements.append(Paragraph(report.physical_mental_notes, body_style))

    if report.detailed_attributes:
        elements.append(Paragraph("Αναλυτική Βαθμολόγηση", section_style))
        for label, value in report.detailed_attributes.items():
            elements.append(AttributeBarFlowable(label, value))
            elements.append(Spacer(1, 3))

    elements.append(Paragraph("Συμπέρασμα", section_style))
    if report.conclusion_text:
        elements.append(Paragraph(report.conclusion_text, body_style))
        elements.append(Spacer(1, 6))

    verdict_bits = []
    if report.recommended is True:
        verdict_bits.append("<b>✔ Recommended</b>")
    elif report.recommended is False:
        verdict_bits.append("<b>✘ Not Recommended</b>")
    if report.potential_rating is not None:
        verdict_bits.append(f"<b>Potential: {report.potential_rating}/10</b>")
    if verdict_bits:
        elements.append(Paragraph("&nbsp;&nbsp;·&nbsp;&nbsp;".join(verdict_bits), ParagraphStyle(
            "VerdictFH", parent=body_style, fontSize=11, textColor=PITCH_GREEN, spaceBefore=4
        )))

    doc.build(elements, onFirstPage=_scout_report_footer, onLaterPages=_scout_report_footer)
    buffer.seek(0)
    return buffer.read()
