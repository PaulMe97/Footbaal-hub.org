"""
Runtime-configurable settings, αποθηκευμένα στη βάση (πίνακας app_settings)
ώστε να μπορούν να αλλάξουν από το UI (π.χ. Ρυθμίσεις -> AI) χωρίς να
χρειάζεται επεξεργασία του .env αρχείου. Αν δεν υπάρχει τιμή στη βάση,
γίνεται fallback στις τιμές του .env (app.config).
"""
from sqlalchemy.orm import Session

from app.models import AppSetting
from app.services.crypto_service import decrypt, encrypt

# Κλειδιά που περιέχουν ευαίσθητα διαπιστευτήρια (κλειδιά API τρίτων
# προγραμμάτων) — κρυπτογραφούνται πάντα πριν την αποθήκευση στη βάση.
SENSITIVE_SETTING_KEYS = {
    "ai_api_key",
    "s3_access_key_id",
    "s3_secret_access_key",
    "hcaptcha_secret_key",
    "smtp_password",
}


def get_setting(db: Session, key: str) -> str | None:
    row = db.query(AppSetting).filter(AppSetting.key == key).first()
    if not row or row.value is None:
        return None
    if key in SENSITIVE_SETTING_KEYS:
        return decrypt(row.value)
    return row.value


def set_setting(db: Session, key: str, value: str | None) -> None:
    stored_value = value
    if value is not None and key in SENSITIVE_SETTING_KEYS:
        stored_value = encrypt(value)
    row = db.query(AppSetting).filter(AppSetting.key == key).first()
    if row:
        row.value = stored_value
    else:
        row = AppSetting(key=key, value=stored_value)
        db.add(row)
    db.commit()


def get_ai_config(db: Session) -> tuple[str, str, str]:
    """Επιστρέφει (provider, api_key, model). Προτεραιότητα στις τιμές της
    βάσης (ρυθμισμένες από το UI), αλλιώς fallback στο .env."""
    from app.config import AI_API_KEY, AI_MODEL, AI_PROVIDER

    provider = get_setting(db, "ai_provider") or AI_PROVIDER
    api_key = get_setting(db, "ai_api_key") or AI_API_KEY
    model = get_setting(db, "ai_model") or AI_MODEL
    return provider, api_key, model


def get_s3_config(db: Session) -> dict:
    """Ρυθμίσεις του S3-συμβατού 3ου προγράμματος αποθήκευσης για τα βίντεο
    (AWS S3, Cloudflare R2, Backblaze B2, MinIO κ.λπ.) — ρυθμίζονται από τον
    admin στις Ρυθμίσεις, ίδιο μοτίβο με το AI Configuration. Επιστρέφει τα
    πεδία ως dict· κενό string αν κάποιο δεν έχει ρυθμιστεί ακόμα."""
    return {
        "endpoint_url": get_setting(db, "s3_endpoint_url") or "",
        "bucket_name": get_setting(db, "s3_bucket_name") or "",
        "access_key_id": get_setting(db, "s3_access_key_id") or "",
        "secret_access_key": get_setting(db, "s3_secret_access_key") or "",
        "region": get_setting(db, "s3_region") or "auto",
    }
