import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import assert_team_id_access, owned_team_ids, require_write_access
from app.database import get_db
from app.services.http_utils import content_disposition_filename
from app.models import Player, TacticalBoard, TacticalObject, Team, TrainingSession, User
from app.schemas import (
    TacticalBoardCreate,
    TacticalBoardDetailOut,
    TacticalBoardListOut,
    TacticalBoardUpdate,
    TacticalObjectIn,
    TacticalObjectOut,
)
from app.services import pdf_service

router = APIRouter(prefix="/api/tactical-boards", tags=["tactical"])


def _list_out(board: TacticalBoard, db: Session) -> TacticalBoardListOut:
    team_name = None
    if board.team_id:
        team = db.query(Team).filter(Team.id == board.team_id).first()
        team_name = team.name if team else None
    training_label = None
    if board.training_session_id:
        training = db.query(TrainingSession).filter(TrainingSession.id == board.training_session_id).first()
        if training:
            training_label = f"Προπόνηση {training.date}"
    count = db.query(TacticalObject).filter(TacticalObject.board_id == board.id).count()
    out = TacticalBoardListOut.model_validate(board)
    out.team_name = team_name
    out.training_label = training_label
    out.object_count = count
    return out


def _object_out(obj: TacticalObject, players_by_id: dict) -> TacticalObjectOut:
    player = players_by_id.get(obj.player_id) if obj.player_id else None
    try:
        coords = json.loads(obj.coordinates_json) if obj.coordinates_json else []
    except (TypeError, ValueError):
        coords = []
    return TacticalObjectOut(
        id=obj.id,
        object_type=obj.object_type,
        player_id=obj.player_id,
        player_name=f"{player.first_name} {player.last_name}" if player else None,
        player_number=player.player_number if player else None,
        coordinates=coords,
        color=obj.color,
        label=obj.label,
    )


def _detail_out(board: TacticalBoard, db: Session) -> TacticalBoardDetailOut:
    base = _list_out(board, db)
    objects = db.query(TacticalObject).filter(TacticalObject.board_id == board.id).all()
    player_ids = [o.player_id for o in objects if o.player_id]
    players_by_id = {}
    if player_ids:
        for p in db.query(Player).filter(Player.id.in_(player_ids)).all():
            players_by_id[p.id] = p
    return TacticalBoardDetailOut(
        **base.model_dump(),
        objects=[_object_out(o, players_by_id) for o in objects],
    )


@router.get("", response_model=list[TacticalBoardListOut])
def list_boards(
    team_id: Optional[str] = None,
    match_id: Optional[str] = None,
    training_session_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(TacticalBoard)
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(TacticalBoard.team_id.in_(owned_ids))
    if team_id:
        query = query.filter(TacticalBoard.team_id == team_id)
    if match_id:
        query = query.filter(TacticalBoard.match_id == match_id)
    if training_session_id:
        query = query.filter(TacticalBoard.training_session_id == training_session_id)
    boards = query.order_by(TacticalBoard.updated_at.desc()).all()
    return [_list_out(b, db) for b in boards]


@router.post("", response_model=TacticalBoardDetailOut, status_code=201)
def create_board(
    payload: TacticalBoardCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    assert_team_id_access(db, current_user, payload.team_id, "Η ομάδα δεν βρέθηκε")
    board = TacticalBoard(**payload.model_dump())
    db.add(board)
    db.commit()
    db.refresh(board)
    return _detail_out(board, db)


@router.get("/{board_id}", response_model=TacticalBoardDetailOut)
def get_board(
    board_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    board = db.query(TacticalBoard).filter(TacticalBoard.id == board_id).first()
    if not board:
        raise HTTPException(status_code=404, detail="Το tactical board δεν βρέθηκε")
    assert_team_id_access(db, current_user, board.team_id, "Το tactical board δεν βρέθηκε")
    return _detail_out(board, db)


@router.put("/{board_id}", response_model=TacticalBoardDetailOut)
def update_board(
    board_id: str,
    payload: TacticalBoardUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    board = db.query(TacticalBoard).filter(TacticalBoard.id == board_id).first()
    if not board:
        raise HTTPException(status_code=404, detail="Το tactical board δεν βρέθηκε")
    assert_team_id_access(db, current_user, board.team_id, "Το tactical board δεν βρέθηκε")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(board, field, value)
    db.commit()
    db.refresh(board)
    return _detail_out(board, db)


@router.delete("/{board_id}", status_code=204)
def delete_board(
    board_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    board = db.query(TacticalBoard).filter(TacticalBoard.id == board_id).first()
    if not board:
        raise HTTPException(status_code=404, detail="Το tactical board δεν βρέθηκε")
    assert_team_id_access(db, current_user, board.team_id, "Το tactical board δεν βρέθηκε")
    db.delete(board)
    db.commit()
    return None


@router.put("/{board_id}/objects", response_model=TacticalBoardDetailOut)
def save_objects(
    board_id: str,
    payload: list[TacticalObjectIn],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Αντικαθιστά ΟΛΑ τα objects του board με τη νέα λίστα (canvas-style save)."""
    board = db.query(TacticalBoard).filter(TacticalBoard.id == board_id).first()
    if not board:
        raise HTTPException(status_code=404, detail="Το tactical board δεν βρέθηκε")
    assert_team_id_access(db, current_user, board.team_id, "Το tactical board δεν βρέθηκε")

    db.query(TacticalObject).filter(TacticalObject.board_id == board_id).delete()
    for item in payload:
        db.add(
            TacticalObject(
                board_id=board_id,
                object_type=item.object_type,
                player_id=item.player_id,
                coordinates_json=json.dumps(item.coordinates),
                color=item.color,
                label=item.label,
            )
        )
    db.commit()
    db.refresh(board)
    return _detail_out(board, db)


@router.get("/{board_id}/export/pdf")
def export_board_pdf(
    board_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    board = db.query(TacticalBoard).filter(TacticalBoard.id == board_id).first()
    if not board:
        raise HTTPException(status_code=404, detail="Το tactical board δεν βρέθηκε")
    assert_team_id_access(db, current_user, board.team_id, "Το tactical board δεν βρέθηκε")
    detail = _detail_out(board, db)
    pdf_bytes = pdf_service.generate_tactical_board_pdf(detail)
    filename = f"tactical-board-{board.name.replace(' ', '-')}.pdf"
    return StreamingResponse(
        iter([pdf_bytes]),
        media_type="application/pdf",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
