import uuid
from datetime import date
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import assert_player_access, assert_team_access, owned_team_ids, require_write_access
from app.config import ALLOWED_IMAGE_TYPES, MAX_UPLOAD_SIZE_MB, PLAYER_PHOTOS_DIR
from app.database import get_db
from app.models import (
    Injury,
    InjuryStatus,
    Match,
    MatchPlayer,
    NotificationType,
    Player,
    PlayerAbsence,
    PlayerAttributes,
    PlayerPosition,
    PlayerStatistics,
    PlayerStatus,
    Team,
    User,
)
from app.schemas import (
    InjuryOut,
    InjuryUpdate,
    MatchHistoryEntry,
    PlayerAttributesOut,
    PlayerAttributesUpdate,
    PlayerCreate,
    PlayerOut,
    PlayerStatisticsIncrement,
    PlayerStatisticsOut,
    PlayerStatisticsUpdate,
    PlayerUpdate,
    TransferStatusUpdate,
)
from app.services.notifications import notify_team

router = APIRouter(prefix="/api/players", tags=["players"])


@router.get("/{player_id}/linked-user")
def get_linked_user(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    """Επιστρέφει το user_id του λογαριασμού που είναι συνδεδεμένος με αυτόν
    τον παίκτη (αν υπάρχει) — χρησιμοποιείται όταν Πρόεδρος/Τεχνικός
    Διευθυντής θέλει να στείλει προσφορά μετατροπής σε staff ρόλο."""
    linked = db.query(User.id).filter(User.linked_player_id == player_id).first()
    return {"user_id": linked[0] if linked else None}


def _calc_age(dob: Optional[date]) -> Optional[int]:
    if not dob:
        return None
    today = date.today()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def _to_out(player: Player, stats_map: Optional[dict] = None) -> PlayerOut:
    out = PlayerOut.model_validate(player)
    out.age = _calc_age(player.date_of_birth)
    out.team_name = player.current_team.name if player.current_team else None
    if stats_map is not None:
        s = stats_map.get(player.id)
        if s:
            out.goals = s.goals
            out.matches_played = s.matches_played
    return out


@router.get("", response_model=list[PlayerOut])
def list_players(
    search: Optional[str] = None,
    team_id: Optional[str] = None,
    position: Optional[PlayerPosition] = None,
    status: Optional[PlayerStatus] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Player)
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(Player.current_team_id.in_(owned_ids))
    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(Player.first_name.ilike(like), Player.last_name.ilike(like))
        )
    if team_id:
        query = query.filter(Player.current_team_id == team_id)
    if position:
        query = query.filter(Player.position == position)
    if status:
        query = query.filter(Player.status == status)
    players = query.order_by(Player.last_name).all()
    stats_rows = (
        db.query(PlayerStatistics)
        .filter(
            PlayerStatistics.player_id.in_([p.id for p in players]),
            PlayerStatistics.season.is_(None),
        )
        .all()
        if players
        else []
    )
    stats_map = {s.player_id: s for s in stats_rows}
    return [_to_out(p, stats_map) for p in players]


@router.post("", response_model=PlayerOut, status_code=201)
def create_player(
    payload: PlayerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if payload.current_team_id:
        team = db.query(Team).filter(Team.id == payload.current_team_id).first()
        if not team:
            raise HTTPException(status_code=400, detail="Η ομάδα δεν βρέθηκε")
        assert_team_access(db, current_user, team)
    player = Player(**payload.model_dump())
    db.add(player)
    db.commit()
    db.refresh(player)
    return _to_out(player)


@router.get("/{player_id}", response_model=PlayerOut)
def get_player(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    return _to_out(player)


def _ensure_active_absence(db: Session, player: Player, reason: str, created_by: Optional[str]) -> None:
    """Αν ο παίκτης δεν έχει ήδη ενεργή απουσία, δημιουργεί μία αυτόματα —
    ώστε η αλλαγή status (π.χ. από το γρήγορο μενού στη λίστα Παικτών) να
    εμφανίζεται αμέσως και στην ενότητα «Τραυματισμοί / Απουσίες», χωρίς
    διπλή χειροκίνητη καταχώρηση."""
    today = date.today()
    existing = (
        db.query(PlayerAbsence)
        .filter(
            PlayerAbsence.player_id == player.id,
            or_(PlayerAbsence.end_date.is_(None), PlayerAbsence.end_date >= today),
        )
        .first()
    )
    if existing:
        return
    db.add(
        PlayerAbsence(
            player_id=player.id,
            team_id=player.current_team_id,
            reason=reason,
            start_date=today,
            created_by=created_by,
        )
    )
    db.commit()


def _close_active_absences(db: Session, player_id: str) -> None:
    """Κλείνει (end_date = σήμερα) όλες τις ενεργές απουσίες ενός παίκτη —
    καλείται όταν το status επιστρέφει σε Διαθέσιμος/Αμφίβολος, ώστε η
    ενότητα «Τραυματισμοί / Απουσίες» να μένει συγχρονισμένη."""
    today = date.today()
    active = (
        db.query(PlayerAbsence)
        .filter(
            PlayerAbsence.player_id == player_id,
            or_(PlayerAbsence.end_date.is_(None), PlayerAbsence.end_date >= today),
        )
        .all()
    )
    for absence in active:
        absence.end_date = today
    if active:
        db.commit()


def mark_player_injured(
    db: Session,
    player: Player,
    injury_type: Optional[str] = None,
    injury_date: Optional[date] = None,
    expected_return: Optional[date] = None,
    notes: Optional[str] = None,
) -> None:
    """Θέτει status=Τραυματίας και δημιουργεί Injury record — κοινή λογική
    ώστε να συμπεριφέρεται ίδια είτε προέρχεται από την επεξεργασία παίκτη
    είτε από το «Τραυματίας» στις παρουσίες προπόνησης (βλ.
    routers/trainings.py set_attendance) — μία μόνο πηγή αλήθειας.
    Ο καλών πρέπει να έχει ήδη ελέγξει ότι ο παίκτης δεν είναι ήδη
    Τραυματίας, ώστε να μη δημιουργούνται διπλές εγγραφές Injury."""
    player.status = PlayerStatus.INJURED
    resolved_type = injury_type if injury_type is not None else player.injury_type
    resolved_date = injury_date or player.injury_date or date.today()
    resolved_return = expected_return if expected_return is not None else player.expected_return
    resolved_notes = notes if notes is not None else player.medical_notes
    player.injury_type = resolved_type
    player.injury_date = resolved_date
    player.expected_return = resolved_return
    db.add(
        Injury(
            player_id=player.id,
            injury_type=resolved_type,
            status=InjuryStatus.ACTIVE,
            injury_date=resolved_date,
            expected_return=resolved_return,
            notes=resolved_notes,
        )
    )
    db.commit()
    notify_team(
        db,
        player.current_team_id,
        NotificationType.PLAYER_INJURY,
        title=f"Τραυματισμός: {player.first_name} {player.last_name}",
        message=resolved_type or "Καταγράφηκε νέος τραυματισμός",
        related_entity_type="player",
        related_entity_id=player.id,
    )


@router.put("/{player_id}", response_model=PlayerOut)
def update_player(
    player_id: str,
    payload: PlayerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    previous_status = player.status
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(player, field, value)
    db.commit()
    db.refresh(player)

    if previous_status != PlayerStatus.INJURED and player.status == PlayerStatus.INJURED:
        mark_player_injured(db, player)
    elif previous_status == PlayerStatus.INJURED and player.status == PlayerStatus.FIT:
        open_injury = (
            db.query(Injury)
            .filter(Injury.player_id == player.id, Injury.status == InjuryStatus.ACTIVE)
            .order_by(Injury.injury_date.desc())
            .first()
        )
        if open_injury:
            open_injury.status = InjuryStatus.RECOVERED
            open_injury.actual_return = date.today()
            db.commit()
        notify_team(
            db,
            player.current_team_id,
            NotificationType.PLAYER_RETURN,
            title=f"Επιστροφή από τραυματισμό: {player.first_name} {player.last_name}",
            related_entity_type="player",
            related_entity_id=player.id,
        )

    # Απουσίες (κόκκινη κάρτα/ποινή, μη διαθέσιμος κ.λπ.) — αμφίδρομη
    # σύνδεση με την ενότητα «Τραυματισμοί / Απουσίες». Δεν αγγίζουμε τον
    # τραυματισμό εδώ, τον διαχειρίζεται ήδη το παραπάνω, πιο λεπτομερές
    # μπλοκ (Injury).
    if previous_status != PlayerStatus.SUSPENDED and player.status == PlayerStatus.SUSPENDED:
        _ensure_active_absence(db, player, reason="suspension", created_by=current_user.id)
    elif previous_status != PlayerStatus.UNAVAILABLE and player.status == PlayerStatus.UNAVAILABLE:
        _ensure_active_absence(db, player, reason="other", created_by=current_user.id)
    elif previous_status in (PlayerStatus.SUSPENDED, PlayerStatus.UNAVAILABLE) and player.status not in (
        PlayerStatus.SUSPENDED,
        PlayerStatus.UNAVAILABLE,
    ):
        _close_active_absences(db, player.id)

    return _to_out(player)


@router.delete("/{player_id}", status_code=204)
def delete_player(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    db.delete(player)
    db.commit()
    return None


@router.post("/{player_id}/photo", response_model=PlayerOut)
def upload_photo(
    player_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail="Επιτρέπονται μόνο JPG, PNG ή WEBP αρχεία")

    contents = file.file.read()
    if len(contents) > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"Το αρχείο ξεπερνά τα {MAX_UPLOAD_SIZE_MB}MB")

    ext = Path(file.filename).suffix or ".png"
    filename = f"{uuid.uuid4()}{ext}"
    dest = PLAYER_PHOTOS_DIR / filename
    dest.write_bytes(contents)

    player.photo_path = f"/media/players/{filename}"
    db.commit()
    db.refresh(player)
    return _to_out(player)


@router.delete("/{player_id}/photo", response_model=PlayerOut)
def delete_photo(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    player.photo_path = None
    db.commit()
    db.refresh(player)
    return _to_out(player)


# ---------------------------------------------------------------------------
# Player statistics (quick stats: matches, goals, cards)
# ---------------------------------------------------------------------------
INCREMENTABLE_FIELDS = {"matches_played", "goals", "assists", "yellow_cards", "red_cards"}


def _get_or_create_stats(db: Session, player: Player) -> PlayerStatistics:
    stats = (
        db.query(PlayerStatistics)
        .filter(PlayerStatistics.player_id == player.id, PlayerStatistics.season.is_(None))
        .first()
    )
    if not stats:
        stats = PlayerStatistics(player_id=player.id, team_id=player.current_team_id, season=None)
        db.add(stats)
        db.commit()
        db.refresh(stats)
    return stats


@router.get("/{player_id}/statistics", response_model=PlayerStatisticsOut)
def get_player_statistics(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    stats = _get_or_create_stats(db, player)

    # avg_rating δεν αποθηκεύεται στο PlayerStatistics — υπολογίζεται από
    # τα rating του Match Rating (MatchPlayer) του τρέχοντος έτους, ίδιο
    # pattern με το Scouting Hub (βλ. routers/scouting.py _season_stats).
    current_year = date.today().year
    rating_rows = (
        db.query(MatchPlayer.rating)
        .join(Match, MatchPlayer.match_id == Match.id)
        .filter(
            MatchPlayer.player_id == player_id,
            Match.date >= date(current_year, 1, 1),
            MatchPlayer.rating.isnot(None),
        )
        .all()
    )
    ratings = [r[0] for r in rating_rows]

    result = PlayerStatisticsOut.model_validate(stats)
    result.avg_rating = round(sum(ratings) / len(ratings), 1) if ratings else None
    return result


@router.put("/{player_id}/statistics", response_model=PlayerStatisticsOut)
def update_player_statistics(
    player_id: str,
    payload: PlayerStatisticsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    stats = _get_or_create_stats(db, player)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(stats, field, max(0, value) if isinstance(value, int) else value)
    db.commit()
    db.refresh(stats)
    return stats


@router.post("/{player_id}/statistics/increment", response_model=PlayerStatisticsOut)
def increment_player_statistic(
    player_id: str,
    payload: PlayerStatisticsIncrement,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if payload.field not in INCREMENTABLE_FIELDS:
        raise HTTPException(status_code=400, detail=f"Μη έγκυρο πεδίο: {payload.field}")
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    stats = _get_or_create_stats(db, player)
    current_value = getattr(stats, payload.field)
    setattr(stats, payload.field, max(0, current_value + payload.delta))
    db.commit()
    db.refresh(stats)
    return stats


# ---------------------------------------------------------------------------
# Injury history
# ---------------------------------------------------------------------------
@router.get("/{player_id}/injuries", response_model=list[InjuryOut])
def list_player_injuries(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    return (
        db.query(Injury)
        .filter(Injury.player_id == player_id)
        .order_by(Injury.injury_date.desc())
        .all()
    )


@router.put("/{player_id}/injuries/{injury_id}", response_model=InjuryOut)
def update_player_injury(
    player_id: str,
    injury_id: str,
    payload: InjuryUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    injury = (
        db.query(Injury)
        .filter(Injury.id == injury_id, Injury.player_id == player_id)
        .first()
    )
    if not injury:
        raise HTTPException(status_code=404, detail="Η καταγραφή τραυματισμού δεν βρέθηκε")
    data = payload.model_dump(exclude_unset=True)
    if "status" in data and data["status"] is not None:
        data["status"] = InjuryStatus(data["status"])
    for field, value in data.items():
        setattr(injury, field, value)

    # Αν ο τραυματισμός γίνεται «Αποθεραπευμένος» και ο παίκτης δεν έχει
    # άλλον ενεργό τραυματισμό, γύρνα το status του παίκτη σε Διαθέσιμος —
    # ίδια λογική συγχρονισμού με το _close_active_absences (βλ. πάνω).
    if injury.status == InjuryStatus.RECOVERED and player.status == PlayerStatus.INJURED:
        other_active = (
            db.query(Injury)
            .filter(
                Injury.player_id == player_id,
                Injury.id != injury.id,
                Injury.status.in_([InjuryStatus.ACTIVE, InjuryStatus.RECOVERING]),
            )
            .first()
        )
        if not other_active:
            player.status = PlayerStatus.FIT
            _close_active_absences(db, player_id)

    db.commit()
    db.refresh(injury)
    return injury


@router.delete("/{player_id}/injuries/{injury_id}", status_code=204)
def delete_player_injury(
    player_id: str,
    injury_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    injury = (
        db.query(Injury)
        .filter(Injury.id == injury_id, Injury.player_id == player_id)
        .first()
    )
    if not injury:
        raise HTTPException(status_code=404, detail="Η καταγραφή τραυματισμού δεν βρέθηκε")
    db.delete(injury)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Match history (για trend charts: rating/γκολ ανά αγώνα)
# ---------------------------------------------------------------------------
@router.get("/{player_id}/match-history", response_model=list[MatchHistoryEntry])
def get_player_match_history(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    rows = (
        db.query(MatchPlayer, Match)
        .join(Match, MatchPlayer.match_id == Match.id)
        .filter(MatchPlayer.player_id == player_id)
        .order_by(Match.date.asc())
        .all()
    )
    entries = []
    for mp, match in rows:
        home_name = match.home_team_name_external
        away_name = match.away_team_name_external
        if not home_name and match.home_team_id:
            t = db.query(Team).filter(Team.id == match.home_team_id).first()
            home_name = t.name if t else None
        if not away_name and match.away_team_id:
            t = db.query(Team).filter(Team.id == match.away_team_id).first()
            away_name = t.name if t else None
        entries.append(
            MatchHistoryEntry(
                match_id=match.id,
                date=match.date,
                opponent=f"{home_name or '—'} vs {away_name or '—'}",
                rating=mp.rating,
                goals=mp.goals,
                assists=mp.assists,
            )
        )
    return entries


# ---------------------------------------------------------------------------
# Scouting attributes (FM-style, 1.0-10.0) — μόνο ο coach τα ρυθμίζει
# ---------------------------------------------------------------------------
@router.get("/{player_id}/attributes", response_model=PlayerAttributesOut)
def get_player_attributes(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    attrs = db.query(PlayerAttributes).filter(PlayerAttributes.player_id == player_id).first()
    if not attrs:
        return PlayerAttributesOut()
    return attrs


@router.put("/{player_id}/attributes", response_model=PlayerAttributesOut)
def update_player_attributes(
    player_id: str,
    payload: PlayerAttributesUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    attrs = db.query(PlayerAttributes).filter(PlayerAttributes.player_id == player_id).first()
    if not attrs:
        attrs = PlayerAttributes(player_id=player_id)
        db.add(attrs)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(attrs, field, value)
    db.commit()
    db.refresh(attrs)
    return attrs


# ---------------------------------------------------------------------------
# Transfer status — ο coach μπορεί να το αλλάξει χωρίς περιορισμό
# (το self-service, περιορισμένο endpoint για τον ίδιο τον παίκτη είναι στο
# /api/scouting/self/transfer-status)
# ---------------------------------------------------------------------------
@router.put("/{player_id}/transfer-status", response_model=PlayerOut)
def update_transfer_status(
    player_id: str,
    payload: TransferStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    assert_player_access(db, current_user, player)
    player.transfer_status = payload.transfer_status
    player.transfer_notes = payload.transfer_notes
    db.commit()
    db.refresh(player)
    return _to_out(player)
