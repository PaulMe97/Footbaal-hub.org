import json
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.config import MAX_VIDEO_DURATION_SECONDS, MAX_VIDEO_UPLOAD_SIZE_MB
from app.database import get_db
from app.models import Team, User, VideoAnalysis, VideoAnalysisStatus, VideoAnnotation
from app.permissions import assert_team_access, owned_team_ids, require_write_access, sees_all_data
from app.schemas import VideoAnalysisOut, VideoAnnotationCreate, VideoAnnotationOut, VideoAnnotationUpdate
from app.services import video_storage

router = APIRouter(prefix="/api/video-analysis", tags=["video-analysis"])

ALLOWED_VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/x-msvideo", "video/webm", "video/x-matroska"}


def _to_out(db: Session, video: VideoAnalysis, current_user: User, include_playback_url: bool = False) -> VideoAnalysisOut:
    team = db.query(Team).filter(Team.id == video.team_id).first()
    uploader = db.query(User).filter(User.id == video.uploaded_by).first() if video.uploaded_by else None
    playback_url = None
    if include_playback_url and video.storage_key and video.status == VideoAnalysisStatus.READY.value:
        try:
            playback_url = video_storage.get_playback_url(db, video.storage_key)
        except video_storage.VideoStorageError:
            playback_url = None
    can_edit = (
        sees_all_data(current_user)
        or video.uploaded_by == current_user.id
        or (team is not None and team.owner_id == current_user.id)
    )
    return VideoAnalysisOut(
        id=video.id,
        team_id=video.team_id,
        team_name=team.name if team else None,
        title=video.title,
        description=video.description,
        duration_seconds=video.duration_seconds,
        file_size_bytes=video.file_size_bytes,
        status=video.status,
        uploaded_by=video.uploaded_by,
        uploaded_by_name=(uploader.full_name or uploader.username) if uploader else None,
        created_at=video.created_at,
        updated_at=video.updated_at,
        playback_url=playback_url,
        can_edit=can_edit,
    )


def _get_video_or_404(db: Session, video_id: str) -> VideoAnalysis:
    video = db.query(VideoAnalysis).filter(VideoAnalysis.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Το βίντεο δεν βρέθηκε")
    return video


def _assert_video_team_access(db: Session, current_user: User, video: VideoAnalysis) -> None:
    team = db.query(Team).filter(Team.id == video.team_id).first()
    assert_team_access(db, current_user, team)


@router.get("", response_model=list[VideoAnalysisOut])
def list_videos(
    team_id: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    query = db.query(VideoAnalysis)
    if not sees_all_data(current_user):
        allowed = owned_team_ids(db, current_user) or set()
        query = query.filter(VideoAnalysis.team_id.in_(allowed))
    if team_id:
        query = query.filter(VideoAnalysis.team_id == team_id)
    videos = query.order_by(VideoAnalysis.created_at.desc()).all()
    return [_to_out(db, v, current_user) for v in videos]


@router.post("/upload", response_model=VideoAnalysisOut, status_code=201)
def upload_video(
    team_id: str = Form(...),
    title: str = Form(...),
    description: str = Form(""),
    duration_seconds: int = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    assert_team_access(db, current_user, team)

    if duration_seconds > MAX_VIDEO_DURATION_SECONDS:
        raise HTTPException(
            status_code=400,
            detail=f"Το βίντεο ξεπερνά το όριο των {MAX_VIDEO_DURATION_SECONDS // 60} λεπτών.",
        )
    if file.content_type not in ALLOWED_VIDEO_TYPES:
        raise HTTPException(status_code=400, detail="Μη υποστηριζόμενος τύπος αρχείου βίντεο")
    if not video_storage.is_configured(db):
        raise HTTPException(
            status_code=503,
            detail=(
                "Δεν έχει ρυθμιστεί ακόμα το 3ο πρόγραμμα αποθήκευσης βίντεο — "
                "ζήτησε από τον admin να το ρυθμίσει στις Ρυθμίσεις."
            ),
        )

    video = VideoAnalysis(
        team_id=team_id,
        title=title,
        description=description or None,
        duration_seconds=duration_seconds,
        status=VideoAnalysisStatus.UPLOADING.value,
        uploaded_by=current_user.id,
    )
    db.add(video)
    db.commit()
    db.refresh(video)

    ext = (file.filename or "video.mp4").rsplit(".", 1)[-1].lower()
    if len(ext) > 5:
        ext = "mp4"
    storage_key = f"video-analysis/{team_id}/{video.id}/{uuid.uuid4()}.{ext}"

    try:
        video_storage.upload_video_stream(db, file.file, storage_key, content_type=file.content_type or "video/mp4")
    except video_storage.VideoStorageError as exc:
        video.status = VideoAnalysisStatus.FAILED.value
        db.commit()
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    try:
        file_size = file.file.tell()
    except Exception:
        file_size = None

    video.storage_key = storage_key
    video.status = VideoAnalysisStatus.READY.value
    video.file_size_bytes = file_size
    db.commit()
    db.refresh(video)
    return _to_out(db, video, current_user)


@router.get("/{video_id}", response_model=VideoAnalysisOut)
def get_video(
    video_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    return _to_out(db, video, current_user, include_playback_url=True)


@router.delete("/{video_id}", status_code=204)
def delete_video(
    video_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    if not (
        sees_all_data(current_user)
        or video.uploaded_by == current_user.id
        or db.query(Team).filter(Team.id == video.team_id, Team.owner_id == current_user.id).first()
    ):
        raise HTTPException(status_code=403, detail="Δεν έχεις δικαίωμα διαγραφής αυτού του βίντεο")
    if video.storage_key:
        video_storage.delete_video(db, video.storage_key)
    db.query(VideoAnnotation).filter(VideoAnnotation.video_id == video_id).delete()
    db.delete(video)
    db.commit()


@router.get("/{video_id}/annotations", response_model=list[VideoAnnotationOut])
def list_annotations(
    video_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    rows = (
        db.query(VideoAnnotation)
        .filter(VideoAnnotation.video_id == video_id)
        .order_by(VideoAnnotation.start_time.asc())
        .all()
    )
    return [
        VideoAnnotationOut(
            id=a.id,
            video_id=a.video_id,
            shape_type=a.shape_type,
            shape_data=json.loads(a.shape_data),
            start_time=a.start_time,
            end_time=a.end_time,
            created_by=a.created_by,
            created_at=a.created_at,
        )
        for a in rows
    ]


@router.post("/{video_id}/annotations", response_model=VideoAnnotationOut, status_code=201)
def create_annotation(
    video_id: str,
    payload: VideoAnnotationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    annotation = VideoAnnotation(
        video_id=video_id,
        shape_type=payload.shape_type,
        shape_data=json.dumps(payload.shape_data),
        start_time=payload.start_time,
        end_time=payload.end_time,
        created_by=current_user.id,
    )
    db.add(annotation)
    db.commit()
    db.refresh(annotation)
    return VideoAnnotationOut(
        id=annotation.id,
        video_id=annotation.video_id,
        shape_type=annotation.shape_type,
        shape_data=json.loads(annotation.shape_data),
        start_time=annotation.start_time,
        end_time=annotation.end_time,
        created_by=annotation.created_by,
        created_at=annotation.created_at,
    )


def _get_annotation_or_404(db: Session, video_id: str, annotation_id: str) -> VideoAnnotation:
    annotation = (
        db.query(VideoAnnotation)
        .filter(VideoAnnotation.id == annotation_id, VideoAnnotation.video_id == video_id)
        .first()
    )
    if not annotation:
        raise HTTPException(status_code=404, detail="Η σημείωση δεν βρέθηκε")
    return annotation


@router.put("/{video_id}/annotations/{annotation_id}", response_model=VideoAnnotationOut)
def update_annotation(
    video_id: str,
    annotation_id: str,
    payload: VideoAnnotationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    annotation = _get_annotation_or_404(db, video_id, annotation_id)
    if payload.shape_data is not None:
        annotation.shape_data = json.dumps(payload.shape_data)
    if payload.start_time is not None:
        annotation.start_time = payload.start_time
    if payload.end_time is not None:
        annotation.end_time = payload.end_time
    db.commit()
    db.refresh(annotation)
    return VideoAnnotationOut(
        id=annotation.id,
        video_id=annotation.video_id,
        shape_type=annotation.shape_type,
        shape_data=json.loads(annotation.shape_data),
        start_time=annotation.start_time,
        end_time=annotation.end_time,
        created_by=annotation.created_by,
        created_at=annotation.created_at,
    )


@router.delete("/{video_id}/annotations/{annotation_id}", status_code=204)
def delete_annotation(
    video_id: str,
    annotation_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    video = _get_video_or_404(db, video_id)
    _assert_video_team_access(db, current_user, video)
    annotation = _get_annotation_or_404(db, video_id, annotation_id)
    db.delete(annotation)
    db.commit()
