import json
import re
import secrets
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.config import ALLOWED_IMAGE_TYPES, MAX_UPLOAD_SIZE_MB, SCOUT_REPORT_PHOTOS_DIR
from app.database import get_db
from app.services.http_utils import content_disposition_filename
from app.models import ScoutReport, ScoutReportShortlistItem, Team, User
from app.permissions import (
    _can_edit_scout_report,
    assert_scout_report_access,
    owned_team_ids,
    require_scout_report_access,
    sees_all_data,
)
from app.schemas import ScoutReportCreate, ScoutReportOut, ScoutReportPublishUpdate, ScoutReportUpdate
from app.services import pdf_service

router = APIRouter(prefix="/api/scout-reports", tags=["scout-reports"])


def _to_out(db: Session, report: ScoutReport, current_user: User) -> ScoutReportOut:
    team = db.query(Team).filter(Team.id == report.team_id).first() if report.team_id else None
    creator = db.query(User).filter(User.id == report.created_by).first() if report.created_by else None
    try:
        attrs = json.loads(report.detailed_attributes) if report.detailed_attributes else {}
    except (TypeError, ValueError):
        attrs = {}
    is_shortlisted = (
        db.query(ScoutReportShortlistItem)
        .filter(
            ScoutReportShortlistItem.user_id == current_user.id,
            ScoutReportShortlistItem.scout_report_id == report.id,
        )
        .first()
        is not None
    )
    can_edit = _can_edit_scout_report(current_user, report)
    return ScoutReportOut(
        id=report.id,
        full_name=report.full_name,
        club_name=report.club_name,
        age=report.age,
        position=report.position,
        role=report.role,
        league=report.league,
        jersey_number=report.jersey_number,
        nationality=report.nationality,
        strong_foot=report.strong_foot,
        goals_per_season=report.goals_per_season,
        photo_path=report.photo_path,
        team_id=report.team_id,
        team_name=team.name if team else None,
        positive_rating=report.positive_rating,
        positive_notes=report.positive_notes,
        negative_rating=report.negative_rating,
        negative_notes=report.negative_notes,
        physical_mental_rating=report.physical_mental_rating,
        physical_mental_notes=report.physical_mental_notes,
        detailed_attributes=attrs,
        conclusion_text=report.conclusion_text,
        recommended=report.recommended,
        potential_rating=report.potential_rating,
        created_by=report.created_by,
        created_by_name=(creator.full_name or creator.username) if creator else None,
        created_at=report.created_at,
        updated_at=report.updated_at,
        is_mine=report.created_by == current_user.id,
        is_shortlisted=is_shortlisted,
        can_edit=can_edit,
        is_publicly_shared=report.is_publicly_shared,
        public_slug=report.public_slug,
    )


@router.get("", response_model=list[ScoutReportOut])
def list_scout_reports(
    team_id: str | None = None,
    position: str | None = None,
    my_list: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    query = db.query(ScoutReport)
    if not sees_all_data(current_user):
        allowed = owned_team_ids(db, current_user) or set()
        # Reports χωρίς team_id (π.χ. αντίπαλος/υποψήφια μεταγραφή εκτός
        # συλλόγου) παραμένουν ορατά μόνο στον δημιουργό τους.
        query = query.filter(
            or_(ScoutReport.team_id.in_(allowed), ScoutReport.created_by == current_user.id)
        )
    if team_id:
        query = query.filter(ScoutReport.team_id == team_id)
    if position:
        query = query.filter(ScoutReport.position == position)

    reports = query.order_by(ScoutReport.created_at.desc()).all()
    out = [_to_out(db, r, current_user) for r in reports]
    if my_list:
        out = [r for r in out if r.is_mine or r.is_shortlisted]
    return out


@router.post("", response_model=ScoutReportOut, status_code=201)
def create_scout_report(
    payload: ScoutReportCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = ScoutReport(
        full_name=payload.full_name,
        club_name=payload.club_name,
        age=payload.age,
        position=payload.position,
        role=payload.role,
        league=payload.league,
        jersey_number=payload.jersey_number,
        nationality=payload.nationality,
        strong_foot=payload.strong_foot,
        goals_per_season=payload.goals_per_season,
        team_id=payload.team_id,
        positive_rating=payload.positive_rating,
        positive_notes=payload.positive_notes,
        negative_rating=payload.negative_rating,
        negative_notes=payload.negative_notes,
        physical_mental_rating=payload.physical_mental_rating,
        physical_mental_notes=payload.physical_mental_notes,
        detailed_attributes=json.dumps(payload.detailed_attributes) if payload.detailed_attributes else None,
        conclusion_text=payload.conclusion_text,
        recommended=payload.recommended,
        potential_rating=payload.potential_rating,
        created_by=current_user.id,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return _to_out(db, report, current_user)


def _get_report_or_404(db: Session, report_id: str) -> ScoutReport:
    report = db.query(ScoutReport).filter(ScoutReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Το scout report δεν βρέθηκε")
    return report


def _generate_report_slug(db: Session, name: str) -> str:
    base = re.sub(r"[^a-zA-Z0-9]+", "-", name).strip("-").lower()
    for _ in range(5):
        suffix = secrets.token_hex(3)
        candidate = f"{base}-{suffix}" if base else suffix
        if not db.query(ScoutReport).filter(ScoutReport.public_slug == candidate).first():
            return candidate
    return secrets.token_hex(6)


@router.put("/{report_id}/publish", response_model=ScoutReportOut)
def publish_scout_report(
    report_id: str,
    payload: ScoutReportPublishUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    """Δημοσίευση/απόκρυψη ενός scout report — δημιουργεί έναν μοναδικό,
    δημόσιο σύνδεσμο ώστε να μπορεί να το δει οποιοσδήποτε (ακόμα και
    εξωτερικό, χωρίς λογαριασμό), χωρίς login."""
    report = _get_report_or_404(db, report_id)
    assert_scout_report_access(current_user, report)

    report.is_publicly_shared = payload.is_publicly_shared
    if payload.is_publicly_shared and not report.public_slug:
        report.public_slug = _generate_report_slug(db, report.full_name)

    db.commit()
    db.refresh(report)
    return _to_out(db, report, current_user)


@router.get("/{report_id}", response_model=ScoutReportOut)
def get_scout_report(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = _get_report_or_404(db, report_id)
    return _to_out(db, report, current_user)


@router.put("/{report_id}", response_model=ScoutReportOut)
def update_scout_report(
    report_id: str,
    payload: ScoutReportUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = _get_report_or_404(db, report_id)
    assert_scout_report_access(current_user, report)
    data = payload.model_dump(exclude_unset=True)
    if "detailed_attributes" in data:
        attrs = data.pop("detailed_attributes")
        report.detailed_attributes = json.dumps(attrs) if attrs else None
    for field, value in data.items():
        setattr(report, field, value)
    db.commit()
    db.refresh(report)
    return _to_out(db, report, current_user)


@router.delete("/{report_id}", status_code=204)
def delete_scout_report(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = _get_report_or_404(db, report_id)
    assert_scout_report_access(current_user, report)
    db.delete(report)
    db.commit()


@router.post("/{report_id}/photo", response_model=ScoutReportOut)
def upload_scout_report_photo(
    report_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = _get_report_or_404(db, report_id)
    assert_scout_report_access(current_user, report)
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail="Επιτρέπονται μόνο JPG, PNG ή WEBP αρχεία")

    contents = file.file.read()
    if len(contents) > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"Το αρχείο ξεπερνά τα {MAX_UPLOAD_SIZE_MB}MB")

    ext = Path(file.filename).suffix or ".png"
    filename = f"{uuid.uuid4()}{ext}"
    dest = SCOUT_REPORT_PHOTOS_DIR / filename
    dest.write_bytes(contents)

    report.photo_path = f"/media/scout_reports/{filename}"
    db.commit()
    db.refresh(report)
    return _to_out(db, report, current_user)


@router.post("/{report_id}/shortlist", status_code=204)
def add_to_shortlist(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    _get_report_or_404(db, report_id)
    existing = (
        db.query(ScoutReportShortlistItem)
        .filter(
            ScoutReportShortlistItem.user_id == current_user.id,
            ScoutReportShortlistItem.scout_report_id == report_id,
        )
        .first()
    )
    if not existing:
        db.add(ScoutReportShortlistItem(user_id=current_user.id, scout_report_id=report_id))
        db.commit()


@router.delete("/{report_id}/shortlist", status_code=204)
def remove_from_shortlist(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    item = (
        db.query(ScoutReportShortlistItem)
        .filter(
            ScoutReportShortlistItem.user_id == current_user.id,
            ScoutReportShortlistItem.scout_report_id == report_id,
        )
        .first()
    )
    if item:
        db.delete(item)
        db.commit()


@router.get("/{report_id}/export/pdf")
def export_scout_report_pdf(
    report_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_scout_report_access),
):
    report = _get_report_or_404(db, report_id)
    report_out = _to_out(db, report, current_user)
    pdf_bytes = pdf_service.generate_scout_report_pdf(report_out)
    filename = f"scout-report-{report.full_name or report.id}.pdf"
    return StreamingResponse(
        iter([pdf_bytes]),
        media_type="application/pdf",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
