from datetime import date
from typing import Optional
import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Federation, Match, Player, Region, ScoutReport, Team
from app.schemas import PublicClubMatchOut, PublicClubPageOut, PublicClubPlayerOut, PublicScoutReportOut

router = APIRouter(prefix="/api/public", tags=["public"])


def _resolve_team_name(db: Session, team_id: Optional[str], external_name: Optional[str]) -> Optional[str]:
    if external_name:
        return external_name
    if team_id:
        t = db.query(Team).filter(Team.id == team_id).first()
        return t.name if t else None
    return None


def _to_public_match(db: Session, match: Match, team_id: str) -> PublicClubMatchOut:
    home_name = _resolve_team_name(db, match.home_team_id, match.home_team_name_external)
    away_name = _resolve_team_name(db, match.away_team_id, match.away_team_name_external)
    status_value = match.status.value if hasattr(match.status, "value") else match.status

    result = None
    if status_value == "finished" and match.home_score is not None and match.away_score is not None:
        is_home = match.home_team_id == team_id
        team_score = match.home_score if is_home else match.away_score
        opp_score = match.away_score if is_home else match.home_score
        result = "W" if team_score > opp_score else ("L" if team_score < opp_score else "D")

    return PublicClubMatchOut(
        date=match.date,
        time=match.time,
        stadium=match.stadium,
        competition=match.competition,
        home_team_name=home_name,
        away_team_name=away_name,
        home_score=match.home_score,
        away_score=match.away_score,
        status=status_value,
        result=result,
    )


@router.get("/club/{slug}", response_model=PublicClubPageOut)
def get_public_club_page(slug: str, db: Session = Depends(get_db)):
    """Δημόσια σελίδα ομάδας — χωρίς login. Επιστρέφει δεδομένα ΜΟΝΟ αν η
    ομάδα έχει δημοσιευτεί ρητά από τον προπονητή της."""
    team = (
        db.query(Team)
        .filter(Team.public_slug == slug, Team.is_publicly_shared.is_(True))
        .first()
    )
    if not team:
        raise HTTPException(status_code=404, detail="Η σελίδα δεν βρέθηκε ή δεν είναι πλέον δημόσια")

    federation = (
        db.query(Federation).filter(Federation.id == team.federation_id).first()
        if team.federation_id
        else None
    )
    region = db.query(Region).filter(Region.id == federation.region_id).first() if federation else None

    next_match_row = (
        db.query(Match)
        .filter(
            (Match.home_team_id == team.id) | (Match.away_team_id == team.id),
            Match.status.in_(["scheduled", "live"]),
            Match.date >= date.today(),
        )
        .order_by(Match.date.asc())
        .first()
    )
    recent_rows = (
        db.query(Match)
        .filter(
            (Match.home_team_id == team.id) | (Match.away_team_id == team.id),
            Match.status == "finished",
        )
        .order_by(Match.date.desc())
        .limit(5)
        .all()
    )

    roster = None
    if team.public_show_roster:
        players = (
            db.query(Player)
            .filter(Player.current_team_id == team.id)
            .order_by(Player.player_number)
            .all()
        )
        roster = [
            PublicClubPlayerOut(
                id=p.id,
                first_name=p.first_name,
                last_name=p.last_name,
                photo_path=p.photo_path,
                player_number=p.player_number,
                position=p.position,
            )
            for p in players
        ]

    return PublicClubPageOut(
        name=team.name,
        logo_path=team.logo_path,
        category=team.category,
        league_tier=team.league_tier,
        federation_name=federation.name if federation else None,
        region_name=region.name if region else None,
        home_stadium=team.home_stadium,
        primary_color=team.primary_color,
        secondary_color=team.secondary_color,
        description=team.description,
        coach_name=team.coach_name,
        next_match=_to_public_match(db, next_match_row, team.id) if next_match_row else None,
        recent_form=[_to_public_match(db, m, team.id) for m in reversed(recent_rows)],
        roster=roster,
    )


@router.get("/scout-report/{slug}", response_model=PublicScoutReportOut)
def get_public_scout_report(slug: str, db: Session = Depends(get_db)):
    """Δημόσια προβολή ενός scout report — χωρίς login, ώστε να μπορεί να
    το δει ακόμα και κάποιος εξωτερικός στην πλατφόρμα. Επιστρέφει
    δεδομένα ΜΟΝΟ αν έχει δημοσιευτεί ρητά από τον δημιουργό του."""
    report = (
        db.query(ScoutReport)
        .filter(ScoutReport.public_slug == slug, ScoutReport.is_publicly_shared.is_(True))
        .first()
    )
    if not report:
        raise HTTPException(status_code=404, detail="Η αναφορά δεν βρέθηκε ή δεν είναι πλέον δημόσια")

    try:
        attrs = json.loads(report.detailed_attributes) if report.detailed_attributes else {}
    except (TypeError, ValueError):
        attrs = {}

    return PublicScoutReportOut(
        full_name=report.full_name,
        club_name=report.club_name,
        age=report.age,
        position=report.position,
        role=report.role,
        league=report.league,
        jersey_number=report.jersey_number,
        nationality=report.nationality,
        strong_foot=report.strong_foot,
        goals_per_season=report.goals_per_season,
        photo_path=report.photo_path,
        positive_rating=report.positive_rating,
        positive_notes=report.positive_notes,
        negative_rating=report.negative_rating,
        negative_notes=report.negative_notes,
        physical_mental_rating=report.physical_mental_rating,
        physical_mental_notes=report.physical_mental_notes,
        detailed_attributes=attrs,
        conclusion_text=report.conclusion_text,
        recommended=report.recommended,
        potential_rating=report.potential_rating,
    )
