import csv
import io
import re
import secrets
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import (
    assert_leadership_approved,
    assert_team_access,
    check_team_limit,
    owned_team_ids,
    require_write_access,
)
from app.config import ALLOWED_IMAGE_TYPES, MAX_UPLOAD_SIZE_MB, TEAM_LOGOS_DIR
from app.database import get_db
from app.services.http_utils import content_disposition_filename
from app.models import (
    Country,
    Federation,
    LeagueGroup,
    LeagueLevel,
    Player,
    PlayerPosition,
    PreferredFoot,
    Region,
    Team,
    TeamAccessGrant,
    TeamStaffMember,
    User,
)
from app.schemas import (
    CSVImportResult,
    CSVImportRowError,
    TeamCreate,
    TeamOut,
    TeamPublishUpdate,
    TeamStaffMemberIn,
    TeamStaffMemberOut,
    TeamStaffMemberRoleUpdate,
    TeamUpdate,
)

router = APIRouter(prefix="/api/teams", tags=["teams"])


def _to_out(team: Team, db: Session) -> TeamOut:
    count = db.query(Player).filter(Player.current_team_id == team.id).count()
    out = TeamOut.model_validate(team)
    out.player_count = count
    if team.owner_id:
        owner = db.query(User).filter(User.id == team.owner_id).first()
        if owner:
            out.president_name = owner.full_name or owner.username

    # Ο "Προπονητής" δείχνει το ΤΡΕΧΟΝ, πραγματικό άτομο που έχει
    # οριστεί ως head_coach μέσω πρόσβασης διαχείρισης ή επιτελείου —
    # όχι το στατικό κείμενο που γράφτηκε στη δημιουργία της ομάδας,
    # ώστε να μην παλιώνει όταν αλλάζει ο πραγματικός προπονητής.
    # Χωρίς κανένα τέτοιο αντίστοιχο, μένει το στατικό coach_name.
    coach_grant = (
        db.query(TeamAccessGrant)
        .filter(TeamAccessGrant.team_id == team.id, TeamAccessGrant.role_title == "head_coach")
        .first()
    )
    coach_user_id = coach_grant.user_id if coach_grant else None
    if not coach_user_id:
        coach_staff = (
            db.query(TeamStaffMember)
            .filter(TeamStaffMember.team_id == team.id, TeamStaffMember.role_title == "head_coach")
            .first()
        )
        coach_user_id = coach_staff.user_id if coach_staff else None
    if coach_user_id:
        coach_user = db.query(User).filter(User.id == coach_user_id).first()
        if coach_user:
            out.coach_name = coach_user.full_name or coach_user.username

    if team.federation_id:
        federation = db.query(Federation).filter(Federation.id == team.federation_id).first()
        if federation:
            out.federation_name = federation.name
            region = db.query(Region).filter(Region.id == federation.region_id).first()
            if region:
                out.region_name = region.name
    if team.country_id:
        country = db.query(Country).filter(Country.id == team.country_id).first()
        if country:
            out.country_name = country.name
    if team.league_level_id:
        level = db.query(LeagueLevel).filter(LeagueLevel.id == team.league_level_id).first()
        if level:
            out.league_level_name = level.name
    if team.league_group_id:
        group = db.query(LeagueGroup).filter(LeagueGroup.id == team.league_group_id).first()
        if group:
            out.league_group_name = group.name
    return out


@router.get("", response_model=list[TeamOut])
def list_teams(
    search: Optional[str] = None,
    category: Optional[str] = None,
    season: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Team)
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(Team.id.in_(owned_ids))
    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(Team.name.ilike(like), Team.league.ilike(like), Team.division.ilike(like))
        )
    if category:
        query = query.filter(Team.category == category)
    if season:
        query = query.filter(Team.season == season)
    teams = query.order_by(Team.name).all()
    return [_to_out(t, db) for t in teams]


@router.post("", response_model=TeamOut, status_code=201)
def create_team(
    payload: TeamCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    assert_leadership_approved(current_user)
    check_team_limit(db, current_user, payload.league_tier)
    data = payload.model_dump()
    if not data.get("country_id"):
        greece = db.query(Country).filter(Country.name == "Ελλάδα").first()
        if greece:
            data["country_id"] = greece.id
    team = Team(owner_id=current_user.id, **data)
    db.add(team)
    db.commit()
    db.refresh(team)
    return _to_out(team, db)


@router.get("/{team_id}", response_model=TeamOut)
def get_team(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    return _to_out(team, db)


@router.put("/{team_id}", response_model=TeamOut)
def update_team(
    team_id: str,
    payload: TeamUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(team, field, value)
    db.commit()
    db.refresh(team)
    return _to_out(team, db)


@router.delete("/{team_id}", status_code=204)
def delete_team(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    db.delete(team)
    db.commit()
    return None


@router.post("/{team_id}/logo", response_model=TeamOut)
def upload_logo(
    team_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail="Επιτρέπονται μόνο JPG, PNG ή WEBP αρχεία")

    contents = file.file.read()
    if len(contents) > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"Το αρχείο ξεπερνά τα {MAX_UPLOAD_SIZE_MB}MB")

    ext = Path(file.filename).suffix or ".png"
    filename = f"{uuid.uuid4()}{ext}"
    dest = TEAM_LOGOS_DIR / filename
    dest.write_bytes(contents)

    team.logo_path = f"/media/teams/{filename}"
    db.commit()
    db.refresh(team)
    return _to_out(team, db)


# ---------------------------------------------------------------------------
# Bulk import players from CSV
# ---------------------------------------------------------------------------
CSV_COLUMN_ALIASES = {
    "first_name": {"first_name", "firstname", "όνομα", "onoma"},
    "last_name": {"last_name", "lastname", "επώνυμο", "eponymo"},
    "full_name": {"full_name", "fullname", "name", "player", "ονοματεπώνυμο", "ονοματεπωνυμο", "παίκτης", "παικτης"},
    "player_number": {"player_number", "number", "νούμερο", "νουμερο", "αριθμός", "αριθμος"},
    "position": {"position", "θέση", "θεση"},
    "date_of_birth": {"date_of_birth", "dob", "birthdate", "ημ_γέννησης", "ημερομηνία γέννησης"},
    "age": {"age", "ηλικία", "ηλικια"},
    "nationality": {"nationality", "εθνικότητα", "εθνικοτητα"},
    "preferred_foot": {"preferred_foot", "foot", "πόδι", "ποδι"},
    "height_cm": {"height_cm", "height", "ύψος", "υψος"},
    "weight_kg": {"weight_kg", "weight", "βάρος", "βαρος"},
    "phone": {"phone", "τηλέφωνο", "τηλεφωνο"},
    "email": {"email"},
}

# Ελληνικές (και μερικές αγγλικές, πιο γενικές) τιμές θέσης που μπορεί να
# βρεθούν ΜΕΣΑ στη στήλη Θέση ενός CSV — αντιστοιχίζονται στο πλησιέστερο
# κωδικό θέσης. Χρησιμοποιεί την ίδια ορολογία με το Excel export της
# εφαρμογής, ώστε να είναι συνεπής.
POSITION_VALUE_ALIASES: dict[str, set[str]] = {
    "GK": {"gk", "goalkeeper", "τερματοφύλακας", "τερματοφυλακας"},
    "CB": {
        "cb",
        "centre back",
        "center back",
        "κεντρικός αμυντικός",
        "κεντρικος αμυντικος",
        "αμυντικός",
        "αμυντικος",
        "defender",
    },
    "LB": {"lb", "left back", "αριστερός μπακ", "αριστερος μπακ", "αριστερό μπακ", "αριστερο μπακ"},
    "RB": {"rb", "right back", "δεξιός μπακ", "δεξιος μπακ", "δεξί μπακ", "δεξι μπακ"},
    "DM": {"dm", "defensive midfielder", "αμυντικός χαφ", "αμυντικος χαφ"},
    "CM": {
        "cm",
        "central midfielder",
        "midfielder",
        "κεντρικός χαφ",
        "κεντρικος χαφ",
        "μέσος",
        "μεσος",
    },
    "AM": {"am", "attacking midfielder", "επιθετικός χαφ", "επιθετικος χαφ"},
    "LW": {"lw", "left winger", "αριστερό άκρο", "αριστερο ακρο"},
    "RW": {"rw", "right winger", "δεξί άκρο", "δεξι ακρο"},
    "ST": {"st", "striker", "forward", "επιθετικός", "επιθετικος"},
}


def _resolve_position(raw: str) -> Optional[str]:
    upper = raw.strip().upper()
    if upper in PlayerPosition.__members__:
        return upper
    lowered = raw.strip().lower()
    for code, aliases in POSITION_VALUE_ALIASES.items():
        if lowered in aliases:
            return code
    return None


def _read_upload_rows(file: UploadFile) -> tuple[list[str], list[dict]]:
    """Διαβάζει CSV ή Excel (.xlsx) αρχείο και επιστρέφει (ονόματα στηλών,
    λίστα γραμμών ως dict) — ενιαία μορφή ανεξαρτήτως πηγής, ώστε η
    υπόλοιπη λογική εισαγωγής να μη χρειάζεται να ξέρει τη διαφορά."""
    filename = (file.filename or "").lower()
    raw = file.file.read()

    if filename.endswith(".csv"):
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("latin-1")
        reader = csv.DictReader(io.StringIO(text))
        fieldnames = list(reader.fieldnames or [])
        rows = [dict(row) for row in reader]
        return fieldnames, rows

    if filename.endswith(".xlsx"):
        from openpyxl import load_workbook

        workbook = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        sheet = workbook.active
        rows_iter = sheet.iter_rows(values_only=True)
        try:
            header_row = next(rows_iter)
        except StopIteration:
            return [], []
        fieldnames = [str(h).strip() if h is not None else "" for h in header_row]

        rows: list[dict] = []
        for values in rows_iter:
            row_dict: dict = {}
            for header, value in zip(fieldnames, values):
                if not header:
                    continue
                if value is None:
                    row_dict[header] = ""
                elif isinstance(value, (datetime, date)):
                    # Τα κελιά ημερομηνίας του Excel έρχονται ως πραγματικά
                    # date/datetime objects — μορφοποίησέ τα ρητά σε
                    # YYYY-MM-DD ώστε να αναγνωριστούν από το date parsing
                    # παρακάτω (αλλιώς το str() θα έβγαζε κάτι σαν
                    # "2005-03-15 00:00:00" που δεν ταιριάζει με τίποτα).
                    row_dict[header] = value.strftime("%Y-%m-%d")
                else:
                    row_dict[header] = str(value)
            if any(v for v in row_dict.values()):
                rows.append(row_dict)
        return fieldnames, rows

    raise HTTPException(status_code=400, detail="Το αρχείο πρέπει να είναι .csv ή .xlsx")


def _map_headers(fieldnames: list[str]) -> dict[str, str]:
    """Επιστρέφει {canonical_field: actual_csv_header} για ό,τι header ταιριάζει."""
    mapping = {}
    normalized = {fn.strip().lower(): fn for fn in fieldnames}
    for canonical, aliases in CSV_COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in normalized:
                mapping[canonical] = normalized[alias]
                break
    return mapping


@router.post("/{team_id}/players/import-csv", response_model=CSVImportResult)
def import_players_csv(
    team_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Μαζική εισαγωγή παικτών από CSV ή Excel (.xlsx). Αναμενόμενες στήλες
    (case-insensitive, δεν χρειάζεται να υπάρχουν όλες): first_name,
    last_name (ή μία στήλη πλήρους ονόματος, π.χ. "Παίκτης"/"Name"),
    player_number, position (δέχεται και ελληνικές τιμές όπως
    "Τερματοφύλακας"), date_of_birth (YYYY-MM-DD) ή age/ηλικία, nationality,
    preferred_foot (δέχεται και "Αριστερό"/"Δεξί"/"Και τα δύο"), height_cm,
    weight_kg, phone, email. Ό,τι λείπει από μια γραμμή απλά παραλείπεται —
    μόνο όνομα+επώνυμο (ή πλήρες όνομα) είναι υποχρεωτικά ανά γραμμή."""
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    if not (file.filename or "").lower().endswith((".csv", ".xlsx")):
        raise HTTPException(status_code=400, detail="Το αρχείο πρέπει να είναι .csv ή .xlsx")

    fieldnames, rows = _read_upload_rows(file)
    if not fieldnames:
        raise HTTPException(status_code=400, detail="Το αρχείο δεν έχει επικεφαλίδες στηλών")

    field_map = _map_headers(fieldnames)
    has_split_name = "first_name" in field_map and "last_name" in field_map
    has_full_name = "full_name" in field_map
    if not has_split_name and not has_full_name:
        raise HTTPException(
            status_code=400,
            detail=(
                "Το CSV πρέπει να έχει στήλες για first_name και last_name "
                "(ή Όνομα/Επώνυμο), ή μία στήλη με το πλήρες όνομα (π.χ. Παίκτης)."
            ),
        )

    created = 0
    errors: list[CSVImportRowError] = []

    for idx, row in enumerate(rows, start=2):  # γραμμή 1 = headers
        def get(field: str) -> Optional[str]:
            header = field_map.get(field)
            if not header:
                return None
            value = (row.get(header) or "").strip()
            return value or None

        first_name = get("first_name")
        last_name = get("last_name")
        name_note = None
        if (not first_name or not last_name) and get("full_name"):
            parts = get("full_name").split()
            if len(parts) >= 2:
                first_name = first_name or parts[0]
                last_name = last_name or " ".join(parts[1:])
            elif len(parts) == 1:
                first_name = first_name or parts[0]
                last_name = last_name or parts[0]
                name_note = "Το πλήρες όνομα είχε μόνο μία λέξη — χρησιμοποιήθηκε και ως επώνυμο"
            if first_name and last_name and name_note is None:
                name_note = "Το όνομα/επώνυμο χωρίστηκαν αυτόματα από το πλήρες όνομα"
        if not first_name or not last_name:
            errors.append(CSVImportRowError(row=idx, message="Λείπει όνομα ή επώνυμο"))
            continue

        try:
            player_number = None
            if get("player_number"):
                player_number = int(float(get("player_number")))

            position = None
            if get("position"):
                pos_raw = get("position")
                resolved = _resolve_position(pos_raw)
                if resolved:
                    position = PlayerPosition[resolved]
                else:
                    errors.append(
                        CSVImportRowError(row=idx, message=f"Άγνωστη θέση: {pos_raw} — παραλείφθηκε")
                    )

            preferred_foot = None
            if get("preferred_foot"):
                foot_raw = get("preferred_foot").strip().lower()
                foot_aliases = {
                    "left": PreferredFoot.LEFT,
                    "αριστερό": PreferredFoot.LEFT,
                    "αριστερο": PreferredFoot.LEFT,
                    "right": PreferredFoot.RIGHT,
                    "δεξί": PreferredFoot.RIGHT,
                    "δεξι": PreferredFoot.RIGHT,
                    "both": PreferredFoot.BOTH,
                    "και τα δύο": PreferredFoot.BOTH,
                    "και τα δυο": PreferredFoot.BOTH,
                    "αμφιδέξιος": PreferredFoot.BOTH,
                    "αμφιδεξιος": PreferredFoot.BOTH,
                }
                preferred_foot = foot_aliases.get(foot_raw)

            dob = None
            if get("date_of_birth"):
                dob_raw = get("date_of_birth")
                for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
                    try:
                        dob = datetime.strptime(dob_raw, fmt).date()
                        break
                    except ValueError:
                        continue
            elif get("age"):
                try:
                    age_years = int(float(get("age")))
                    # Δεν ξέρουμε ακριβή μήνα/ημέρα γέννησης — 1η Ιουλίου
                    # δίνει την πιο ουδέτερη (μέση) εκτίμηση ηλικίας.
                    dob = date(date.today().year - age_years, 7, 1)
                    errors.append(
                        CSVImportRowError(
                            row=idx,
                            message="Η ημ. γέννησης υπολογίστηκε κατά προσέγγιση από την ηλικία (μόνο το έτος είναι ακριβές)",
                        )
                    )
                except ValueError:
                    pass

            height_cm = float(get("height_cm")) if get("height_cm") else None
            weight_kg = float(get("weight_kg")) if get("weight_kg") else None

            player = Player(
                first_name=first_name,
                last_name=last_name,
                current_team_id=team_id,
                player_number=player_number,
                position=position,
                preferred_foot=preferred_foot,
                date_of_birth=dob,
                nationality=get("nationality"),
                height_cm=height_cm,
                weight_kg=weight_kg,
                phone=get("phone"),
                email=get("email"),
            )
            db.add(player)
            created += 1
            if name_note:
                errors.append(CSVImportRowError(row=idx, message=name_note))
        except (ValueError, KeyError) as exc:
            errors.append(CSVImportRowError(row=idx, message=f"Σφάλμα στη γραμμή: {exc}"))

    db.commit()
    return CSVImportResult(created=created, errors=errors)


# ---------------------------------------------------------------------------
# Δημόσια Σελίδα Ομάδας (Club Page) — δημοσίευση / απόκρυψη
# ---------------------------------------------------------------------------
def _slugify(name: str) -> str:
    ascii_part = re.sub(r"[^a-zA-Z0-9]+", "-", name).strip("-").lower()
    return ascii_part


def _generate_public_slug(db: Session, name: str) -> str:
    base = _slugify(name)
    for _ in range(5):
        suffix = secrets.token_hex(3)
        candidate = f"{base}-{suffix}" if base else suffix
        if not db.query(Team).filter(Team.public_slug == candidate).first():
            return candidate
    return secrets.token_hex(6)


@router.put("/{team_id}/publish", response_model=TeamOut)
def publish_team(
    team_id: str,
    payload: TeamPublishUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    team.is_publicly_shared = payload.is_publicly_shared
    if payload.public_show_roster is not None:
        team.public_show_roster = payload.public_show_roster
    if payload.is_publicly_shared and not team.public_slug:
        team.public_slug = _generate_public_slug(db, team.name)

    db.commit()
    db.refresh(team)
    return _to_out(team, db)


# ---------------------------------------------------------------------------
# Τεχνικό Επιτελείο (Team Staff)
# ---------------------------------------------------------------------------
@router.get("/{team_id}/staff", response_model=list[TeamStaffMemberOut])
def list_team_staff(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    rows = (
        db.query(TeamStaffMember, User)
        .join(User, TeamStaffMember.user_id == User.id)
        .filter(TeamStaffMember.team_id == team_id)
        .all()
    )
    return [
        TeamStaffMemberOut(
            id=member.id,
            user_id=user.id,
            full_name=user.full_name,
            username=user.username,
            role_title=member.role_title,
        )
        for member, user in rows
    ]


@router.post("/{team_id}/staff", response_model=TeamStaffMemberOut, status_code=201)
def add_team_staff(
    team_id: str,
    payload: TeamStaffMemberIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    target_user = db.query(User).filter(User.id == payload.user_id).first()
    if not target_user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")

    existing = (
        db.query(TeamStaffMember)
        .filter(TeamStaffMember.team_id == team_id, TeamStaffMember.user_id == payload.user_id)
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Ο χρήστης είναι ήδη στο επιτελείο")

    member = TeamStaffMember(team_id=team_id, user_id=payload.user_id, role_title=payload.role_title)
    db.add(member)
    db.commit()
    db.refresh(member)
    return TeamStaffMemberOut(
        id=member.id,
        user_id=target_user.id,
        full_name=target_user.full_name,
        username=target_user.username,
        role_title=member.role_title,
    )


@router.put("/{team_id}/staff/{staff_id}", response_model=TeamStaffMemberOut)
def update_team_staff_role(
    team_id: str,
    staff_id: str,
    payload: TeamStaffMemberRoleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Ενημερώνει την αρμοδιότητα (π.χ. Βοηθός Προπονητή, Αναλυτής) ενός
    μέλους του τεχνικού επιτελείου που προστέθηκε απευθείας στην ομάδα."""
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    member = (
        db.query(TeamStaffMember)
        .filter(TeamStaffMember.id == staff_id, TeamStaffMember.team_id == team_id)
        .first()
    )
    if not member:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    member.role_title = payload.role_title
    db.commit()
    db.refresh(member)

    target_user = db.query(User).filter(User.id == member.user_id).first()
    return TeamStaffMemberOut(
        id=member.id,
        user_id=member.user_id,
        full_name=target_user.full_name if target_user else None,
        username=target_user.username if target_user else "",
        role_title=member.role_title,
    )


@router.delete("/{team_id}/staff/{staff_id}", status_code=204)
def remove_team_staff(
    team_id: str,
    staff_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    member = (
        db.query(TeamStaffMember)
        .filter(TeamStaffMember.id == staff_id, TeamStaffMember.team_id == team_id)
        .first()
    )
    if not member:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.delete(member)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Εξαγωγή Ρόστερ
# ---------------------------------------------------------------------------
@router.get("/{team_id}/export/excel")
def export_roster_excel(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    from fastapi.responses import StreamingResponse

    from app.services.excel_service import generate_team_roster_excel

    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    players = db.query(Player).filter(Player.current_team_id == team_id).order_by(Player.first_name.asc()).all()

    content = generate_team_roster_excel(team, players)
    filename = f"roster-{team.name.replace(' ', '-')}.xlsx"
    return StreamingResponse(
        iter([content]),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )


@router.get("/{team_id}/export/pdf")
def export_roster_pdf(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    from fastapi.responses import StreamingResponse

    from app.services.pdf_service import generate_team_roster_pdf

    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    players = db.query(Player).filter(Player.current_team_id == team_id).order_by(Player.first_name.asc()).all()

    content = generate_team_roster_pdf(team, players)
    filename = f"roster-{team.name.replace(' ', '-')}.pdf"
    return StreamingResponse(
        iter([content]),
        media_type="application/pdf",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
