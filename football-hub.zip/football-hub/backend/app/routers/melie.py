from pydantic import BaseModel, Field

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import User
from app.services import ai_service

router = APIRouter(prefix="/api/melie", tags=["melie"])

# Μέγιστος αριθμός προηγούμενων μηνυμάτων που στέλνουμε στο AI ως context —
# κρατάει το κόστος/latency λογικό χωρίς να χρειάζεται πλήρες ιστορικό.
MAX_HISTORY_MESSAGES = 12

# ---------------------------------------------------------------------------
# Γνώση ανά ενότητα — τι κάνει η κάθε σελίδα, ώστε η Melie να μπορεί να
# εξηγήσει συγκεκριμένα και όχι γενικόλογα. Το section key έρχεται από το
# frontend (βλ. MelieWidget.tsx, παράγεται από το pathname).
# ---------------------------------------------------------------------------
SECTION_INFO: dict[str, dict[str, str]] = {
    "dashboard": {
        "el": (
            "Το Dashboard είναι η αρχική σελίδα με σύνοψη δραστηριότητας.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι δείχνει το Dashboard;\n"
            "Απ: Σύνοψη επόμενων αγώνων/προπονήσεων, πρόσφατη δραστηριότητα (νέες αιτήσεις, "
            "αλλαγές), και γρήγορη πρόσβαση σε ομάδες/παίκτες.\n\n"
            "Ερ: Μπορώ να κρύψω κάποια widgets;\n"
            "Απ: Ναι, μπορείς να κρύψεις widgets που δεν χρειάζεσαι — η προτίμηση αποθηκεύεται "
            "στον browser σου.\n\n"
            "Ερ: Πώς ανοίγω γρήγορα μια ομάδα ή έναν παίκτη από εδώ;\n"
            "Απ: Κάνε κλικ πάνω στο αντίστοιχο activity item ή στη λίστα ομάδων/παικτών."
        ),
        "en": (
            "The Dashboard is the home page with an activity summary.\n\n"
            "Frequently asked questions:\n"
            "Q: What does the Dashboard show?\n"
            "A: A summary of upcoming matches/trainings, recent activity (new requests, "
            "changes), and quick access to teams/players.\n\n"
            "Q: Can I hide some widgets?\n"
            "A: Yes, you can hide widgets you don't need — the preference is saved in your "
            "browser.\n\n"
            "Q: How do I quickly open a team or player from here?\n"
            "A: Click the relevant activity item or the team/player list."
        ),
    },
    "teams": {
        "el": (
            "Η ενότητα Ομάδες διαχειρίζεται δημιουργία, ρόστερ, δημόσια σελίδα και αγγελίες.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πόσες ομάδες μπορώ να δημιουργήσω;\n"
            "Απ: Ως coach (Head Coach/Assistant Coach/Fitness Coach/Analyst/Scout) έως 1 "
            "ανδρικό/επαγγελματικό ή ερασιτεχνικό τμήμα και έως 2 ακαδημίες — σύνολο έως 3. "
            "Πρόεδρος και Τεχνικός Διευθυντής έχουν μεγαλύτερο όριο (έως 8), αφού συνήθως "
            "εποπτεύουν όλο τον σύλλογο.\n\n"
            "Ερ: Μπορεί μια ομάδα να έχει δύο προπονητές;\n"
            "Απ: Όχι — κάθε ομάδα μπορεί να έχει μόνο έναν Προπονητή (Head Coach), είτε ως "
            "ιδιοκτήτη είτε μέσω πρόσβασης διαχείρισης.\n\n"
            "Ερ: Πώς προσθέτω πολλούς παίκτες μαζί;\n"
            "Απ: Στη σελίδα της ομάδας υπάρχει «Εισαγωγή CSV/Excel» με στήλες όνομα, αριθμός, "
            "θέση, ημερομηνία γέννησης κ.ά.\n\n"
            "Ερ: Τι είναι η δημόσια σελίδα ομάδας;\n"
            "Απ: Δημόσια, μη-συνδεδεμένη σελίδα (/club/όνομα-ομάδας) με επόμενο αγώνα, "
            "πρόσφατα αποτελέσματα και ρόστερ ταξινομημένο ανά θέση· ο επισκέπτης επιλέγει "
            "ομαδοποιημένη ή συμπαγή προβολή.\n\n"
            "Ερ: Πώς βρίσκω προσωπικό ή παίκτες για την ομάδα μου;\n"
            "Απ: Δημοσίευσε αγγελία (Listing) από τη σελίδα της ομάδας — επιλέγεις ρόλους/"
            "θέσεις, ηλικιακά όρια, και συγκεκριμένους νομούς (ΕΠΣ). Εμφανίζεται στο Scouting "
            "Hub.\n\n"
            "Ερ: Πώς αναλαμβάνω μια ομάδα χωρίς προπονητή;\n"
            "Απ: Κάνε αίτηση ανάληψης από τη σελίδα της ομάδας — ο πρόεδρος/τεχνικός "
            "διευθυντής θα την εγκρίνει ή θα την απορρίψει."
        ),
        "en": (
            "The Teams section manages creation, rosters, the public page and listings.\n\n"
            "Frequently asked questions:\n"
            "Q: How many teams can I create?\n"
            "A: As a coach (Head Coach/Assistant Coach/Fitness Coach/Analyst/Scout) up to 1 "
            "senior/professional or amateur team and up to 2 academies — 3 total. President "
            "and Technical Director get a higher limit (up to 8), since they usually oversee "
            "the whole club.\n\n"
            "Q: Can a team have two coaches?\n"
            "A: No — each team can have only one Head Coach, whether as owner or via "
            "management access.\n\n"
            "Q: How do I add many players at once?\n"
            "A: The team page has \"Import CSV/Excel\" with columns like name, number, "
            "position, date of birth, etc.\n\n"
            "Q: What's the public team page?\n"
            "A: A public, no-login page (/club/team-name) with the next match, recent "
            "results, and a roster sorted by position; visitors can choose grouped or "
            "compact view.\n\n"
            "Q: How do I find staff or players for my team?\n"
            "A: Post a listing from the team page — you can pick roles/positions, age "
            "limits, and specific regions. It shows up in the Scouting Hub.\n\n"
            "Q: How do I take over a team without a coach?\n"
            "A: Submit a takeover request from the team page — the president/technical "
            "director will accept or reject it."
        ),
    },
    "players": {
        "el": (
            "Η ενότητα Παίκτες δείχνει λίστα, προφίλ και εργαλείο σύγκρισης παικτών.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς ταξινομούνται οι παίκτες στο ρόστερ ομάδας;\n"
            "Απ: Ομαδοποιημένοι ανά θέση: Τερματοφύλακες, Άμυνα, Κέντρο, Επίθεση.\n\n"
            "Ερ: Τι είναι τα Χαρακτηριστικά (Attributes);\n"
            "Απ: 7 βαθμολογίες 1-10 ανά παίκτη: Δυναμικό, Πάσα, Σουτ, Ντρίμπλα, Άμυνα, "
            "Επίθεση, Φυσική Κατάσταση.\n\n"
            "Ερ: Τι σημαίνει η Κατάσταση Μεταγραφής;\n"
            "Απ: Δείχνει αν ο παίκτης είναι Χωρίς καταχώρηση, Ελεύθερος, Προς Μεταγραφή, ή "
            "Διαθέσιμος για Δανεισμό — εμφανίζεται στο Scouting Hub.\n\n"
            "Ερ: Μπορεί ο ίδιος ο παίκτης να αλλάξει την κατάστασή του;\n"
            "Απ: Ναι, αν ο λογαριασμός του είναι συνδεδεμένος με το προφίλ παίκτη — έως 3 "
            "φορές ανά ομάδα/σεζόν.\n\n"
            "Ερ: Πώς συγκρίνω δύο παίκτες;\n"
            "Απ: Στη σελίδα Παίκτες υπάρχει εργαλείο σύγκρισης με στατιστικά και "
            "χαρακτηριστικά δίπλα-δίπλα.\n\n"
            "Ερ: Πώς καταγράφω γρήγορα γκολ ή κάρτα;\n"
            "Απ: Δεξί κλικ στην κάρτα παίκτη στη σελίδα ομάδας για γρήγορη προσθήκη γκολ, "
            "αγώνα, κάρτας, ή αλλαγή κατάστασης."
        ),
        "en": (
            "The Players section shows a list, profiles, and a comparison tool.\n\n"
            "Frequently asked questions:\n"
            "Q: How are players sorted on a team roster?\n"
            "A: Grouped by position: Goalkeepers, Defense, Midfield, Attack.\n\n"
            "Q: What are Attributes?\n"
            "A: 7 ratings from 1-10 per player: Potential, Passing, Shooting, Dribbling, "
            "Defending, Attacking, Physical.\n\n"
            "Q: What does Transfer Status mean?\n"
            "A: Shows whether a player is Not Listed, Free Agent, For Transfer, or Available "
            "for Loan — shown in the Scouting Hub.\n\n"
            "Q: Can a player change their own status?\n"
            "A: Yes, if their account is linked to the player profile — up to 3 times per "
            "team/season.\n\n"
            "Q: How do I compare two players?\n"
            "A: The Players page has a comparison tool showing stats and attributes side by "
            "side.\n\n"
            "Q: How do I quickly log a goal or card?\n"
            "A: Right-click a player card on the team page to quickly add a goal, match, "
            "card, or change status."
        ),
    },
    "matches": {
        "el": (
            "Η ενότητα Αγώνες καταγράφει αποτελέσματα, βαθμολογίες και match reports.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς καταγράφω αποτέλεσμα αγώνα;\n"
            "Απ: Άνοιξε τον αγώνα, βάλε κατάσταση «Ολοκληρώθηκε» και συμπλήρωσε το σκορ.\n\n"
            "Ερ: Πώς βαθμολογώ τους παίκτες σε έναν αγώνα;\n"
            "Απ: Στη σελίδα του αγώνα επίλεξε την ομάδα ρόστερ και βαθμολόγησε κάθε παίκτη "
            "(λεπτά, γκολ, ασίστ, κάρτες, rating, MVP) — αποθηκεύονται όλα μαζί.\n\n"
            "Ερ: Τι είναι το AI Match Summary;\n"
            "Απ: Αυτόματη ανάλυση αγώνα (δυνατά σημεία, αδυναμίες, τακτικές παρατηρήσεις) "
            "βάσει των πραγματικών δεδομένων που έχεις καταγράψει — χρειάζεται ρυθμισμένο AI "
            "στις Ρυθμίσεις.\n\n"
            "Ερ: Μπορώ να εξάγω τις βαθμολογίες σε PDF;\n"
            "Απ: Ναι, υπάρχει κουμπί εξαγωγής PDF στη σελίδα του αγώνα."
        ),
        "en": (
            "The Matches section records results, ratings, and match reports.\n\n"
            "Frequently asked questions:\n"
            "Q: How do I record a match result?\n"
            "A: Open the match, set status to \"Finished\" and fill in the score.\n\n"
            "Q: How do I rate players in a match?\n"
            "A: On the match page, pick the roster team and rate each player (minutes, "
            "goals, assists, cards, rating, MVP) — all saved together.\n\n"
            "Q: What is AI Match Summary?\n"
            "A: An automatic match analysis (strengths, weaknesses, tactical notes) based on "
            "the real data you've recorded — requires AI to be configured in Settings.\n\n"
            "Q: Can I export ratings to PDF?\n"
            "A: Yes, there's a PDF export button on the match page."
        ),
    },
    "trainings": {
        "el": (
            "Η ενότητα Προπονήσεις καταγράφει προγραμματισμό, παρουσίες και διαγράμματα.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς καταγράφω παρουσίες;\n"
            "Απ: Στη σελίδα της προπόνησης, σημείωσε για κάθε παίκτη Παρών/Απών/Καθυστέρησε/"
            "Τραυματίας/Δικαιολογημένος.\n\n"
            "Ερ: Μπορώ να φτιάξω διάγραμμα τακτικής για συγκεκριμένη προπόνηση;\n"
            "Απ: Ναι, από τη σελίδα προπόνησης δημιουργείς νέο διάγραμμα που συνδέεται "
            "αυτόματα με αυτή την προπόνηση."
        ),
        "en": (
            "The Trainings section records scheduling, attendance, and diagrams.\n\n"
            "Frequently asked questions:\n"
            "Q: How do I record attendance?\n"
            "A: On the training page, mark each player Present/Absent/Late/Injured/Excused.\n\n"
            "Q: Can I create a tactical diagram for a specific training?\n"
            "A: Yes, from the training page you can create a new diagram that's "
            "automatically linked to that session."
        ),
    },
    "calendar": {
        "el": (
            "Το Ημερολόγιο δείχνει όλους τους αγώνες και τις προπονήσεις σε μηνιαία προβολή.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι δείχνει το Ημερολόγιο;\n"
            "Απ: Όλα τα events (αγώνες και προπονήσεις) των ομάδων σου, σε μηνιαία προβολή."
        ),
        "en": (
            "The Calendar shows all matches and trainings in a monthly view.\n\n"
            "Frequently asked questions:\n"
            "Q: What does the Calendar show?\n"
            "A: All events (matches and trainings) for your teams, in a monthly view."
        ),
    },
    "tacticalBoard": {
        "el": (
            "Το Tactical Board είναι οπτικός σχεδιαστής τακτικής.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι μπορώ να σχεδιάσω;\n"
            "Απ: Γηπεδάκι, θέσεις παικτών, βέλη κίνησης, κώνους, και ολόκληρα formations.\n\n"
            "Ερ: Μπορώ να το συνδέσω με προπόνηση;\n"
            "Απ: Ναι, ένα διάγραμμα μπορεί να δημιουργηθεί απευθείας από μια προπόνηση και να "
            "συνδεθεί μαζί της."
        ),
        "en": (
            "The Tactical Board is a visual tactics designer.\n\n"
            "Frequently asked questions:\n"
            "Q: What can I draw?\n"
            "A: A pitch, player positions, movement arrows, cones, and full formations.\n\n"
            "Q: Can I link it to a training session?\n"
            "A: Yes, a diagram can be created directly from a training session and stays "
            "linked to it."
        ),
    },
    "reports": {
        "el": (
            "Η ενότητα Αναφορές (Reports) δεν είναι ακόμα διαθέσιμη.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πότε θα είναι διαθέσιμη η ενότητα Αναφορές;\n"
            "Απ: Δεν είναι ακόμα διαθέσιμη — έρχεται σύντομα."
        ),
        "en": (
            "The Reports section is not yet available.\n\n"
            "Frequently asked questions:\n"
            "Q: When will the Reports section be available?\n"
            "A: It's not available yet — coming soon."
        ),
    },
    "scouting": {
        "el": (
            "Το Scouting Hub είναι δημόσιος κατάλογος ομάδων, παικτών και τεχνικού επιτελείου.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι είναι το Scouting Hub;\n"
            "Απ: Δημόσιος κατάλογος ομάδων, παικτών και τεχνικού επιτελείου, με φίλτρα ανά "
            "θέση/ηλικία/κατάσταση.\n\n"
            "Ερ: Πώς εμφανίζονται οι παίκτες όταν βλέπω μια ομάδα;\n"
            "Απ: Ταξινομημένοι ανά θέση (Τερματοφύλακες → Άμυνα → Κέντρο → Επίθεση), με "
            "επιλογή ομαδοποιημένης ή συμπαγούς προβολής.\n\n"
            "Ερ: Πώς οργανώνεται το staff;\n"
            "Απ: Σε ενότητες ανά νομό (ΕΠΣ) καταγωγής — κάθε στέλεχος μπορεί να δηλώσει από "
            "πού είναι, τι ρόλο ψάχνει, και σε ποιες περιοχές θέλει να εργαστεί, από το "
            "Προφίλ του.\n\n"
            "Ερ: Τι είναι οι αγγελίες (Listings);\n"
            "Απ: Ομάδες δημοσιεύουν αγγελίες για staff ή παίκτες, προαιρετικά στοχεύοντας "
            "συγκεκριμένους νομούς — μπορείς να κάνεις αίτηση απευθείας.\n\n"
            "Ερ: Μπορώ να διεκδικήσω το προφίλ μου αν με βρω στο ρόστερ;\n"
            "Απ: Ναι, αν το όνομα ταιριάζει, υπάρχει κουμπί «Είσαι εσύ αυτός/αυτή ο παίκτης;» "
            "για να συνδέσεις τον λογαριασμό σου."
        ),
        "en": (
            "The Scouting Hub is a public directory of teams, players, and technical staff.\n\n"
            "Frequently asked questions:\n"
            "Q: What is the Scouting Hub?\n"
            "A: A public directory of teams, players and technical staff, with filters by "
            "position/age/status.\n\n"
            "Q: How are players shown when I view a team?\n"
            "A: Sorted by position (Goalkeepers → Defense → Midfield → Attack), with a "
            "choice of grouped or compact view.\n\n"
            "Q: How is staff organized?\n"
            "A: In sections by home region (federation) — each staff member can declare "
            "where they're from, what role they're seeking, and which regions they'd like to "
            "work in, from their Profile.\n\n"
            "Q: What are Listings?\n"
            "A: Teams post listings for staff or players, optionally targeting specific "
            "regions — you can apply directly.\n\n"
            "Q: Can I claim my profile if I find myself on a roster?\n"
            "A: Yes, if the name matches, there's an \"Is this you?\" button to link your "
            "account."
        ),
    },
    "messages": {
        "el": (
            "Η ενότητα Μηνύματα είναι εσωτερικό chat μεταξύ χρηστών.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς στέλνω μήνυμα σε κάποιον;\n"
            "Απ: Οι συζητήσεις δημιουργούνται συχνά αυτόματα (π.χ. όταν αποδεχτείς αίτηση "
            "ανάληψης ομάδας) — μπορείς επίσης να ξεκινήσεις νέα από τη σελίδα Μηνύματα."
        ),
        "en": (
            "The Messages section is internal chat between users.\n\n"
            "Frequently asked questions:\n"
            "Q: How do I message someone?\n"
            "A: Conversations are often created automatically (e.g. when you accept a team "
            "takeover request) — you can also start a new one from the Messages page."
        ),
    },
    "staff": {
        "el": (
            "Η ενότητα Staff δείχνει λίστα του τεχνικού επιτελείου σου.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι δείχνει η ενότητα Staff;\n"
            "Απ: Λίστα του τεχνικού επιτελείου των ομάδων σου."
        ),
        "en": (
            "The Staff section shows a list of your technical staff.\n\n"
            "Frequently asked questions:\n"
            "Q: What does the Staff section show?\n"
            "A: A list of your teams' technical staff."
        ),
    },
    "academy": {
        "el": (
            "Η ενότητα Ακαδημία διαχειρίζεται εγγραφές, συνδρομές και ρουχισμό παικτών.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς παρακολουθώ ποιος έχει απλήρωτη συνδρομή;\n"
            "Απ: Η λίστα δείχνει ποιοι παίκτες έχουν εκπρόθεσμη δόση ή συνολική οφειλή, με το "
            "ποσό.\n\n"
            "Ερ: Πώς στέλνω υπενθύμιση σε γονέα;\n"
            "Απ: Υπάρχουν έτοιμα μηνύματα (εκπρόθεσμη δόση, συνολική οφειλή, υπενθύμιση "
            "εγγραφής, ρουχισμός, γενική υπενθύμιση) που στέλνεις με ένα κλικ.\n\n"
            "Ερ: Πώς παρακολουθώ τον ρουχισμό;\n"
            "Απ: Κάθε παίκτης ακαδημίας έχει λίστα ειδών ρουχισμού με κατάσταση παραλαβής/"
            "πληρωμής."
        ),
        "en": (
            "The Academy section manages registrations, fees, and kit for players.\n\n"
            "Frequently asked questions:\n"
            "Q: How do I track who has an unpaid fee?\n"
            "A: The list shows which players have an overdue installment or a total balance, "
            "with the amount.\n\n"
            "Q: How do I send a reminder to a parent?\n"
            "A: There are ready-made messages (overdue installment, total balance, "
            "registration reminder, kit, general reminder) you can send with one click.\n\n"
            "Q: How do I track kit?\n"
            "A: Each academy player has a list of kit items with received/paid status."
        ),
    },
    "crm": {
        "el": (
            "Το CRM οργανώνει επαφές και θέματα προς παρακολούθηση (follow-ups).\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι είναι το CRM;\n"
            "Απ: Οργανώνει επαφές και θέματα (topics) προς παρακολούθηση, με κατηγορία, "
            "προτεραιότητα και κατάσταση, ώστε να μη σου ξεφεύγει κανένα follow-up."
        ),
        "en": (
            "The CRM organizes contacts and topics to follow up on.\n\n"
            "Frequently asked questions:\n"
            "Q: What is the CRM?\n"
            "A: It organizes contacts and topics to track, with category, priority, and "
            "status, so no follow-up slips through."
        ),
    },
    "notifications": {
        "el": (
            "Η ενότητα Ειδοποιήσεις δείχνει όλες τις πρόσφατες ειδοποιήσεις σου.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πού βλέπω τις ειδοποιήσεις μου;\n"
            "Απ: Εδώ εμφανίζονται όλες οι πρόσφατες ειδοποιήσεις σου (νέες αιτήσεις, "
            "απαντήσεις κ.λπ.)."
        ),
        "en": (
            "The Notifications section shows all your recent notifications.\n\n"
            "Frequently asked questions:\n"
            "Q: Where do I see my notifications?\n"
            "A: Here you'll find all your recent notifications (new requests, replies, etc.)."
        ),
    },
    "settings": {
        "el": (
            "Οι Ρυθμίσεις περιλαμβάνουν λογαριασμό, AI, χρήστες, εξαγωγή δεδομένων και backup.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πού ρυθμίζω το AI (για Match Summary και επαλήθευση πτυχίων);\n"
            "Απ: Ρυθμίσεις -> AI Configuration — πρόσθεσε το δικό σου API key από Anthropic ή "
            "OpenAI. Αποθηκεύεται στη βάση σου.\n\n"
            "Ερ: Πώς κάνω backup της βάσης δεδομένων;\n"
            "Απ: Ρυθμίσεις -> Backup & Restore (μόνο για admin, λειτουργεί με τοπική SQLite "
            "βάση).\n\n"
            "Ερ: Πώς συνδέω λογαριασμό χρήστη με παίκτη;\n"
            "Απ: Ρυθμίσεις -> Διαχείριση Χρηστών (admin only) -> επίλεξε τον παίκτη από τη "
            "λίστα δίπλα στον χρήστη."
        ),
        "en": (
            "Settings includes account, AI, users, data export, and backup.\n\n"
            "Frequently asked questions:\n"
            "Q: Where do I configure AI (for Match Summary and diploma verification)?\n"
            "A: Settings -> AI Configuration — add your own API key from Anthropic or "
            "OpenAI. It's stored in your database.\n\n"
            "Q: How do I back up the database?\n"
            "A: Settings -> Backup & Restore (admin only, works with the local SQLite "
            "database).\n\n"
            "Q: How do I link a user account to a player?\n"
            "A: Settings -> User Management (admin only) -> pick the player from the list "
            "next to the user."
        ),
    },
    "profile": {
        "el": (
            "Το Προφίλ δείχνει στοιχεία, trust level, πτυχία και τι δουλειά ψάχνεις.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Πώς ανεβάζω πτυχίο προπονητικής άδειας;\n"
            "Απ: Προφίλ -> Trust & Verification, επίλεξε τύπο εγγράφου «Πτυχίο Προπονητή» και "
            "ανέβασε τη φωτογραφία. Αν είναι γνήσιο πτυχίο UEFA C/B/A/PRO (ή αντίστοιχο) και "
            "το όνομα ταιριάζει, εγκρίνεται αυτόματα από το AI.\n\n"
            "Ερ: Τι είναι το επίπεδο επαλήθευσης (Trust Level);\n"
            "Απ: Grey (0 εγκεκριμένα έγγραφα), Blue (1), Green (2+) — καθορίζει πόσες "
            "ταυτόχρονες ομάδες μπορείς να διαχειρίζεσαι.\n\n"
            "Ερ: Πώς δηλώνω τι δουλειά ψάχνω;\n"
            "Απ: Προφίλ, ενότητα «Τι Ψάχνω» — επίλεξε ρόλο, από πού είσαι, και σε ποιες "
            "περιοχές θέλεις να εργαστείς. Εμφανίζεται στο Scouting Hub."
        ),
        "en": (
            "The Profile shows your details, trust level, diplomas, and job preferences.\n\n"
            "Frequently asked questions:\n"
            "Q: How do I upload a coaching license diploma?\n"
            "A: Profile -> Trust & Verification, pick document type \"Coaching License\" and "
            "upload the photo. If it's a genuine UEFA C/B/A/PRO diploma (or equivalent) and "
            "the name matches, it's auto-approved by AI.\n\n"
            "Q: What is the Trust Level?\n"
            "A: Grey (0 approved documents), Blue (1), Green (2+) — determines how many "
            "simultaneous teams you can manage.\n\n"
            "Q: How do I declare what job I'm looking for?\n"
            "A: Profile, \"What I'm Looking For\" section — pick a role, where you're from, "
            "and which regions you want to work in. Shows up in the Scouting Hub."
        ),
    },
    "performance": {
        "el": (
            "Η ενότητα Απόδοση δείχνει γραφήματα στατιστικών με την πάροδο του χρόνου.\n\n"
            "Συχνές ερωτήσεις:\n"
            "Ερ: Τι δείχνει η ενότητα Απόδοση;\n"
            "Απ: Γραφήματα στατιστικών απόδοσης παικτών/ομάδας με την πάροδο του χρόνου."
        ),
        "en": (
            "The Performance section shows statistics charts over time.\n\n"
            "Frequently asked questions:\n"
            "Q: What does the Performance section show?\n"
            "A: Charts of player/team performance statistics over time."
        ),
    },
    "general": {
        "el": "Αυτή είναι η εφαρμογή FootballHub — πλατφόρμα διαχείρισης ποδοσφαιρικού συλλόγου (ομάδες, παίκτες, αγώνες, προπονήσεις, scouting, ακαδημία, CRM).",
        "en": "This is FootballHub — a football club management platform (teams, players, matches, trainings, scouting, academy, CRM).",
    },
}


class MelieChatMessage(BaseModel):
    role: str = Field(description="user | assistant")
    content: str


class MelieChatRequest(BaseModel):
    section: str
    language: str = Field(default="el", description="el | en")
    message: str
    history: list[MelieChatMessage] = Field(default_factory=list)


class MelieChatResponse(BaseModel):
    reply: str
    ai_configured: bool


def _build_system_prompt(section: str, language: str) -> str:
    section_desc = SECTION_INFO.get(section, SECTION_INFO["general"])
    lang_key = "en" if language == "en" else "el"
    section_text = section_desc.get(lang_key, section_desc["el"])
    lang_name = "English" if lang_key == "en" else "Greek (Ελληνικά)"

    return (
        "Είσαι η Melie, ο φιλικός βοηθός χρήσης της εφαρμογής FootballHub. Ο ρόλος σου "
        "είναι ΑΠΟΚΛΕΙΣΤΙΚΑ να εξηγείς πώς λειτουργεί η εφαρμογή — ΟΧΙ να δίνεις "
        "ποδοσφαιρικές συμβουλές, τακτικές αναλύσεις, ή να απαντάς σε άσχετα θέματα. "
        f"Ο χρήστης βρίσκεται αυτή τη στιγμή σε αυτή την ενότητα: {section_text} "
        "Απάντησε σύντομα, φιλικά και συγκεκριμένα, εστιάζοντας στην ενότητα που "
        "βρίσκεται ο χρήστης εκτός αν ρωτήσει ρητά για κάτι άλλο της εφαρμογής. "
        f"Απάντησε ΠΑΝΤΑ στα {lang_name}, ανεξάρτητα από τη γλώσσα της ερώτησης. "
        "Αν κάτι δεν σχετίζεται με τη χρήση της εφαρμογής, εξήγησε ευγενικά ότι μπορείς "
        "να βοηθήσεις μόνο με ερωτήσεις για το πώς λειτουργεί το FootballHub."
    )


@router.post("/chat", response_model=MelieChatResponse)
def chat_with_melie(
    payload: MelieChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not ai_service.is_configured(db):
        fallback = (
            "Η Melie χρειάζεται να ρυθμιστεί το AI από κάποιον διαχειριστή (Ρυθμίσεις -> AI "
            "Configuration) για να μπορεί να απαντήσει."
            if payload.language != "en"
            else "Melie needs AI to be configured by an admin (Settings -> AI Configuration) "
            "before she can reply."
        )
        return MelieChatResponse(reply=fallback, ai_configured=False)

    system_prompt = _build_system_prompt(payload.section, payload.language)
    history = [{"role": m.role, "content": m.content} for m in payload.history[-MAX_HISTORY_MESSAGES:]]
    history.append({"role": "user", "content": payload.message})

    try:
        reply = ai_service.generate_chat_reply(db, system_prompt, history, max_tokens=600)
    except ai_service.AINotConfiguredError:
        fallback = (
            "Η Melie χρειάζεται να ρυθμιστεί το AI από κάποιον διαχειριστή για να απαντήσει."
            if payload.language != "en"
            else "Melie needs AI to be configured by an admin before she can reply."
        )
        return MelieChatResponse(reply=fallback, ai_configured=False)

    return MelieChatResponse(reply=reply, ai_configured=True)
