from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, true
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import Notification, User
from app.permissions import sees_all_data
from app.schemas import NotificationOut

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


def _visible_filter(current_user: User):
    """Ένας χρήστης βλέπει τις δικές του στοχευμένες ειδοποιήσεις ΚΑΙ τις
    καθολικές (user_id IS NULL, π.χ. 'επερχόμενος αγώνας') — όχι τις
    στοχευμένες ειδοποιήσεις άλλων χρηστών. Ο Super Admin βλέπει τα πάντα
    (επίβλεψη πλατφόρμας) — αλλιώς, αν δεν ανήκει σε καμία ομάδα, θα έβλεπε
    πάντα άδεια λίστα παρά το ότι συμβαίνουν πράγματα στην πλατφόρμα."""
    if sees_all_data(current_user):
        return true()
    return or_(Notification.user_id == current_user.id, Notification.user_id.is_(None))


@router.get("", response_model=list[NotificationOut])
def list_notifications(
    unread_only: bool = False,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Notification).filter(_visible_filter(current_user))
    if unread_only:
        query = query.filter(Notification.is_read.is_(False))
    return query.order_by(Notification.created_at.desc()).limit(limit).all()


@router.get("/unread-count")
def unread_count(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    count = (
        db.query(Notification)
        .filter(_visible_filter(current_user), Notification.is_read.is_(False))
        .count()
    )
    return {"count": count}


@router.put("/{notification_id}/read", response_model=NotificationOut)
def mark_read(
    notification_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    notification = (
        db.query(Notification)
        .filter(Notification.id == notification_id, _visible_filter(current_user))
        .first()
    )
    if not notification:
        raise HTTPException(status_code=404, detail="Η ειδοποίηση δεν βρέθηκε")
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


@router.put("/read-all", status_code=204)
def mark_all_read(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    db.query(Notification).filter(_visible_filter(current_user), Notification.is_read.is_(False)).update(
        {"is_read": True}, synchronize_session=False
    )
    db.commit()
    return None


@router.delete("/{notification_id}", status_code=204)
def delete_notification(
    notification_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    notification = (
        db.query(Notification)
        .filter(Notification.id == notification_id, _visible_filter(current_user))
        .first()
    )
    if not notification:
        raise HTTPException(status_code=404, detail="Η ειδοποίηση δεν βρέθηκε")
    db.delete(notification)
    db.commit()
    return None
