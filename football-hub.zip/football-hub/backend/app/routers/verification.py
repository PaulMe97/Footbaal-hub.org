import json
import re
import unicodedata
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.config import MAX_UPLOAD_SIZE_MB, VERIFICATION_DOCS_DIR
from app.database import get_db
from app.models import Team, User, UserRole, VerificationDocument
from app.permissions import VERIFICATION_LEVEL_LABELS, get_max_grants_for_verification
from app.schemas import (
    AdminUserDocumentOut,
    AdminUserListItem,
    VerificationDocumentAdminOut,
    VerificationDocumentOut,
    VerificationReviewRequest,
    VerificationStatusOut,
)
from app.services import ai_service

router = APIRouter(prefix="/api/verification", tags=["verification"])

VALID_DOCUMENT_TYPES = {"id_document", "coaching_license", "reference_letter", "club_registration"}
ALLOWED_DOCUMENT_MIME_TYPES = {"image/jpeg", "image/png", "image/webp", "application/pdf"}
# Η αυτόματη επαλήθευση με AI vision δουλεύει μόνο σε εικόνες (όχι PDF).
AUTO_VERIFY_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}

# Η επέκταση αποθήκευσης καθορίζεται ΠΑΝΤΑ από τον server (βάσει του
# πραγματικά ανιχνευμένου τύπου αρχείου) — ποτέ από το filename που έστειλε
# ο client, ώστε να μην μπορεί κάποιος να "μεταμφιέσει" ένα κακόβουλο
# αρχείο (π.χ. .html με script μέσα) πίσω από ένα ψεύτικο Content-Type.
EXTENSION_BY_MIME = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "application/pdf": ".pdf",
}


def _detect_real_mime_type(contents: bytes) -> str | None:
    """Ανιχνεύει το ΠΡΑΓΜΑΤΙΚΟ mime type ενός αρχείου από τα πρώτα του bytes
    (magic number/file signature) — ΠΟΤΕ μην εμπιστεύεσαι το Content-Type
    header που στέλνει ο client, παραποιείται πολύ εύκολα και θα άνοιγε
    δρόμο για stored XSS (π.χ. ανέβασμα .html μεταμφιεσμένο σε "εικόνα")."""
    if contents.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if contents.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if contents[:4] == b"RIFF" and contents[8:12] == b"WEBP":
        return "image/webp"
    if contents.startswith(b"%PDF"):
        return "application/pdf"
    return None
ADMIN_ROLES = {UserRole.SUPER_ADMIN, UserRole.ADMIN}
CLUB_LEADERSHIP_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}

_COACHING_LICENSE_SYSTEM_PROMPT = (
    "Είσαι σύστημα επαλήθευσης εγγράφων για πλατφόρμα διαχείρισης ποδοσφαιρικών "
    "σωματείων. Θα δεις μια εικόνα ενός εγγράφου που υποστηρίζεται ότι είναι "
    "πτυχίο/δίπλωμα προπονητικής άδειας ποδοσφαίρου (π.χ. UEFA C/B/A/PRO Diploma, ή "
    "αντίστοιχο επίσημο πτυχίο εθνικής ποδοσφαιρικής ομοσπονδίας). Απάντησε "
    "ΑΠΟΚΛΕΙΣΤΙΚΑ με ένα JSON object, χωρίς κανένα άλλο κείμενο και χωρίς markdown "
    "code fences, με ακριβώς αυτά τα πεδία:\n"
    '{"is_coaching_license": true/false, "level": "C"|"B"|"A"|"PRO"|"other"|null, '
    '"name_on_document": "..."|null, "confidence": "high"|"medium"|"low"}\n'
    "Μην επινοήσεις πληροφορίες που δεν φαίνονται καθαρά στην εικόνα."
)
_COACHING_LICENSE_USER_PROMPT = "Ανάλυσε το επισυναπτόμενο έγγραφο και απάντησε με το ζητούμενο JSON."


def _require_admin(current_user: User) -> None:
    if current_user.role not in ADMIN_ROLES:
        raise HTTPException(status_code=403, detail="Μόνο διαχειριστές έχουν πρόσβαση.")


def _recompute_verification_level(db: Session, user_id: str) -> None:
    """grey (0): 0 εγκεκριμένα έγγραφα, blue (1): 1 εγκεκριμένο,
    green (2): 2+ εγκεκριμένα — ΜΟΝΟ βάσει εγκεκριμένων (όχι απλά
    ανεβασμένων) εγγράφων, ώστε η πιστότητα να αντανακλά πραγματικό έλεγχο,
    όχι απλή προσπάθεια μεταφόρτωσης."""
    approved_count = (
        db.query(VerificationDocument)
        .filter(VerificationDocument.user_id == user_id, VerificationDocument.status == "approved")
        .count()
    )
    level = 2 if approved_count >= 2 else (1 if approved_count >= 1 else 0)
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        user.verification_level = level
        db.commit()


def _normalize_name_words(name: str) -> set:
    if not name:
        return set()
    normalized = unicodedata.normalize("NFKD", name)
    normalized = "".join(c for c in normalized if not unicodedata.combining(c))
    return set(re.findall(r"[a-zA-Zα-ωΑ-Ω]+", normalized.lower()))


def _names_match(stored_name: str, document_name: str) -> bool:
    """Χαλαρή σύγκριση ονομάτων — αγνοεί τόνους/κεφαλαία/σειρά λέξεων, αλλά
    απαιτεί όλες οι λέξεις του ενός ονόματος να εμφανίζονται στο άλλο."""
    stored_words = _normalize_name_words(stored_name)
    doc_words = _normalize_name_words(document_name)
    if not stored_words or not doc_words:
        return False
    return stored_words.issubset(doc_words) or doc_words.issubset(stored_words)


def _try_auto_verify_coaching_license(
    db: Session, document: VerificationDocument, user: User, contents: bytes, media_type: str
) -> bool:
    """Προσπαθεί να επαληθεύσει αυτόματα ένα πτυχίο προπονητικής άδειας
    (UEFA C/B/A/PRO ή αντίστοιχο εθνικής ομοσπονδίας) μέσω AI vision. Αν
    πετύχει, εγκρίνει το έγγραφο αμέσως — χωρίς να χρειάζεται manual admin
    review. Σε κάθε άλλη περίπτωση (AI μη ρυθμισμένο, σφάλμα, αβεβαιότητα,
    ασυμφωνία ονόματος) το έγγραφο ΠΑΡΑΜΕΝΕΙ pending για κανονικό review —
    ΔΕΝ απορρίπτεται ποτέ αυτόματα. Επιστρέφει True αν έγινε auto-approve."""
    if media_type not in AUTO_VERIFY_IMAGE_TYPES:
        return False
    if not ai_service.is_configured(db):
        return False
    if not user.full_name:
        return False
    try:
        raw = ai_service.generate_vision_text(
            db, _COACHING_LICENSE_SYSTEM_PROMPT, _COACHING_LICENSE_USER_PROMPT, contents, media_type
        )
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned
        result = json.loads(cleaned)
    except Exception:
        return False

    if not result.get("is_coaching_license"):
        return False
    if result.get("confidence") not in ("high", "medium"):
        return False
    if not _names_match(user.full_name, result.get("name_on_document") or ""):
        return False

    document.status = "approved"
    document.auto_verified = True
    document.reviewed_at = datetime.utcnow()
    db.commit()
    return True


_CLUB_REGISTRATION_SYSTEM_PROMPT = (
    "Είσαι σύστημα επαλήθευσης εγγράφων για πλατφόρμα διαχείρισης ποδοσφαιρικών "
    "σωματείων. Θα δεις μια εικόνα ενός εγγράφου που υποστηρίζεται ότι είναι επίσημο "
    "έγγραφο συλλόγου (π.χ. βεβαίωση εγγραφής/μέλους από ΕΠΣ ή ΕΠΟ, καταστατικό, "
    "έγγραφο ΓΕΜΗ, ή επίσημη επιστολή με λογότυπο/σφραγίδα συλλόγου). Απάντησε "
    "ΑΠΟΚΛΕΙΣΤΙΚΑ με ένα JSON object, χωρίς κανένα άλλο κείμενο και χωρίς markdown "
    "code fences, με ακριβώς αυτά τα πεδία:\n"
    '{"is_club_document": true/false, "club_name": "..."|null, "tax_id": "..."|null, '
    '"confidence": "high"|"medium"|"low"}\n'
    "Μην επινοήσεις πληροφορίες που δεν φαίνονται καθαρά στην εικόνα."
)
_CLUB_REGISTRATION_USER_PROMPT = "Ανάλυσε το επισυναπτόμενο έγγραφο και απάντησε με το ζητούμενο JSON."


def _try_auto_verify_club_registration(
    db: Session, document: VerificationDocument, user: User, contents: bytes, media_type: str
) -> bool:
    """Προσπαθεί να επαληθεύσει αυτόματα ότι ο χρήστης (Πρόεδρος/Τεχνικός
    Διευθυντής) εκπροσωπεί έναν γνήσιο σύλλογο, μέσω AI vision πάνω σε
    επίσημο έγγραφο συλλόγου. Επιτυχία = γίνεται user.club_verified = True,
    το οποίο ξεκλειδώνει ορατότητα στο Scouting Hub και δημοσίευση αγγελιών
    για τις ομάδες του — ΔΕΝ επηρεάζει το γενικό verification_level. Σε κάθε
    αβεβαιότητα το έγγραφο ΠΑΡΑΜΕΝΕΙ pending για manual admin review."""
    if media_type not in AUTO_VERIFY_IMAGE_TYPES:
        return False
    if not ai_service.is_configured(db):
        return False
    try:
        raw = ai_service.generate_vision_text(
            db, _CLUB_REGISTRATION_SYSTEM_PROMPT, _CLUB_REGISTRATION_USER_PROMPT, contents, media_type
        )
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned
        result = json.loads(cleaned)
    except Exception:
        return False

    if not result.get("is_club_document"):
        return False
    if result.get("confidence") not in ("high", "medium"):
        return False

    matched = False
    doc_tax_id = (result.get("tax_id") or "").strip()
    if doc_tax_id and user.team_tax_id and doc_tax_id == user.team_tax_id.strip():
        matched = True
    if not matched and result.get("club_name"):
        owned_team_names = [t.name for t in db.query(Team).filter(Team.owner_id == user.id).all()]
        matched = any(_names_match(name, result["club_name"]) for name in owned_team_names)

    if not matched:
        return False

    user.club_verified = True
    document.status = "approved"
    document.auto_verified = True
    document.reviewed_at = datetime.utcnow()
    db.commit()
    return True


@router.get("/me", response_model=VerificationStatusOut)
def get_my_verification_status(
    db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    documents = (
        db.query(VerificationDocument)
        .filter(VerificationDocument.user_id == current_user.id)
        .order_by(VerificationDocument.uploaded_at.desc())
        .all()
    )
    return VerificationStatusOut(
        verification_level=current_user.verification_level,
        level_label=VERIFICATION_LEVEL_LABELS.get(current_user.verification_level, "grey"),
        documents=[VerificationDocumentOut.model_validate(d) for d in documents],
        max_simultaneous_teams=get_max_grants_for_verification(current_user),
        club_verified=current_user.club_verified,
    )


@router.post("/documents", response_model=VerificationDocumentOut, status_code=201)
def upload_verification_document(
    document_type: str = Form(...),
    consent: bool = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not consent:
        raise HTTPException(
            status_code=400,
            detail="Χρειάζεται ρητή συναίνεση για την επεξεργασία του εγγράφου (GDPR) πριν το ανέβασμα.",
        )
    if document_type not in VALID_DOCUMENT_TYPES:
        raise HTTPException(status_code=400, detail="Μη έγκυρος τύπος εγγράφου")
    contents = file.file.read()
    if len(contents) > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"Το αρχείο ξεπερνά τα {MAX_UPLOAD_SIZE_MB}MB")

    # Ποτέ μην εμπιστεύεσαι το Content-Type header του client — παραποιείται
    # πολύ εύκολα. Ελέγχουμε τα ΠΡΑΓΜΑΤΙΚΑ πρώτα bytes του αρχείου.
    detected_mime = _detect_real_mime_type(contents)
    if detected_mime not in ALLOWED_DOCUMENT_MIME_TYPES:
        raise HTTPException(status_code=400, detail="Επιτρέπονται μόνο JPG, PNG, WEBP ή PDF αρχεία")

    filename = f"{uuid.uuid4()}{EXTENSION_BY_MIME[detected_mime]}"
    dest = VERIFICATION_DOCS_DIR / filename
    dest.write_bytes(contents)

    if not current_user.document_consent_at:
        current_user.document_consent_at = datetime.utcnow()

    document = VerificationDocument(
        user_id=current_user.id,
        document_type=document_type,
        file_path=filename,
        content_type=detected_mime,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    if document_type == "coaching_license":
        auto_approved = _try_auto_verify_coaching_license(
            db, document, current_user, contents, detected_mime
        )
        if auto_approved:
            db.refresh(document)
            _recompute_verification_level(db, current_user.id)
    elif document_type == "club_registration":
        auto_approved = _try_auto_verify_club_registration(
            db, document, current_user, contents, detected_mime
        )
        if auto_approved:
            db.refresh(document)

    return document


@router.delete("/documents/{document_id}", status_code=204)
def delete_my_document(
    document_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    document = (
        db.query(VerificationDocument)
        .filter(VerificationDocument.id == document_id, VerificationDocument.user_id == current_user.id)
        .first()
    )
    if not document:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    if document.status == "approved":
        raise HTTPException(status_code=400, detail="Δεν μπορείς να διαγράψεις ήδη εγκεκριμένο έγγραφο.")
    file_path = VERIFICATION_DOCS_DIR / document.file_path
    if file_path.exists():
        file_path.unlink()
    db.delete(document)
    db.commit()
    _recompute_verification_level(db, current_user.id)
    return None


# ---------------------------------------------------------------------------
# Admin review queue
# ---------------------------------------------------------------------------
@router.get("/admin/users", response_model=list[AdminUserListItem])
def list_admin_users(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Ενιαία, εμπλουτισμένη λίστα όλων των χρηστών για τη σελίδα Διαχείρισης
    Χρηστών — μαζεύει σε ΈΝΑ μόνο API call τα βασικά στοιχεία κάθε χρήστη
    ΜΑΖΙ με όλα τα έγγραφα επαλήθευσης που έχει ανεβάσει, ώστε το frontend
    να μην χρειάζεται ξεχωριστό αίτημα ανά χρήστη — σημαντικό με μεγάλο
    όγκο χρηστών."""
    _require_admin(current_user)
    users = db.query(User).order_by(User.full_name, User.username).all()
    docs_by_user: dict[str, list[VerificationDocument]] = {}
    for doc in db.query(VerificationDocument).order_by(VerificationDocument.uploaded_at.desc()).all():
        docs_by_user.setdefault(doc.user_id, []).append(doc)

    result = []
    for u in users:
        needs_approval = u.role in CLUB_LEADERSHIP_ROLES and not u.leadership_approved
        result.append(
            AdminUserListItem(
                id=u.id,
                email=u.email,
                username=u.username,
                full_name=u.full_name,
                role=u.role,
                is_active=u.is_active,
                avatar_path=u.avatar_path,
                phone=u.phone,
                date_of_birth=u.date_of_birth,
                verification_level=u.verification_level,
                leadership_approved=u.leadership_approved,
                needs_approval=needs_approval,
                created_at=u.created_at,
                documents=[
                    AdminUserDocumentOut(
                        id=d.id,
                        document_type=d.document_type,
                        status=d.status,
                        content_type=d.content_type,
                        rejection_reason=d.rejection_reason,
                        auto_verified=d.auto_verified,
                        uploaded_at=d.uploaded_at,
                    )
                    for d in docs_by_user.get(u.id, [])
                ],
            )
        )
    return result


@router.get("/admin/pending", response_model=list[VerificationDocumentAdminOut])
def list_pending_documents(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    _require_admin(current_user)
    rows = (
        db.query(VerificationDocument, User)
        .join(User, VerificationDocument.user_id == User.id)
        .filter(VerificationDocument.status == "pending")
        .order_by(VerificationDocument.uploaded_at.asc())
        .all()
    )
    return [
        VerificationDocumentAdminOut(
            id=d.id,
            document_type=d.document_type,
            status=d.status,
            rejection_reason=d.rejection_reason,
            uploaded_at=d.uploaded_at,
            reviewed_at=d.reviewed_at,
            user_id=u.id,
            user_name=u.full_name,
            user_role=u.role,
        )
        for d, u in rows
    ]


@router.get("/admin/documents/{document_id}/file")
def get_document_file(
    document_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    document = db.query(VerificationDocument).filter(VerificationDocument.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    # Μόνο ο ίδιος ο χρήστης ή admin μπορεί να δει το αρχείο — ποτέ δημόσιο URL.
    if current_user.role not in ADMIN_ROLES and current_user.id != document.user_id:
        raise HTTPException(status_code=403, detail="Δεν έχεις πρόσβαση")
    file_path = VERIFICATION_DOCS_DIR / document.file_path
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Το αρχείο δεν βρέθηκε")
    # ΠΟΤΕ να μην αφήνεις τον server να "μαντέψει" τον τύπο βάσει της
    # επέκτασης του filename — δίνουμε ρητά τον server-verified τύπο (από
    # τα πραγματικά bytes κατά το upload), ώστε ένα κακόβουλο αρχείο να
    # μην μπορεί ποτέ να σερβιριστεί σαν HTML/script (stored XSS).
    return FileResponse(str(file_path), media_type=document.content_type or "application/octet-stream")


@router.put("/admin/documents/{document_id}/review", response_model=VerificationDocumentAdminOut)
def review_document(
    document_id: str,
    payload: VerificationReviewRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    document = db.query(VerificationDocument).filter(VerificationDocument.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    if document.status != "pending":
        raise HTTPException(status_code=400, detail="Το έγγραφο έχει ήδη αξιολογηθεί.")

    document.status = "approved" if payload.approve else "rejected"
    document.rejection_reason = payload.rejection_reason if not payload.approve else None
    document.reviewed_by = current_user.id
    document.reviewed_at = datetime.utcnow()
    db.commit()
    db.refresh(document)

    _recompute_verification_level(db, document.user_id)

    user = db.query(User).filter(User.id == document.user_id).first()
    return VerificationDocumentAdminOut(
        id=document.id,
        document_type=document.document_type,
        status=document.status,
        rejection_reason=document.rejection_reason,
        uploaded_at=document.uploaded_at,
        reviewed_at=document.reviewed_at,
        user_id=document.user_id,
        user_name=user.full_name if user else None,
        user_role=user.role if user else None,
    )
