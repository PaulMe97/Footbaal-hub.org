from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user
from app.models import (
    ContractOffer,
    Injury,
    Match,
    MatchPlayer,
    Player,
    PlayerAbsence,
    PlayerStatistics,
    PlayerStatus,
    RenewalRequest,
    Team,
    TrainingSession,
    User,
)
from app.permissions import owned_team_ids
from app.schemas import (
    DashboardStats,
    TopPlayerStat,
    UpcomingMatchInfo,
    UpcomingTrainingInfo,
)

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

MAX_TEAMS_SCANNED = 12  # ασφαλές πλαφόν ακόμα και για Super Admin


def _resolve_team_name(db: Session, team_id, external_name):
    if external_name:
        return external_name
    if team_id:
        t = db.query(Team).filter(Team.id == team_id).first()
        return t.name if t else None
    return None


@router.get("/stats", response_model=DashboardStats)
def get_stats(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    owned_ids = owned_team_ids(db, current_user)
    team_query = db.query(Team)
    player_query = db.query(Player)
    training_query = db.query(TrainingSession)
    if owned_ids is not None:
        team_query = team_query.filter(Team.id.in_(owned_ids))
        player_query = player_query.filter(Player.current_team_id.in_(owned_ids))
        training_query = training_query.filter(TrainingSession.team_id.in_(owned_ids))

    teams = team_query.order_by(Team.name.asc()).limit(MAX_TEAMS_SCANNED).all()

    total_teams = team_query.count()
    total_players = player_query.count()
    injured_players = player_query.filter(Player.status == PlayerStatus.INJURED).count()
    upcoming_trainings_count = training_query.count()

    # Ενεργές απουσίες (εκτός ιατρικού τραυματισμού — αυτός μετράει ήδη ως
    # injured_players) — κόκκινη κάρτα, ταξίδι, αδικαιολόγητος κ.λπ.
    # Μετράμε distinct παίκτες (όχι γραμμές) και συμπεριλαμβάνουμε ΚΑΙ
    # παίκτες με status Ποινή/Μη Διαθέσιμος που δεν έχουν (ακόμα) αντίστοιχη
    # γραμμή PlayerAbsence — ίδιο "virtual merge" pattern με το GET
    # /api/absences (βλ. routers/absences.py), ώστε ο αριθμός εδώ να
    # ταιριάζει πάντα με την ενότητα "Τραυματισμοί / Απουσίες".
    absences_query = db.query(PlayerAbsence.player_id).filter(
        or_(PlayerAbsence.end_date.is_(None), PlayerAbsence.end_date >= date.today())
    )
    if owned_ids is not None:
        absences_query = absences_query.filter(PlayerAbsence.team_id.in_(owned_ids))
    absence_player_ids = {pid for (pid,) in absences_query.all()}

    status_derived_query = db.query(Player.id).filter(
        Player.status.in_([PlayerStatus.SUSPENDED, PlayerStatus.UNAVAILABLE])
    )
    if owned_ids is not None:
        status_derived_query = status_derived_query.filter(Player.current_team_id.in_(owned_ids))
    absence_player_ids.update(pid for (pid,) in status_derived_query.all())

    active_absences_count = len(absence_player_ids)

    today = date.today()
    monday = today - timedelta(days=today.weekday())
    sunday = monday + timedelta(days=6)
    trainings_this_week = training_query.filter(
        TrainingSession.date >= monday, TrainingSession.date <= sunday
    ).count()

    year_start = date(today.year, 1, 1)
    month_start = date(today.year, today.month, 1)

    upcoming_matches: list[UpcomingMatchInfo] = []
    upcoming_trainings: list[UpcomingTrainingInfo] = []
    top_scorers: list[TopPlayerStat] = []
    best_avg_rating_players: list[TopPlayerStat] = []
    top_performers_this_month: list[TopPlayerStat] = []

    # --- Ανά ομάδα breakdown — έτσι κάποιος με πολλές ομάδες (π.χ. Τεχνικός
    # Διευθυντής με έως 8) τις βλέπει ΟΛΕΣ, όχι μόνο τη "νικήτρια" μία. -------
    for team in teams:
        # Επόμενος αγώνας αυτής της ομάδας
        m = (
            db.query(Match)
            .filter(
                Match.status.in_(["scheduled", "live"]),
                Match.date >= today,
                (Match.home_team_id == team.id) | (Match.away_team_id == team.id),
            )
            .order_by(Match.date.asc())
            .first()
        )
        if m:
            is_home = m.home_team_id == team.id
            opponent_name = _resolve_team_name(
                db,
                m.away_team_id if is_home else m.home_team_id,
                m.away_team_name_external if is_home else m.home_team_name_external,
            )
            upcoming_matches.append(
                UpcomingMatchInfo(
                    id=m.id,
                    date=m.date,
                    days_until=(m.date - today).days,
                    team_id=team.id,
                    team_name=team.name,
                    opponent_name=opponent_name,
                    is_home=is_home,
                    stadium=m.stadium,
                    competition=m.competition,
                )
            )

        # Επόμενη προπόνηση αυτής της ομάδας
        t = (
            db.query(TrainingSession)
            .filter(TrainingSession.team_id == team.id, TrainingSession.date >= today)
            .order_by(TrainingSession.date.asc())
            .first()
        )
        if t:
            upcoming_trainings.append(
                UpcomingTrainingInfo(
                    id=t.id,
                    date=t.date,
                    days_until=(t.date - today).days,
                    team_id=team.id,
                    team_name=team.name,
                    training_type=t.training_type,
                    location=t.location,
                )
            )

        # Κορυφαίος σκόρερ αυτής της ομάδας (career σύνολο)
        scorer_row = (
            db.query(PlayerStatistics, Player)
            .join(Player, PlayerStatistics.player_id == Player.id)
            .filter(
                Player.current_team_id == team.id,
                PlayerStatistics.season.is_(None),
                PlayerStatistics.goals > 0,
            )
            .order_by(PlayerStatistics.goals.desc())
            .first()
        )
        if scorer_row:
            stats, player = scorer_row
            top_scorers.append(
                TopPlayerStat(
                    player_id=player.id,
                    player_name=f"{player.first_name} {player.last_name}",
                    team_id=team.id,
                    team_name=team.name,
                    value=float(stats.goals),
                    label=f"{stats.goals} γκολ",
                )
            )

        # Καλύτερος μέσος όρος βαθμολογίας αυτής της ομάδας (φετινό έτος)
        rating_row = (
            db.query(
                MatchPlayer.player_id,
                func.avg(MatchPlayer.rating).label("avg_rating"),
                func.count(MatchPlayer.id).label("apps"),
            )
            .join(Match, MatchPlayer.match_id == Match.id)
            .join(Player, MatchPlayer.player_id == Player.id)
            .filter(
                Player.current_team_id == team.id,
                Match.date >= year_start,
                MatchPlayer.rating.isnot(None),
            )
            .group_by(MatchPlayer.player_id)
            .order_by(func.avg(MatchPlayer.rating).desc())
            .first()
        )
        if rating_row:
            player = db.query(Player).filter(Player.id == rating_row.player_id).first()
            if player:
                avg_val = round(rating_row.avg_rating, 2)
                best_avg_rating_players.append(
                    TopPlayerStat(
                        player_id=player.id,
                        player_name=f"{player.first_name} {player.last_name}",
                        team_id=team.id,
                        team_name=team.name,
                        value=avg_val,
                        label=f"{avg_val} μ.ό. ({rating_row.apps} αγ.)",
                    )
                )

        # Κορυφαία απόδοση αυτής της ομάδας τον τρέχοντα μήνα
        month_row = (
            db.query(
                MatchPlayer.player_id,
                func.avg(MatchPlayer.rating).label("avg_rating"),
                func.count(MatchPlayer.id).label("apps"),
            )
            .join(Match, MatchPlayer.match_id == Match.id)
            .join(Player, MatchPlayer.player_id == Player.id)
            .filter(
                Player.current_team_id == team.id,
                Match.date >= month_start,
                Match.date <= today,
                MatchPlayer.rating.isnot(None),
            )
            .group_by(MatchPlayer.player_id)
            .order_by(func.avg(MatchPlayer.rating).desc())
            .first()
        )
        if month_row:
            player = db.query(Player).filter(Player.id == month_row.player_id).first()
            if player:
                avg_val = round(month_row.avg_rating, 2)
                top_performers_this_month.append(
                    TopPlayerStat(
                        player_id=player.id,
                        player_name=f"{player.first_name} {player.last_name}",
                        team_id=team.id,
                        team_name=team.name,
                        value=avg_val,
                        label=f"{avg_val} μ.ό. ({month_row.apps} αγ.)",
                    )
                )

    # Ταξινόμηση: πιο επείγον/καλύτερο πρώτα
    upcoming_matches.sort(key=lambda x: x.days_until)
    upcoming_trainings.sort(key=lambda x: x.days_until)
    top_scorers.sort(key=lambda x: x.value, reverse=True)
    best_avg_rating_players.sort(key=lambda x: x.value, reverse=True)
    top_performers_this_month.sort(key=lambda x: x.value, reverse=True)

    # --- Πρόσφατη δραστηριότητα (εμπλουτισμένη) --------------------------------
    recent_activity = []
    recent_players = player_query.order_by(Player.created_at.desc()).limit(4).all()
    for p in recent_players:
        recent_activity.append(
            {
                "type": "player_added",
                "text": f"Προστέθηκε ο παίκτης {p.first_name} {p.last_name}",
                "timestamp": p.created_at.isoformat(),
                "entity_type": "player",
                "entity_id": p.id,
            }
        )
    recent_teams = team_query.order_by(Team.created_at.desc()).limit(3).all()
    for team_row in recent_teams:
        recent_activity.append(
            {
                "type": "team_added",
                "text": f"Δημιουργήθηκε η ομάδα {team_row.name}",
                "timestamp": team_row.created_at.isoformat(),
                "entity_type": "team",
                "entity_id": team_row.id,
            }
        )

    injury_query = db.query(Injury, Player).join(Player, Injury.player_id == Player.id)
    if owned_ids is not None:
        injury_query = injury_query.filter(Player.current_team_id.in_(owned_ids))
    for injury, player in injury_query.order_by(Injury.created_at.desc()).limit(3).all():
        recent_activity.append(
            {
                "type": "player_injury",
                "text": f"Ο/Η {player.first_name} {player.last_name} τραυματίστηκε"
                + (f" ({injury.injury_type})" if injury.injury_type else ""),
                "timestamp": injury.created_at.isoformat(),
                "entity_type": "player",
                "entity_id": player.id,
            }
        )

    offer_query = db.query(ContractOffer).filter(ContractOffer.status == "accepted")
    if owned_ids is not None:
        if owned_ids:
            offer_query = offer_query.filter(ContractOffer.team_id.in_(owned_ids))
        else:
            offer_query = offer_query.filter(ContractOffer.id == None)  # noqa: E711
    for offer in offer_query.order_by(ContractOffer.responded_at.desc()).limit(3).all():
        player_user = db.query(User).filter(User.id == offer.player_user_id).first()
        team = db.query(Team).filter(Team.id == offer.team_id).first()
        if player_user and offer.responded_at:
            recent_activity.append(
                {
                    "type": "contract_offer_accepted",
                    "text": f"{player_user.full_name or player_user.username} αποδέχτηκε την προσφορά"
                    + (f" από {team.name}" if team else ""),
                    "timestamp": offer.responded_at.isoformat(),
                    "entity_type": "contract_offer",
                    "entity_id": offer.id,
                }
            )

    renewal_query = db.query(RenewalRequest).filter(RenewalRequest.status == "accepted")
    if owned_ids is not None:
        if owned_ids:
            renewal_query = renewal_query.filter(RenewalRequest.team_id.in_(owned_ids))
        else:
            renewal_query = renewal_query.filter(RenewalRequest.id == None)  # noqa: E711
    for renewal in renewal_query.order_by(RenewalRequest.resolved_at.desc()).limit(3).all():
        renewed_user = db.query(User).filter(User.id == renewal.user_id).first()
        team = db.query(Team).filter(Team.id == renewal.team_id).first()
        if renewed_user and renewal.resolved_at:
            recent_activity.append(
                {
                    "type": "renewal_accepted",
                    "text": f"{renewed_user.full_name or renewed_user.username} ανανέωσε"
                    + (f" με {team.name}" if team else "")
                    + f" για τη σεζόν {renewal.next_season}",
                    "timestamp": renewal.resolved_at.isoformat(),
                    "entity_type": "renewal_request",
                    "entity_id": renewal.id,
                }
            )

    recent_activity.sort(key=lambda x: x["timestamp"], reverse=True)

    return DashboardStats(
        total_teams=total_teams,
        total_players=total_players,
        injured_players=injured_players,
        active_absences_count=active_absences_count,
        upcoming_trainings_count=upcoming_trainings_count,
        trainings_this_week=trainings_this_week,
        upcoming_matches=upcoming_matches,
        upcoming_trainings=upcoming_trainings,
        top_scorers=top_scorers,
        best_avg_rating_players=best_avg_rating_players,
        top_performers_this_month=top_performers_this_month,
        recent_activity=recent_activity[:10],
    )
