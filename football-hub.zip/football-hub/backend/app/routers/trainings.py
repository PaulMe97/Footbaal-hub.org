from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import assert_team_id_access, owned_team_ids, require_write_access
from app.database import get_db
from app.models import (
    AttendanceStatus,
    NotificationType,
    Player,
    PlayerStatus,
    Team,
    TrainingAttendance,
    TrainingSession,
    User,
)
from app.routers.players import mark_player_injured
from app.schemas import (
    PlayerAttendanceSummary,
    TrainingAttendanceIn,
    TrainingAttendanceOut,
    TrainingSessionCreate,
    TrainingSessionOut,
    TrainingSessionUpdate,
)
from app.services.notifications import notify_team

router = APIRouter(prefix="/api/trainings", tags=["trainings"])

VALID_STATUSES = {s.value for s in AttendanceStatus}


def _to_out(session: TrainingSession, db: Session) -> TrainingSessionOut:
    team = db.query(Team).filter(Team.id == session.team_id).first()
    attendances = (
        db.query(TrainingAttendance).filter(TrainingAttendance.session_id == session.id).all()
    )
    present = sum(1 for a in attendances if a.status == AttendanceStatus.PRESENT)
    out = TrainingSessionOut.model_validate(session)
    out.team_name = team.name if team else None
    out.attendance_present = present
    out.attendance_total = len(attendances)
    return out


@router.get("", response_model=list[TrainingSessionOut])
def list_trainings(
    team_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(TrainingSession)
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(TrainingSession.team_id.in_(owned_ids))
    if team_id:
        query = query.filter(TrainingSession.team_id == team_id)
    sessions = query.order_by(TrainingSession.date.desc()).all()
    return [_to_out(s, db) for s in sessions]


@router.post("", response_model=TrainingSessionOut, status_code=201)
def create_training(
    payload: TrainingSessionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == payload.team_id).first()
    if not team:
        raise HTTPException(status_code=400, detail="Η ομάδα δεν βρέθηκε")
    assert_team_id_access(db, current_user, team.id, "Η ομάδα δεν βρέθηκε")
    session = TrainingSession(**payload.model_dump())
    db.add(session)
    db.commit()
    db.refresh(session)

    # Αυτόματη προ-συμπλήρωση attendance ως "present" για όλους τους παίκτες της ομάδας
    players = db.query(Player).filter(Player.current_team_id == team.id).all()
    for p in players:
        db.add(TrainingAttendance(session_id=session.id, player_id=p.id, status=AttendanceStatus.PRESENT))
    db.commit()
    db.refresh(session)

    notify_team(
        db,
        team.id,
        NotificationType.UPCOMING_TRAINING,
        title=f"Νέα προπόνηση: {team.name}",
        message=f"Προγραμματίστηκε για {session.date}" + (f" στις {session.time}" if session.time else ""),
        related_entity_type="training",
        related_entity_id=session.id,
    )
    return _to_out(session, db)


@router.get("/{session_id}", response_model=TrainingSessionOut)
def get_training(
    session_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Η προπόνηση δεν βρέθηκε")
    assert_team_id_access(db, current_user, session.team_id, "Η προπόνηση δεν βρέθηκε")
    return _to_out(session, db)


@router.put("/{session_id}", response_model=TrainingSessionOut)
def update_training(
    session_id: str,
    payload: TrainingSessionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Η προπόνηση δεν βρέθηκε")
    assert_team_id_access(db, current_user, session.team_id, "Η προπόνηση δεν βρέθηκε")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(session, field, value)
    db.commit()
    db.refresh(session)
    return _to_out(session, db)


@router.delete("/{session_id}", status_code=204)
def delete_training(
    session_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Η προπόνηση δεν βρέθηκε")
    assert_team_id_access(db, current_user, session.team_id, "Η προπόνηση δεν βρέθηκε")
    db.delete(session)
    db.commit()
    return None


@router.get("/{session_id}/attendance", response_model=list[TrainingAttendanceOut])
def get_attendance(
    session_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Η προπόνηση δεν βρέθηκε")
    assert_team_id_access(db, current_user, session.team_id, "Η προπόνηση δεν βρέθηκε")
    rows = (
        db.query(TrainingAttendance, Player)
        .join(Player, TrainingAttendance.player_id == Player.id)
        .filter(TrainingAttendance.session_id == session_id)
        .all()
    )
    result = []
    for attendance, player in rows:
        result.append(
            TrainingAttendanceOut(
                id=attendance.id,
                player_id=player.id,
                player_name=f"{player.first_name} {player.last_name}",
                status=attendance.status.value,
                notes=attendance.notes,
            )
        )
    return result


@router.put("/{session_id}/attendance", response_model=list[TrainingAttendanceOut])
def set_attendance(
    session_id: str,
    payload: list[TrainingAttendanceIn],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    session = db.query(TrainingSession).filter(TrainingSession.id == session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Η προπόνηση δεν βρέθηκε")
    assert_team_id_access(db, current_user, session.team_id, "Η προπόνηση δεν βρέθηκε")

    injured_entries: list[tuple[str, Optional[str]]] = []
    for entry in payload:
        if entry.status not in VALID_STATUSES:
            raise HTTPException(status_code=400, detail=f"Μη έγκυρη κατάσταση: {entry.status}")
        record = (
            db.query(TrainingAttendance)
            .filter(
                TrainingAttendance.session_id == session_id,
                TrainingAttendance.player_id == entry.player_id,
            )
            .first()
        )
        if record:
            record.status = AttendanceStatus(entry.status)
            record.notes = entry.notes
        else:
            db.add(
                TrainingAttendance(
                    session_id=session_id,
                    player_id=entry.player_id,
                    status=AttendanceStatus(entry.status),
                    notes=entry.notes,
                )
            )
        if entry.status == "injured":
            injured_entries.append((entry.player_id, entry.notes))
    db.commit()

    # Σύνδεση με το γενικό status/Injury του παίκτη — αν σημειώθηκε
    # «Τραυματίας» στην παρουσία και ο παίκτης δεν είναι ήδη Τραυματίας,
    # ενημερώνεται αυτόματα ώστε να φαίνεται παντού στην εφαρμογή (λίστα
    # Παικτών, ενότητα Τραυματισμοί / Απουσίες) — ίδια λογική με την
    # επεξεργασία παίκτη, μία μόνο πηγή αλήθειας (βλ. mark_player_injured).
    for player_id, entry_notes in injured_entries:
        player = db.query(Player).filter(Player.id == player_id).first()
        if player and player.status != PlayerStatus.INJURED:
            mark_player_injured(db, player, notes=entry_notes)

    return get_attendance(session_id, db, current_user)


@router.get("/stats/team/{team_id}", response_model=list[PlayerAttendanceSummary])
def team_attendance_stats(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    assert_team_id_access(db, current_user, team_id, "Η ομάδα δεν βρέθηκε")
    players = db.query(Player).filter(Player.current_team_id == team_id).all()
    result = []
    for p in players:
        attendances = (
            db.query(TrainingAttendance)
            .join(TrainingSession, TrainingAttendance.session_id == TrainingSession.id)
            .filter(TrainingAttendance.player_id == p.id, TrainingSession.team_id == team_id)
            .all()
        )
        total = len(attendances)
        attended = sum(1 for a in attendances if a.status == AttendanceStatus.PRESENT)
        pct = round((attended / total) * 100, 1) if total else 0.0
        result.append(
            PlayerAttendanceSummary(
                player_id=p.id,
                player_name=f"{p.first_name} {p.last_name}",
                total_sessions=total,
                attended=attended,
                attendance_percentage=pct,
            )
        )
    return result
