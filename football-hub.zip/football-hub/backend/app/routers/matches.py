from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import assert_match_access, assert_team_id_access, owned_team_ids, require_write_access
from app.config import AI_MODEL
from app.database import get_db
from app.services.http_utils import content_disposition_filename
from app.models import (
    AIReport,
    Match,
    MatchPlayer,
    MatchStatus,
    NotificationType,
    Player,
    PlayerStatistics,
    Team,
    User,
)
from app.schemas import (
    AIReportOut,
    MatchCreate,
    MatchOut,
    MatchPlayerIn,
    MatchPlayerOut,
    MatchReportUpdate,
    MatchUpdate,
)
from app.services import ai_service, pdf_service
from app.services.notifications import notify_team

router = APIRouter(prefix="/api/matches", tags=["matches"])

VALID_STATUSES = {s.value for s in MatchStatus}


def _team_name(db: Session, team_id: Optional[str], external_name: Optional[str]) -> Optional[str]:
    if external_name:
        return external_name
    if team_id:
        team = db.query(Team).filter(Team.id == team_id).first()
        return team.name if team else None
    return None


def _to_out(match: Match, db: Session) -> MatchOut:
    out = MatchOut.model_validate(match)
    out.home_team_name = _team_name(db, match.home_team_id, match.home_team_name_external)
    out.away_team_name = _team_name(db, match.away_team_id, match.away_team_name_external)
    return out


@router.get("", response_model=list[MatchOut])
def list_matches(
    team_id: Optional[str] = None,
    status: Optional[str] = None,
    season: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Match)
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(
            (Match.home_team_id.in_(owned_ids)) | (Match.away_team_id.in_(owned_ids))
        )
    if team_id:
        query = query.filter((Match.home_team_id == team_id) | (Match.away_team_id == team_id))
    if status:
        query = query.filter(Match.status == status)
    if season:
        query = query.filter(Match.season == season)
    matches = query.order_by(Match.date.desc()).all()
    return [_to_out(m, db) for m in matches]


@router.post("", response_model=MatchOut, status_code=201)
def create_match(
    payload: MatchCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    data = payload.model_dump()
    if data.get("status") and data["status"] not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Μη έγκυρο status")
    owned = owned_team_ids(db, current_user)
    if owned is not None:
        home_ok = not data.get("home_team_id") or data["home_team_id"] in owned
        away_ok = not data.get("away_team_id") or data["away_team_id"] in owned
        has_internal_team = data.get("home_team_id") or data.get("away_team_id")
        if not has_internal_team or not (home_ok and away_ok):
            raise HTTPException(
                status_code=403,
                detail="Μπορείς να δημιουργήσεις αγώνα μόνο για τις δικές σου ομάδες.",
            )
    match = Match(**data)
    db.add(match)
    db.commit()
    db.refresh(match)

    out = _to_out(match, db)
    for tid in {match.home_team_id, match.away_team_id}:
        notify_team(
            db,
            tid,
            NotificationType.UPCOMING_MATCH,
            title=f"Νέος αγώνας: {out.home_team_name or '—'} vs {out.away_team_name or '—'}",
            message=f"Προγραμματίστηκε για {match.date}" + (f" στις {match.time}" if match.time else ""),
            related_entity_type="match",
            related_entity_id=match.id,
        )
    return out


@router.get("/{match_id}", response_model=MatchOut)
def get_match(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    return _to_out(match, db)


@router.put("/{match_id}", response_model=MatchOut)
def update_match(
    match_id: str,
    payload: MatchUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    data = payload.model_dump(exclude_unset=True)
    if data.get("status") and data["status"] not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Μη έγκυρο status")
    for field, value in data.items():
        setattr(match, field, value)
    db.commit()
    db.refresh(match)
    return _to_out(match, db)


@router.put("/{match_id}/report", response_model=MatchOut)
def update_report(
    match_id: str,
    payload: MatchReportUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Ενημέρωση του free-text match report. Δεν σβήνει ποτέ δεδομένα εκτός
    από αυτά που στέλνονται ρητά — ξεχωριστό endpoint από τα βασικά match fields."""
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(match, field, value)
    db.commit()
    db.refresh(match)
    return _to_out(match, db)


@router.delete("/{match_id}", status_code=204)
def delete_match(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    db.delete(match)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Player performance per match
# ---------------------------------------------------------------------------
def _perf_out(mp: MatchPlayer, player: Player) -> MatchPlayerOut:
    return MatchPlayerOut(
        id=mp.id,
        player_id=player.id,
        player_name=f"{player.first_name} {player.last_name}",
        player_number=player.player_number,
        is_starting=mp.is_starting,
        position_played=mp.position_played,
        minutes_played=mp.minutes_played,
        goals=mp.goals,
        assists=mp.assists,
        yellow_cards=mp.yellow_cards,
        red_cards=mp.red_cards,
        fouls=mp.fouls,
        rating=mp.rating,
        coach_rating=mp.coach_rating,
        is_mvp=mp.is_mvp,
        notes=mp.notes,
    )


@router.get("/{match_id}/players", response_model=list[MatchPlayerOut])
def list_match_players(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    rows = (
        db.query(MatchPlayer, Player)
        .join(Player, MatchPlayer.player_id == Player.id)
        .filter(MatchPlayer.match_id == match_id)
        .all()
    )
    return [_perf_out(mp, p) for mp, p in rows]


def _adjust_player_statistics(
    db: Session,
    player: Player,
    delta_goals: int,
    delta_assists: int,
    delta_yellow: int,
    delta_red: int,
    delta_matches: int,
):
    """Ενημερώνει τα συνολικά στατιστικά του παίκτη (career totals) με βάση τη
    ΔΙΑΦΟΡΑ που προκύπτει από μια αποθήκευση Match Rating — έτσι ώστε τα γκολ
    που καταγράφονται σε έναν αγώνα να εμφανίζονται και στο προφίλ του
    παίκτη, χωρίς να σβήνει τυχόν στατιστικά που προστέθηκαν χειροκίνητα."""
    if not any([delta_goals, delta_assists, delta_yellow, delta_red, delta_matches]):
        return
    stats = (
        db.query(PlayerStatistics)
        .filter(PlayerStatistics.player_id == player.id, PlayerStatistics.season.is_(None))
        .first()
    )
    if not stats:
        stats = PlayerStatistics(player_id=player.id, team_id=player.current_team_id, season=None)
        db.add(stats)
        db.flush()
    stats.goals = max(0, stats.goals + delta_goals)
    stats.assists = max(0, stats.assists + delta_assists)
    stats.yellow_cards = max(0, stats.yellow_cards + delta_yellow)
    stats.red_cards = max(0, stats.red_cards + delta_red)
    stats.matches_played = max(0, stats.matches_played + delta_matches)


@router.put("/{match_id}/players/bulk", response_model=list[MatchPlayerOut])
def bulk_upsert_match_players(
    match_id: str,
    payload: list[MatchPlayerIn],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Δημιουργεί ή ενημερώνει σε ένα request τη βαθμολογία για ολόκληρη τη
    λίστα παικτών ενός ρόστερ — έτσι ώστε να μπορείς να βαθμολογήσεις όλη την
    ομάδα μονομιάς αντί να ανοίγεις φόρμα ανά παίκτη."""
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)

    player_ids = [item.player_id for item in payload]
    players_by_id = {
        p.id: p for p in db.query(Player).filter(Player.id.in_(player_ids)).all()
    }
    existing_by_player = {
        mp.player_id: mp
        for mp in db.query(MatchPlayer).filter(MatchPlayer.match_id == match_id).all()
    }

    mvp_player_id = None
    for item in payload:
        if item.is_mvp:
            mvp_player_id = item.player_id  # τελευταίος με is_mvp=True κερδίζει

    for item in payload:
        player = players_by_id.get(item.player_id)
        if not player:
            continue  # αγνόησε άκυρα player_id αντί να ρίξει όλο το batch
        data = item.model_dump()
        data["is_mvp"] = item.player_id == mvp_player_id if mvp_player_id else item.is_mvp

        existing = existing_by_player.get(item.player_id)
        if existing:
            old_goals, old_assists = existing.goals, existing.assists
            old_yellow, old_red = existing.yellow_cards, existing.red_cards
            for field, value in data.items():
                if field == "player_id":
                    continue
                setattr(existing, field, value)
            _adjust_player_statistics(
                db,
                player,
                delta_goals=data["goals"] - old_goals,
                delta_assists=data["assists"] - old_assists,
                delta_yellow=data["yellow_cards"] - old_yellow,
                delta_red=data["red_cards"] - old_red,
                delta_matches=0,
            )
        else:
            mp = MatchPlayer(match_id=match_id, **data)
            db.add(mp)
            existing_by_player[item.player_id] = mp
            _adjust_player_statistics(
                db,
                player,
                delta_goals=data["goals"],
                delta_assists=data["assists"],
                delta_yellow=data["yellow_cards"],
                delta_red=data["red_cards"],
                delta_matches=1,
            )

    db.commit()

    rows = (
        db.query(MatchPlayer, Player)
        .join(Player, MatchPlayer.player_id == Player.id)
        .filter(MatchPlayer.match_id == match_id)
        .all()
    )
    return [_perf_out(mp, p) for mp, p in rows]


@router.post("/{match_id}/players", response_model=MatchPlayerOut, status_code=201)
def add_match_player(
    match_id: str,
    payload: MatchPlayerIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    player = db.query(Player).filter(Player.id == payload.player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")

    existing = (
        db.query(MatchPlayer)
        .filter(MatchPlayer.match_id == match_id, MatchPlayer.player_id == payload.player_id)
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Ο παίκτης υπάρχει ήδη σε αυτόν τον αγώνα")

    if payload.is_mvp:
        db.query(MatchPlayer).filter(MatchPlayer.match_id == match_id).update({"is_mvp": False})

    mp = MatchPlayer(match_id=match_id, **payload.model_dump())
    db.add(mp)
    db.commit()
    db.refresh(mp)
    return _perf_out(mp, player)


@router.put("/{match_id}/players/{match_player_id}", response_model=MatchPlayerOut)
def update_match_player(
    match_id: str,
    match_player_id: str,
    payload: MatchPlayerIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    mp = (
        db.query(MatchPlayer)
        .filter(MatchPlayer.id == match_player_id, MatchPlayer.match_id == match_id)
        .first()
    )
    if not mp:
        raise HTTPException(status_code=404, detail="Η συμμετοχή δεν βρέθηκε")
    match = db.query(Match).filter(Match.id == match_id).first()
    assert_match_access(db, current_user, match)
    if payload.is_mvp:
        db.query(MatchPlayer).filter(
            MatchPlayer.match_id == match_id, MatchPlayer.id != match_player_id
        ).update({"is_mvp": False})
    for field, value in payload.model_dump(exclude={"player_id"}).items():
        setattr(mp, field, value)
    db.commit()
    db.refresh(mp)
    player = db.query(Player).filter(Player.id == mp.player_id).first()
    return _perf_out(mp, player)


@router.put("/{match_id}/players/{match_player_id}/mvp", response_model=MatchPlayerOut)
def set_mvp(
    match_id: str,
    match_player_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Ορίζει αυτόν τον παίκτη ως MVP του αγώνα (αφαιρεί το MVP από οποιονδήποτε άλλο)."""
    mp = (
        db.query(MatchPlayer)
        .filter(MatchPlayer.id == match_player_id, MatchPlayer.match_id == match_id)
        .first()
    )
    if not mp:
        raise HTTPException(status_code=404, detail="Η συμμετοχή δεν βρέθηκε")
    match = db.query(Match).filter(Match.id == match_id).first()
    assert_match_access(db, current_user, match)
    db.query(MatchPlayer).filter(MatchPlayer.match_id == match_id).update({"is_mvp": False})
    mp.is_mvp = True
    db.commit()
    db.refresh(mp)
    player = db.query(Player).filter(Player.id == mp.player_id).first()
    return _perf_out(mp, player)


@router.delete("/{match_id}/players/{match_player_id}/mvp", response_model=MatchPlayerOut)
def clear_mvp(
    match_id: str,
    match_player_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    mp = (
        db.query(MatchPlayer)
        .filter(MatchPlayer.id == match_player_id, MatchPlayer.match_id == match_id)
        .first()
    )
    if not mp:
        raise HTTPException(status_code=404, detail="Η συμμετοχή δεν βρέθηκε")
    match = db.query(Match).filter(Match.id == match_id).first()
    assert_match_access(db, current_user, match)
    mp.is_mvp = False
    db.commit()
    db.refresh(mp)
    player = db.query(Player).filter(Player.id == mp.player_id).first()
    return _perf_out(mp, player)


@router.delete("/{match_id}/players/{match_player_id}", status_code=204)
def remove_match_player(
    match_id: str,
    match_player_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    mp = (
        db.query(MatchPlayer)
        .filter(MatchPlayer.id == match_player_id, MatchPlayer.match_id == match_id)
        .first()
    )
    if not mp:
        raise HTTPException(status_code=404, detail="Η συμμετοχή δεν βρέθηκε")
    match = db.query(Match).filter(Match.id == match_id).first()
    assert_match_access(db, current_user, match)
    db.delete(mp)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# AI Match Summary
# ---------------------------------------------------------------------------
@router.get("/{match_id}/ai-reports", response_model=list[AIReportOut])
def list_match_ai_reports(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return (
        db.query(AIReport)
        .filter(AIReport.match_id == match_id)
        .order_by(AIReport.created_at.desc())
        .all()
    )


@router.post("/{match_id}/ai-summary", response_model=AIReportOut, status_code=201)
def generate_ai_summary(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    match_out = _to_out(match, db)

    rows = (
        db.query(MatchPlayer, Player)
        .join(Player, MatchPlayer.player_id == Player.id)
        .filter(MatchPlayer.match_id == match_id)
        .all()
    )
    performances = [_perf_out(mp, p) for mp, p in rows]

    if not ai_service.is_configured(db):
        raise HTTPException(
            status_code=503,
            detail=(
                "Το AI δεν έχει ρυθμιστεί. Όρισε AI_PROVIDER και AI_API_KEY στο backend/.env "
                "για να ενεργοποιήσεις την παραγωγή AI Match Summary."
            ),
        )

    system_prompt, user_prompt = ai_service.build_match_summary_prompt(match_out, performances)
    try:
        content = ai_service.generate_text(db, system_prompt, user_prompt, max_tokens=1200)
    except ai_service.AINotConfiguredError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:  # network/provider errors
        raise HTTPException(status_code=502, detail=f"Το AI request απέτυχε: {exc}")

    report = AIReport(
        report_type="match_summary",
        match_id=match_id,
        content=content,
        model_used=AI_MODEL,
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    for tid in {match.home_team_id, match.away_team_id}:
        notify_team(
            db,
            tid,
            NotificationType.AI_REPORT_READY,
            title=f"Το AI Match Summary είναι έτοιμο: {match_out.home_team_name} vs {match_out.away_team_name}",
            related_entity_type="match",
            related_entity_id=match_id,
        )
    return report


# ---------------------------------------------------------------------------
# PDF export
# ---------------------------------------------------------------------------
@router.get("/{match_id}/export/pdf")
def export_match_rating_pdf(
    match_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    match = db.query(Match).filter(Match.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    assert_match_access(db, current_user, match)
    match_out = _to_out(match, db)

    rows = (
        db.query(MatchPlayer, Player)
        .join(Player, MatchPlayer.player_id == Player.id)
        .filter(MatchPlayer.match_id == match_id)
        .order_by(MatchPlayer.is_starting.desc())
        .all()
    )
    performances = [_perf_out(mp, p) for mp, p in rows]

    pdf_bytes = pdf_service.generate_match_rating_pdf(match_out, performances)
    filename = f"match-rating-{match.date}.pdf"
    return StreamingResponse(
        iter([pdf_bytes]),
        media_type="application/pdf",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
