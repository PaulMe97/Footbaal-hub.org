from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import Injury, InjuryStatus, Player, PlayerAbsence, PlayerStatus, Team, User
from app.permissions import assert_player_access, owned_team_ids, require_absence_editor, sees_all_data
from app.schemas import PlayerAbsenceCreate, PlayerAbsenceOut, PlayerAbsenceUpdate

router = APIRouter(prefix="/api/absences", tags=["absences"])

# Ποιο PlayerStatus αντιστοιχεί σε κάθε λόγο απουσίας — χρησιμοποιείται για
# την αμφίδρομη σύνδεση: όταν καταχωρείται μια απουσία, ενημερώνεται αυτόματα
# και το γενικό status του παίκτη (ώστε να φαίνεται παντού στην εφαρμογή),
# και το αντίστροφο (βλ. routers/players.py _ensure_active_absence).
_STATUS_FOR_REASON = {
    "red_card": PlayerStatus.SUSPENDED,
    "suspension": PlayerStatus.SUSPENDED,
}


def _status_for_reason(reason: str) -> PlayerStatus:
    return _STATUS_FOR_REASON.get(reason, PlayerStatus.UNAVAILABLE)


def _to_absence_out(db: Session, absence: PlayerAbsence) -> PlayerAbsenceOut:
    player = db.query(Player).filter(Player.id == absence.player_id).first()
    team = db.query(Team).filter(Team.id == absence.team_id).first() if absence.team_id else None
    creator = db.query(User).filter(User.id == absence.created_by).first() if absence.created_by else None
    is_active = absence.end_date is None or absence.end_date >= date.today()
    return PlayerAbsenceOut(
        id=absence.id,
        player_id=absence.player_id,
        player_name=f"{player.first_name} {player.last_name}" if player else None,
        team_id=absence.team_id,
        team_name=team.name if team else None,
        reason=absence.reason,
        start_date=absence.start_date,
        end_date=absence.end_date,
        notes=absence.notes,
        created_by=absence.created_by,
        created_by_name=creator.full_name or creator.username if creator else None,
        created_at=absence.created_at,
        updated_at=absence.updated_at,
        is_active=is_active,
        is_editable=True,
    )


def _sync_player_status_for_absence(db: Session, player: Player, reason: str) -> None:
    """Μετά τη δημιουργία/ενημέρωση μιας (ενεργής) απουσίας, ενημερώνει το
    γενικό status του παίκτη — εκτός αν είναι ήδη Τραυματίας (αυτό το
    διαχειρίζεται αποκλειστικά το πιο λεπτομερές μοντέλο Injury)."""
    if player.status == PlayerStatus.INJURED:
        return
    new_status = _status_for_reason(reason)
    if player.status != new_status:
        player.status = new_status
        db.commit()


def _recompute_status_after_absence_change(db: Session, player_id: str) -> None:
    """Μετά τη διαγραφή ή τη λήξη μιας απουσίας: αν ο παίκτης έχει ΑΛΛΗ
    ενεργή απουσία, το status αντανακλά εκείνη· αλλιώς (και εφόσον δεν είναι
    Τραυματίας) επιστρέφει σε Διαθέσιμος."""
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player or player.status == PlayerStatus.INJURED:
        return
    today = date.today()
    remaining = (
        db.query(PlayerAbsence)
        .filter(
            PlayerAbsence.player_id == player_id,
            (PlayerAbsence.end_date.is_(None)) | (PlayerAbsence.end_date >= today),
        )
        .order_by(PlayerAbsence.start_date.desc())
        .first()
    )
    new_status = _status_for_reason(remaining.reason) if remaining else PlayerStatus.FIT
    if player.status != new_status:
        player.status = new_status
        db.commit()


def _injury_virtual_entries(db: Session, allowed_team_ids) -> list[PlayerAbsenceOut]:
    """Ενεργοί τραυματισμοί (μοντέλο Injury) εμφανισμένοι σαν απουσίες —
    read-only (η επεξεργασία γίνεται από το προφίλ του παίκτη)."""
    query = (
        db.query(Injury, Player)
        .join(Player, Player.id == Injury.player_id)
        .filter(Injury.status == InjuryStatus.ACTIVE)
    )
    if allowed_team_ids is not None:
        query = query.filter(Player.current_team_id.in_(allowed_team_ids))
    out = []
    for injury, player in query.all():
        team = db.query(Team).filter(Team.id == player.current_team_id).first() if player.current_team_id else None
        out.append(
            PlayerAbsenceOut(
                id=f"injury:{injury.id}",
                player_id=player.id,
                player_name=f"{player.first_name} {player.last_name}",
                team_id=player.current_team_id,
                team_name=team.name if team else None,
                reason="injury",
                start_date=injury.injury_date or injury.created_at.date(),
                end_date=injury.expected_return,
                # Ο πραγματικός τύπος τραυματισμού (π.χ. "Λαγονοψοΐτιδα",
                # "Ρήξη Μηνίσκου") πρέπει να είναι ορατός στην κάρτα — δεν
                # υπάρχει ξεχωριστό πεδίο στο PlayerAbsenceOut γι' αυτό, οπότε
                # μπαίνει πρώτο μέσα στις σημειώσεις.
                notes=(
                    f"{injury.injury_type} — {injury.notes}"
                    if injury.injury_type and injury.notes
                    else injury.injury_type or injury.notes
                ),
                created_by=None,
                created_by_name=None,
                created_at=injury.created_at,
                updated_at=injury.created_at,
                is_active=True,
                # Επεξεργάσιμο μέσω του dedicated Injury update endpoint (βλ.
                # routers/players.py update_player_injury) — το frontend
                # ανιχνεύει το "injury:" πρόθεμα και καλεί εκεί, όχι στο
                # γενικό PlayerAbsence update.
                is_editable=True,
            )
        )
    return out


def _status_virtual_entries(db: Session, allowed_team_ids, covered_player_ids: set) -> list[PlayerAbsenceOut]:
    """Παίκτες με status Ποινή/Μη Διαθέσιμος που (για οποιοδήποτε λόγο, π.χ.
    παλαιά δεδομένα) δεν έχουν ήδη αντίστοιχη ενεργή γραμμή PlayerAbsence —
    ώστε να μη «χάνονται» από την ενιαία προβολή."""
    query = db.query(Player).filter(Player.status.in_([PlayerStatus.SUSPENDED, PlayerStatus.UNAVAILABLE]))
    if allowed_team_ids is not None:
        query = query.filter(Player.current_team_id.in_(allowed_team_ids))
    out = []
    for player in query.all():
        if player.id in covered_player_ids:
            continue
        reason = "suspension" if player.status == PlayerStatus.SUSPENDED else "other"
        team = db.query(Team).filter(Team.id == player.current_team_id).first() if player.current_team_id else None
        out.append(
            PlayerAbsenceOut(
                id=f"status:{player.id}",
                player_id=player.id,
                player_name=f"{player.first_name} {player.last_name}",
                team_id=player.current_team_id,
                team_name=team.name if team else None,
                reason=reason,
                start_date=date.today(),
                end_date=None,
                notes=None,
                created_by=None,
                created_by_name=None,
                created_at=player.created_at,
                updated_at=player.created_at,
                is_active=True,
                is_editable=False,
            )
        )
    return out


@router.get("", response_model=list[PlayerAbsenceOut])
def list_absences(
    team_id: str | None = None,
    player_id: str | None = None,
    active_only: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    allowed = None if sees_all_data(current_user) else (owned_team_ids(db, current_user) or set())

    query = db.query(PlayerAbsence)
    if allowed is not None:
        query = query.filter(PlayerAbsence.team_id.in_(allowed))
    if team_id:
        query = query.filter(PlayerAbsence.team_id == team_id)
    if player_id:
        query = query.filter(PlayerAbsence.player_id == player_id)
    real_absences = query.order_by(PlayerAbsence.start_date.desc()).all()

    today = date.today()
    active_real = [a for a in real_absences if a.end_date is None or a.end_date >= today]
    covered_player_ids = {a.player_id for a in active_real}

    results = [_to_absence_out(db, a) for a in real_absences]
    results.extend(_injury_virtual_entries(db, allowed))
    results.extend(_status_virtual_entries(db, allowed, covered_player_ids))

    if player_id:
        results = [r for r in results if r.player_id == player_id]
    if team_id:
        results = [r for r in results if r.team_id == team_id]
    if active_only:
        results = [r for r in results if r.is_active]

    results.sort(key=lambda r: r.start_date, reverse=True)
    return results


@router.post("", response_model=PlayerAbsenceOut, status_code=201)
def create_absence(
    payload: PlayerAbsenceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_absence_editor),
):
    player = db.query(Player).filter(Player.id == payload.player_id).first()
    assert_player_access(db, current_user, player)

    absence = PlayerAbsence(
        player_id=payload.player_id,
        team_id=player.current_team_id,
        reason=payload.reason,
        start_date=payload.start_date,
        end_date=payload.end_date,
        notes=payload.notes,
        created_by=current_user.id,
    )
    db.add(absence)
    db.commit()
    db.refresh(absence)

    is_active = absence.end_date is None or absence.end_date >= date.today()
    if is_active:
        _sync_player_status_for_absence(db, player, absence.reason)

    return _to_absence_out(db, absence)


@router.put("/{absence_id}", response_model=PlayerAbsenceOut)
def update_absence(
    absence_id: str,
    payload: PlayerAbsenceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_absence_editor),
):
    absence = db.query(PlayerAbsence).filter(PlayerAbsence.id == absence_id).first()
    if not absence:
        raise HTTPException(status_code=404, detail="Η απουσία δεν βρέθηκε")
    player = db.query(Player).filter(Player.id == absence.player_id).first()
    assert_player_access(db, current_user, player)

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(absence, field, value)
    db.commit()
    db.refresh(absence)

    is_active = absence.end_date is None or absence.end_date >= date.today()
    if is_active:
        _sync_player_status_for_absence(db, player, absence.reason)
    else:
        _recompute_status_after_absence_change(db, absence.player_id)

    return _to_absence_out(db, absence)


@router.delete("/{absence_id}", status_code=204)
def delete_absence(
    absence_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_absence_editor),
):
    absence = db.query(PlayerAbsence).filter(PlayerAbsence.id == absence_id).first()
    if not absence:
        raise HTTPException(status_code=404, detail="Η απουσία δεν βρέθηκε")
    player = db.query(Player).filter(Player.id == absence.player_id).first()
    assert_player_access(db, current_user, player)
    player_id = absence.player_id
    db.delete(absence)
    db.commit()
    _recompute_status_after_absence_change(db, player_id)
