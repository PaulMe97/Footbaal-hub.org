from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.permissions import require_admin
from app.schemas import (
    AISettingsOut,
    AISettingsUpdate,
    CaptchaSettingsOut,
    CaptchaSettingsUpdate,
    PublicCaptchaConfigOut,
    SMTPSettingsOut,
    SMTPSettingsUpdate,
    StorageSettingsOut,
    StorageSettingsUpdate,
)
from app.services.settings_service import get_ai_config, get_s3_config, set_setting
from app.services import captcha_service
from app.services import email_service

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("/ai", response_model=AISettingsOut)
def get_ai_settings(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    provider, api_key, model = get_ai_config(db)
    return AISettingsOut(provider=provider, model=model, api_key_set=bool(api_key))


@router.put("/ai", response_model=AISettingsOut)
def update_ai_settings(
    payload: AISettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if payload.provider is not None:
        set_setting(db, "ai_provider", payload.provider)
    if payload.model is not None:
        set_setting(db, "ai_model", payload.model)
    if payload.api_key is not None and payload.api_key != "":
        set_setting(db, "ai_api_key", payload.api_key)

    provider, api_key, model = get_ai_config(db)
    return AISettingsOut(provider=provider, model=model, api_key_set=bool(api_key))


@router.get("/storage", response_model=StorageSettingsOut)
def get_storage_settings(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    cfg = get_s3_config(db)
    configured = bool(cfg["endpoint_url"] and cfg["bucket_name"] and cfg["access_key_id"] and cfg["secret_access_key"])
    return StorageSettingsOut(
        configured=configured,
        endpoint_url=cfg["endpoint_url"] or None,
        bucket_name=cfg["bucket_name"] or None,
        region=cfg["region"] or None,
    )


@router.put("/storage", response_model=StorageSettingsOut)
def update_storage_settings(
    payload: StorageSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if payload.endpoint_url is not None:
        set_setting(db, "s3_endpoint_url", payload.endpoint_url)
    if payload.bucket_name is not None:
        set_setting(db, "s3_bucket_name", payload.bucket_name)
    if payload.region is not None:
        set_setting(db, "s3_region", payload.region)
    if payload.access_key_id is not None and payload.access_key_id != "":
        set_setting(db, "s3_access_key_id", payload.access_key_id)
    if payload.secret_access_key is not None and payload.secret_access_key != "":
        set_setting(db, "s3_secret_access_key", payload.secret_access_key)

    cfg = get_s3_config(db)
    configured = bool(cfg["endpoint_url"] and cfg["bucket_name"] and cfg["access_key_id"] and cfg["secret_access_key"])
    return StorageSettingsOut(
        configured=configured,
        endpoint_url=cfg["endpoint_url"] or None,
        bucket_name=cfg["bucket_name"] or None,
        region=cfg["region"] or None,
    )


@router.get("/captcha", response_model=CaptchaSettingsOut)
def get_captcha_settings(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    cfg = captcha_service.get_captcha_config(db)
    return CaptchaSettingsOut(configured=captcha_service.is_configured(db), site_key=cfg["site_key"] or None)


@router.put("/captcha", response_model=CaptchaSettingsOut)
def update_captcha_settings(
    payload: CaptchaSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if payload.site_key is not None:
        set_setting(db, "hcaptcha_site_key", payload.site_key)
    if payload.secret_key is not None and payload.secret_key != "":
        set_setting(db, "hcaptcha_secret_key", payload.secret_key)

    cfg = captcha_service.get_captcha_config(db)
    return CaptchaSettingsOut(configured=captcha_service.is_configured(db), site_key=cfg["site_key"] or None)


@router.get("/captcha-public", response_model=PublicCaptchaConfigOut)
def get_public_captcha_config(db: Session = Depends(get_db)):
    """Δημόσιο endpoint (χωρίς authentication) — η φόρμα εγγραφής το καλεί
    πριν καν υπάρχει λογαριασμός, για να ξέρει αν πρέπει να δείξει CAPTCHA."""
    cfg = captcha_service.get_captcha_config(db)
    enabled = captcha_service.is_configured(db)
    return PublicCaptchaConfigOut(enabled=enabled, site_key=cfg["site_key"] if enabled else None)


@router.get("/smtp", response_model=SMTPSettingsOut)
def get_smtp_settings(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    cfg = email_service.get_smtp_config(db)
    return SMTPSettingsOut(
        configured=email_service.is_configured(db),
        host=cfg["host"] or None,
        port=cfg["port"] or None,
        username=cfg["username"] or None,
        from_email=cfg["from_email"] or None,
        from_name=cfg["from_name"] or None,
    )


@router.put("/smtp", response_model=SMTPSettingsOut)
def update_smtp_settings(
    payload: SMTPSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if payload.host is not None:
        set_setting(db, "smtp_host", payload.host)
    if payload.port is not None:
        set_setting(db, "smtp_port", payload.port)
    if payload.username is not None:
        set_setting(db, "smtp_username", payload.username)
    if payload.from_email is not None:
        set_setting(db, "smtp_from_email", payload.from_email)
    if payload.from_name is not None:
        set_setting(db, "smtp_from_name", payload.from_name)
    if payload.password is not None and payload.password != "":
        set_setting(db, "smtp_password", payload.password)

    cfg = email_service.get_smtp_config(db)
    return SMTPSettingsOut(
        configured=email_service.is_configured(db),
        host=cfg["host"] or None,
        port=cfg["port"] or None,
        username=cfg["username"] or None,
        from_email=cfg["from_email"] or None,
        from_name=cfg["from_name"] or None,
    )
