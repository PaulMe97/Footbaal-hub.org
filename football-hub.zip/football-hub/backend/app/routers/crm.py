from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import (
    CrmTopic,
    CrmTopicComment,
    NotificationType,
    Team,
    TeamAccessGrant,
    User,
    UserRole,
)
from app.permissions import assert_team_access, owned_team_ids
from app.schemas import (
    CrmContactOut,
    CrmStatsOut,
    CrmTopicCommentCreate,
    CrmTopicCommentOut,
    CrmTopicCreate,
    CrmTopicDetailOut,
    CrmTopicOut,
    CrmTopicUpdate,
)
from app.services.notifications import notify_team

router = APIRouter(prefix="/api/crm", tags=["crm"])

# Το CRM αφορά όλο το τεχνικό/διοικητικό επιτελείο — όχι μόνο τους ρόλους
# με δικαίωμα εγγραφής αλλού στην εφαρμογή (π.χ. Analyst/Scout/Fitness
# Coach έχουν πρόσβαση εδώ, όπως ζητήθηκε ρητά).
CRM_ROLES = {
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRESIDENT,
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
    UserRole.FITNESS_COACH,
    UserRole.ANALYST,
    UserRole.SCOUT,
}
VALID_CATEGORIES = {"general", "stadium", "parents", "event", "other"}
VALID_PRIORITIES = {"urgent", "normal", "low"}
VALID_STATUSES = {"open", "in_progress", "resolved"}


def require_crm_access(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in CRM_ROLES:
        raise HTTPException(status_code=403, detail="Δεν έχεις πρόσβαση στο CRM.")
    return current_user


def _team_scope(db: Session, current_user: User):
    owned_ids = owned_team_ids(db, current_user)
    query = db.query(Team)
    if owned_ids is not None:
        if not owned_ids:
            return [], owned_ids
        query = query.filter(Team.id.in_(owned_ids))
    return query.all(), owned_ids


def _topic_out(db: Session, topic: CrmTopic) -> CrmTopicOut:
    team = db.query(Team).filter(Team.id == topic.team_id).first()
    author = db.query(User).filter(User.id == topic.created_by).first()
    comment_count = db.query(CrmTopicComment).filter(CrmTopicComment.topic_id == topic.id).count()
    is_expired = bool(topic.expires_at and topic.expires_at < datetime.utcnow())
    return CrmTopicOut(
        id=topic.id,
        team_id=topic.team_id,
        team_name=team.name if team else None,
        title=topic.title,
        description=topic.description,
        category=topic.category,
        priority=topic.priority,
        status=topic.status,
        expires_at=topic.expires_at,
        is_expired=is_expired,
        created_by=topic.created_by,
        created_by_name=author.full_name if author else None,
        created_by_avatar=author.avatar_path if author else None,
        comment_count=comment_count,
        created_at=topic.created_at,
        updated_at=topic.updated_at,
        resolved_at=topic.resolved_at,
    )


# ---------------------------------------------------------------------------
# Directory επαφών
# ---------------------------------------------------------------------------
@router.get("/contacts", response_model=list[CrmContactOut])
def list_contacts(db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)):
    teams, _ = _team_scope(db, current_user)
    by_user: dict[str, CrmContactOut] = {}
    for team in teams:
        candidates: list[User] = []
        if team.owner_id:
            owner = db.query(User).filter(User.id == team.owner_id).first()
            if owner:
                candidates.append(owner)
        grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.team_id == team.id).all()
        for g in grants:
            u = db.query(User).filter(User.id == g.user_id).first()
            if u:
                candidates.append(u)

        for u in candidates:
            if u.id == current_user.id or u.role not in CRM_ROLES:
                continue
            if u.id in by_user:
                if team.name not in by_user[u.id].teams:
                    by_user[u.id].teams.append(team.name)
            else:
                by_user[u.id] = CrmContactOut(
                    user_id=u.id,
                    full_name=u.full_name,
                    username=u.username,
                    role=u.role,
                    avatar_path=u.avatar_path,
                    email=u.email,
                    phone=u.phone,
                    teams=[team.name],
                )
    return sorted(by_user.values(), key=lambda c: c.full_name or c.username)


@router.get("/teams")
def list_crm_teams(db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)):
    teams, _ = _team_scope(db, current_user)
    return [{"id": t.id, "name": t.name} for t in sorted(teams, key=lambda t: t.name)]


# ---------------------------------------------------------------------------
# Θέματα
# ---------------------------------------------------------------------------
@router.get("/topics", response_model=list[CrmTopicOut])
def list_topics(
    team_id: str | None = None,
    category: str | None = None,
    priority: str | None = None,
    status: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_crm_access),
):
    owned_ids = owned_team_ids(db, current_user)
    query = db.query(CrmTopic)
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(CrmTopic.team_id.in_(owned_ids))
    if team_id:
        if owned_ids is not None and team_id not in owned_ids:
            raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
        query = query.filter(CrmTopic.team_id == team_id)
    if category:
        query = query.filter(CrmTopic.category == category)
    if priority:
        query = query.filter(CrmTopic.priority == priority)
    if status:
        query = query.filter(CrmTopic.status == status)

    topics = query.all()
    # Urgent & ανοιχτά πρώτα, μετά πιο πρόσφατα
    priority_rank = {"urgent": 0, "normal": 1, "low": 2}
    status_rank = {"open": 0, "in_progress": 1, "resolved": 2}
    topics.sort(
        key=lambda t: (
            status_rank.get(t.status, 3),
            priority_rank.get(t.priority, 3),
            -t.created_at.timestamp(),
        )
    )
    return [_topic_out(db, t) for t in topics]


@router.post("/topics", response_model=CrmTopicOut, status_code=201)
def create_topic(
    payload: CrmTopicCreate, db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)
):
    team = db.query(Team).filter(Team.id == payload.team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    if payload.category not in VALID_CATEGORIES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη κατηγορία")
    if payload.priority not in VALID_PRIORITIES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη προτεραιότητα")

    topic = CrmTopic(
        team_id=payload.team_id,
        title=payload.title,
        description=payload.description,
        category=payload.category,
        priority=payload.priority,
        expires_at=payload.expires_at,
        created_by=current_user.id,
    )
    db.add(topic)
    db.commit()
    db.refresh(topic)

    priority_icon = "🔴" if payload.priority == "urgent" else ""
    notify_team(
        db,
        team.id,
        NotificationType.CRM_TOPIC,
        title=f"{priority_icon} Νέο θέμα CRM: {payload.title}",
        message=team.name,
        related_entity_type="crm_topic",
        related_entity_id=topic.id,
    )

    return _topic_out(db, topic)


def _get_topic_with_access(db: Session, topic_id: str, current_user: User) -> CrmTopic:
    topic = db.query(CrmTopic).filter(CrmTopic.id == topic_id).first()
    if not topic:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    team = db.query(Team).filter(Team.id == topic.team_id).first()
    if team:
        assert_team_access(db, current_user, team)
    return topic


@router.get("/topics/{topic_id}", response_model=CrmTopicDetailOut)
def get_topic(topic_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)):
    topic = _get_topic_with_access(db, topic_id, current_user)
    rows = (
        db.query(CrmTopicComment, User)
        .join(User, CrmTopicComment.author_id == User.id)
        .filter(CrmTopicComment.topic_id == topic_id)
        .order_by(CrmTopicComment.created_at.asc())
        .all()
    )
    comments = [
        CrmTopicCommentOut(
            id=c.id,
            author_id=author.id,
            author_name=author.full_name,
            author_avatar=author.avatar_path,
            content=c.content,
            created_at=c.created_at,
        )
        for c, author in rows
    ]
    base = _topic_out(db, topic)
    return CrmTopicDetailOut(**base.model_dump(), comments=comments)


@router.put("/topics/{topic_id}", response_model=CrmTopicOut)
def update_topic(
    topic_id: str,
    payload: CrmTopicUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_crm_access),
):
    topic = _get_topic_with_access(db, topic_id, current_user)
    data = payload.model_dump(exclude_unset=True)

    if "category" in data and data["category"] not in VALID_CATEGORIES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη κατηγορία")
    if "priority" in data and data["priority"] not in VALID_PRIORITIES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη προτεραιότητα")
    if "status" in data and data["status"] not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη κατάσταση")

    for field, value in data.items():
        setattr(topic, field, value)
    if data.get("status") == "resolved" and not topic.resolved_at:
        topic.resolved_at = datetime.utcnow()
    elif data.get("status") and data["status"] != "resolved":
        topic.resolved_at = None

    db.commit()
    db.refresh(topic)
    return _topic_out(db, topic)


@router.delete("/topics/{topic_id}", status_code=204)
def delete_topic(topic_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)):
    topic = _get_topic_with_access(db, topic_id, current_user)
    db.query(CrmTopicComment).filter(CrmTopicComment.topic_id == topic_id).delete()
    db.delete(topic)
    db.commit()
    return None


@router.post("/topics/{topic_id}/comments", response_model=CrmTopicDetailOut, status_code=201)
def add_comment(
    topic_id: str,
    payload: CrmTopicCommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_crm_access),
):
    topic = _get_topic_with_access(db, topic_id, current_user)
    comment = CrmTopicComment(topic_id=topic_id, author_id=current_user.id, content=payload.content)
    db.add(comment)
    topic.updated_at = datetime.utcnow()
    db.commit()

    team = db.query(Team).filter(Team.id == topic.team_id).first()
    if team:
        notify_team(
            db,
            team.id,
            NotificationType.CRM_TOPIC,
            title=f"💬 Νέο σχόλιο: {topic.title}",
            message=payload.content[:100],
            related_entity_type="crm_topic",
            related_entity_id=topic.id,
        )

    return get_topic(topic_id, db, current_user)


# ---------------------------------------------------------------------------
# Στατιστικά (για τα γραφήματα)
# ---------------------------------------------------------------------------
@router.get("/stats", response_model=CrmStatsOut)
def get_stats(db: Session = Depends(get_db), current_user: User = Depends(require_crm_access)):
    owned_ids = owned_team_ids(db, current_user)
    query = db.query(CrmTopic)
    if owned_ids is not None:
        if not owned_ids:
            return CrmStatsOut()
        query = query.filter(CrmTopic.team_id.in_(owned_ids))
    topics = query.all()

    by_category: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    by_status: dict[str, int] = {}
    urgent_open = 0
    expired = 0
    resolved_this_month = 0
    now = datetime.utcnow()

    for t in topics:
        by_category[t.category] = by_category.get(t.category, 0) + 1
        by_priority[t.priority] = by_priority.get(t.priority, 0) + 1
        by_status[t.status] = by_status.get(t.status, 0) + 1
        if t.priority == "urgent" and t.status != "resolved":
            urgent_open += 1
        if t.expires_at and t.expires_at < now and t.status != "resolved":
            expired += 1
        if t.resolved_at and t.resolved_at.year == now.year and t.resolved_at.month == now.month:
            resolved_this_month += 1

    return CrmStatsOut(
        by_category=by_category,
        by_priority=by_priority,
        by_status=by_status,
        urgent_open_count=urgent_open,
        expired_count=expired,
        total_topics=len(topics),
        resolved_this_month=resolved_this_month,
    )
