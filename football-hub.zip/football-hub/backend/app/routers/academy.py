from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.services.http_utils import content_disposition_filename
from app.models import (
    AcademyAnnouncement,
    AcademyFeeSettings,
    AcademyKitItem,
    AcademyPayment,
    AcademyPlayerAccount,
    Player,
    Team,
    User,
    UserRole,
)
from app.permissions import assert_team_access, owned_team_ids
from app.schemas import (
    AcademyAnnouncementCreate,
    AcademyAnnouncementOut,
    AcademyFeeSettingsOut,
    AcademyFeeSettingsUpdate,
    AcademyKitItemCreate,
    AcademyKitItemOut,
    AcademyKitItemUpdate,
    AcademyOwedMonth,
    AcademyPaymentCreate,
    AcademyPaymentOut,
    AcademyPlayerAccountUpdate,
    AcademyPlayerDetailOut,
    AcademyPlayerSummaryOut,
    AcademyTeamSummaryOut,
)

router = APIRouter(prefix="/api/academy", tags=["academy"])

# Σκόπιμα πιο στενό από τα γενικά STAFF_ROLES — οικονομικά/προσωπικά
# στοιχεία γονέων, δεν αφορούν Analyst/Scout/Assistant Coach.
ACADEMY_MANAGER_ROLES = {
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRESIDENT,
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
}


def require_academy_access(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in ACADEMY_MANAGER_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Η ενότητα Συνδρομές Ακαδημιών διαχειρίζεται μόνο από Πρόεδρο, "
            "Τεχνικό Διευθυντή ή Προπονητή.",
        )
    return current_user


def _get_academy_team(db: Session, team_id: str, current_user: User) -> Team:
    team = db.query(Team).filter(Team.id == team_id, Team.league_tier == "academy").first()
    if not team:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε ομάδα ακαδημίας")
    assert_team_access(db, current_user, team)
    return team


def _compute_owed(
    account,
    settings,
    payments,
    today: date,
):
    """Υπολογίζει τους ανεξόφλητους μήνες, το συνολικό ποσό, και αν η
    τρέχουσα δόση είναι εκπρόθεσμη — βάσει πραγματικού ιστορικού πληρωμών
    (λογιστήριο), όχι απλή σημαία. Χρειάζεται plan_type=monthly, μηνιαία
    τιμή, και ημερομηνία εγγραφής για να υπολογιστεί κάτι."""
    if not account or account.plan_type != "monthly":
        return [], 0.0, False
    if not settings or not settings.monthly_fee or not account.enrollment_date:
        return [], 0.0, False

    months = []
    y, m = account.enrollment_date.year, account.enrollment_date.month
    while (y, m) <= (today.year, today.month):
        months.append((y, m))
        m += 1
        if m > 12:
            m = 1
            y += 1

    paid_set = {(p.period_year, p.period_month) for p in payments if p.payment_type == "monthly"}
    unpaid = [(yy, mm) for (yy, mm) in months if (yy, mm) not in paid_set]
    total = round(len(unpaid) * settings.monthly_fee, 2)

    is_overdue = (today.year, today.month) in unpaid and today.day > settings.payment_due_day

    return (
        [AcademyOwedMonth(year=yy, month=mm, amount=settings.monthly_fee) for yy, mm in unpaid],
        total,
        is_overdue,
    )


def _player_summary(db: Session, player: Player, settings) -> AcademyPlayerSummaryOut:
    account = db.query(AcademyPlayerAccount).filter(AcademyPlayerAccount.player_id == player.id).first()
    payments = db.query(AcademyPayment).filter(AcademyPayment.player_id == player.id).all()
    kit_items = db.query(AcademyKitItem).filter(AcademyKitItem.player_id == player.id).all()

    today = date.today()
    unpaid_months, total_owed, is_overdue = _compute_owed(account, settings, payments, today)

    registration_paid = any(p.payment_type == "registration" for p in payments)
    annual_paid_in_full = any(p.payment_type == "annual" for p in payments)
    kit_owed = round(sum(k.price or 0 for k in kit_items if not k.paid), 2)

    return AcademyPlayerSummaryOut(
        player_id=player.id,
        player_name=f"{player.first_name} {player.last_name}",
        photo_path=player.photo_path,
        plan_type=account.plan_type if account else "monthly",
        parent_name=account.parent_name if account else None,
        parent_phone=account.parent_phone if account else None,
        enrollment_date=account.enrollment_date if account else None,
        registration_paid=registration_paid,
        annual_paid_in_full=annual_paid_in_full,
        total_owed=total_owed,
        unpaid_months=unpaid_months,
        is_overdue=is_overdue,
        kit_items=[
            AcademyKitItemOut(id=k.id, item_name=k.item_name, received=k.received, paid=k.paid, price=k.price)
            for k in kit_items
        ],
        kit_owed=kit_owed,
        has_account=account is not None,
    )


# ---------------------------------------------------------------------------
# Ομάδες ακαδημίας
# ---------------------------------------------------------------------------
@router.get("/teams", response_model=list[AcademyTeamSummaryOut])
def list_academy_teams(db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)):
    owned_ids = owned_team_ids(db, current_user)
    query = db.query(Team).filter(Team.league_tier == "academy")
    if owned_ids is not None:
        if not owned_ids:
            return []
        query = query.filter(Team.id.in_(owned_ids))
    teams = query.order_by(Team.name.asc()).all()

    results = []
    for team in teams:
        players = db.query(Player).filter(Player.current_team_id == team.id).all()
        settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team.id).first()
        players_with_debt = 0
        total_owed = 0.0
        for p in players:
            summary = _player_summary(db, p, settings)
            if summary.total_owed > 0 or summary.kit_owed > 0:
                players_with_debt += 1
            total_owed += summary.total_owed + summary.kit_owed
        results.append(
            AcademyTeamSummaryOut(
                team_id=team.id,
                team_name=team.name,
                category=team.category,
                player_count=len(players),
                players_with_debt=players_with_debt,
                total_owed=round(total_owed, 2),
            )
        )
    return results


@router.get("/teams/{team_id}/settings", response_model=AcademyFeeSettingsOut)
def get_fee_settings(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    if not settings:
        return AcademyFeeSettingsOut(team_id=team_id)
    return AcademyFeeSettingsOut(
        team_id=team_id,
        monthly_fee=settings.monthly_fee,
        annual_fee=settings.annual_fee,
        registration_fee=settings.registration_fee,
        payment_due_day=settings.payment_due_day,
        kit_template=[i for i in (settings.kit_template or "").split(",") if i],
    )


@router.put("/teams/{team_id}/settings", response_model=AcademyFeeSettingsOut)
def update_fee_settings(
    team_id: str,
    payload: AcademyFeeSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    if not settings:
        settings = AcademyFeeSettings(team_id=team_id)
        db.add(settings)
    settings.monthly_fee = payload.monthly_fee
    settings.annual_fee = payload.annual_fee
    settings.registration_fee = payload.registration_fee
    settings.payment_due_day = payload.payment_due_day
    settings.kit_template = ",".join(i.strip() for i in payload.kit_template if i.strip()) or None
    db.commit()
    db.refresh(settings)
    return AcademyFeeSettingsOut(
        team_id=team_id,
        monthly_fee=settings.monthly_fee,
        annual_fee=settings.annual_fee,
        registration_fee=settings.registration_fee,
        payment_due_day=settings.payment_due_day,
        kit_template=[i for i in (settings.kit_template or "").split(",") if i],
    )


@router.post("/teams/{team_id}/apply-kit-template", response_model=list[AcademyPlayerSummaryOut])
def apply_kit_template(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    """Δημιουργεί τα είδη του προτύπου ρουχισμού της ομάδας για ΚΑΘΕ
    παίκτη που δεν τα έχει ήδη — απλό, γρήγορο "smart" εργαλείο ώστε να
    μην ξαναγράφεται το ίδιο όνομα είδους παίκτη-παίκτη."""
    _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    template = [i for i in (settings.kit_template or "").split(",") if i] if settings else []
    if not template:
        raise HTTPException(
            status_code=400, detail="Δεν έχει οριστεί πρότυπο ρουχισμού για αυτή την ομάδα."
        )

    players = db.query(Player).filter(Player.current_team_id == team_id).all()
    for player in players:
        existing_names = {
            k.item_name
            for k in db.query(AcademyKitItem).filter(AcademyKitItem.player_id == player.id).all()
        }
        for item_name in template:
            if item_name not in existing_names:
                db.add(AcademyKitItem(player_id=player.id, item_name=item_name))
    db.commit()

    return [_player_summary(db, p, settings) for p in players]


@router.get("/teams/{team_id}/players", response_model=list[AcademyPlayerSummaryOut])
def list_academy_players(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    players = (
        db.query(Player).filter(Player.current_team_id == team_id).order_by(Player.first_name.asc()).all()
    )
    return [_player_summary(db, p, settings) for p in players]


# ---------------------------------------------------------------------------
# Ανακοινώσεις ομάδας
# ---------------------------------------------------------------------------
@router.get("/teams/{team_id}/announcements", response_model=list[AcademyAnnouncementOut])
def list_announcements(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    _get_academy_team(db, team_id, current_user)
    rows = (
        db.query(AcademyAnnouncement, User)
        .join(User, AcademyAnnouncement.created_by == User.id)
        .filter(AcademyAnnouncement.team_id == team_id)
        .order_by(AcademyAnnouncement.created_at.desc())
        .all()
    )
    return [
        AcademyAnnouncementOut(
            id=a.id,
            team_id=a.team_id,
            title=a.title,
            description=a.description,
            event_date=a.event_date,
            event_time=a.event_time,
            location_name=a.location_name,
            location_maps_url=a.location_maps_url,
            created_by_name=u.full_name,
            created_at=a.created_at,
        )
        for a, u in rows
    ]


@router.post("/teams/{team_id}/announcements", response_model=AcademyAnnouncementOut, status_code=201)
def create_announcement(
    team_id: str,
    payload: AcademyAnnouncementCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    _get_academy_team(db, team_id, current_user)
    announcement = AcademyAnnouncement(team_id=team_id, created_by=current_user.id, **payload.model_dump())
    db.add(announcement)
    db.commit()
    db.refresh(announcement)
    return AcademyAnnouncementOut(
        id=announcement.id,
        team_id=announcement.team_id,
        title=announcement.title,
        description=announcement.description,
        event_date=announcement.event_date,
        event_time=announcement.event_time,
        location_name=announcement.location_name,
        location_maps_url=announcement.location_maps_url,
        created_by_name=current_user.full_name,
        created_at=announcement.created_at,
    )


@router.delete("/announcements/{announcement_id}", status_code=204)
def delete_announcement(
    announcement_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    announcement = db.query(AcademyAnnouncement).filter(AcademyAnnouncement.id == announcement_id).first()
    if not announcement:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    team = db.query(Team).filter(Team.id == announcement.team_id).first()
    if team:
        assert_team_access(db, current_user, team)
    db.delete(announcement)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Ανά παίκτη — λογαριασμός, πληρωμές, ρουχισμός
# ---------------------------------------------------------------------------
def _get_academy_player(db: Session, player_id: str, current_user: User) -> Player:
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player or not player.current_team_id:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    team = db.query(Team).filter(Team.id == player.current_team_id, Team.league_tier == "academy").first()
    if not team:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν ανήκει σε ομάδα ακαδημίας")
    assert_team_access(db, current_user, team)
    return player


@router.get("/players/{player_id}", response_model=AcademyPlayerDetailOut)
def get_academy_player(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    player = _get_academy_player(db, player_id, current_user)
    team = db.query(Team).filter(Team.id == player.current_team_id).first()
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team.id).first()
    account = db.query(AcademyPlayerAccount).filter(AcademyPlayerAccount.player_id == player.id).first()

    summary = _player_summary(db, player, settings)

    payment_rows = (
        db.query(AcademyPayment, User)
        .outerjoin(User, AcademyPayment.recorded_by == User.id)
        .filter(AcademyPayment.player_id == player.id)
        .order_by(AcademyPayment.paid_date.desc())
        .all()
    )
    payments_out = [
        AcademyPaymentOut(
            id=pay.id,
            payment_type=pay.payment_type,
            period_year=pay.period_year,
            period_month=pay.period_month,
            amount=pay.amount,
            paid_date=pay.paid_date,
            recorded_by_name=u.full_name if u else None,
            notes=pay.notes,
            created_at=pay.created_at,
        )
        for pay, u in payment_rows
    ]

    return AcademyPlayerDetailOut(
        **summary.model_dump(),
        team_id=team.id,
        team_name=team.name,
        notes=account.notes if account else None,
        payments=payments_out,
    )


@router.put("/players/{player_id}/account", response_model=AcademyPlayerDetailOut)
def update_academy_account(
    player_id: str,
    payload: AcademyPlayerAccountUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    _get_academy_player(db, player_id, current_user)
    account = db.query(AcademyPlayerAccount).filter(AcademyPlayerAccount.player_id == player_id).first()
    if not account:
        account = AcademyPlayerAccount(player_id=player_id)
        db.add(account)
    account.plan_type = payload.plan_type
    account.parent_name = payload.parent_name
    account.parent_phone = payload.parent_phone
    account.enrollment_date = payload.enrollment_date
    account.notes = payload.notes
    db.commit()
    return get_academy_player(player_id, db, current_user)


@router.post("/players/{player_id}/payments", response_model=AcademyPlayerDetailOut, status_code=201)
def add_payment(
    player_id: str,
    payload: AcademyPaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    _get_academy_player(db, player_id, current_user)
    if payload.payment_type not in {"monthly", "annual", "registration"}:
        raise HTTPException(status_code=400, detail="Μη έγκυρος τύπος πληρωμής")
    if payload.payment_type == "monthly" and (not payload.period_year or not payload.period_month):
        raise HTTPException(status_code=400, detail="Χρειάζεται έτος/μήνας για μηνιαία πληρωμή")

    payment = AcademyPayment(
        player_id=player_id,
        payment_type=payload.payment_type,
        period_year=payload.period_year,
        period_month=payload.period_month,
        amount=payload.amount,
        paid_date=payload.paid_date or date.today(),
        recorded_by=current_user.id,
        notes=payload.notes,
    )
    db.add(payment)
    db.commit()
    return get_academy_player(player_id, db, current_user)


@router.delete("/payments/{payment_id}", status_code=204)
def delete_payment(
    payment_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    payment = db.query(AcademyPayment).filter(AcademyPayment.id == payment_id).first()
    if not payment:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    _get_academy_player(db, payment.player_id, current_user)
    db.delete(payment)
    db.commit()
    return None


@router.post("/players/{player_id}/kit", response_model=AcademyPlayerDetailOut, status_code=201)
def add_kit_item(
    player_id: str,
    payload: AcademyKitItemCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    _get_academy_player(db, player_id, current_user)
    item = AcademyKitItem(player_id=player_id, **payload.model_dump())
    db.add(item)
    db.commit()
    return get_academy_player(player_id, db, current_user)


@router.put("/kit/{item_id}", response_model=AcademyPlayerDetailOut)
def update_kit_item(
    item_id: str,
    payload: AcademyKitItemUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_academy_access),
):
    item = db.query(AcademyKitItem).filter(AcademyKitItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    _get_academy_player(db, item.player_id, current_user)
    if payload.received is not None:
        item.received = payload.received
    if payload.paid is not None:
        item.paid = payload.paid
    if payload.price is not None:
        item.price = payload.price
    db.commit()
    return get_academy_player(item.player_id, db, current_user)


@router.delete("/kit/{item_id}", status_code=204)
def delete_kit_item(
    item_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    item = db.query(AcademyKitItem).filter(AcademyKitItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    _get_academy_player(db, item.player_id, current_user)
    db.delete(item)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Εξαγωγή Συνδρομών/Οφειλών
# ---------------------------------------------------------------------------
@router.get("/teams/{team_id}/export/excel")
def export_academy_excel(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    from fastapi.responses import StreamingResponse

    from app.services.excel_service import generate_academy_debts_excel

    team = _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    players = db.query(Player).filter(Player.current_team_id == team_id).order_by(Player.first_name.asc()).all()
    summaries = [_player_summary(db, p, settings) for p in players]

    content = generate_academy_debts_excel(team, summaries, settings)
    filename = f"academy-subscriptions-{team.name.replace(' ', '-')}.xlsx"
    return StreamingResponse(
        iter([content]),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )


@router.get("/teams/{team_id}/export/pdf")
def export_academy_pdf(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_academy_access)
):
    from fastapi.responses import StreamingResponse

    from app.services.pdf_service import generate_academy_debts_pdf

    team = _get_academy_team(db, team_id, current_user)
    settings = db.query(AcademyFeeSettings).filter(AcademyFeeSettings.team_id == team_id).first()
    players = db.query(Player).filter(Player.current_team_id == team_id).order_by(Player.first_name.asc()).all()
    summaries = [_player_summary(db, p, settings) for p in players]

    content = generate_academy_debts_pdf(team, summaries, settings)
    filename = f"academy-subscriptions-{team.name.replace(' ', '-')}.pdf"
    return StreamingResponse(
        iter([content]),
        media_type="application/pdf",
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
