from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import (
    Federation,
    ListingApplication,
    Player,
    Team,
    TeamAccessGrant,
    TeamListing,
    User,
    UserRole,
)
from app.permissions import (
    assert_can_receive_new_grant,
    assert_can_respond_to_request,
    assert_no_duplicate_head_coach,
    assert_team_access,
    can_respond_to_request,
    require_write_access,
)
from app.routers.messages import get_or_create_conversation
from app.services.notifications import notify_eligible_approvers
from app.services.player_matching import find_unlinked_player_match
from app.schemas import (
    ListingApplicationCreate,
    ListingApplicationOut,
    ListingApplicationRespond,
    TeamListingCreate,
    TeamListingOut,
)

router = APIRouter(prefix="/api", tags=["listings"])

LISTING_LIFETIME_DAYS = 3
MAX_POSITIONS_PER_LISTING = 5

LISTING_POSTER_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR, UserRole.SUPER_ADMIN, UserRole.ADMIN}
LISTING_ROLE_LABELS_FOR_CHAT = {
    "technical_director": "Τεχνικός Διευθυντής",
    "head_coach": "Προπονητής",
    "assistant_coach": "Βοηθός Προπονητή",
    "fitness_coach": "Γυμναστής",
    "analyst": "Αναλυτής",
    "scout": "Scout",
}


def _to_csv(values) -> Optional[str]:
    if not values:
        return None
    return ",".join(v.value if hasattr(v, "value") else str(v) for v in values)


def _from_csv(value: Optional[str]) -> list:
    if not value:
        return []
    return [v for v in value.split(",") if v]


def _expire_stale_listing(db: Session, listing: TeamListing) -> None:
    if listing.status == "open" and listing.expires_at and listing.expires_at < datetime.utcnow():
        listing.status = "expired"
        db.commit()


def _listing_out(db: Session, listing: TeamListing) -> TeamListingOut:
    team = db.query(Team).filter(Team.id == listing.team_id).first()
    count = db.query(ListingApplication).filter(ListingApplication.listing_id == listing.id).count()
    target_federation_ids = _from_csv(listing.target_federation_ids)
    target_federation_names = []
    if target_federation_ids:
        feds = db.query(Federation).filter(Federation.id.in_(target_federation_ids)).all()
        target_federation_names = [f.name for f in feds]
    return TeamListingOut(
        id=listing.id,
        team_id=listing.team_id,
        team_name=team.name if team else None,
        posted_by=listing.posted_by,
        listing_type=listing.listing_type,
        status=listing.status,
        role_needed=_from_csv(listing.role_needed),
        season=listing.season,
        employment_type=listing.employment_type,
        position_needed=_from_csv(listing.position_needed),
        min_age=listing.min_age,
        max_age=listing.max_age,
        target_federation_ids=target_federation_ids,
        target_federation_names=target_federation_names,
        description=listing.description,
        created_at=listing.created_at,
        expires_at=listing.expires_at,
        application_count=count,
    )


@router.post("/teams/{team_id}/listings", response_model=TeamListingOut, status_code=201)
def create_listing(
    team_id: str,
    payload: TeamListingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if current_user.role not in LISTING_POSTER_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Μόνο ο Πρόεδρος ή ο Τεχνικός Διευθυντής μπορούν να δημοσιεύσουν αγγελία.",
        )
    if current_user.role in (UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR) and not current_user.club_verified:
        raise HTTPException(
            status_code=403,
            detail=(
                "Ο σύλλογός σου δεν έχει επαληθευτεί ακόμα. Ανέβασε επίσημο έγγραφο συλλόγου "
                "στο Προφίλ -> Trust & Verification για να μπορείς να δημοσιεύσεις αγγελίες."
            ),
        )
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    if payload.listing_type not in {"staff", "player"}:
        raise HTTPException(status_code=400, detail="listing_type πρέπει να είναι 'staff' ή 'player'")

    data = payload.model_dump()
    data["role_needed"] = _to_csv(payload.role_needed)
    data["position_needed"] = _to_csv(payload.position_needed)
    data["target_federation_ids"] = _to_csv(payload.target_federation_ids)

    listing = TeamListing(
        team_id=team_id,
        posted_by=current_user.id,
        expires_at=datetime.utcnow() + timedelta(days=LISTING_LIFETIME_DAYS),
        **data,
    )
    db.add(listing)
    db.commit()
    db.refresh(listing)
    return _listing_out(db, listing)


@router.get("/teams/{team_id}/listings", response_model=list[TeamListingOut])
def list_team_listings(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    listings = (
        db.query(TeamListing)
        .filter(TeamListing.team_id == team_id)
        .order_by(TeamListing.created_at.desc())
        .all()
    )
    for l in listings:
        _expire_stale_listing(db, l)
    return [_listing_out(db, l) for l in listings]


@router.put("/teams/{team_id}/listings/{listing_id}/close", response_model=TeamListingOut)
def close_listing(
    team_id: str,
    listing_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    listing = (
        db.query(TeamListing)
        .filter(TeamListing.id == listing_id, TeamListing.team_id == team_id)
        .first()
    )
    if not listing:
        raise HTTPException(status_code=404, detail="Η αγγελία δεν βρέθηκε")
    listing.status = "closed"
    db.commit()
    db.refresh(listing)
    return _listing_out(db, listing)


# ---------------------------------------------------------------------------
# Δημόσια αναζήτηση αγγελιών (candidates browsing)
# ---------------------------------------------------------------------------
@router.get("/scouting/listings", response_model=list[TeamListingOut])
def browse_listings(
    listing_type: Optional[str] = None,
    role_needed: Optional[str] = None,
    position_needed: Optional[str] = None,
    season: Optional[str] = None,
    employment_type: Optional[str] = None,
    max_age: Optional[int] = None,
    federation_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(TeamListing).filter(TeamListing.status == "open")
    if listing_type:
        query = query.filter(TeamListing.listing_type == listing_type)
    if role_needed:
        query = query.filter(TeamListing.role_needed.like(f"%{role_needed}%"))
    if position_needed:
        query = query.filter(TeamListing.position_needed.like(f"%{position_needed}%"))
    if season:
        query = query.filter(TeamListing.season == season)
    if employment_type:
        query = query.filter(TeamListing.employment_type == employment_type)
    if federation_id:
        # Αγγελίες χωρίς δηλωμένο νομό θεωρούνται "οπουδήποτε" — πάντα ορατές.
        query = query.filter(
            (TeamListing.target_federation_ids.is_(None))
            | (TeamListing.target_federation_ids == "")
            | (TeamListing.target_federation_ids.like(f"%{federation_id}%"))
        )
    listings = query.order_by(TeamListing.created_at.desc()).all()
    for l in listings:
        _expire_stale_listing(db, l)
    listings = [l for l in listings if l.status == "open"]
    if max_age is not None:
        # Δείξε αγγελίες χωρίς όριο ηλικίας ή με όριο >= ό,τι ζητά ο υποψήφιος
        listings = [l for l in listings if l.max_age is None or l.max_age >= max_age]
    return [_listing_out(db, l) for l in listings]


# ---------------------------------------------------------------------------
# Αιτήσεις σε αγγελία
# ---------------------------------------------------------------------------
def _application_out(
    db: Session, app_: ListingApplication, current_user: User, team_id: str
) -> ListingApplicationOut:
    from app.routers.scouting import _to_scouting_player  # τοπικό import, αποφυγή κύκλου

    applicant = db.query(User).filter(User.id == app_.applicant_user_id).first()
    applicant_player = None
    if applicant and applicant.linked_player_id:
        player = db.query(Player).filter(Player.id == applicant.linked_player_id).first()
        if player:
            applicant_player = _to_scouting_player(db, player, current_user)

    return ListingApplicationOut(
        id=app_.id,
        listing_id=app_.listing_id,
        applicant_user_id=app_.applicant_user_id,
        applicant_name=applicant.full_name if applicant else None,
        applicant_role=applicant.role if applicant else None,
        message=app_.message,
        status=app_.status,
        created_at=app_.created_at,
        can_respond=can_respond_to_request(db, current_user, applicant.role, team_id) if applicant else True,
        applicant_player=applicant_player,
    )


@router.post("/listings/{listing_id}/apply", response_model=ListingApplicationOut, status_code=201)
def apply_to_listing(
    listing_id: str,
    payload: ListingApplicationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    listing = db.query(TeamListing).filter(TeamListing.id == listing_id, TeamListing.status == "open").first()
    if not listing:
        raise HTTPException(status_code=404, detail="Η αγγελία δεν βρέθηκε ή δεν είναι πλέον ανοιχτή")
    _expire_stale_listing(db, listing)
    if listing.status != "open":
        raise HTTPException(status_code=400, detail="Η αγγελία έχει λήξει (3 μέρες διάρκεια).")

    if listing.listing_type == "player" and current_user.role != UserRole.PLAYER:
        raise HTTPException(status_code=403, detail="Μόνο λογαριασμοί ρόλου Player μπορούν να αιτηθούν.")
    if listing.listing_type == "staff" and current_user.role == UserRole.PLAYER:
        raise HTTPException(status_code=403, detail="Αυτή η αγγελία αφορά staff ρόλους, όχι παίκτες.")

    existing = (
        db.query(ListingApplication)
        .filter(
            ListingApplication.listing_id == listing_id,
            ListingApplication.applicant_user_id == current_user.id,
        )
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Έχεις ήδη αιτηθεί σε αυτή την αγγελία.")

    application = ListingApplication(
        listing_id=listing_id, applicant_user_id=current_user.id, message=payload.message
    )
    db.add(application)
    db.commit()
    db.refresh(application)
    team = db.query(Team).filter(Team.id == listing.team_id).first()
    notify_eligible_approvers(
        db,
        listing.team_id,
        current_user.role,
        title=f"Νέα αίτηση σε αγγελία: {current_user.full_name or current_user.username}"
        + (f" — {team.name}" if team else ""),
        message=payload.message,
        related_entity_type="listing_application",
        related_entity_id=application.id,
    )
    return _application_out(db, application, current_user, listing.team_id)


@router.get("/listings/{listing_id}/applications", response_model=list[ListingApplicationOut])
def list_listing_applications(
    listing_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    listing = db.query(TeamListing).filter(TeamListing.id == listing_id).first()
    if not listing:
        raise HTTPException(status_code=404, detail="Η αγγελία δεν βρέθηκε")
    team = db.query(Team).filter(Team.id == listing.team_id).first()
    assert_team_access(db, current_user, team)

    applications = (
        db.query(ListingApplication)
        .filter(ListingApplication.listing_id == listing_id)
        .order_by(ListingApplication.created_at.desc())
        .all()
    )
    return [_application_out(db, a, current_user, listing.team_id) for a in applications]


@router.put(
    "/listings/{listing_id}/applications/{application_id}/respond", response_model=ListingApplicationOut
)
def respond_to_listing_application(
    listing_id: str,
    application_id: str,
    payload: ListingApplicationRespond,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    listing = db.query(TeamListing).filter(TeamListing.id == listing_id).first()
    if not listing:
        raise HTTPException(status_code=404, detail="Η αγγελία δεν βρέθηκε")
    team = db.query(Team).filter(Team.id == listing.team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    application = (
        db.query(ListingApplication)
        .filter(ListingApplication.id == application_id, ListingApplication.listing_id == listing_id)
        .first()
    )
    if not application:
        raise HTTPException(status_code=404, detail="Η αίτηση δεν βρέθηκε")
    if application.status != "pending":
        raise HTTPException(status_code=400, detail=f"Η αίτηση δεν είναι πλέον εκκρεμής ({application.status}).")

    applicant = db.query(User).filter(User.id == application.applicant_user_id).first()
    if applicant:
        assert_can_respond_to_request(db, current_user, applicant.role, listing.team_id)

    if payload.accept:
        if listing.listing_type == "staff":
            existing_grant = (
                db.query(TeamAccessGrant)
                .filter(TeamAccessGrant.team_id == listing.team_id, TeamAccessGrant.user_id == applicant.id)
                .first()
            )
            if not existing_grant:
                assert_can_receive_new_grant(db, applicant)
                assert_no_duplicate_head_coach(db, listing.team_id, applicant.id, applicant.role)
                db.add(
                    TeamAccessGrant(
                        team_id=listing.team_id,
                        user_id=applicant.id,
                        role_title=_from_csv(listing.role_needed)[0] if listing.role_needed else None,
                        granted_by=current_user.id,
                    )
                )
        else:  # player
            if applicant.linked_player_id:
                player = db.query(Player).filter(Player.id == applicant.linked_player_id).first()
                if player:
                    player.current_team_id = listing.team_id
            else:
                matched = find_unlinked_player_match(
                    db, applicant.full_name or applicant.username, listing.team_id
                )
                if matched:
                    applicant.linked_player_id = matched.id
                    matched.current_team_id = listing.team_id
                else:
                    name_parts = (applicant.full_name or applicant.username).split(" ", 1)
                    first_name = name_parts[0]
                    last_name = name_parts[1] if len(name_parts) > 1 else "—"
                    player = Player(
                        first_name=first_name, last_name=last_name, current_team_id=listing.team_id
                    )
                    db.add(player)
                    db.flush()
                    applicant.linked_player_id = player.id
        application.status = "accepted"
        # Η θέση καλύφθηκε — κλείνουμε την αγγελία ώστε να μην παραμένει
        # ορατή/ανοιχτή στο Scouting Hub και να μην προσληφθεί δεύτερος
        # άνθρωπος για την ίδια θέση. Οι υπόλοιπες εκκρεμείς αιτήσεις στην
        # ίδια αγγελία απορρίπτονται αυτόματα, ώστε να μη μένουν κρεμασμένες.
        listing.status = "closed"
        db.query(ListingApplication).filter(
            ListingApplication.listing_id == listing.id,
            ListingApplication.status == "pending",
            ListingApplication.id != application.id,
        ).update({"status": "rejected"}, synchronize_session=False)
        role_labels = ", ".join(
            LISTING_ROLE_LABELS_FOR_CHAT.get(r, r) for r in _from_csv(listing.role_needed)
        )
        position_labels = ", ".join(_from_csv(listing.position_needed)) or "οποιαδήποτε θέση"
        label = (
            f"Αγγελία: {role_labels or 'Staff'}"
            if listing.listing_type == "staff"
            else f"Αγγελία: Παίκτης ({position_labels})"
        )
        get_or_create_conversation(
            db,
            current_user.id,
            applicant.id,
            related_team_id=listing.team_id,
            related_listing_id=listing.id,
            context_label=label,
        )
    else:
        application.status = "rejected"

    application.responded_at = datetime.utcnow()
    application.responded_by = current_user.id
    db.commit()
    db.refresh(application)
    return _application_out(db, application, current_user, listing.team_id)
