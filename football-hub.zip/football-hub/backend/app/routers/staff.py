from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import StaffEvaluation, Team, TeamAccessGrant, User, UserRole
from app.permissions import can_respond_to_request, owned_team_ids, require_write_access
from app.models import NotificationType
from app.routers.messages import _conversation_out, get_or_create_conversation
from app.schemas import (
    ConversationOut,
    StaffEvaluationCreate,
    StaffEvaluationOut,
    StaffMemberOut,
    StaffRoleTitleUpdate,
    StaffTeamGroup,
)
from app.services.notifications import notify

router = APIRouter(prefix="/api/staff", tags=["staff"])


def _avg_rating(db: Session, team_id: str, staff_user_id: str):
    row = (
        db.query(func.avg(StaffEvaluation.rating), func.count(StaffEvaluation.id))
        .filter(StaffEvaluation.team_id == team_id, StaffEvaluation.staff_user_id == staff_user_id)
        .first()
    )
    if not row or not row[1]:
        return None, 0
    return round(row[0], 2), row[1]


@router.get("/my-teams", response_model=list[StaffTeamGroup])
def list_my_staff(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Για κάθε ομάδα στην οποία έχει πρόσβαση ο χρήστης, το υπόλοιπο
    επιτελείο της — χωρισμένο ανά ομάδα/σύλλογο, ώστε ένας coach με ομάδες
    σε 3 διαφορετικούς συλλόγους να τους βλέπει ξεχωριστά, όχι όλους μαζί."""
    owned_ids = owned_team_ids(db, current_user)
    team_query = db.query(Team)
    if owned_ids is not None:
        if not owned_ids:
            return []
        team_query = team_query.filter(Team.id.in_(owned_ids))
    teams = team_query.order_by(Team.name.asc()).all()

    groups = []
    for team in teams:
        members_by_user: dict[str, User] = {}
        role_titles: dict[str, str] = {}

        if team.owner_id and team.owner_id != current_user.id:
            owner = db.query(User).filter(User.id == team.owner_id).first()
            if owner:
                members_by_user[owner.id] = owner

        grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.team_id == team.id).all()
        for g in grants:
            if g.user_id == current_user.id:
                continue
            u = db.query(User).filter(User.id == g.user_id).first()
            if u:
                members_by_user[u.id] = u
                if g.role_title:
                    role_titles[u.id] = g.role_title

        if not members_by_user:
            continue

        member_outs = []
        for uid, u in members_by_user.items():
            avg, count = _avg_rating(db, team.id, uid)
            can_fire = current_user.role in {UserRole.SUPER_ADMIN, UserRole.ADMIN} or (
                u.role != UserRole.PRESIDENT and can_respond_to_request(db, current_user, u.role, team.id)
            )
            member_outs.append(
                StaffMemberOut(
                    user_id=u.id,
                    full_name=u.full_name,
                    username=u.username,
                    role=u.role,
                    avatar_path=u.avatar_path,
                    role_title=role_titles.get(uid),
                    staff_availability=u.staff_availability,
                    avg_rating=avg,
                    evaluation_count=count,
                    can_fire=can_fire,
                )
            )
        member_outs.sort(key=lambda m: m.full_name or m.username)
        groups.append(StaffTeamGroup(team_id=team.id, team_name=team.name, members=member_outs))

    return groups


@router.delete("/teams/{team_id}/members/{user_id}", status_code=204)
def fire_staff_member(
    team_id: str,
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    if team.owner_id == user_id:
        raise HTTPException(status_code=400, detail="Δεν μπορείς να αφαιρέσεις τον ιδιοκτήτη της ομάδας.")

    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")

    if current_user.role not in {UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        if not can_respond_to_request(db, current_user, target.role, team_id):
            raise HTTPException(
                status_code=403, detail="Δεν έχεις δικαίωμα να αφαιρέσεις αυτό το μέλος επιτελείου."
            )

    grant = (
        db.query(TeamAccessGrant)
        .filter(TeamAccessGrant.team_id == team_id, TeamAccessGrant.user_id == user_id)
        .first()
    )
    if not grant:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε ενεργή συνεργασία για αφαίρεση.")
    db.delete(grant)
    db.commit()

    notify(
        db,
        NotificationType.TEAM_EVENT,
        title=f"Τερματίστηκε η συνεργασία σου με την ομάδα {team.name}",
        message=f"Η πρόσβασή σου στην ομάδα {team.name} αφαιρέθηκε από {current_user.full_name or current_user.username}.",
        related_entity_type="team",
        related_entity_id=team.id,
        user_id=user_id,
        related_team_id=team.id,
    )
    return None


@router.put("/teams/{team_id}/members/{user_id}/role-title", response_model=StaffMemberOut)
def update_staff_role_title(
    team_id: str,
    user_id: str,
    payload: StaffRoleTitleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    """Ενημερώνει την αρμοδιότητα (π.χ. ποια ομάδα/ρόλο αναλαμβάνει) ενός
    μέλους επιτελείου μέσα σε μια συγκεκριμένη ομάδα."""
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    if current_user.role not in {UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        if not can_respond_to_request(db, current_user, target.role, team_id):
            raise HTTPException(
                status_code=403, detail="Δεν έχεις δικαίωμα να ενημερώσεις την αρμοδιότητα αυτού του μέλους."
            )

    grant = (
        db.query(TeamAccessGrant)
        .filter(TeamAccessGrant.team_id == team_id, TeamAccessGrant.user_id == user_id)
        .first()
    )
    if not grant:
        raise HTTPException(
            status_code=404, detail="Δεν βρέθηκε ενεργή συνεργασία — η αρμοδιότητα δεν μπορεί να αλλάξει."
        )
    grant.role_title = payload.role_title
    db.commit()

    avg, count = _avg_rating(db, team_id, user_id)
    can_fire = current_user.role in {UserRole.SUPER_ADMIN, UserRole.ADMIN} or (
        target.role != UserRole.PRESIDENT and can_respond_to_request(db, current_user, target.role, team_id)
    )
    return StaffMemberOut(
        user_id=target.id,
        full_name=target.full_name,
        username=target.username,
        role=target.role,
        avatar_path=target.avatar_path,
        role_title=grant.role_title,
        staff_availability=target.staff_availability,
        avg_rating=avg,
        evaluation_count=count,
        can_fire=can_fire,
    )


@router.post(
    "/teams/{team_id}/members/{user_id}/evaluations", response_model=StaffEvaluationOut, status_code=201
)
def add_evaluation(
    team_id: str,
    user_id: str,
    payload: StaffEvaluationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")

    if current_user.role not in {UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        if not can_respond_to_request(db, current_user, target.role, team_id):
            raise HTTPException(status_code=403, detail="Δεν έχεις δικαίωμα να αξιολογήσεις αυτό το μέλος.")

    evaluation = StaffEvaluation(
        team_id=team_id,
        staff_user_id=user_id,
        evaluator_id=current_user.id,
        rating=payload.rating,
        comment=payload.comment,
    )
    db.add(evaluation)
    db.commit()
    db.refresh(evaluation)

    notify(
        db,
        NotificationType.TEAM_EVENT,
        title=f"Νέα αξιολόγηση — {team.name}",
        message=f"{'★' * payload.rating}{'☆' * (5 - payload.rating)}" + (f" · {payload.comment}" if payload.comment else ""),
        related_entity_type="team",
        related_entity_id=team.id,
        user_id=user_id,
        related_team_id=team.id,
    )

    return StaffEvaluationOut(
        id=evaluation.id,
        evaluator_id=current_user.id,
        evaluator_name=current_user.full_name,
        rating=evaluation.rating,
        comment=evaluation.comment,
        created_at=evaluation.created_at,
    )


@router.get("/teams/{team_id}/members/{user_id}/evaluations", response_model=list[StaffEvaluationOut])
def list_evaluations(
    team_id: str,
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    rows = (
        db.query(StaffEvaluation, User)
        .join(User, StaffEvaluation.evaluator_id == User.id)
        .filter(StaffEvaluation.team_id == team_id, StaffEvaluation.staff_user_id == user_id)
        .order_by(StaffEvaluation.created_at.desc())
        .all()
    )
    return [
        StaffEvaluationOut(
            id=e.id,
            evaluator_id=evaluator.id,
            evaluator_name=evaluator.full_name,
            rating=e.rating,
            comment=e.comment,
            created_at=e.created_at,
        )
        for e, evaluator in rows
    ]


@router.post("/teams/{team_id}/members/{user_id}/start-conversation", response_model=ConversationOut)
def start_conversation_with_staff(
    team_id: str,
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")

    conversation = get_or_create_conversation(
        db,
        current_user.id,
        user_id,
        related_team_id=team_id,
        context_label=f"Συζήτηση επιτελείου: {team.name}",
    )
    return _conversation_out(db, conversation, current_user.id)
