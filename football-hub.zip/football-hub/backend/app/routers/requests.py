from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import (
    Player,
    PlayerJoinRequest,
    Team,
    TeamAccessGrant,
    TeamJoinRequest,
    User,
    UserRole,
)
from app.permissions import (
    assert_can_receive_new_grant,
    assert_can_respond_to_request,
    assert_leadership_approved,
    assert_no_duplicate_head_coach,
    assert_team_access,
    can_respond_to_request,
    owned_team_ids,
    require_write_access,
)
from app.routers.messages import get_or_create_conversation
from app.services.notifications import notify_eligible_approvers
from app.services.player_matching import find_unlinked_player_match
from app.schemas import (
    PlayerJoinRequestCreate,
    PlayerJoinRequestOut,
    PlayerJoinRequestRespond,
    TeamAccessGrantOut,
    TeamJoinRequestCreate,
    TeamJoinRequestOut,
    TeamJoinRequestRespond,
    UnlinkedPlayerOut,
)

router = APIRouter(prefix="/api", tags=["join-requests"])

REQUEST_LIFETIME_DAYS = 3
MAX_APPLICATIONS_PER_TEAM = 3  # μέγιστες συνολικές αιτήσεις ενός παίκτη στην ΙΔΙΑ ομάδα (αποτρέπει spam μετά από κάθε απόρριψη)
MAX_TEAMS_PER_ACCEPTANCE = 3  # η αρχική ομάδα + έως 2 ακόμα


def _expire_stale(db: Session, model, request) -> None:
    if request.status == "pending" and request.expires_at < datetime.utcnow():
        request.status = "expired"
        db.commit()


# ---------------------------------------------------------------------------
# Team join requests — coach/staff ζητάει να αναλάβει ομάδα
# ---------------------------------------------------------------------------
def _team_request_out(db: Session, r: TeamJoinRequest, current_user: User) -> TeamJoinRequestOut:
    team = db.query(Team).filter(Team.id == r.team_id).first()
    applicant = db.query(User).filter(User.id == r.applicant_user_id).first()
    return TeamJoinRequestOut(
        id=r.id,
        team_id=r.team_id,
        team_name=team.name if team else None,
        applicant_user_id=r.applicant_user_id,
        applicant_name=applicant.full_name if applicant else None,
        applicant_role=applicant.role if applicant else None,
        message=r.message,
        status=r.status,
        created_at=r.created_at,
        expires_at=r.expires_at,
        can_respond=can_respond_to_request(db, current_user, applicant.role, r.team_id) if applicant else True,
    )


@router.post("/teams/{team_id}/join-requests", response_model=TeamJoinRequestOut, status_code=201)
def apply_to_team(
    team_id: str,
    payload: TeamJoinRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role == UserRole.PLAYER:
        raise HTTPException(
            status_code=403, detail="Οι αιτήσεις για ανάληψη ομάδας αφορούν staff ρόλους, όχι παίκτες."
        )
    assert_leadership_approved(current_user)
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")

    accessible = owned_team_ids(db, current_user)
    if accessible is None or team_id in accessible:
        raise HTTPException(status_code=400, detail="Ήδη έχεις πρόσβαση σε αυτή την ομάδα.")

    existing = (
        db.query(TeamJoinRequest)
        .filter(
            TeamJoinRequest.team_id == team_id,
            TeamJoinRequest.applicant_user_id == current_user.id,
            TeamJoinRequest.status == "pending",
        )
        .first()
    )
    if existing:
        _expire_stale(db, TeamJoinRequest, existing)
        if existing.status == "pending":
            raise HTTPException(
                status_code=400,
                detail="Έχεις ήδη εκκρεμή αίτηση σε αυτή την ομάδα. Περίμενε απάντηση ή λήξη (3 μέρες).",
            )

    request = TeamJoinRequest(
        team_id=team_id,
        applicant_user_id=current_user.id,
        message=payload.message,
        expires_at=datetime.utcnow() + timedelta(days=REQUEST_LIFETIME_DAYS),
    )
    db.add(request)
    db.commit()
    db.refresh(request)
    notify_eligible_approvers(
        db,
        team_id,
        current_user.role,
        title=f"Νέα αίτηση: {current_user.full_name or current_user.username} — {team.name}",
        message=payload.message,
        related_entity_type="team_join_request",
        related_entity_id=request.id,
    )
    return _team_request_out(db, request, current_user)


@router.get("/join-requests/mine", response_model=list[TeamJoinRequestOut])
def list_my_team_requests(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    requests = (
        db.query(TeamJoinRequest)
        .filter(TeamJoinRequest.applicant_user_id == current_user.id)
        .order_by(TeamJoinRequest.created_at.desc())
        .all()
    )
    for r in requests:
        _expire_stale(db, TeamJoinRequest, r)
    return [_team_request_out(db, r, current_user) for r in requests]


@router.get("/teams/{team_id}/join-requests", response_model=list[TeamJoinRequestOut])
def list_team_join_requests(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    requests = (
        db.query(TeamJoinRequest)
        .filter(TeamJoinRequest.team_id == team_id)
        .order_by(TeamJoinRequest.created_at.desc())
        .all()
    )
    for r in requests:
        _expire_stale(db, TeamJoinRequest, r)
    return [_team_request_out(db, r, current_user) for r in requests]


@router.put("/teams/{team_id}/join-requests/{request_id}/respond", response_model=TeamJoinRequestOut)
def respond_to_team_request(
    team_id: str,
    request_id: str,
    payload: TeamJoinRequestRespond,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    request = (
        db.query(TeamJoinRequest)
        .filter(TeamJoinRequest.id == request_id, TeamJoinRequest.team_id == team_id)
        .first()
    )
    if not request:
        raise HTTPException(status_code=404, detail="Η αίτηση δεν βρέθηκε")
    _expire_stale(db, TeamJoinRequest, request)
    if request.status != "pending":
        raise HTTPException(status_code=400, detail=f"Η αίτηση δεν είναι πλέον εκκρεμής ({request.status}).")

    applicant = db.query(User).filter(User.id == request.applicant_user_id).first()
    if applicant:
        assert_can_respond_to_request(db, current_user, applicant.role, team_id)

    if payload.accept:
        team_ids_to_grant = [team_id] + payload.additional_team_ids[: MAX_TEAMS_PER_ACCEPTANCE - 1]
        owned = owned_team_ids(db, current_user) or set()
        for tid in team_ids_to_grant:
            if tid != team_id and tid not in owned:
                raise HTTPException(
                    status_code=400,
                    detail="Μπορείς να αναθέσεις μόνο ομάδες που κατέχεις εσύ ο ίδιος.",
                )
        new_grants_needed = [
            tid
            for tid in team_ids_to_grant
            if not db.query(TeamAccessGrant)
            .filter(TeamAccessGrant.team_id == tid, TeamAccessGrant.user_id == request.applicant_user_id)
            .first()
        ]
        if new_grants_needed and applicant:
            assert_can_receive_new_grant(db, applicant)
        if applicant:
            for tid in team_ids_to_grant:
                assert_no_duplicate_head_coach(db, tid, request.applicant_user_id, applicant.role)
        for tid in team_ids_to_grant:
            existing_grant = (
                db.query(TeamAccessGrant)
                .filter(TeamAccessGrant.team_id == tid, TeamAccessGrant.user_id == request.applicant_user_id)
                .first()
            )
            if not existing_grant:
                db.add(
                    TeamAccessGrant(
                        team_id=tid,
                        user_id=request.applicant_user_id,
                        role_title=payload.role_title,
                        granted_by=current_user.id,
                    )
                )
        request.status = "accepted"
        get_or_create_conversation(
            db,
            current_user.id,
            request.applicant_user_id,
            related_team_id=team_id,
            context_label=f"Ανάληψη ομάδας: {team.name}",
        )
    else:
        request.status = "rejected"

    request.responded_at = datetime.utcnow()
    request.responded_by = current_user.id
    db.commit()
    db.refresh(request)
    return _team_request_out(db, request, current_user)


# ---------------------------------------------------------------------------
# Team access grants — ποιοι coaches διαχειρίζονται μια ομάδα χωρίς να την
# κατέχουν
# ---------------------------------------------------------------------------
@router.get("/teams/{team_id}/access-grants", response_model=list[TeamAccessGrantOut])
def list_team_access_grants(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    rows = (
        db.query(TeamAccessGrant, User)
        .join(User, TeamAccessGrant.user_id == User.id)
        .filter(TeamAccessGrant.team_id == team_id)
        .all()
    )
    return [
        TeamAccessGrantOut(
            id=g.id,
            team_id=g.team_id,
            team_name=team.name,
            user_id=u.id,
            full_name=u.full_name,
            username=u.username,
            role_title=g.role_title,
        )
        for g, u in rows
    ]


@router.delete("/teams/{team_id}/access-grants/{grant_id}", status_code=204)
def revoke_team_access_grant(
    team_id: str,
    grant_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    grant = (
        db.query(TeamAccessGrant)
        .filter(TeamAccessGrant.id == grant_id, TeamAccessGrant.team_id == team_id)
        .first()
    )
    if not grant:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.delete(grant)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Player join requests — παίκτης ζητάει να ενταχθεί σε ομάδα
# ---------------------------------------------------------------------------
def _player_request_out(db: Session, r: PlayerJoinRequest, current_user: User) -> PlayerJoinRequestOut:
    team = db.query(Team).filter(Team.id == r.team_id).first()
    applicant = db.query(User).filter(User.id == r.applicant_user_id).first()
    return PlayerJoinRequestOut(
        id=r.id,
        team_id=r.team_id,
        team_name=team.name if team else None,
        applicant_user_id=r.applicant_user_id,
        applicant_name=applicant.full_name if applicant else None,
        message=r.message,
        status=r.status,
        created_at=r.created_at,
        expires_at=r.expires_at,
        can_respond=can_respond_to_request(db, current_user, UserRole.PLAYER, r.team_id),
    )


@router.get("/teams/{team_id}/unlinked-players", response_model=list[UnlinkedPlayerOut])
def list_unlinked_players(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    """Παίκτες στο ρόστερ αυτής της ομάδας που δεν είναι ήδη συνδεδεμένοι με
    κανέναν λογαριασμό — για το dropdown χειροκίνητης σύνδεσης όταν
    εγκρίνεται μια αίτηση παίκτη."""
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    linked_ids = {u.linked_player_id for u in db.query(User).filter(User.linked_player_id.isnot(None))}
    players = db.query(Player).filter(Player.current_team_id == team_id).all()
    return [
        UnlinkedPlayerOut(id=p.id, first_name=p.first_name, last_name=p.last_name)
        for p in players
        if p.id not in linked_ids
    ]


@router.post("/teams/{team_id}/player-join-requests", response_model=PlayerJoinRequestOut, status_code=201)
def apply_as_player(
    team_id: str,
    payload: PlayerJoinRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != UserRole.PLAYER:
        raise HTTPException(status_code=403, detail="Μόνο λογαριασμοί ρόλου Player μπορούν να κάνουν αίτηση.")
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")

    # Ένας παίκτης έχει δικαίωμα σε ΜΙΑ ομάδα κάθε φορά — αν έχει ήδη
    # εκκρεμή αίτηση οπουδήποτε, δεν μπορεί να κάνει άλλη.
    pending = (
        db.query(PlayerJoinRequest)
        .filter(PlayerJoinRequest.applicant_user_id == current_user.id, PlayerJoinRequest.status == "pending")
        .first()
    )
    if pending:
        _expire_stale(db, PlayerJoinRequest, pending)
        if pending.status == "pending":
            raise HTTPException(
                status_code=400,
                detail="Έχεις ήδη εκκρεμή αίτηση σε ομάδα. Περίμενε απάντηση ή λήξη (3 μέρες).",
            )

    # Όριο συνολικών αιτήσεων στην ΙΔΙΑ ομάδα — αποτρέπει επαναλαμβανόμενη
    # αίτηση ξανά και ξανά μετά από κάθε απόρριψη.
    total_attempts = (
        db.query(PlayerJoinRequest)
        .filter(
            PlayerJoinRequest.applicant_user_id == current_user.id,
            PlayerJoinRequest.team_id == team_id,
        )
        .count()
    )
    if total_attempts >= MAX_APPLICATIONS_PER_TEAM:
        raise HTTPException(
            status_code=400,
            detail=f"Έχεις ήδη κάνει {total_attempts} αιτήσεις σε αυτή την ομάδα — δεν μπορείς να κάνεις άλλη.",
        )

    request = PlayerJoinRequest(
        team_id=team_id,
        applicant_user_id=current_user.id,
        message=payload.message,
        date_of_birth=payload.date_of_birth,
        expires_at=datetime.utcnow() + timedelta(days=REQUEST_LIFETIME_DAYS),
    )
    db.add(request)
    db.commit()
    db.refresh(request)
    notify_eligible_approvers(
        db,
        team_id,
        UserRole.PLAYER,
        title=f"Νέα αίτηση παίκτη: {current_user.full_name or current_user.username} — {team.name}",
        message=payload.message,
        related_entity_type="player_join_request",
        related_entity_id=request.id,
    )
    return _player_request_out(db, request, current_user)


@router.get("/player-join-requests/mine", response_model=list[PlayerJoinRequestOut])
def list_my_player_requests(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    requests = (
        db.query(PlayerJoinRequest)
        .filter(PlayerJoinRequest.applicant_user_id == current_user.id)
        .order_by(PlayerJoinRequest.created_at.desc())
        .all()
    )
    for r in requests:
        _expire_stale(db, PlayerJoinRequest, r)
    return [_player_request_out(db, r, current_user) for r in requests]


@router.get("/teams/{team_id}/player-join-requests", response_model=list[PlayerJoinRequestOut])
def list_team_player_requests(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    requests = (
        db.query(PlayerJoinRequest)
        .filter(PlayerJoinRequest.team_id == team_id)
        .order_by(PlayerJoinRequest.created_at.desc())
        .all()
    )
    for r in requests:
        _expire_stale(db, PlayerJoinRequest, r)
    return [_player_request_out(db, r, current_user) for r in requests]


@router.put("/teams/{team_id}/player-join-requests/{request_id}/respond", response_model=PlayerJoinRequestOut)
def respond_to_player_request(
    team_id: str,
    request_id: str,
    payload: PlayerJoinRequestRespond,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    request = (
        db.query(PlayerJoinRequest)
        .filter(PlayerJoinRequest.id == request_id, PlayerJoinRequest.team_id == team_id)
        .first()
    )
    if not request:
        raise HTTPException(status_code=404, detail="Η αίτηση δεν βρέθηκε")
    _expire_stale(db, PlayerJoinRequest, request)
    if request.status != "pending":
        raise HTTPException(status_code=400, detail=f"Η αίτηση δεν είναι πλέον εκκρεμής ({request.status}).")

    assert_can_respond_to_request(db, current_user, UserRole.PLAYER, team_id)


    if payload.accept:
        applicant = db.query(User).filter(User.id == request.applicant_user_id).first()
        if payload.link_to_player_id:
            # Ο εγκρίνων επέλεξε χειροκίνητα ποιον υπάρχοντα παίκτη να
            # συνδέσει — προτεραιότητα πάνω από το αυτόματο ταίριασμα.
            manual_target = (
                db.query(Player)
                .filter(Player.id == payload.link_to_player_id, Player.current_team_id == team_id)
                .first()
            )
            if not manual_target:
                raise HTTPException(
                    status_code=400, detail="Ο επιλεγμένος παίκτης δεν βρέθηκε σε αυτή την ομάδα."
                )
            already_linked = (
                db.query(User)
                .filter(User.linked_player_id == manual_target.id, User.id != applicant.id)
                .first()
            )
            if already_linked:
                raise HTTPException(
                    status_code=400, detail="Αυτός ο παίκτης είναι ήδη συνδεδεμένος με άλλο λογαριασμό."
                )
            applicant.linked_player_id = manual_target.id
            manual_target.current_team_id = team_id
        elif applicant.linked_player_id:
            player = db.query(Player).filter(Player.id == applicant.linked_player_id).first()
            if player:
                player.current_team_id = team_id
        else:
            # Πριν φτιάξουμε νέα εγγραφή, ψάχνουμε μήπως υπάρχει ήδη ο ίδιος
            # παίκτης στο ρόστερ (π.χ. τον πρόσθεσε coach πριν κάνει εγγραφή
            # ο ίδιος) — ταίριασμα με ονοματεπώνυμο, και ημερομηνία γέννησης
            # σε περίπτωση συνωνυμίας, ίδια λογική με την εγγραφή λογαριασμού.
            matched = find_unlinked_player_match(
                db,
                applicant.full_name or applicant.username,
                team_id,
                request.date_of_birth,
            )
            if matched:
                applicant.linked_player_id = matched.id
                matched.current_team_id = team_id
            else:
                name_parts = (applicant.full_name or applicant.username).split(" ", 1)
                first_name = name_parts[0]
                last_name = name_parts[1] if len(name_parts) > 1 else "—"
                player = Player(first_name=first_name, last_name=last_name, current_team_id=team_id)
                db.add(player)
                db.flush()
                applicant.linked_player_id = player.id
        request.status = "accepted"
        get_or_create_conversation(
            db,
            current_user.id,
            request.applicant_user_id,
            related_team_id=team_id,
            context_label=f"Ένταξη ως παίκτης: {team.name}",
        )
    else:
        request.status = "rejected"

    request.responded_at = datetime.utcnow()
    request.responded_by = current_user.id
    db.commit()
    db.refresh(request)
    return _player_request_out(db, request, current_user)
