import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.config import ALLOWED_IMAGE_TYPES, AVATARS_DIR, MAX_UPLOAD_SIZE_MB
from app.database import get_db
from app.models import Achievement, Federation, Qualification, Team, TeamAccessGrant, User, WorkExperience
from app.schemas import (
    AchievementIn,
    AchievementOut,
    LinkedInUpdate,
    MyTeamMembershipOut,
    QualificationIn,
    QualificationOut,
    StaffAvailabilityUpdate,
    StaffScoutingPrefsUpdate,
    StaffVisibilityUpdate,
    UserOut,
    UserSearchResult,
    WorkExperienceIn,
    WorkExperienceOut,
)

router = APIRouter(prefix="/api/profile", tags=["profile"])


@router.post("/me/avatar", response_model=UserOut)
def upload_avatar(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail="Επιτρέπονται μόνο JPG, PNG ή WEBP αρχεία")
    contents = file.file.read()
    if len(contents) > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"Το αρχείο ξεπερνά τα {MAX_UPLOAD_SIZE_MB}MB")

    ext = Path(file.filename).suffix or ".png"
    filename = f"{uuid.uuid4()}{ext}"
    dest = AVATARS_DIR / filename
    dest.write_bytes(contents)

    current_user.avatar_path = f"/media/avatars/{filename}"
    db.commit()
    db.refresh(current_user)
    return current_user


@router.put("/me/visibility", response_model=UserOut)
def update_visibility(
    payload: StaffVisibilityUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    current_user.is_staff_visible = payload.is_staff_visible
    db.commit()
    db.refresh(current_user)
    return current_user


VALID_STAFF_AVAILABILITY = {"not_listed", "available", "open_to_offers"}


@router.put("/me/availability", response_model=UserOut)
def update_staff_availability(
    payload: StaffAvailabilityUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if payload.staff_availability not in VALID_STAFF_AVAILABILITY:
        raise HTTPException(status_code=400, detail="Μη έγκυρη κατάσταση διαθεσιμότητας")
    current_user.staff_availability = payload.staff_availability
    db.commit()
    db.refresh(current_user)
    return current_user


VALID_DESIRED_STAFF_ROLES = {
    "technical_director",
    "head_coach",
    "assistant_coach",
    "fitness_coach",
    "analyst",
    "scout",
}


@router.put("/me/staff-scouting-prefs", response_model=UserOut)
def update_staff_scouting_prefs(
    payload: StaffScoutingPrefsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ο ίδιος ο χρήστης δηλώνει τι ψάχνει: ρόλος + περιοχές ενδιαφέροντος +
    από πού είναι. Εμφανίζεται στο δημόσιο staff directory του Scouting Hub."""
    if payload.desired_staff_role and payload.desired_staff_role not in VALID_DESIRED_STAFF_ROLES:
        raise HTTPException(status_code=400, detail="Μη έγκυρος ρόλος αναζήτησης")

    if payload.origin_federation_id:
        fed = db.query(Federation).filter(Federation.id == payload.origin_federation_id).first()
        if not fed:
            raise HTTPException(status_code=404, detail="Η ΕΠΣ καταγωγής δεν βρέθηκε")

    if payload.desired_federation_ids:
        found = (
            db.query(Federation.id)
            .filter(Federation.id.in_(payload.desired_federation_ids))
            .all()
        )
        if len(found) != len(set(payload.desired_federation_ids)):
            raise HTTPException(status_code=404, detail="Μία ή περισσότερες ΕΠΣ δεν βρέθηκαν")

    current_user.desired_staff_role = payload.desired_staff_role or None
    current_user.origin_federation_id = payload.origin_federation_id or None
    current_user.desired_federation_ids = ",".join(payload.desired_federation_ids) or None
    db.commit()
    db.refresh(current_user)
    return current_user


@router.put("/me/linkedin", response_model=UserOut)
def update_linkedin(
    payload: LinkedInUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    current_user.linkedin_url = payload.linkedin_url or None
    current_user.show_linkedin = payload.show_linkedin
    db.commit()
    db.refresh(current_user)
    return current_user


# ---------------------------------------------------------------------------
# Πτυχία
# ---------------------------------------------------------------------------
@router.get("/me/qualifications", response_model=list[QualificationOut])
def list_my_qualifications(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Qualification).filter(Qualification.user_id == current_user.id).all()


@router.post("/me/qualifications", response_model=QualificationOut, status_code=201)
def add_qualification(
    payload: QualificationIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = Qualification(user_id=current_user.id, **payload.model_dump())
    db.add(q)
    db.commit()
    db.refresh(q)
    return q


@router.delete("/me/qualifications/{qualification_id}", status_code=204)
def delete_qualification(
    qualification_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = (
        db.query(Qualification)
        .filter(Qualification.id == qualification_id, Qualification.user_id == current_user.id)
        .first()
    )
    if not q:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.delete(q)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Εργασιακή εμπειρία
# ---------------------------------------------------------------------------
@router.get("/me/experience", response_model=list[WorkExperienceOut])
def list_my_experience(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return (
        db.query(WorkExperience)
        .filter(WorkExperience.user_id == current_user.id)
        .order_by(WorkExperience.start_year.desc())
        .all()
    )


@router.post("/me/experience", response_model=WorkExperienceOut, status_code=201)
def add_experience(
    payload: WorkExperienceIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    e = WorkExperience(user_id=current_user.id, **payload.model_dump())
    db.add(e)
    db.commit()
    db.refresh(e)
    return e


@router.delete("/me/experience/{experience_id}", status_code=204)
def delete_experience(
    experience_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    e = (
        db.query(WorkExperience)
        .filter(WorkExperience.id == experience_id, WorkExperience.user_id == current_user.id)
        .first()
    )
    if not e:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.delete(e)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Κατακτήσεις
# ---------------------------------------------------------------------------
@router.get("/me/achievements", response_model=list[AchievementOut])
def list_my_achievements(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return (
        db.query(Achievement)
        .filter(Achievement.user_id == current_user.id)
        .order_by(Achievement.year.desc())
        .all()
    )


@router.post("/me/achievements", response_model=AchievementOut, status_code=201)
def add_achievement(
    payload: AchievementIn,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    a = Achievement(user_id=current_user.id, **payload.model_dump())
    db.add(a)
    db.commit()
    db.refresh(a)
    return a


@router.delete("/me/achievements/{achievement_id}", status_code=204)
def delete_achievement(
    achievement_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    a = (
        db.query(Achievement)
        .filter(Achievement.id == achievement_id, Achievement.user_id == current_user.id)
        .first()
    )
    if not a:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.delete(a)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Αναζήτηση χρηστών (για να προσθέσεις κάποιον στο Τεχνικό Επιτελείο ομάδας)
# ---------------------------------------------------------------------------
@router.get("/search", response_model=list[UserSearchResult])
def search_users(
    q: str = "", db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    if not q or len(q) < 2:
        return []
    like = f"%{q}%"
    users = (
        db.query(User)
        .filter(or_(User.full_name.ilike(like), User.username.ilike(like)))
        .limit(15)
        .all()
    )
    return users


# ---------------------------------------------------------------------------
# Οι δικές μου συνεργασίες (TeamAccessGrant) — αυτοεξυπηρέτηση αποχώρησης.
# Λύνει το εξής: ένας coach που "έφυγε" νοερά από μια ομάδα αλλά κανείς δεν
# τον αφαίρεσε (Απόλυση) παραμένει να μετράει στο όριο ομάδων του — έτσι
# μπορεί ο ίδιος να αφήσει την παλιά ομάδα χωρίς να χρειάζεται τον πρόεδρό
# της.
# ---------------------------------------------------------------------------
@router.get("/me/team-memberships", response_model=list[MyTeamMembershipOut])
def list_my_team_memberships(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.user_id == current_user.id).all()
    results = []
    for g in grants:
        team = db.query(Team).filter(Team.id == g.team_id).first()
        if team:
            results.append(MyTeamMembershipOut(team_id=team.id, team_name=team.name, role_title=g.role_title))
    return results


@router.delete("/me/team-memberships/{team_id}", status_code=204)
def leave_team(team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    grant = (
        db.query(TeamAccessGrant)
        .filter(TeamAccessGrant.team_id == team_id, TeamAccessGrant.user_id == current_user.id)
        .first()
    )
    if not grant:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε συνεργασία με αυτή την ομάδα.")
    db.delete(grant)
    db.commit()
    return None
