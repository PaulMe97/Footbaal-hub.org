import json
import shutil
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse

from app.config import DATABASE_URL
from app.database import engine, get_db
from app.models import Match, Player, PlayerStatistics, Team, TrainingSession, User
from app.permissions import owned_team_ids, require_admin, require_write_access
from app.services.http_utils import content_disposition_filename
from sqlalchemy.orm import Session

router = APIRouter(prefix="/api/backup", tags=["backup"])


def _sqlite_path() -> Path:
    if not DATABASE_URL.startswith("sqlite"):
        raise HTTPException(
            status_code=400,
            detail=(
                "Το backup/restore μέσω αρχείου λειτουργεί μόνο με την τοπική SQLite βάση. "
                "Για PostgreSQL, χρησιμοποίησε pg_dump / pg_restore."
            ),
        )
    return Path(DATABASE_URL.replace("sqlite:///", ""))


@router.get("/export")
def export_backup(current_user: User = Depends(require_admin)):
    db_path = _sqlite_path()
    if not db_path.exists():
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε αρχείο βάσης δεδομένων")

    # Χρησιμοποιεί το sqlite3 backup API ώστε να πάρει consistent snapshot ακόμα
    # κι αν η εφαρμογή γράφει ταυτόχρονα, αντί για ωμή αντιγραφή του αρχείου.
    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    tmp_dir = Path(tempfile.mkdtemp())
    snapshot_path = tmp_dir / f"footballhub-backup-{timestamp}.db"

    source = sqlite3.connect(str(db_path))
    dest = sqlite3.connect(str(snapshot_path))
    with dest:
        source.backup(dest)
    source.close()
    dest.close()

    return FileResponse(
        path=str(snapshot_path),
        filename=snapshot_path.name,
        media_type="application/octet-stream",
    )


@router.post("/import")
def import_backup(file: UploadFile = File(...), current_user: User = Depends(require_admin)):
    db_path = _sqlite_path()

    if not file.filename.endswith(".db"):
        raise HTTPException(status_code=400, detail="Το αρχείο πρέπει να είναι .db (SQLite)")

    contents = file.file.read()

    # Επικύρωση: πρέπει να είναι ένα έγκυρο SQLite αρχείο με τα αναμενόμενα tables,
    # πριν αντικαταστήσουμε οτιδήποτε — αλλιώς ρίχνει καθαρό σφάλμα χωρίς να πειράξει τη βάση.
    tmp_dir = Path(tempfile.mkdtemp())
    uploaded_path = tmp_dir / "uploaded.db"
    uploaded_path.write_bytes(contents)
    try:
        conn = sqlite3.connect(str(uploaded_path))
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        }
        conn.close()
    except sqlite3.DatabaseError:
        raise HTTPException(status_code=400, detail="Το αρχείο δεν είναι έγκυρη SQLite βάση δεδομένων")

    required_tables = {"users", "teams", "players"}
    if not required_tables.issubset(tables):
        raise HTTPException(
            status_code=400,
            detail="Το αρχείο δεν μοιάζει με backup του FootballHub (λείπουν βασικοί πίνακες)",
        )

    # Κλείνει τις υπάρχουσες συνδέσεις πριν αντικαταστήσει το αρχείο.
    engine.dispose()
    shutil.copyfile(str(uploaded_path), str(db_path))

    return {
        "message": (
            "Η επαναφορά ολοκληρώθηκε. Κάνε επανεκκίνηση τον backend server "
            "(σταμάτα το uvicorn με Ctrl+C και ξανατρέξτο) ώστε να φορτωθούν τα νέα δεδομένα."
        )
    }


@router.get("/export-my-data")
def export_my_data(db: Session = Depends(get_db), current_user: User = Depends(require_write_access)):
    """Εξαγωγή σε JSON ΜΟΝΟ των δεδομένων που έχει πρόσβαση ο συγκεκριμένος
    χρήστης (τις δικές του ομάδες) — για Πρόεδρο/Τεχνικό Διευθυντή/Προπονητή
    που θέλουν αντίγραφο του δικού τους συλλόγου. Σκόπιμα ΔΕΝ είναι το ωμό
    αρχείο SQLite (αυτό παραμένει μόνο για Admin), ώστε να μην μπορεί ποτέ
    κάποιος να δει ή να αντικαταστήσει δεδομένα άλλου συλλόγου."""
    owned_ids = owned_team_ids(db, current_user)
    team_query = db.query(Team)
    if owned_ids is not None:
        if not owned_ids:
            teams = []
        else:
            teams = team_query.filter(Team.id.in_(owned_ids)).all()
    else:
        teams = team_query.all()

    export = {"exported_at": datetime.utcnow().isoformat(), "exported_by": current_user.username, "teams": []}

    for team in teams:
        players = db.query(Player).filter(Player.current_team_id == team.id).all()
        players_data = []
        for p in players:
            stats = (
                db.query(PlayerStatistics)
                .filter(PlayerStatistics.player_id == p.id, PlayerStatistics.season.is_(None))
                .first()
            )
            players_data.append(
                {
                    "first_name": p.first_name,
                    "last_name": p.last_name,
                    "position": p.position,
                    "date_of_birth": p.date_of_birth.isoformat() if p.date_of_birth else None,
                    "nationality": p.nationality,
                    "status": p.status,
                    "transfer_status": p.transfer_status,
                    "career_stats": {
                        "goals": stats.goals,
                        "assists": stats.assists,
                        "matches_played": stats.matches_played,
                    }
                    if stats
                    else None,
                }
            )

        matches = (
            db.query(Match)
            .filter((Match.home_team_id == team.id) | (Match.away_team_id == team.id))
            .all()
        )
        matches_data = [
            {
                "date": m.date.isoformat() if m.date else None,
                "home_team_id": m.home_team_id,
                "away_team_id": m.away_team_id,
                "home_team_name_external": m.home_team_name_external,
                "away_team_name_external": m.away_team_name_external,
                "home_score": m.home_score,
                "away_score": m.away_score,
                "competition": m.competition,
                "status": m.status,
            }
            for m in matches
        ]

        trainings = db.query(TrainingSession).filter(TrainingSession.team_id == team.id).all()
        trainings_data = [
            {
                "date": t.date.isoformat() if t.date else None,
                "time": t.time,
                "location": t.location,
                "training_type": t.training_type,
            }
            for t in trainings
        ]

        export["teams"].append(
            {
                "name": team.name,
                "category": team.category,
                "league_tier": team.league_tier,
                "season": team.season,
                "players": players_data,
                "matches": matches_data,
                "trainings": trainings_data,
            }
        )

    filename = f"footballhub-export-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(
        content=export,
        headers={"Content-Disposition": content_disposition_filename(filename)},
    )
