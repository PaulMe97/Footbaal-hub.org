import calendar
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import Integer, func
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import Match, MatchPlayer, Player, Team, User
from app.permissions import owned_team_ids
from app.schemas import PlayerMonthlyPerformance

router = APIRouter(prefix="/api/performance", tags=["performance"])


@router.get("/monthly", response_model=list[PlayerMonthlyPerformance])
def monthly_performance(
    year: int = Query(...),
    month: int = Query(..., ge=1, le=12),
    team_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None and not owned_ids:
        return []

    last_day = calendar.monthrange(year, month)[1]
    start = date(year, month, 1)
    end = date(year, month, last_day)

    query = (
        db.query(
            MatchPlayer.player_id,
            func.count(MatchPlayer.id).label("matches_played"),
            func.avg(MatchPlayer.rating).label("avg_rating"),
            func.sum(MatchPlayer.goals).label("goals"),
            func.sum(MatchPlayer.assists).label("assists"),
            func.sum(MatchPlayer.yellow_cards).label("yellow_cards"),
            func.sum(MatchPlayer.red_cards).label("red_cards"),
            func.sum(func.cast(MatchPlayer.is_mvp, Integer)).label("mvp_count"),
        )
        .join(Match, MatchPlayer.match_id == Match.id)
        .join(Player, MatchPlayer.player_id == Player.id)
        .filter(Match.date >= start, Match.date <= end)
        .group_by(MatchPlayer.player_id)
    )

    if owned_ids is not None:
        query = query.filter(Player.current_team_id.in_(owned_ids))
    if team_id:
        query = query.filter(Player.current_team_id == team_id)

    rows = query.all()

    results = []
    for row in rows:
        player = db.query(Player).filter(Player.id == row.player_id).first()
        if not player:
            continue
        team = db.query(Team).filter(Team.id == player.current_team_id).first() if player.current_team_id else None
        results.append(
            PlayerMonthlyPerformance(
                player_id=player.id,
                player_name=f"{player.first_name} {player.last_name}",
                team_name=team.name if team else None,
                matches_played=row.matches_played or 0,
                avg_rating=round(row.avg_rating, 2) if row.avg_rating is not None else None,
                goals=row.goals or 0,
                assists=row.assists or 0,
                yellow_cards=row.yellow_cards or 0,
                red_cards=row.red_cards or 0,
                mvp_count=row.mvp_count or 0,
            )
        )

    results.sort(key=lambda r: (r.avg_rating or 0), reverse=True)
    return results
