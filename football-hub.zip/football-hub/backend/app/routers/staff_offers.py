from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import NotificationType, StaffAssignmentOffer, Team, TeamAccessGrant, User, UserRole
from app.permissions import (
    assert_can_receive_new_grant,
    assert_no_duplicate_head_coach,
    assert_team_access,
    require_write_access,
)
from app.routers.messages import get_or_create_conversation
from app.schemas import (
    StaffAssignmentOfferCreate,
    StaffAssignmentOfferOut,
    StaffAssignmentOfferRespond,
)
from app.services.notifications import notify

router = APIRouter(prefix="/api", tags=["staff-offers"])

OFFER_SENDER_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR, UserRole.SUPER_ADMIN, UserRole.ADMIN}
# Έγκυροι στόχοι για new_role — ποτέ Player (η μετατροπή ΣΕ staff καλύπτεται
# ήδη, όχι staff -> player) και ποτέ President/Admin (πολύ ευαίσθητοι
# ρόλοι, δεν αλλάζουν με απλή προσφορά).
VALID_NEW_ROLES = {
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
    UserRole.FITNESS_COACH,
    UserRole.ANALYST,
    UserRole.SCOUT,
}


def _offer_out(db: Session, offer: StaffAssignmentOffer) -> StaffAssignmentOfferOut:
    team = db.query(Team).filter(Team.id == offer.team_id).first()
    sender = db.query(User).filter(User.id == offer.sender_id).first()
    recipient = db.query(User).filter(User.id == offer.recipient_user_id).first()
    return StaffAssignmentOfferOut(
        id=offer.id,
        team_id=offer.team_id,
        team_name=team.name if team else None,
        sender_id=offer.sender_id,
        sender_name=sender.full_name if sender else None,
        recipient_user_id=offer.recipient_user_id,
        recipient_name=recipient.full_name if recipient else None,
        role_title=offer.role_title,
        new_role=offer.new_role,
        season=offer.season,
        incentive_details=offer.incentive_details,
        message=offer.message,
        status=offer.status,
        created_at=offer.created_at,
    )


@router.post("/teams/{team_id}/staff-offers", response_model=StaffAssignmentOfferOut, status_code=201)
def send_staff_assignment_offer(
    team_id: str,
    payload: StaffAssignmentOfferCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if current_user.role not in OFFER_SENDER_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Μόνο ο Πρόεδρος ή ο Τεχνικός Διευθυντής μπορούν να στείλουν προσφορά.",
        )
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    recipient = db.query(User).filter(User.id == payload.recipient_user_id).first()
    if not recipient:
        raise HTTPException(status_code=404, detail="Ο παραλήπτης δεν βρέθηκε")
    if recipient.role in {UserRole.PRESIDENT, UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        raise HTTPException(status_code=400, detail="Δεν μπορείς να στείλεις τέτοια προσφορά σε αυτόν τον ρόλο.")
    if payload.new_role is not None and payload.new_role not in VALID_NEW_ROLES:
        raise HTTPException(status_code=400, detail="Μη έγκυρος νέος ρόλος για προσφορά.")

    # Σκόπιμα ΔΕΝ μπλοκάρουμε αν ο παραλήπτης έχει ήδη πρόσβαση σε αυτή την
    # ομάδα — μια νέα προσφορά μπορεί να είναι ανανέωση στην ίδια θέση,
    # καλύτερα λεφτά φέτος, ή αναβάθμιση/αλλαγή ρόλου. Μπλοκάρουμε μόνο αν
    # υπάρχει ήδη ΕΚΚΡΕΜΗΣ προσφορά, ώστε να μη σωρεύονται διπλές.
    # Απαγόρευση επαναλαμβανόμενης/διπλής προσφοράς: αν ο ίδιος αποστολέας
    # έχει ήδη εκκρεμή προσφορά σε αυτόν τον παραλήπτη (ΑΝΕΞΑΡΤΗΤΑ ομάδας),
    # δεν επιτρέπεται νέα — πρέπει πρώτα να απαντηθεί (αποδοχή/απόρριψη) ή
    # να ανακληθεί.
    existing_pending = (
        db.query(StaffAssignmentOffer)
        .filter(
            StaffAssignmentOffer.sender_id == current_user.id,
            StaffAssignmentOffer.recipient_user_id == recipient.id,
            StaffAssignmentOffer.status == "pending",
        )
        .first()
    )
    if existing_pending:
        raise HTTPException(status_code=400, detail="Έχεις ήδη εκκρεμή προσφορά σε αυτόν τον χρήστη.")

    offer = StaffAssignmentOffer(
        team_id=team_id,
        sender_id=current_user.id,
        recipient_user_id=recipient.id,
        role_title=payload.role_title,
        new_role=payload.new_role.value if payload.new_role else None,
        season=payload.season,
        incentive_details=payload.incentive_details,
        message=payload.message,
    )
    db.add(offer)
    db.commit()
    db.refresh(offer)

    notify(
        db,
        NotificationType.CONTRACT_OFFER,
        title=f"Νέα προσφορά — {team.name}",
        message=payload.incentive_details or payload.message,
        related_entity_type="staff_assignment_offer",
        related_entity_id=offer.id,
        user_id=recipient.id,
        related_team_id=team_id,
    )
    get_or_create_conversation(
        db,
        current_user.id,
        recipient.id,
        related_team_id=team_id,
        context_label=f"Προσφορά: {team.name}",
    )

    return _offer_out(db, offer)


@router.get("/staff-offers/mine", response_model=list[StaffAssignmentOfferOut])
def list_my_staff_offers(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    offers = (
        db.query(StaffAssignmentOffer)
        .filter(StaffAssignmentOffer.recipient_user_id == current_user.id)
        .order_by(StaffAssignmentOffer.created_at.desc())
        .all()
    )
    return [_offer_out(db, o) for o in offers]


@router.get("/teams/{team_id}/staff-offers", response_model=list[StaffAssignmentOfferOut])
def list_team_staff_offers(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    offers = (
        db.query(StaffAssignmentOffer)
        .filter(StaffAssignmentOffer.team_id == team_id)
        .order_by(StaffAssignmentOffer.created_at.desc())
        .all()
    )
    return [_offer_out(db, o) for o in offers]


@router.put("/staff-offers/{offer_id}/respond", response_model=StaffAssignmentOfferOut)
def respond_to_staff_offer(
    offer_id: str,
    payload: StaffAssignmentOfferRespond,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    offer = db.query(StaffAssignmentOffer).filter(StaffAssignmentOffer.id == offer_id).first()
    if not offer or offer.recipient_user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    if offer.status != "pending":
        raise HTTPException(status_code=400, detail=f"Η προσφορά έχει ήδη απαντηθεί ({offer.status}).")

    if payload.accept:
        final_role = offer.new_role or current_user.role.value
        assert_no_duplicate_head_coach(db, offer.team_id, current_user.id, final_role)

        existing_grant = (
            db.query(TeamAccessGrant)
            .filter(TeamAccessGrant.team_id == offer.team_id, TeamAccessGrant.user_id == current_user.id)
            .first()
        )
        if existing_grant:
            # Ήδη στην ομάδα — η προσφορά ήταν ανανέωση/αναβάθμιση, όχι νέα
            # ομάδα. Απλά ενημερώνουμε τον τίτλο ρόλου αν δόθηκε νέος.
            if offer.role_title:
                existing_grant.role_title = offer.role_title
        else:
            # Πραγματικά νέα ομάδα για αυτόν — εδώ μετράει το όριο
            # ταυτόχρονων ομάδων βάσει επαλήθευσης.
            assert_can_receive_new_grant(db, current_user)
            db.add(
                TeamAccessGrant(
                    team_id=offer.team_id,
                    user_id=current_user.id,
                    role_title=offer.role_title,
                    granted_by=offer.sender_id,
                )
            )

        if offer.new_role and offer.new_role != current_user.role.value:
            current_user.role = UserRole(offer.new_role)

        offer.status = "accepted"
    else:
        offer.status = "rejected"

    offer.responded_at = datetime.utcnow()
    db.commit()
    db.refresh(offer)

    team = db.query(Team).filter(Team.id == offer.team_id).first()
    verb = "αποδέχτηκε" if payload.accept else "απέρριψε"
    notify(
        db,
        NotificationType.CONTRACT_OFFER,
        title=f"{current_user.full_name or current_user.username} {verb} την προσφορά",
        message=team.name if team else None,
        related_entity_type="staff_assignment_offer",
        related_entity_id=offer.id,
        user_id=offer.sender_id,
        related_team_id=offer.team_id,
    )
    return _offer_out(db, offer)
