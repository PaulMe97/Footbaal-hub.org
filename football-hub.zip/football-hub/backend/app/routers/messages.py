from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import Conversation, Message, User
from app.schemas import ConversationOut, MessageCreate, MessageOut, StartConversationRequest

router = APIRouter(prefix="/api/conversations", tags=["messages"])


def get_or_create_conversation(
    db: Session,
    user_a_id: str,
    user_b_id: str,
    related_team_id: Optional[str] = None,
    related_listing_id: Optional[str] = None,
    context_label: Optional[str] = None,
) -> Conversation:
    """Επιστρέφει την υπάρχουσα συνομιλία ανάμεσα σε δύο χρήστες (ανεξάρτητα
    από τη σειρά), αλλιώς δημιουργεί καινούρια. Μία συνομιλία ανά ζεύγος
    χρηστών — ο νέος λόγος επικοινωνίας απλά ενημερώνει το context_label."""
    existing = (
        db.query(Conversation)
        .filter(
            or_(
                (Conversation.user_a_id == user_a_id) & (Conversation.user_b_id == user_b_id),
                (Conversation.user_a_id == user_b_id) & (Conversation.user_b_id == user_a_id),
            )
        )
        .first()
    )
    if existing:
        if context_label:
            existing.context_label = context_label
        if related_team_id:
            existing.related_team_id = related_team_id
        if related_listing_id:
            existing.related_listing_id = related_listing_id
        db.commit()
        return existing

    conversation = Conversation(
        user_a_id=user_a_id,
        user_b_id=user_b_id,
        related_team_id=related_team_id,
        related_listing_id=related_listing_id,
        context_label=context_label,
    )
    db.add(conversation)
    db.commit()
    db.refresh(conversation)
    return conversation


def _conversation_out(db: Session, conv: Conversation, current_user_id: str) -> ConversationOut:
    other_id = conv.user_b_id if conv.user_a_id == current_user_id else conv.user_a_id
    other = db.query(User).filter(User.id == other_id).first()
    last_message = (
        db.query(Message)
        .filter(Message.conversation_id == conv.id)
        .order_by(Message.created_at.desc())
        .first()
    )
    unread_count = (
        db.query(Message)
        .filter(
            Message.conversation_id == conv.id,
            Message.sender_id != current_user_id,
            Message.read_at.is_(None),
        )
        .count()
    )
    return ConversationOut(
        id=conv.id,
        other_user_id=other_id,
        other_user_name=other.full_name if other else None,
        other_user_avatar=other.avatar_path if other else None,
        context_label=conv.context_label,
        related_team_id=conv.related_team_id,
        last_message=last_message.content if last_message else None,
        last_message_at=last_message.created_at if last_message else None,
        unread_count=unread_count,
        created_at=conv.created_at,
    )


@router.get("", response_model=list[ConversationOut])
def list_conversations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    conversations = (
        db.query(Conversation)
        .filter(or_(Conversation.user_a_id == current_user.id, Conversation.user_b_id == current_user.id))
        .all()
    )
    results = [_conversation_out(db, c, current_user.id) for c in conversations]
    results.sort(key=lambda c: c.last_message_at or c.created_at, reverse=True)
    return results


@router.post("/start", response_model=ConversationOut)
def start_conversation(
    payload: StartConversationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ξεκινά (ή ανοίγει την ήδη υπάρχουσα) 1-προς-1 συνομιλία με έναν
    συγκεκριμένο χρήστη — π.χ. όταν ο χρήστης διαλέγει κάποιον απευθείας
    από τη λίστα "άτομα του συλλόγου μου" στα Μηνύματα."""
    if payload.other_user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Δεν μπορείς να στείλεις μήνυμα στον εαυτό σου.")
    other = db.query(User).filter(User.id == payload.other_user_id).first()
    if not other:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    conversation = get_or_create_conversation(db, current_user.id, payload.other_user_id)
    return _conversation_out(db, conversation, current_user.id)


@router.get("/{conversation_id}/messages", response_model=list[MessageOut])
def get_messages(
    conversation_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
    if not conv or current_user.id not in {conv.user_a_id, conv.user_b_id}:
        raise HTTPException(status_code=404, detail="Η συνομιλία δεν βρέθηκε")

    messages = (
        db.query(Message)
        .filter(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.asc())
        .all()
    )
    # Μαρκάρει ως διαβασμένα ό,τι έστειλε ο άλλος
    unread = [m for m in messages if m.sender_id != current_user.id and m.read_at is None]
    if unread:
        for m in unread:
            m.read_at = datetime.utcnow()
        db.commit()
    return messages


@router.post("/{conversation_id}/messages", response_model=MessageOut, status_code=201)
def send_message(
    conversation_id: str,
    payload: MessageCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
    if not conv or current_user.id not in {conv.user_a_id, conv.user_b_id}:
        raise HTTPException(status_code=404, detail="Η συνομιλία δεν βρέθηκε")

    message = Message(conversation_id=conversation_id, sender_id=current_user.id, content=payload.content)
    db.add(message)
    db.commit()
    db.refresh(message)
    return message


@router.get("/unread-count")
def get_unread_count(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    conversations = (
        db.query(Conversation)
        .filter(or_(Conversation.user_a_id == current_user.id, Conversation.user_b_id == current_user.id))
        .all()
    )
    total = 0
    for conv in conversations:
        total += (
            db.query(Message)
            .filter(
                Message.conversation_id == conv.id,
                Message.sender_id != current_user.id,
                Message.read_at.is_(None),
            )
            .count()
        )
    return {"count": total}
