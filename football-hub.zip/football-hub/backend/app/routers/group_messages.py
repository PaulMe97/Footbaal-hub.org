"""
Ομαδικές συνομιλίες — ξεχωριστό, παράλληλο σύστημα από το 1-προς-1
messaging (routers/messages.py). Καλύπτει δύο περιπτώσεις:
  1. Ελεύθερη ομαδική συνομιλία με συγκεκριμένα επιλεγμένα άτομα.
  2. Η μόνιμη ομαδική συνομιλία μιας ΣΥΓΚΕΚΡΙΜΕΝΗΣ ομάδας (related_team_id)
     — μία ανά ομάδα, περιλαμβάνει αυτόματα όλα τα μέλη της.
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import (
    GroupConversation,
    GroupConversationParticipant,
    GroupMessage,
    Player,
    Team,
    TeamAccessGrant,
    TeamStaffMember,
    User,
)
from app.schemas import (
    ClubPersonOut,
    GroupConversationCreate,
    GroupConversationOut,
    GroupConversationParticipantOut,
    GroupMessageCreate,
    GroupMessageOut,
)

router = APIRouter(prefix="/api/group-conversations", tags=["group-messages"])


def _my_managed_team_ids(db: Session, user_id: str) -> set[str]:
    """Ομάδες που ο χρήστης διαχειρίζεται — owner ή με TeamAccessGrant."""
    team_ids = {t.id for t in db.query(Team).filter(Team.owner_id == user_id).all()}
    for g in db.query(TeamAccessGrant).filter(TeamAccessGrant.user_id == user_id).all():
        team_ids.add(g.team_id)
    return team_ids


def _team_member_user_ids(db: Session, team_id: str) -> set[str]:
    """Όλα τα user_id που ανήκουν σε μια ομάδα: owner + access grants +
    καταχωρημένο επιτελείο + παίκτες με συνδεδεμένο λογαριασμό."""
    ids: set[str] = set()
    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id:
        ids.add(team.owner_id)
    for g in db.query(TeamAccessGrant).filter(TeamAccessGrant.team_id == team_id).all():
        ids.add(g.user_id)
    for m in db.query(TeamStaffMember).filter(TeamStaffMember.team_id == team_id).all():
        ids.add(m.user_id)
    player_ids = {p.id for p in db.query(Player).filter(Player.current_team_id == team_id).all()}
    if player_ids:
        for u in db.query(User).filter(User.linked_player_id.in_(player_ids)).all():
            ids.add(u.id)
    return ids


@router.get("/club-people", response_model=list[ClubPersonOut])
def list_club_people(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Όλα τα άτομα που ανήκουν στις ομάδες που διαχειρίζεται ο χρήστης —
    ώστε να μπορεί να ξεκινήσει εύκολα μια νέα συνομιλία μαζί τους, χωρίς
    να χρειάζεται να έχει ήδη υπάρξει επικοινωνία."""
    managed_team_ids = _my_managed_team_ids(db, current_user.id)
    results: list[ClubPersonOut] = []
    seen: set[tuple] = set()
    for team_id in managed_team_ids:
        team = db.query(Team).filter(Team.id == team_id).first()
        if not team:
            continue
        for uid in _team_member_user_ids(db, team_id):
            if uid == current_user.id:
                continue
            key = (uid, team_id)
            if key in seen:
                continue
            seen.add(key)
            u = db.query(User).filter(User.id == uid).first()
            if not u:
                continue
            results.append(
                ClubPersonOut(
                    id=u.id,
                    full_name=u.full_name,
                    username=u.username,
                    avatar_path=u.avatar_path,
                    role=u.role,
                    team_id=team.id,
                    team_name=team.name,
                )
            )
    return results


def _group_conversation_out(db: Session, conv: GroupConversation, current_user_id: str) -> GroupConversationOut:
    participant_rows = (
        db.query(GroupConversationParticipant)
        .filter(GroupConversationParticipant.group_conversation_id == conv.id)
        .all()
    )
    my_participant = next((p for p in participant_rows if p.user_id == current_user_id), None)
    participants = []
    for p in participant_rows:
        u = db.query(User).filter(User.id == p.user_id).first()
        if u:
            participants.append(
                GroupConversationParticipantOut(user_id=u.id, full_name=u.full_name, avatar_path=u.avatar_path)
            )

    last_message = (
        db.query(GroupMessage)
        .filter(GroupMessage.group_conversation_id == conv.id)
        .order_by(GroupMessage.created_at.desc())
        .first()
    )
    last_sender_name = None
    if last_message:
        sender = db.query(User).filter(User.id == last_message.sender_id).first()
        last_sender_name = sender.full_name if sender else None

    last_read_at = my_participant.last_read_at if my_participant else None
    unread_query = db.query(GroupMessage).filter(
        GroupMessage.group_conversation_id == conv.id,
        GroupMessage.sender_id != current_user_id,
    )
    if last_read_at:
        unread_query = unread_query.filter(GroupMessage.created_at > last_read_at)
    unread_count = unread_query.count()

    team_name = None
    if conv.related_team_id:
        team = db.query(Team).filter(Team.id == conv.related_team_id).first()
        team_name = team.name if team else None

    display_name = conv.name or team_name
    if not display_name:
        others = [p.full_name or "?" for p in participants if p.user_id != current_user_id]
        display_name = ", ".join(others) if others else None

    return GroupConversationOut(
        id=conv.id,
        name=display_name,
        related_team_id=conv.related_team_id,
        related_team_name=team_name,
        participants=participants,
        last_message=last_message.content if last_message else None,
        last_message_sender_name=last_sender_name,
        last_message_at=last_message.created_at if last_message else None,
        unread_count=unread_count,
        created_at=conv.created_at,
    )


@router.get("", response_model=list[GroupConversationOut])
def list_group_conversations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    my_conv_ids = {
        p.group_conversation_id
        for p in db.query(GroupConversationParticipant)
        .filter(GroupConversationParticipant.user_id == current_user.id)
        .all()
    }
    conversations = db.query(GroupConversation).filter(GroupConversation.id.in_(my_conv_ids)).all()
    results = [_group_conversation_out(db, c, current_user.id) for c in conversations]
    results.sort(key=lambda c: c.last_message_at or c.created_at, reverse=True)
    return results


def _assert_participant(db: Session, conversation_id: str, user_id: str) -> GroupConversation:
    conv = db.query(GroupConversation).filter(GroupConversation.id == conversation_id).first()
    if not conv:
        raise HTTPException(status_code=404, detail="Η συνομιλία δεν βρέθηκε")
    is_participant = (
        db.query(GroupConversationParticipant)
        .filter(
            GroupConversationParticipant.group_conversation_id == conversation_id,
            GroupConversationParticipant.user_id == user_id,
        )
        .first()
        is not None
    )
    if not is_participant:
        raise HTTPException(status_code=404, detail="Η συνομιλία δεν βρέθηκε")
    return conv


@router.post("", response_model=GroupConversationOut, status_code=201)
def create_group_conversation(
    payload: GroupConversationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    unique_ids = {uid for uid in payload.participant_ids if uid != current_user.id}
    if len(unique_ids) < 1:
        raise HTTPException(status_code=400, detail="Χρειάζεται τουλάχιστον ένα ακόμα άτομο.")
    valid_users = db.query(User).filter(User.id.in_(unique_ids)).all()
    if len(valid_users) != len(unique_ids):
        raise HTTPException(status_code=404, detail="Κάποιος από τους επιλεγμένους δεν βρέθηκε.")

    conv = GroupConversation(name=payload.name, created_by=current_user.id)
    db.add(conv)
    db.commit()
    db.refresh(conv)

    for uid in unique_ids | {current_user.id}:
        db.add(GroupConversationParticipant(group_conversation_id=conv.id, user_id=uid))
    db.commit()

    return _group_conversation_out(db, conv, current_user.id)


@router.post("/team/{team_id}", response_model=GroupConversationOut)
def get_or_create_team_group_chat(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    member_ids = _team_member_user_ids(db, team_id)
    if current_user.id not in member_ids:
        raise HTTPException(status_code=403, detail="Δεν έχεις πρόσβαση σε αυτή την ομάδα.")

    existing = db.query(GroupConversation).filter(GroupConversation.related_team_id == team_id).first()
    if existing:
        # Συγχρονισμός συμμετεχόντων — αν προστέθηκε νέο μέλος στην ομάδα
        # από τότε που δημιουργήθηκε η συνομιλία, το προσθέτουμε τώρα.
        existing_participant_ids = {
            p.user_id
            for p in db.query(GroupConversationParticipant)
            .filter(GroupConversationParticipant.group_conversation_id == existing.id)
            .all()
        }
        newcomers = member_ids - existing_participant_ids
        for uid in newcomers:
            db.add(GroupConversationParticipant(group_conversation_id=existing.id, user_id=uid))
        if newcomers:
            db.commit()
        return _group_conversation_out(db, existing, current_user.id)

    conv = GroupConversation(related_team_id=team_id, created_by=current_user.id)
    db.add(conv)
    db.commit()
    db.refresh(conv)
    for uid in member_ids:
        db.add(GroupConversationParticipant(group_conversation_id=conv.id, user_id=uid))
    db.commit()
    return _group_conversation_out(db, conv, current_user.id)


@router.get("/{conversation_id}/messages", response_model=list[GroupMessageOut])
def get_group_messages(
    conversation_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    _assert_participant(db, conversation_id, current_user.id)
    messages = (
        db.query(GroupMessage)
        .filter(GroupMessage.group_conversation_id == conversation_id)
        .order_by(GroupMessage.created_at.asc())
        .all()
    )

    participant = (
        db.query(GroupConversationParticipant)
        .filter(
            GroupConversationParticipant.group_conversation_id == conversation_id,
            GroupConversationParticipant.user_id == current_user.id,
        )
        .first()
    )
    if participant:
        participant.last_read_at = datetime.utcnow()
        db.commit()

    results = []
    for m in messages:
        sender = db.query(User).filter(User.id == m.sender_id).first()
        results.append(
            GroupMessageOut(
                id=m.id,
                group_conversation_id=m.group_conversation_id,
                sender_id=m.sender_id,
                sender_name=sender.full_name if sender else None,
                sender_avatar=sender.avatar_path if sender else None,
                content=m.content,
                created_at=m.created_at,
            )
        )
    return results


@router.post("/{conversation_id}/messages", response_model=GroupMessageOut, status_code=201)
def send_group_message(
    conversation_id: str,
    payload: GroupMessageCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    _assert_participant(db, conversation_id, current_user.id)
    message = GroupMessage(
        group_conversation_id=conversation_id, sender_id=current_user.id, content=payload.content
    )
    db.add(message)
    db.commit()
    db.refresh(message)
    return GroupMessageOut(
        id=message.id,
        group_conversation_id=message.group_conversation_id,
        sender_id=message.sender_id,
        sender_name=current_user.full_name,
        sender_avatar=current_user.avatar_path,
        content=message.content,
        created_at=message.created_at,
    )


@router.get("/unread-count")
def get_group_unread_count(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    my_participations = (
        db.query(GroupConversationParticipant)
        .filter(GroupConversationParticipant.user_id == current_user.id)
        .all()
    )
    total = 0
    for p in my_participations:
        q = db.query(GroupMessage).filter(
            GroupMessage.group_conversation_id == p.group_conversation_id,
            GroupMessage.sender_id != current_user.id,
        )
        if p.last_read_at:
            q = q.filter(GroupMessage.created_at > p.last_read_at)
        total += q.count()
    return {"count": total}
