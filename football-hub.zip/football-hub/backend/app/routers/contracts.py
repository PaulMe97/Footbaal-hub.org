from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import ContractOffer, NotificationType, Player, Team, User, UserRole
from app.permissions import assert_team_access, require_write_access
from app.routers.messages import get_or_create_conversation
from app.schemas import ContractOfferCreate, ContractOfferOut, ContractOfferRespond
from app.services.notifications import notify

router = APIRouter(prefix="/api", tags=["contract-offers"])

OFFER_SENDER_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR, UserRole.SUPER_ADMIN, UserRole.ADMIN}


def _offer_out(db: Session, offer: ContractOffer) -> ContractOfferOut:
    team = db.query(Team).filter(Team.id == offer.team_id).first()
    sender = db.query(User).filter(User.id == offer.sender_id).first()
    return ContractOfferOut(
        id=offer.id,
        team_id=offer.team_id,
        team_name=team.name if team else None,
        sender_id=offer.sender_id,
        sender_name=sender.full_name if sender else None,
        player_user_id=offer.player_user_id,
        years=offer.years,
        salary_details=offer.salary_details,
        bonus_details=offer.bonus_details,
        status=offer.status,
        created_at=offer.created_at,
    )


@router.post("/teams/{team_id}/contract-offers", response_model=ContractOfferOut, status_code=201)
def send_contract_offer(
    team_id: str,
    payload: ContractOfferCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if current_user.role not in OFFER_SENDER_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Μόνο ο Πρόεδρος ή ο Τεχνικός Διευθυντής μπορούν να στείλουν προσφορά.",
        )
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    player_user = (
        db.query(User).filter(User.id == payload.player_user_id, User.role == UserRole.PLAYER).first()
    )
    if not player_user:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")

    offer = ContractOffer(
        team_id=team_id,
        sender_id=current_user.id,
        player_user_id=payload.player_user_id,
        years=payload.years,
        salary_details=payload.salary_details,
        bonus_details=payload.bonus_details,
    )
    db.add(offer)
    db.commit()
    db.refresh(offer)

    notify(
        db,
        NotificationType.CONTRACT_OFFER,
        title=f"Νέα προσφορά συμβολαίου — {team.name}",
        message=(
            f"{payload.years or '—'} χρόνια"
            + (f" · {payload.salary_details}" if payload.salary_details else "")
        ),
        related_entity_type="contract_offer",
        related_entity_id=offer.id,
        user_id=payload.player_user_id,
        related_team_id=team_id,
    )
    get_or_create_conversation(
        db,
        current_user.id,
        payload.player_user_id,
        related_team_id=team_id,
        context_label=f"Προσφορά συμβολαίου: {team.name}",
    )

    return _offer_out(db, offer)


@router.get("/contract-offers/mine", response_model=list[ContractOfferOut])
def list_my_offers(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    offers = (
        db.query(ContractOffer)
        .filter(ContractOffer.player_user_id == current_user.id)
        .order_by(ContractOffer.created_at.desc())
        .all()
    )
    return [_offer_out(db, o) for o in offers]


@router.get("/teams/{team_id}/contract-offers", response_model=list[ContractOfferOut])
def list_team_offers(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    offers = (
        db.query(ContractOffer)
        .filter(ContractOffer.team_id == team_id)
        .order_by(ContractOffer.created_at.desc())
        .all()
    )
    return [_offer_out(db, o) for o in offers]


@router.put("/contract-offers/{offer_id}/respond", response_model=ContractOfferOut)
def respond_to_offer(
    offer_id: str,
    payload: ContractOfferRespond,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    offer = db.query(ContractOffer).filter(ContractOffer.id == offer_id).first()
    if not offer or offer.player_user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    if offer.status != "pending":
        raise HTTPException(status_code=400, detail=f"Η προσφορά έχει ήδη απαντηθεί ({offer.status}).")

    if payload.accept:
        offer.status = "accepted"
        if current_user.linked_player_id:
            player = db.query(Player).filter(Player.id == current_user.linked_player_id).first()
            if player:
                player.current_team_id = offer.team_id
                player.transfer_status = "not_listed"
    else:
        offer.status = "rejected"

    offer.responded_at = datetime.utcnow()
    db.commit()
    db.refresh(offer)

    team = db.query(Team).filter(Team.id == offer.team_id).first()
    verb = "αποδέχτηκε" if payload.accept else "απέρριψε"
    notify(
        db,
        NotificationType.CONTRACT_OFFER,
        title=f"{current_user.full_name or current_user.username} {verb} την προσφορά",
        message=team.name if team else None,
        related_entity_type="contract_offer",
        related_entity_id=offer.id,
        user_id=offer.sender_id,
        related_team_id=offer.team_id,
    )
    return _offer_out(db, offer)
