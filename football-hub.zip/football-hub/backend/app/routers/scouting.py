from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.permissions import require_admin
from app.routers.messages import _conversation_out, get_or_create_conversation
from app.schemas import ConversationOut
from app.models import (
    Achievement,
    Country,
    Federation,
    LeagueGroup,
    LeagueLevel,
    Match,
    MatchPlayer,
    Player,
    PlayerAttributes,
    PlayerStatistics,
    Qualification,
    Region,
    ScoutingShortlistItem,
    StaffAssignmentOffer,
    Team,
    TeamStaffMember,
    User,
    UserRole,
    WorkExperience,
)
from app.schemas import (
    AchievementOut,
    CountryOut,
    FederationOut,
    LeagueGroupCreate,
    LeagueGroupOut,
    LeagueLevelCreate,
    LeagueLevelOut,
    PlayerAttributesOut,
    PlayerClaimResult,
    QualificationOut,
    RegionOut,
    ScoutingPlayerOut,
    ScoutingSeasonStats,
    ScoutingStaffOut,
    ScoutingTeamOut,
    StaffTeamHistoryEntry,
    TransferStatusSelfUpdate,
    WorkExperienceOut,
)

router = APIRouter(prefix="/api/scouting", tags=["scouting"])


# ---------------------------------------------------------------------------
# Reference hierarchy
# ---------------------------------------------------------------------------
@router.get("/countries", response_model=list[CountryOut])
def list_countries(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Country).order_by(Country.name).all()


@router.get("/regions", response_model=list[RegionOut])
def list_regions(
    country_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Region)
    if country_id:
        query = query.filter(Region.country_id == country_id)
    return query.order_by(Region.name).all()


@router.get("/federations", response_model=list[FederationOut])
def list_federations(
    region_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Federation)
    if region_id:
        query = query.filter(Federation.region_id == region_id)
    return query.order_by(Federation.name).all()


@router.get("/league-levels", response_model=list[LeagueLevelOut])
def list_league_levels(
    federation_id: str,
    applies_to: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(LeagueLevel).filter(LeagueLevel.federation_id == federation_id)
    if applies_to:
        query = query.filter(LeagueLevel.applies_to == applies_to)
    levels = query.order_by(LeagueLevel.order_index.asc(), LeagueLevel.name.asc()).all()
    results = []
    for lvl in levels:
        group_count = db.query(LeagueGroup).filter(LeagueGroup.league_level_id == lvl.id).count()
        results.append(
            LeagueLevelOut(
                id=lvl.id,
                federation_id=lvl.federation_id,
                name=lvl.name,
                order_index=lvl.order_index,
                applies_to=lvl.applies_to,
                group_count=group_count,
            )
        )
    return results


@router.post("/league-levels", response_model=LeagueLevelOut, status_code=201)
def create_league_level(
    payload: LeagueLevelCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)
):
    federation = db.query(Federation).filter(Federation.id == payload.federation_id).first()
    if not federation:
        raise HTTPException(status_code=404, detail="Η ΕΠΣ δεν βρέθηκε")
    if payload.applies_to not in {"regional", "academy"}:
        raise HTTPException(status_code=400, detail="Μη έγκυρη τιμή applies_to")
    level = LeagueLevel(
        federation_id=payload.federation_id,
        name=payload.name,
        order_index=payload.order_index,
        applies_to=payload.applies_to,
    )
    db.add(level)
    db.commit()
    db.refresh(level)
    return LeagueLevelOut(
        id=level.id,
        federation_id=level.federation_id,
        name=level.name,
        order_index=level.order_index,
        applies_to=level.applies_to,
        group_count=0,
    )


@router.delete("/league-levels/{level_id}", status_code=204)
def delete_league_level(
    level_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)
):
    level = db.query(LeagueLevel).filter(LeagueLevel.id == level_id).first()
    if not level:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.query(Team).filter(Team.league_level_id == level_id).update(
        {Team.league_level_id: None, Team.league_group_id: None}
    )
    db.query(LeagueGroup).filter(LeagueGroup.league_level_id == level_id).delete()
    db.delete(level)
    db.commit()
    return None


@router.get("/league-groups", response_model=list[LeagueGroupOut])
def list_league_groups(
    league_level_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    return (
        db.query(LeagueGroup)
        .filter(LeagueGroup.league_level_id == league_level_id)
        .order_by(LeagueGroup.name.asc())
        .all()
    )


@router.post("/league-groups", response_model=LeagueGroupOut, status_code=201)
def create_league_group(
    payload: LeagueGroupCreate, db: Session = Depends(get_db), current_user: User = Depends(require_admin)
):
    level = db.query(LeagueLevel).filter(LeagueLevel.id == payload.league_level_id).first()
    if not level:
        raise HTTPException(status_code=404, detail="Το επίπεδο δεν βρέθηκε")
    group = LeagueGroup(league_level_id=payload.league_level_id, name=payload.name)
    db.add(group)
    db.commit()
    db.refresh(group)
    return group


@router.delete("/league-groups/{group_id}", status_code=204)
def delete_league_group(
    group_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_admin)
):
    group = db.query(LeagueGroup).filter(LeagueGroup.id == group_id).first()
    if not group:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    db.query(Team).filter(Team.league_group_id == group_id).update({Team.league_group_id: None})
    db.delete(group)
    db.commit()
    return None


# ---------------------------------------------------------------------------
# Teams (global directory — ΟΛΕΣ οι δημόσιες ομάδες όλων των coaches)
# ---------------------------------------------------------------------------
@router.get("/teams", response_model=list[ScoutingTeamOut])
def list_scouting_teams(
    search: Optional[str] = None,
    country_id: Optional[str] = None,
    region_id: Optional[str] = None,
    federation_id: Optional[str] = None,
    league_tier: Optional[str] = None,
    league_level_id: Optional[str] = None,
    league_group_id: Optional[str] = None,
    academy_only: Optional[bool] = None,
    academy_age_group: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Team).filter(Team.is_public_scouting.is_(True))
    # Ήπιο gating κατά fake λογαριασμών: ομάδες Προέδρου/Τεχνικού Διευθυντή
    # που δεν έχουν επαληθεύσει τον σύλλογό τους μένουν κρυφές από το
    # Scouting Hub (βλ. User.club_verified). Δεν επηρεάζει head_coach κ.λπ.
    # ούτε ομάδες χωρίς owner (outerjoin + ρητός έλεγχος IS NULL, μιας που
    # NULL NOT IN (...) δεν είναι True σε SQL — θα έκρυβε λάθος τέτοιες
    # ομάδες αν βασιζόμασταν μόνο στο notin_).
    query = query.outerjoin(User, User.id == Team.owner_id).filter(
        or_(
            Team.owner_id.is_(None),
            User.role.notin_([UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR]),
            User.club_verified.is_(True),
        )
    )
    if search:
        query = query.filter(Team.name.ilike(f"%{search}%"))
    if country_id:
        query = query.filter(or_(Team.country_id == country_id, Team.country_id.is_(None)))
    if federation_id:
        query = query.filter(Team.federation_id == federation_id)
    elif region_id:
        fed_ids = [f.id for f in db.query(Federation.id).filter(Federation.region_id == region_id).all()]
        query = query.filter(Team.federation_id.in_(fed_ids))
    if league_tier:
        query = query.filter(Team.league_tier == league_tier)
    if academy_only is True:
        query = query.filter(Team.academy_age_group.isnot(None))
    elif academy_only is False:
        query = query.filter(Team.academy_age_group.is_(None))
    if academy_age_group:
        query = query.filter(Team.academy_age_group == academy_age_group)
    if league_group_id:
        query = query.filter(Team.league_group_id == league_group_id)
    elif league_level_id:
        query = query.filter(Team.league_level_id == league_level_id)

    teams = query.order_by(Team.name).all()
    results = []
    for t in teams:
        federation = (
            db.query(Federation).filter(Federation.id == t.federation_id).first()
            if t.federation_id
            else None
        )
        region = db.query(Region).filter(Region.id == federation.region_id).first() if federation else None
        country = db.query(Country).filter(Country.id == t.country_id).first() if t.country_id else None
        league_level = (
            db.query(LeagueLevel).filter(LeagueLevel.id == t.league_level_id).first()
            if t.league_level_id
            else None
        )
        league_group = (
            db.query(LeagueGroup).filter(LeagueGroup.id == t.league_group_id).first()
            if t.league_group_id
            else None
        )
        player_count = db.query(Player).filter(Player.current_team_id == t.id).count()
        results.append(
            ScoutingTeamOut(
                id=t.id,
                name=t.name,
                logo_path=t.logo_path,
                category=t.category,
                league_tier=t.league_tier,
                academy_age_group=t.academy_age_group,
                federation_name=federation.name if federation else None,
                league_level_name=league_level.name if league_level else None,
                league_group_name=league_group.name if league_group else None,
                region_name=region.name if region else None,
                country_name=country.name if country else None,
                player_count=player_count,
            )
        )
    return results


def _season_stats(db: Session, player_id: str) -> ScoutingSeasonStats:
    """Goals/assists/matches_played έρχονται από το PlayerStatistics — την ΙΔΙΑ
    πηγή που ενημερώνει το κουμπί '+1 Γκολ' και η φόρμα στατιστικών στη λίστα
    Παίκτες, ώστε ό,τι αλλαγή γίνεται εκεί να φαίνεται αμέσως και εδώ. Το
    avg_rating δεν αποθηκεύεται στο PlayerStatistics, οπότε υπολογίζεται από
    τα rating του Match Rating (MatchPlayer) του τρέχοντος έτους."""
    stats = (
        db.query(PlayerStatistics)
        .filter(PlayerStatistics.player_id == player_id, PlayerStatistics.season.is_(None))
        .first()
    )

    current_year = date.today().year
    rating_rows = (
        db.query(MatchPlayer.rating)
        .join(Match, MatchPlayer.match_id == Match.id)
        .filter(
            MatchPlayer.player_id == player_id,
            Match.date >= date(current_year, 1, 1),
            MatchPlayer.rating.isnot(None),
        )
        .all()
    )
    ratings = [r[0] for r in rating_rows]

    return ScoutingSeasonStats(
        matches_played=stats.matches_played if stats else 0,
        goals=stats.goals if stats else 0,
        assists=stats.assists if stats else 0,
        avg_rating=round(sum(ratings) / len(ratings), 1) if ratings else None,
    )


def _to_scouting_player(db: Session, player: Player, current_user: User) -> ScoutingPlayerOut:
    from app.routers.players import _calc_age  # επαναχρησιμοποίηση χωρίς διπλό κώδικα

    team = (
        db.query(Team).filter(Team.id == player.current_team_id).first()
        if player.current_team_id
        else None
    )
    attrs = db.query(PlayerAttributes).filter(PlayerAttributes.player_id == player.id).first()
    is_shortlisted = (
        db.query(ScoutingShortlistItem)
        .filter(
            ScoutingShortlistItem.user_id == current_user.id,
            ScoutingShortlistItem.player_id == player.id,
        )
        .first()
        is not None
    )
    return ScoutingPlayerOut(
        id=player.id,
        first_name=player.first_name,
        last_name=player.last_name,
        photo_path=player.photo_path,
        age=_calc_age(player.date_of_birth),
        nationality=player.nationality,
        position=player.position,
        secondary_position=player.secondary_position,
        height_cm=player.height_cm,
        weight_kg=player.weight_kg,
        preferred_foot=player.preferred_foot,
        team_id=team.id if team else None,
        team_name=team.name if team else None,
        league_tier=team.league_tier if team else None,
        transfer_status=player.transfer_status,
        transfer_notes=player.transfer_notes,
        attributes=PlayerAttributesOut.model_validate(attrs) if attrs else None,
        season_stats=_season_stats(db, player.id),
        is_shortlisted=is_shortlisted,
        linked_user_id=(
            db.query(User.id).filter(User.linked_player_id == player.id).scalar()
        ),
    )


@router.get("/teams/{team_id}/players", response_model=list[ScoutingPlayerOut])
def list_team_scouting_players(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    team = db.query(Team).filter(Team.id == team_id, Team.is_public_scouting.is_(True)).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    players = db.query(Player).filter(Player.current_team_id == team_id).all()
    return [_to_scouting_player(db, p, current_user) for p in players]


# ---------------------------------------------------------------------------
# Global player search — "transfer market"
# ---------------------------------------------------------------------------
@router.get("/players", response_model=list[ScoutingPlayerOut])
def search_scouting_players(
    search: Optional[str] = None,
    position: Optional[str] = None,
    transfer_status: Optional[str] = None,
    min_age: Optional[int] = None,
    max_age: Optional[int] = None,
    country_id: Optional[str] = None,
    region_id: Optional[str] = None,
    federation_id: Optional[str] = None,
    league_tier: Optional[str] = None,
    limit: int = Query(default=100, le=300),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = (
        db.query(Player)
        .join(Team, Player.current_team_id == Team.id)
        .filter(Team.is_public_scouting.is_(True))
    )
    if search:
        like = f"%{search}%"
        query = query.filter(or_(Player.first_name.ilike(like), Player.last_name.ilike(like)))
    if position:
        query = query.filter(Player.position == position)
    if transfer_status:
        query = query.filter(Player.transfer_status == transfer_status)
    if country_id:
        query = query.filter(or_(Team.country_id == country_id, Team.country_id.is_(None)))
    if federation_id:
        query = query.filter(Team.federation_id == federation_id)
    elif region_id:
        fed_ids = [f.id for f in db.query(Federation.id).filter(Federation.region_id == region_id).all()]
        query = query.filter(Team.federation_id.in_(fed_ids))
    if league_tier:
        query = query.filter(Team.league_tier == league_tier)

    players = query.limit(limit).all()
    results = [_to_scouting_player(db, p, current_user) for p in players]

    if min_age is not None:
        results = [r for r in results if r.age is not None and r.age >= min_age]
    if max_age is not None:
        results = [r for r in results if r.age is not None and r.age <= max_age]
    return results


# ---------------------------------------------------------------------------
# Shortlist
# ---------------------------------------------------------------------------
@router.get("/shortlist", response_model=list[ScoutingPlayerOut])
def get_shortlist(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    items = (
        db.query(ScoutingShortlistItem).filter(ScoutingShortlistItem.user_id == current_user.id).all()
    )
    players = []
    for item in items:
        player = db.query(Player).filter(Player.id == item.player_id).first()
        if player:
            players.append(_to_scouting_player(db, player, current_user))
    return players


@router.post("/shortlist/{player_id}", status_code=201)
def add_to_shortlist(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    existing = (
        db.query(ScoutingShortlistItem)
        .filter(
            ScoutingShortlistItem.user_id == current_user.id,
            ScoutingShortlistItem.player_id == player_id,
        )
        .first()
    )
    if existing:
        return {"message": "Υπάρχει ήδη στη λίστα"}
    db.add(ScoutingShortlistItem(user_id=current_user.id, player_id=player_id))
    db.commit()
    return {"message": "Προστέθηκε στη λίστα παρακολούθησης"}


@router.delete("/shortlist/{player_id}", status_code=204)
def remove_from_shortlist(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    item = (
        db.query(ScoutingShortlistItem)
        .filter(
            ScoutingShortlistItem.user_id == current_user.id,
            ScoutingShortlistItem.player_id == player_id,
        )
        .first()
    )
    if item:
        db.delete(item)
        db.commit()
    return None


# ---------------------------------------------------------------------------
# Self-service transfer status — μόνο για λογαριασμούς ρόλου Player,
# συνδεδεμένους με την πραγματική εγγραφή τους (linked_player_id).
# Μέχρι 3 αλλαγές ανά ομάδα/σεζόν, ώστε να μην γίνεται spam.
# ---------------------------------------------------------------------------
MAX_SELF_TRANSFER_CHANGES = 3
VALID_TRANSFER_STATUSES = {"not_listed", "free_agent", "for_transfer", "loan_listed"}


@router.put("/self/transfer-status", response_model=ScoutingPlayerOut)
def update_own_transfer_status(
    payload: TransferStatusSelfUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != UserRole.PLAYER:
        raise HTTPException(
            status_code=403, detail="Μόνο λογαριασμοί ρόλου Player μπορούν να το χρησιμοποιήσουν."
        )
    if not current_user.linked_player_id:
        raise HTTPException(
            status_code=400,
            detail="Ο λογαριασμός σου δεν έχει συνδεθεί ακόμα με εγγραφή παίκτη. Ζήτησε από τον "
            "προπονητή/admin σου να τον συνδέσει από τις Ρυθμίσεις.",
        )
    if payload.transfer_status not in VALID_TRANSFER_STATUSES:
        raise HTTPException(status_code=400, detail="Μη έγκυρη κατάσταση μεταγραφής")

    player = db.query(Player).filter(Player.id == current_user.linked_player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο συνδεδεμένος παίκτης δεν βρέθηκε")

    season_key = f"{player.current_team_id or 'no-team'}:{date.today().year}"
    if player.transfer_status_season_key != season_key:
        player.transfer_status_season_key = season_key
        player.transfer_status_change_count = 0

    if player.transfer_status_change_count >= MAX_SELF_TRANSFER_CHANGES:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Έχεις φτάσει το όριο των {MAX_SELF_TRANSFER_CHANGES} αλλαγών κατάστασης για τη "
                "φετινή σεζόν σε αυτή την ομάδα."
            ),
        )

    player.transfer_status = payload.transfer_status
    player.transfer_status_change_count += 1
    db.commit()
    db.refresh(player)
    return _to_scouting_player(db, player, current_user)


# ---------------------------------------------------------------------------
# Staff directory — προπονητές/τεχνικοί διευθυντές/scouts/αναλυτές που έχουν
# επιλέξει να είναι ορατοί.
# ---------------------------------------------------------------------------
def _to_scouting_staff(db: Session, user: User, current_user_id: str | None = None) -> ScoutingStaffOut:
    qualifications = db.query(Qualification).filter(Qualification.user_id == user.id).all()
    achievements = (
        db.query(Achievement).filter(Achievement.user_id == user.id).order_by(Achievement.year.desc()).all()
    )
    experience = (
        db.query(WorkExperience)
        .filter(WorkExperience.user_id == user.id)
        .order_by(WorkExperience.start_year.desc())
        .all()
    )
    staff_rows = db.query(TeamStaffMember).filter(TeamStaffMember.user_id == user.id).all()
    teams_history = []
    for row in staff_rows:
        team = db.query(Team).filter(Team.id == row.team_id).first()
        if team:
            teams_history.append(
                StaffTeamHistoryEntry(team_id=team.id, team_name=team.name, role_title=row.role_title)
            )
    # Ο owner μιας ομάδας θεωρείται επίσης staff της, ακόμα κι αν δεν έχει
    # προστεθεί ρητά στο TeamStaffMember.
    owned_teams = db.query(Team).filter(Team.owner_id == user.id).all()
    existing_team_ids = {t.team_id for t in teams_history}
    for t in owned_teams:
        if t.id not in existing_team_ids:
            role_label = {
                UserRole.PRESIDENT: "Πρόεδρος",
                UserRole.TECHNICAL_DIRECTOR: "Τεχνικός Διευθυντής",
                UserRole.HEAD_COACH: "Προπονητής",
                UserRole.ASSISTANT_COACH: "Βοηθός Προπονητή",
                UserRole.FITNESS_COACH: "Γυμναστής",
            }.get(user.role, None)
            teams_history.append(StaffTeamHistoryEntry(team_id=t.id, team_name=t.name, role_title=role_label))

    origin_federation = (
        db.query(Federation).filter(Federation.id == user.origin_federation_id).first()
        if user.origin_federation_id
        else None
    )
    desired_federation_ids = [x for x in (user.desired_federation_ids or "").split(",") if x]
    desired_federations = (
        db.query(Federation).filter(Federation.id.in_(desired_federation_ids)).all()
        if desired_federation_ids
        else []
    )

    has_pending_offer_from_me = False
    if current_user_id:
        has_pending_offer_from_me = (
            db.query(StaffAssignmentOffer)
            .filter(
                StaffAssignmentOffer.sender_id == current_user_id,
                StaffAssignmentOffer.recipient_user_id == user.id,
                StaffAssignmentOffer.status == "pending",
            )
            .first()
            is not None
        )

    return ScoutingStaffOut(
        id=user.id,
        full_name=user.full_name,
        role=user.role,
        avatar_path=user.avatar_path,
        bio=user.bio,
        staff_availability=user.staff_availability,
        desired_staff_role=user.desired_staff_role,
        origin_federation_id=user.origin_federation_id,
        origin_federation_name=origin_federation.name if origin_federation else None,
        desired_federation_ids=desired_federation_ids,
        desired_federation_names=[f.name for f in desired_federations],
        linkedin_url=user.linkedin_url if user.show_linkedin else None,
        verification_level=user.verification_level,
        qualifications=[QualificationOut.model_validate(q) for q in qualifications],
        achievements=[AchievementOut.model_validate(a) for a in achievements],
        experience=[WorkExperienceOut.model_validate(e) for e in experience],
        teams=teams_history,
        has_pending_offer_from_me=has_pending_offer_from_me,
    )


@router.get("/staff", response_model=list[ScoutingStaffOut])
def list_scouting_staff(
    search: Optional[str] = None,
    federation_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(User).filter(
        User.is_staff_visible.is_(True), User.role != UserRole.PLAYER
    )
    if search:
        query = query.filter(User.full_name.ilike(f"%{search}%"))
    if federation_id:
        query = query.filter(
            or_(
                User.origin_federation_id == federation_id,
                User.desired_federation_ids.like(f"%{federation_id}%"),
            )
        )
    users = query.order_by(User.full_name).all()
    return [_to_scouting_staff(db, u, current_user.id) for u in users]


@router.get("/staff/{user_id}", response_model=ScoutingStaffOut)
def get_scouting_staff(
    user_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    user = (
        db.query(User)
        .filter(User.id == user_id, User.is_staff_visible.is_(True), User.role != UserRole.PLAYER)
        .first()
    )
    if not user:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    return _to_scouting_staff(db, user, current_user.id)


@router.post("/staff/{user_id}/start-conversation", response_model=ConversationOut)
def start_conversation_with_scouting_staff(
    user_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    """Ξεκινά (ή ανοίγει την ήδη υπάρχουσα) συνομιλία με ένα στέλεχος που
    βρέθηκε μέσω του Scouting Hub — π.χ. ένας πρόεδρος/προπονητής θέλει να
    επικοινωνήσει με κάποιον που δηλώνει ότι ψάχνει για εργασία."""
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Δεν μπορείς να στείλεις μήνυμα στον εαυτό σου.")
    target = (
        db.query(User)
        .filter(User.id == user_id, User.is_staff_visible.is_(True), User.role != UserRole.PLAYER)
        .first()
    )
    if not target:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")

    conversation = get_or_create_conversation(
        db,
        current_user.id,
        user_id,
        context_label="Επικοινωνία μέσω Scouting Hub",
    )
    return _conversation_out(db, conversation, current_user.id)


# ---------------------------------------------------------------------------
# Αντιστοίχηση παίκτη — ο ίδιος ο παίκτης βρίσκει την εγγραφή του (που
# έφτιαξε κάποιος coach) στο Scouting Hub και τη συνδέει με τον λογαριασμό
# του, χωρίς να χρειάζεται admin.
# ---------------------------------------------------------------------------
@router.post("/players/{player_id}/claim", response_model=PlayerClaimResult)
def claim_player(
    player_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    if current_user.role != UserRole.PLAYER:
        raise HTTPException(
            status_code=403, detail="Μόνο λογαριασμοί ρόλου Player μπορούν να κάνουν αντιστοίχηση."
        )
    if current_user.linked_player_id:
        raise HTTPException(status_code=400, detail="Ο λογαριασμός σου είναι ήδη συνδεδεμένος με παίκτη.")

    player = db.query(Player).filter(Player.id == player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")

    already_linked = db.query(User).filter(User.linked_player_id == player_id).first()
    if already_linked:
        raise HTTPException(
            status_code=400, detail="Αυτή η εγγραφή παίκτη είναι ήδη συνδεδεμένη με άλλον λογαριασμό."
        )

    current_user.linked_player_id = player.id
    db.commit()
    return PlayerClaimResult(
        message=f"Ο λογαριασμός σου συνδέθηκε με τον {player.first_name} {player.last_name}.",
        player_id=player.id,
    )
