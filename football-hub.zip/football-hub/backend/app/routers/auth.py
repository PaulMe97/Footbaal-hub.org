import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.auth import (
    create_access_token,
    get_current_user,
    hash_password,
    verify_password,
)
from app.database import get_db
from app.models import NotificationType, PasswordResetToken, Player, TeamAccessGrant, TeamStaffMember, User, UserRole
from app.permissions import require_admin
from app.services.greek_validators import validate_afm
from app.services.notifications import notify_admins
from app.services import security_service
from app.services import captcha_service
from app.services import email_service
from app.schemas import (
    AdminCreateUserRequest,
    ForgotPasswordRequest,
    ForgotPasswordResponse,
    LinkPlayerAccountRequest,
    LoginRequest,
    PasswordChangeRequest,
    ResetPasswordRequest,
    Token,
    UserActiveStatusUpdate,
    UserCreate,
    UserMeOut,
    UserOut,
    UserRoleUpdate,
    UserUpdate,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])

SELF_REGISTRABLE_ROLES = {
    UserRole.PRESIDENT,
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
    UserRole.FITNESS_COACH,
    UserRole.ANALYST,
    UserRole.SCOUT,
    UserRole.PLAYER,
}

# Ρόλοι που μπορούν να έχουν πολλαπλές ομάδες με το μεγαλύτερο όριο (βλ.
# permissions.MAX_TEAMS_BY_ROLE) — χρειάζονται ΑΦΜ ομάδας στην εγγραφή.
CLUB_LEADERSHIP_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}


@router.post("/register", response_model=Token, status_code=201)
def register(payload: UserCreate, request: Request, db: Session = Depends(get_db)):
    ip = security_service.get_client_ip(
        dict(request.headers), request.client.host if request.client else ""
    )

    # Honeypot: αόρατο πεδίο στη φόρμα — αν γεμίσει, πρόκειται σχεδόν
    # σίγουρα για bot. Απορρίπτουμε σιωπηλά (γενικό μήνυμα, χωρίς να
    # αποκαλύψουμε τον μηχανισμό) και καταγράφουμε το IP.
    if payload.honeypot:
        security_service.record_security_event(
            db, ip, "known_attack_tool", detail="honeypot field filled on registration", endpoint="/api/auth/register"
        )
        raise HTTPException(status_code=400, detail="Η εγγραφή απέτυχε.")

    if captcha_service.is_configured(db):
        if not payload.captcha_token or not captcha_service.verify_captcha(db, payload.captcha_token, ip):
            raise HTTPException(status_code=400, detail="Αποτυχία επαλήθευσης CAPTCHA — δοκίμασε ξανά.")

    if not payload.gdpr_consent:
        raise HTTPException(
            status_code=400,
            detail="Πρέπει να αποδεχτείς την επεξεργασία προσωπικών δεδομένων (GDPR) για να "
            "δημιουργήσεις λογαριασμό.",
        )

    existing = (
        db.query(User)
        .filter(or_(User.email == payload.email, User.username == payload.username))
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Το email ή το username χρησιμοποιείται ήδη")

    # Ο πρώτος χρήστης του συστήματος γίνεται αυτόματα Super Admin.
    is_first_user = db.query(User).count() == 0

    if is_first_user:
        role = UserRole.SUPER_ADMIN
    elif payload.role in SELF_REGISTRABLE_ROLES:
        role = payload.role
    else:
        role = UserRole.PLAYER

    # Πρόεδρος/Τεχνικός Διευθυντής μπορούν να δημιουργήσουν πολλαπλές
    # ομάδες με μεγαλύτερο όριο (βλ. permissions.MAX_TEAMS_BY_ROLE) — για
    # να αποθαρρύνουμε fake λογαριασμούς που θα δημιουργούσαν ψεύτικες
    # ομάδες, απαιτούμε έγκυρο ΑΦΜ ομάδας (μορφολογικός έλεγχος, όχι
    # επιβεβαίωση πραγματικής ύπαρξης — αυτή γίνεται αργότερα με έγγραφο).
    if role in CLUB_LEADERSHIP_ROLES and not validate_afm(payload.tax_id):
        raise HTTPException(
            status_code=400,
            detail="Χρειάζεται έγκυρο ΑΦΜ ομάδας (9 ψηφία) για εγγραφή ως Πρόεδρος ή Τεχνικός Διευθυντής.",
        )

    user = User(
        email=payload.email,
        username=payload.username,
        full_name=payload.full_name,
        hashed_password=hash_password(payload.password),
        role=role,
        team_tax_id=payload.tax_id if role in CLUB_LEADERSHIP_ROLES else None,
        gdpr_consent_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Πρόεδρος/Τεχνικός Διευθυντής: ο admin πρέπει να τους εγκρίνει
    # προσωπικά πριν μπορέσουν να δημιουργήσουν ομάδα (βλ.
    # permissions.assert_leadership_approved) — ενημέρωσέ τον αμέσως.
    if role in CLUB_LEADERSHIP_ROLES:
        role_label = "Πρόεδρος" if role == UserRole.PRESIDENT else "Τεχνικός Διευθυντής"
        notify_admins(
            db,
            NotificationType.NEW_LEADERSHIP_REGISTRATION,
            title=f"Νέα εγγραφή {role_label}: {user.full_name or user.username}",
            message=(
                f"Email: {user.email} — Χρειάζεται επαλήθευση πριν μπορέσει να δημιουργήσει ομάδα. "
                "Ρυθμίσεις → Διαχείριση Χρηστών."
            ),
            related_entity_type="user",
            related_entity_id=user.id,
        )

    # Έξυπνη αυτόματη σύνδεση: αν κάποιος δηλώσει "Παίκτης" στην εγγραφή και
    # το ονοματεπώνυμό του ταιριάζει με έναν ή περισσότερους παίκτες στο
    # ρόστερ, τον συνδέουμε αυτόματα ώστε να μπορεί κατευθείαν να
    # διαχειριστεί το δικό του transfer status. Αν υπάρχουν συνωνυμίες
    # (παραπάνω από ένα ταίριασμα ονόματος), χρησιμοποιούμε την ημερομηνία
    # γέννησης που έδωσε στην εγγραφή για να ξεχωρίσουμε ποιος είναι ο
    # σωστός. Σε περίπτωση αμφιβολίας δεν γίνεται καμία σύνδεση — ο admin
    # μπορεί πάντα να τη ρυθμίσει χειροκίνητα από τις Ρυθμίσεις.
    if role == UserRole.PLAYER and payload.full_name:
        normalized_name = " ".join(payload.full_name.strip().lower().split())
        linked_player_ids = {u.linked_player_id for u in db.query(User).filter(User.linked_player_id.isnot(None))}
        name_candidates = [
            p
            for p in db.query(Player).all()
            if p.id not in linked_player_ids
            and " ".join(f"{p.first_name} {p.last_name}".strip().lower().split()) == normalized_name
        ]

        candidates = name_candidates
        if len(name_candidates) > 1 and payload.date_of_birth:
            candidates = [p for p in name_candidates if p.date_of_birth == payload.date_of_birth]

        if len(candidates) == 1:
            user.linked_player_id = candidates[0].id
            db.commit()
            db.refresh(user)

    token = create_access_token({"sub": user.id})

    # Email καλωσορίσματος — best-effort, ποτέ δεν μπλοκάρει την εγγραφή αν
    # αποτύχει η αποστολή (π.χ. δεν έχει ρυθμιστεί SMTP ακόμα).
    try:
        email_service.send_welcome_email(db, user.email, user.full_name or user.username)
    except Exception:
        pass

    return Token(access_token=token, user=UserOut.model_validate(user))


@router.post("/admin/create-user", response_model=UserOut, status_code=201)
def admin_create_user(
    payload: AdminCreateUserRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Ο admin δημιουργεί έναν λογαριασμό απευθείας — δίνει ο ίδιος τα
    στοιχεία σύνδεσης στον χρήστη. Σε αντίθεση με τη δημόσια εγγραφή:
      - Δεν χρειάζεται έγκυρο ΑΦΜ για Πρόεδρο/Τεχνικό Διευθυντή (ο admin
        παρακάμπτει τον έλεγχο, τον επιβεβαιώνει προσωπικά αν χρειαστεί).
      - Ο λογαριασμός θεωρείται αυτόματα εγκεκριμένος (leadership_approved),
        αφού τον δημιουργεί ο ίδιος ο admin — δεν χρειάζεται δεύτερο βήμα
        έγκρισης.
      - Δεν υπάρχει honeypot/CAPTCHA/GDPR-consent έλεγχος (αυτά αφορούν την
        δημόσια, ανώνυμη φόρμα εγγραφής, όχι εσωτερική admin ενέργεια).
    """
    existing = (
        db.query(User)
        .filter(or_(User.email == payload.email, User.username == payload.username))
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Το email ή το username χρησιμοποιείται ήδη")

    user = User(
        email=payload.email,
        username=payload.username,
        full_name=payload.full_name,
        hashed_password=hash_password(payload.password),
        role=payload.role,
        team_tax_id=payload.tax_id if payload.role in CLUB_LEADERSHIP_ROLES else None,
        phone=payload.phone,
        date_of_birth=payload.date_of_birth,
        leadership_approved=payload.role in CLUB_LEADERSHIP_ROLES,
        gdpr_consent_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    try:
        email_service.send_welcome_email(db, user.email, user.full_name or user.username)
    except Exception:
        pass

    return user


@router.post("/login", response_model=Token)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    ip = security_service.get_client_ip(
        dict(request.headers), request.client.host if request.client else ""
    )
    user = (
        db.query(User)
        .filter(
            or_(
                User.username == payload.username_or_email,
                User.email == payload.username_or_email,
            )
        )
        .first()
    )
    if not user or not verify_password(payload.password, user.hashed_password):
        security_service.record_login_attempt(db, ip, payload.username_or_email, success=False)
        raise HTTPException(status_code=401, detail="Λάθος στοιχεία σύνδεσης")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Ο λογαριασμός είναι ανενεργός")

    security_service.record_login_attempt(db, ip, payload.username_or_email, success=True)
    token = create_access_token({"sub": user.id})
    return Token(access_token=token, user=UserOut.model_validate(user))


@router.get("/me", response_model=UserMeOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.put("/me", response_model=UserMeOut)
def update_me(
    payload: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    data = payload.model_dump(exclude_unset=True)
    if "email" in data and data["email"] != current_user.email:
        existing = db.query(User).filter(User.email == data["email"]).first()
        if existing:
            raise HTTPException(status_code=400, detail="Το email χρησιμοποιείται ήδη")
    for field, value in data.items():
        setattr(current_user, field, value)
    db.commit()
    db.refresh(current_user)
    return current_user


@router.post("/change-password", status_code=204)
def change_password(
    payload: PasswordChangeRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not verify_password(payload.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Ο τρέχων κωδικός δεν είναι σωστός")
    current_user.hashed_password = hash_password(payload.new_password)
    db.commit()
    return None


@router.post("/forgot-password", response_model=ForgotPasswordResponse)
def forgot_password(payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    """Δημιουργεί reset token. Αν είναι ρυθμισμένο SMTP (Ρυθμίσεις → admin),
    στέλνεται πραγματικό email με τον κωδικό και ΔΕΝ επιστρέφεται στην
    απόκριση — ασφαλές για production με πραγματικούς χρήστες. Αν δεν έχει
    ρυθμιστεί SMTP, ο κωδικός τυπώνεται στο console του backend ΚΑΙ
    επιστρέφεται απευθείας στην απόκριση — αποδεκτό ΜΟΝΟ για local
    single-admin χρήση χωρίς SMTP."""
    user = (
        db.query(User)
        .filter(
            or_(
                User.username == payload.username_or_email,
                User.email == payload.username_or_email,
            )
        )
        .first()
    )
    # Πάντα ίδιο μήνυμα ώστε να μη γίνεται user enumeration μέσω response.
    generic_message = (
        "Αν το username/email υπάρχει, δημιουργήθηκε κωδικός επαναφοράς."
    )
    if not user:
        return ForgotPasswordResponse(message=generic_message, reset_token=None)

    token = secrets.token_urlsafe(24)
    reset = PasswordResetToken(
        user_id=user.id,
        token=token,
        expires_at=datetime.utcnow() + timedelta(hours=1),
    )
    db.add(reset)
    db.commit()

    if email_service.is_configured(db):
        email_service.send_password_reset_email(db, user.email, user.full_name or user.username, token)
        return ForgotPasswordResponse(message=generic_message, reset_token=None)

    # Dev fallback — μόνο όταν δεν έχει ρυθμιστεί SMTP.
    print(f"\n[FootballHub] Password reset code for '{user.username}': {token}\n")

    return ForgotPasswordResponse(
        message=(
            "Δημιουργήθηκε κωδικός επαναφοράς. Δεν υπάρχει ρυθμισμένο email σε αυτή την "
            "εγκατάσταση, οπότε ο κωδικός εμφανίζεται παρακάτω (τυπώθηκε επίσης στο "
            "terminal του backend). Ισχύει για 1 ώρα."
        ),
        reset_token=token,
    )


@router.post("/reset-password", status_code=204)
def reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    reset = (
        db.query(PasswordResetToken)
        .filter(PasswordResetToken.token == payload.token, PasswordResetToken.used.is_(False))
        .first()
    )
    if not reset or reset.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Μη έγκυρος ή ληγμένος κωδικός επαναφοράς")

    user = db.query(User).filter(User.id == reset.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")

    user.hashed_password = hash_password(payload.new_password)
    reset.used = True
    db.commit()
    return None


@router.get("/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    """Λίστα όλων των χρηστών — μόνο για Admin/Super Admin, ώστε να μπορούν
    να διαχειρίζονται ρόλους (π.χ. να δώσουν πρόσβαση εγγραφής σε βοηθό
    προπονητή που έκανε self-registration ως Player)."""
    return db.query(User).order_by(User.created_at).all()


@router.put("/users/{user_id}/role", response_model=UserOut)
def update_user_role(
    user_id: str,
    payload: UserRoleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    if user.id == current_user.id and payload.role != UserRole.SUPER_ADMIN:
        raise HTTPException(
            status_code=400, detail="Δεν μπορείς να αφαιρέσεις τα δικά σου δικαιώματα admin."
        )

    old_role_value = user.role.value if hasattr(user.role, "value") else user.role
    new_role_value = payload.role.value if hasattr(payload.role, "value") else payload.role
    user.role = payload.role

    # Συγχρονισμός: αν αυτός ο χρήστης έχει role_title σε κάποια ομάδα που
    # τυχαίνει να είναι ΑΚΡΙΒΩΣ ο ΠΡΟΗΓΟΥΜΕΝΟΣ system ρόλος του (π.χ.
    # "head_coach" — ελεύθερο κείμενο που όμως γράφτηκε έτσι κατά την
    # έγκριση πρόσβασης ή την πρόσληψη), το ενημερώνουμε ώστε να
    # αντανακλά τον νέο του ρόλο — αλλιώς παραμένει "κολλημένος" σε
    # έναν ρόλο που δεν έχει πια. Δεν αγγίζουμε role_title με ελεύθερο,
    # προσαρμοσμένο κείμενο (π.χ. "Αναλυτής Απόδοσης Β' ομάδας").
    if old_role_value != new_role_value:
        for g in db.query(TeamAccessGrant).filter(TeamAccessGrant.user_id == user_id).all():
            if g.role_title == old_role_value:
                g.role_title = new_role_value
        for m in db.query(TeamStaffMember).filter(TeamStaffMember.user_id == user_id).all():
            if m.role_title == old_role_value:
                m.role_title = new_role_value

    db.commit()
    db.refresh(user)
    return user


@router.put("/users/{user_id}/active-status", response_model=UserOut)
def update_user_active_status(
    user_id: str,
    payload: UserActiveStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Ενεργοποίηση/απενεργοποίηση λογαριασμού — π.χ. ύποπτος/ανεπιθύμητος
    χρήστης, χωρίς να χρειάζεται διαγραφή. Ένας ανενεργός χρήστης δεν
    μπορεί να συνδεθεί (βλ. auth.get_current_user)."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    if user.id == current_user.id and not payload.is_active:
        raise HTTPException(status_code=400, detail="Δεν μπορείς να απενεργοποιήσεις τον δικό σου λογαριασμό.")
    user.is_active = payload.is_active
    db.commit()
    db.refresh(user)
    return user


@router.put("/users/{user_id}/approve-leadership", response_model=UserOut)
def approve_leadership(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Ο admin επιβεβαιώνει προσωπικά (εκτός εφαρμογής, π.χ. μέσω email)
    την ταυτότητα ενός Προέδρου/Τεχνικού Διευθυντή — μόνο μετά από αυτό
    μπορεί να δημιουργήσει ομάδα (βλ. permissions.assert_leadership_approved)."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    user.leadership_approved = True
    db.commit()
    db.refresh(user)
    return user


@router.get("/admin-contact")
def get_admin_contact(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Emails των Admin/Super Admin — ώστε ένας μη εγκεκριμένος Πρόεδρος/
    Τεχνικός Διευθυντής να ξέρει με ποιον να επικοινωνήσει για επαλήθευση."""
    admins = db.query(User).filter(User.role.in_([UserRole.SUPER_ADMIN, UserRole.ADMIN])).all()
    return {"emails": [a.email for a in admins]}


@router.put("/users/{user_id}/link-player", response_model=UserOut)
def link_user_to_player(
    user_id: str,
    payload: LinkPlayerAccountRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Συνδέει έναν λογαριασμό ρόλου Player με την πραγματική εγγραφή του στο
    ρόστερ, ώστε να μπορεί να διαχειριστεί τη δική του κατάσταση μεταγραφής."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Ο χρήστης δεν βρέθηκε")
    player = db.query(Player).filter(Player.id == payload.player_id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    user.linked_player_id = player.id
    db.commit()
    db.refresh(user)
    return user
