from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import BannedIP, SecurityEvent, User
from app.permissions import require_admin
from app.schemas import BanIPRequest, BannedIPOut, SecurityEventOut
from app.services import security_service

router = APIRouter(prefix="/api/security", tags=["security"])


def _to_banned_out(db: Session, row: BannedIP) -> BannedIPOut:
    banner = db.query(User).filter(User.id == row.banned_by).first() if row.banned_by else None
    return BannedIPOut(
        id=row.id,
        ip_address=row.ip_address,
        reason=row.reason,
        strike_count=row.strike_count,
        is_permanent=row.is_permanent,
        banned_at=row.banned_at,
        banned_until=row.banned_until,
        banned_by=row.banned_by,
        banned_by_name=(banner.full_name or banner.username) if banner else None,
    )


@router.get("/banned-ips", response_model=list[BannedIPOut])
def list_banned_ips(db: Session = Depends(get_db), current_user: User = Depends(require_admin)):
    rows = db.query(BannedIP).order_by(BannedIP.banned_at.desc()).all()
    return [_to_banned_out(db, r) for r in rows]


@router.post("/banned-ips", response_model=BannedIPOut, status_code=201)
def ban_ip_manually(
    payload: BanIPRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    row = security_service.ban_ip(
        db,
        payload.ip_address,
        reason=payload.reason,
        permanent=payload.permanent,
        banned_by=current_user.id,
    )
    return _to_banned_out(db, row)


@router.delete("/banned-ips/{ip_address}", status_code=204)
def unban_ip(
    ip_address: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    removed = security_service.unban_ip(db, ip_address)
    if not removed:
        raise HTTPException(status_code=404, detail="Το IP δεν βρέθηκε στη λίστα μπλοκαρισμένων")


@router.get("/events", response_model=list[SecurityEventOut])
def list_security_events(
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    capped_limit = min(max(limit, 1), 500)
    rows = db.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(capped_limit).all()
    return [SecurityEventOut.model_validate(r) for r in rows]
