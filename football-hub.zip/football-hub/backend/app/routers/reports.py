from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import AIReport, Match, Player, Team, User
from app.permissions import owned_team_ids
from app.schemas import AIReportOut

router = APIRouter(prefix="/api/ai-reports", tags=["reports"])


@router.get("", response_model=list[AIReportOut])
def list_ai_reports(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    owned_ids = owned_team_ids(db, current_user)
    reports = db.query(AIReport).order_by(AIReport.created_at.desc()).all()
    if owned_ids is None:
        return reports
    if not owned_ids:
        return []
    visible = []
    for r in reports:
        if r.match_id:
            match = db.query(Match).filter(Match.id == r.match_id).first()
            if match and (match.home_team_id in owned_ids or match.away_team_id in owned_ids):
                visible.append(r)
        elif r.team_id and r.team_id in owned_ids:
            visible.append(r)
        elif r.player_id:
            player = db.query(Player).filter(Player.id == r.player_id).first()
            if player and player.current_team_id in owned_ids:
                visible.append(r)
    return visible


@router.get("/{report_id}/context")
def get_report_context(
    report_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)
):
    """Επιστρέφει ανθρώπινα αναγνώσιμο τίτλο για ένα report (ποιος αγώνας/παίκτης/ομάδα)."""
    report = db.query(AIReport).filter(AIReport.id == report_id).first()
    if not report:
        return {"title": "—"}
    if report.match_id:
        match = db.query(Match).filter(Match.id == report.match_id).first()
        if match:
            return {"title": f"Αγώνας {match.date}"}
    if report.player_id:
        player = db.query(Player).filter(Player.id == report.player_id).first()
        if player:
            return {"title": f"{player.first_name} {player.last_name}"}
    if report.team_id:
        team = db.query(Team).filter(Team.id == report.team_id).first()
        if team:
            return {"title": team.name}
    return {"title": "—"}
