from datetime import date as date_type
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.permissions import assert_team_id_access, owned_team_ids, require_write_access
from app.database import get_db
from app.models import CalendarEvent, Match, Team, TrainingSession, User
from app.schemas import CalendarEventCreate, CalendarEventOut, CalendarEventUpdate

router = APIRouter(prefix="/api/calendar", tags=["calendar"])


@router.get("/events", response_model=list[CalendarEventOut])
def list_events(
    start: Optional[date_type] = None,
    end: Optional[date_type] = None,
    team_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Ενοποιημένη λίστα events: αγώνες + προπονήσεις (auto) + custom events."""
    events: list[CalendarEventOut] = []
    teams_by_id = {t.id: t.name for t in db.query(Team).all()}
    owned_ids = owned_team_ids(db, current_user)
    if owned_ids is not None and not owned_ids:
        return []

    # Matches
    match_query = db.query(Match)
    if owned_ids is not None:
        match_query = match_query.filter(
            (Match.home_team_id.in_(owned_ids)) | (Match.away_team_id.in_(owned_ids))
        )
    if start:
        match_query = match_query.filter(Match.date >= start)
    if end:
        match_query = match_query.filter(Match.date <= end)
    if team_id:
        match_query = match_query.filter(
            (Match.home_team_id == team_id) | (Match.away_team_id == team_id)
        )
    for m in match_query.all():
        home = m.home_team_name_external or teams_by_id.get(m.home_team_id, "—")
        away = m.away_team_name_external or teams_by_id.get(m.away_team_id, "—")
        events.append(
            CalendarEventOut(
                id=f"match-{m.id}",
                title=f"{home} vs {away}",
                event_type="match",
                date=m.date,
                time=m.time,
                team_id=m.home_team_id,
                team_name=teams_by_id.get(m.home_team_id),
                related_entity_type="match",
                related_entity_id=m.id,
                status=m.status.value if hasattr(m.status, "value") else m.status,
                editable=False,
            )
        )

    # Trainings
    training_query = db.query(TrainingSession)
    if owned_ids is not None:
        training_query = training_query.filter(TrainingSession.team_id.in_(owned_ids))
    if start:
        training_query = training_query.filter(TrainingSession.date >= start)
    if end:
        training_query = training_query.filter(TrainingSession.date <= end)
    if team_id:
        training_query = training_query.filter(TrainingSession.team_id == team_id)
    for tr in training_query.all():
        events.append(
            CalendarEventOut(
                id=f"training-{tr.id}",
                title=f"Προπόνηση — {teams_by_id.get(tr.team_id, '—')}",
                event_type="training",
                date=tr.date,
                time=tr.time,
                team_id=tr.team_id,
                team_name=teams_by_id.get(tr.team_id),
                related_entity_type="training",
                related_entity_id=tr.id,
                editable=False,
            )
        )

    # Custom events
    custom_query = db.query(CalendarEvent)
    if owned_ids is not None:
        custom_query = custom_query.filter(
            (CalendarEvent.team_id.in_(owned_ids)) | (CalendarEvent.team_id.is_(None))
        )
    if start:
        custom_query = custom_query.filter(CalendarEvent.date >= start)
    if end:
        custom_query = custom_query.filter(CalendarEvent.date <= end)
    if team_id:
        custom_query = custom_query.filter(CalendarEvent.team_id == team_id)
    for ce in custom_query.all():
        events.append(
            CalendarEventOut(
                id=f"event-{ce.id}",
                title=ce.title,
                event_type=ce.event_type,
                date=ce.date,
                time=ce.time,
                team_id=ce.team_id,
                team_name=teams_by_id.get(ce.team_id) if ce.team_id else None,
                related_entity_type="calendar_event",
                related_entity_id=ce.id,
                notes=ce.notes,
                editable=True,
            )
        )

    events.sort(key=lambda e: (e.date, e.time or ""))
    return events


@router.post("/events", response_model=CalendarEventOut, status_code=201)
def create_event(
    payload: CalendarEventCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    if payload.team_id:
        assert_team_id_access(db, current_user, payload.team_id, "Η ομάδα δεν βρέθηκε")
    event = CalendarEvent(**payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    team_name = None
    if event.team_id:
        team = db.query(Team).filter(Team.id == event.team_id).first()
        team_name = team.name if team else None
    return CalendarEventOut(
        id=f"event-{event.id}",
        title=event.title,
        event_type=event.event_type,
        date=event.date,
        time=event.time,
        team_id=event.team_id,
        team_name=team_name,
        related_entity_type="calendar_event",
        related_entity_id=event.id,
        notes=event.notes,
        editable=True,
    )


@router.put("/events/{event_id}", response_model=CalendarEventOut)
def update_event(
    event_id: str,
    payload: CalendarEventUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    event = db.query(CalendarEvent).filter(CalendarEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Το event δεν βρέθηκε")
    if event.team_id:
        assert_team_id_access(db, current_user, event.team_id, "Το event δεν βρέθηκε")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(event, field, value)
    db.commit()
    db.refresh(event)
    team_name = None
    if event.team_id:
        team = db.query(Team).filter(Team.id == event.team_id).first()
        team_name = team.name if team else None
    return CalendarEventOut(
        id=f"event-{event.id}",
        title=event.title,
        event_type=event.event_type,
        date=event.date,
        time=event.time,
        team_id=event.team_id,
        team_name=team_name,
        related_entity_type="calendar_event",
        related_entity_id=event.id,
        notes=event.notes,
        editable=True,
    )


@router.delete("/events/{event_id}", status_code=204)
def delete_event(
    event_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    event = db.query(CalendarEvent).filter(CalendarEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Το event δεν βρέθηκε")
    if event.team_id:
        assert_team_id_access(db, current_user, event.team_id, "Το event δεν βρέθηκε")
    db.delete(event)
    db.commit()
    return None
