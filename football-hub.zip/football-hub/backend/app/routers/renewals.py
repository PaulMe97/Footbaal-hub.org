from datetime import date, datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import NotificationType, Player, RenewalRequest, Team, TeamAccessGrant, User, UserRole
from app.permissions import assert_team_access, require_write_access
from app.schemas import ClubRenewalResolveRequest, RenewalDecisionRequest, RenewalRequestOut
from app.services.notifications import notify

router = APIRouter(prefix="/api/renewals", tags=["renewals"])

HOLD_PERIOD_DAYS = 30
RENEWAL_CUTOFF_MONTH = 6
RENEWAL_CUTOFF_DAY = 30

# Ρόλοι που συμμετέχουν στη ροή ανανέωσης — ρητά ΟΧΙ ο Πρόεδρος (δεν
# ανανεώνει "συμβόλαιο" με τον ίδιο τον σύλλογο) και ΟΧΙ ο Player εδώ (οι
# παίκτες χειρίζονται ξεχωριστά, μέσω current_team_id).
RENEWAL_STAFF_ROLES = {
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
    UserRole.FITNESS_COACH,
    UserRole.ANALYST,
    UserRole.SCOUT,
}


def get_season_labels(today: date) -> Optional[tuple]:
    """Επιστρέφει (τρέχουσα_σεζόν, επόμενη_σεζόν) αν έχουμε περάσει τις 30
    Ιουνίου φέτος (π.χ. στις 30/6/2026: ('2025-2026', '2026-2027')).
    Πριν τις 30/6 κάθε χρόνο, επιστρέφει None — δεν είναι ακόμα η ώρα."""
    cutoff = date(today.year, RENEWAL_CUTOFF_MONTH, RENEWAL_CUTOFF_DAY)
    if today < cutoff:
        return None
    current_season = f"{today.year - 1}-{today.year}"
    next_season = f"{today.year}-{today.year + 1}"
    return current_season, next_season


def _apply_release(db: Session, renewal: RenewalRequest) -> None:
    """Το άτομο μένει ελεύθερο από αυτή την ομάδα: αφαιρείται η πρόσβαση
    διαχείρισης (coach/staff) ή γίνεται ελεύθερος παίκτης (player)."""
    user = db.query(User).filter(User.id == renewal.user_id).first()
    if not user:
        return
    if user.role == UserRole.PLAYER and user.linked_player_id:
        player = db.query(Player).filter(Player.id == user.linked_player_id).first()
        if player and player.current_team_id == renewal.team_id:
            player.current_team_id = None
            player.transfer_status = "free_agent"
    else:
        grant = (
            db.query(TeamAccessGrant)
            .filter(TeamAccessGrant.team_id == renewal.team_id, TeamAccessGrant.user_id == renewal.user_id)
            .first()
        )
        if grant:
            db.delete(grant)


def _expire_stale_hold(db: Session, renewal: RenewalRequest) -> None:
    if renewal.status == "on_hold" and renewal.hold_deadline and renewal.hold_deadline < datetime.utcnow():
        _apply_release(db, renewal)
        renewal.status = "released"
        renewal.resolved_at = datetime.utcnow()
        db.commit()


def _renewal_out(db: Session, r: RenewalRequest) -> RenewalRequestOut:
    team = db.query(Team).filter(Team.id == r.team_id).first()
    user = db.query(User).filter(User.id == r.user_id).first()
    return RenewalRequestOut(
        id=r.id,
        team_id=r.team_id,
        team_name=team.name if team else None,
        user_id=r.user_id,
        user_name=user.full_name if user else None,
        current_season=r.current_season,
        next_season=r.next_season,
        status=r.status,
        hold_reason=r.hold_reason,
        hold_deadline=r.hold_deadline,
        created_at=r.created_at,
    )


def _get_or_create_for_team(
    db: Session, team_id: str, user_id: str, current_season: str, next_season: str
) -> RenewalRequest:
    existing = (
        db.query(RenewalRequest)
        .filter(
            RenewalRequest.team_id == team_id,
            RenewalRequest.user_id == user_id,
            RenewalRequest.current_season == current_season,
        )
        .first()
    )
    if existing:
        return existing
    renewal = RenewalRequest(
        team_id=team_id, user_id=user_id, current_season=current_season, next_season=next_season
    )
    db.add(renewal)
    db.commit()
    db.refresh(renewal)
    return renewal


def _get_team_leadership(db: Session, team_id: str) -> list:
    """Επιστρέφει τους χρήστες President/Technical Director που σχετίζονται
    με μια ομάδα (owner ή access grant) — για στοχευμένες ειδοποιήσεις."""
    leaders = []
    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id:
        owner = db.query(User).filter(User.id == team.owner_id).first()
        if owner and owner.role in {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}:
            leaders.append(owner)
    grantees = (
        db.query(User)
        .join(TeamAccessGrant, TeamAccessGrant.user_id == User.id)
        .filter(TeamAccessGrant.team_id == team_id, User.role.in_([UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR]))
        .all()
    )
    for u in grantees:
        if u.id not in {l.id for l in leaders}:
            leaders.append(u)
    return leaders


@router.get("/pending", response_model=list[RenewalRequestOut])
def get_pending_renewals(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """Καλείται με το που μπαίνει ο χρήστης — δημιουργεί (αν χρειάζεται) και
    επιστρέφει τις εκκρεμείς ερωτήσεις ανανέωσης σεζόν του."""
    if current_user.role == UserRole.PRESIDENT:
        return []

    seasons = get_season_labels(date.today())

    if seasons:
        current_season, next_season = seasons
        if current_user.role == UserRole.PLAYER:
            if current_user.linked_player_id:
                player = db.query(Player).filter(Player.id == current_user.linked_player_id).first()
                if player and player.current_team_id:
                    _get_or_create_for_team(
                        db, player.current_team_id, current_user.id, current_season, next_season
                    )
        elif current_user.role in RENEWAL_STAFF_ROLES:
            grants = db.query(TeamAccessGrant).filter(TeamAccessGrant.user_id == current_user.id).all()
            for g in grants:
                _get_or_create_for_team(db, g.team_id, current_user.id, current_season, next_season)

    all_mine = db.query(RenewalRequest).filter(RenewalRequest.user_id == current_user.id).all()
    for r in all_mine:
        _expire_stale_hold(db, r)

    pending = [r for r in all_mine if r.status in {"pending", "on_hold"}]
    return [_renewal_out(db, r) for r in pending]


@router.post("/{renewal_id}/respond", response_model=RenewalRequestOut)
def respond_to_renewal(
    renewal_id: str,
    payload: RenewalDecisionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    renewal = db.query(RenewalRequest).filter(RenewalRequest.id == renewal_id).first()
    if not renewal or renewal.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    _expire_stale_hold(db, renewal)
    if renewal.status not in {"pending", "on_hold"}:
        raise HTTPException(status_code=400, detail=f"Η αίτηση έχει ήδη οριστικοποιηθεί ({renewal.status}).")

    if payload.decision == "accept":
        renewal.status = "accepted"
        renewal.resolved_at = datetime.utcnow()
        renewal.resolved_by = current_user.id
    elif payload.decision == "reject":
        _apply_release(db, renewal)
        renewal.status = "released"
        renewal.resolved_at = datetime.utcnow()
        renewal.resolved_by = current_user.id
    elif payload.decision == "hold":
        if not payload.hold_reason or not payload.hold_reason.strip():
            raise HTTPException(status_code=400, detail="Χρειάζεται αιτιολογία για αναμονή.")
        renewal.status = "on_hold"
        renewal.hold_reason = payload.hold_reason.strip()
        if not renewal.hold_started_at:
            renewal.hold_started_at = datetime.utcnow()
            renewal.hold_deadline = datetime.utcnow() + timedelta(days=HOLD_PERIOD_DAYS)

        team = db.query(Team).filter(Team.id == renewal.team_id).first()
        team_name = team.name if team else "—"

        # Υπενθύμιση στον ίδιο τον χρήστη ότι έχει εκκρεμή απόφαση
        notify(
            db,
            NotificationType.RENEWAL_ON_HOLD,
            title=f"Εκκρεμεί απόφαση ανανέωσης — {team_name}",
            message=f"Έβαλες σε αναμονή την ανανέωση για τη σεζόν {renewal.next_season}. "
            f"Χρειάζεται τελική απάντηση μέσα σε {HOLD_PERIOD_DAYS} μέρες.",
            related_entity_type="renewal_request",
            related_entity_id=renewal.id,
            user_id=current_user.id,
            related_team_id=renewal.team_id,
        )
        # Ειδοποίηση στον Πρόεδρο/Τεχνικό Διευθυντή της ομάδας
        for leader in _get_team_leadership(db, renewal.team_id):
            notify(
                db,
                NotificationType.RENEWAL_ON_HOLD,
                title=f"{current_user.full_name or current_user.username} έβαλε σε αναμονή",
                message=f"Αιτιολογία: {renewal.hold_reason}",
                related_entity_type="renewal_request",
                related_entity_id=renewal.id,
                user_id=leader.id,
                related_team_id=renewal.team_id,
            )
    else:
        raise HTTPException(status_code=400, detail="Μη έγκυρη επιλογή (accept | hold | reject)")

    db.commit()
    db.refresh(renewal)
    return _renewal_out(db, renewal)


# ---------------------------------------------------------------------------
# Πλευρά συλλόγου — ο owner της ομάδας βλέπει/απαντάει στις αιτήσεις σε
# αναμονή (30ήμερη προθεσμία και για τις 2 πλευρές)
# ---------------------------------------------------------------------------
@router.get("/teams/{team_id}", response_model=list[RenewalRequestOut])
def list_team_renewals(
    team_id: str, db: Session = Depends(get_db), current_user: User = Depends(require_write_access)
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)
    renewals = db.query(RenewalRequest).filter(RenewalRequest.team_id == team_id).all()
    for r in renewals:
        _expire_stale_hold(db, r)
    return [_renewal_out(db, r) for r in renewals]


@router.put("/teams/{team_id}/{renewal_id}/resolve", response_model=RenewalRequestOut)
def resolve_team_renewal(
    team_id: str,
    renewal_id: str,
    payload: ClubRenewalResolveRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_write_access),
):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")
    assert_team_access(db, current_user, team)

    renewal = (
        db.query(RenewalRequest)
        .filter(RenewalRequest.id == renewal_id, RenewalRequest.team_id == team_id)
        .first()
    )
    if not renewal:
        raise HTTPException(status_code=404, detail="Δεν βρέθηκε")
    _expire_stale_hold(db, renewal)
    if renewal.status != "on_hold":
        raise HTTPException(
            status_code=400,
            detail="Ο σύλλογος μπορεί να απαντήσει μόνο σε αίτηση που βρίσκεται σε αναμονή.",
        )

    if payload.action == "confirm":
        renewal.status = "accepted"
    elif payload.action == "release":
        _apply_release(db, renewal)
        renewal.status = "released"
    else:
        raise HTTPException(status_code=400, detail="Μη έγκυρη ενέργεια (confirm | release)")

    renewal.resolved_at = datetime.utcnow()
    renewal.resolved_by = current_user.id
    db.commit()
    db.refresh(renewal)
    return _renewal_out(db, renewal)
