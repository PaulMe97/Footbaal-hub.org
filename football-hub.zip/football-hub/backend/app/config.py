"""
Κεντρικές ρυθμίσεις της εφαρμογής.
Όλες οι τιμές διαβάζονται από environment variables (βλ. .env.example).
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# --- Database -----------------------------------------------------------
# Για local development χρησιμοποιούμε SQLite by default.
# Σε production, όρισε DATABASE_URL="postgresql://user:pass@host:5432/dbname"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'footballhub.db'}")

# --- Auth -----------------------------------------------------------------
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-secret-change-me-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "60"))
JWT_REFRESH_EXPIRE_DAYS = int(os.getenv("JWT_REFRESH_EXPIRE_DAYS", "30"))

# --- Encryption at rest -----------------------------------------------------
# Κλειδί συμμετρικής κρυπτογράφησης (Fernet) για ευαίσθητα πεδία που
# αποθηκεύονται στη βάση (π.χ. ΑΦΜ, κλειδιά API τρίτων προγραμμάτων). Σε
# production ΠΡΕΠΕΙ να οριστεί ρητά μέσω .env (ENCRYPTION_KEY) και να ΜΗΝ
# αλλάξει ποτέ μετά — αν αλλάξει, τα ήδη κρυπτογραφημένα δεδομένα δεν θα
# μπορούν πλέον να αποκρυπτογραφηθούν. Το auto-generated fallback εδώ είναι
# ΜΟΝΟ για local development.
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "")

# --- File storage ---------------------------------------------------------
STORAGE_DIR = Path(os.getenv("STORAGE_DIR", BASE_DIR / "app" / "storage"))
PLAYER_PHOTOS_DIR = STORAGE_DIR / "players"
TEAM_LOGOS_DIR = STORAGE_DIR / "teams"
DOCUMENTS_DIR = STORAGE_DIR / "documents"
REPORTS_DIR = STORAGE_DIR / "reports"
AVATARS_DIR = STORAGE_DIR / "avatars"
SCOUT_REPORT_PHOTOS_DIR = STORAGE_DIR / "scout_reports"
MAX_UPLOAD_SIZE_MB = int(os.getenv("MAX_UPLOAD_SIZE_MB", "5"))

# --- Video Editing (ενότητα ανάλυσης βίντεο, τύπου Hudl Studio) ---
MAX_VIDEO_DURATION_SECONDS = int(os.getenv("MAX_VIDEO_DURATION_SECONDS", str(15 * 60)))
MAX_VIDEO_UPLOAD_SIZE_MB = int(os.getenv("MAX_VIDEO_UPLOAD_SIZE_MB", "2000"))
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}

# Ξεχωριστός, ΜΗ δημόσιος φάκελος για ευαίσθητα έγγραφα ταυτοποίησης
# (ταυτότητα, πτυχία). Βρίσκεται ΕΚΤΟΣ του STORAGE_DIR που είναι mounted
# δημόσια στο /media — δεν είναι ποτέ προσβάσιμο μέσω URL, μόνο μέσω
# αυθεντικοποιημένου endpoint που ελέγχει δικαιώματα πριν σερβίρει το αρχείο.
VERIFICATION_DOCS_DIR = Path(os.getenv("VERIFICATION_DOCS_DIR", BASE_DIR / "app" / "private_storage"))

for d in (PLAYER_PHOTOS_DIR, TEAM_LOGOS_DIR, DOCUMENTS_DIR, REPORTS_DIR, AVATARS_DIR, SCOUT_REPORT_PHOTOS_DIR, VERIFICATION_DOCS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# --- AI service layer -------------------------------------------------------
# Modular: αν δεν υπάρχει API key, το AI service επιστρέφει clear "not configured"
# αντί να επινοεί δεδομένα.
AI_PROVIDER = os.getenv("AI_PROVIDER", "anthropic")  # "anthropic" | "openai" | "none"
AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "claude-sonnet-4-6")

# --- CORS -------------------------------------------------------------------
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")
