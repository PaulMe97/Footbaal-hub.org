"""
Βασικό σύστημα δικαιωμάτων (RBAC) βάσει ρόλου χρήστη.

STAFF_ROLES έχουν πλήρη πρόσβαση εγγραφής (δημιουργία/επεξεργασία/διαγραφή).
Οι υπόλοιποι ρόλοι (Analyst, Scout, Player) έχουν πρόσβαση μόνο για ανάγνωση
σε αυτή τη φάση — δεν υπάρχει ακόμα εξατομικευμένο scoping (π.χ. ένας Player
να βλέπει μόνο τα δικά του δεδομένα).
"""
from typing import Optional

from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.models import Player, Team, TeamAccessGrant, User, UserRole

STAFF_ROLES = {
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRESIDENT,
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
}


def require_write_access(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in STAFF_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Ο ρόλος σου δεν επιτρέπει αυτή την ενέργεια. Χρειάζεσαι ρόλο "
            "Admin, Πρόεδρο, Τεχνικό Διευθυντή, Head Coach ή Assistant Coach.",
        )
    return current_user


def require_admin(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in {UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        raise HTTPException(
            status_code=403, detail="Απαιτείται ρόλος Admin ή Super Admin για αυτή την ενέργεια."
        )
    return current_user


# Πρόεδρος/Τεχνικός Διευθυντής/Head Coach — μόνο αυτοί μπορούν να
# δημιουργήσουν/επεξεργαστούν/διαγράψουν εγγραφές στην ενότητα
# "Τραυματισμοί / Απουσίες" (βλ. routers/absences.py).
ABSENCE_EDITOR_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR, UserRole.HEAD_COACH}


def require_absence_editor(current_user: User = Depends(get_current_user)) -> User:
    if sees_all_data(current_user):
        return current_user
    if current_user.role not in ABSENCE_EDITOR_ROLES:
        raise HTTPException(
            status_code=403,
            detail="Μόνο Πρόεδρος, Τεχνικός Διευθυντής ή Head Coach μπορούν να επεξεργαστούν απουσίες.",
        )
    return current_user


# ---------------------------------------------------------------------------
# Data isolation ανά coach — κάθε coach (μη Super Admin) βλέπει μόνο τις δικές
# του ομάδες και τα δεδομένα που συνδέονται με αυτές.
# ---------------------------------------------------------------------------
MAX_TEAMS_PER_COACH = 3
# Ανδρικό/επαγγελματικό/ερασιτεχνικό τμήμα (league_tier != "academy") — έως 1.
# Ακαδημίες (league_tier == "academy") — έως 2. Σύνολο έως 3 ομάδες.
MAX_SENIOR_TEAMS_PER_COACH = 1
MAX_ACADEMY_TEAMS_PER_COACH = 2
# Ο Πρόεδρος και ο Τεχνικός Διευθυντής συνήθως εποπτεύουν ολόκληρο τον
# σύλλογο (π.χ. 1 ανδρικό + πολλαπλές ακαδημίες), οπότε παίρνουν μεγαλύτερο
# όριο ομάδων — χωρίς τον typed διαχωρισμό senior/academy των coaches.
MAX_TEAMS_BY_ROLE = {
    UserRole.PRESIDENT: 8,
    UserRole.TECHNICAL_DIRECTOR: 8,
}


def sees_all_data(user: User) -> bool:
    return user.role == UserRole.SUPER_ADMIN


def owned_team_ids(db: Session, user: User) -> Optional[set]:
    """None σημαίνει 'χωρίς φίλτρο' (Super Admin, βλέπει τα πάντα).
    Διαφορετικά, επιστρέφει το σύνολο των team.id στα οποία ο χρήστης έχει
    πρόσβαση — είτε γιατί τις κατέχει (owner_id), είτε γιατί του έχει δοθεί
    πρόσβαση διαχείρισης (TeamAccessGrant, π.χ. coach σε σύλλογο άλλου
    προέδρου μετά από αποδεκτή αίτηση), είτε γιατί είναι ο ίδιος παίκτης σε
    αυτή την ομάδα (linked_player_id -> current_team_id) — σε αυτή την
    τελευταία περίπτωση η πρόσβαση είναι ΜΟΝΟ για ανάγνωση, αφού όλα τα
    endpoints εγγραφής ελέγχουν ξεχωριστά STAFF_ROLES μέσω του
    require_write_access."""
    if sees_all_data(user):
        return None
    owned = {r[0] for r in db.query(Team.id).filter(Team.owner_id == user.id).all()}
    granted = {r[0] for r in db.query(TeamAccessGrant.team_id).filter(TeamAccessGrant.user_id == user.id).all()}
    result = owned | granted
    if user.role == UserRole.PLAYER and user.linked_player_id:
        player = db.query(Player).filter(Player.id == user.linked_player_id).first()
        if player and player.current_team_id:
            result.add(player.current_team_id)
    return result


def assert_team_access(db: Session, user: User, team) -> None:
    if sees_all_data(user):
        return
    if team is None or team.id not in (owned_team_ids(db, user) or set()):
        raise HTTPException(status_code=404, detail="Η ομάδα δεν βρέθηκε")


def check_team_limit(db: Session, user: User, league_tier: Optional[str] = None) -> None:
    if sees_all_data(user):
        return
    if user.role in MAX_TEAMS_BY_ROLE:
        # Πρόεδρος/Τεχνικός Διευθυντής: γενικό όριο, χωρίς typed διαχωρισμό.
        max_teams = MAX_TEAMS_BY_ROLE[user.role]
        count = db.query(Team).filter(Team.owner_id == user.id).count()
        if count >= max_teams:
            raise HTTPException(
                status_code=400,
                detail=f"Έχεις φτάσει το όριο των {max_teams} ομάδων για τον λογαριασμό σου.",
            )
        return

    # Λοιπό επιτελείο (π.χ. Head Coach): έως 1 ανδρικό/επαγγελματικό ή
    # ερασιτεχνικό τμήμα + έως 2 ακαδημίες — σύνολο έως 3 ομάδες.
    owned = db.query(Team).filter(Team.owner_id == user.id).all()
    is_new_academy = league_tier == "academy"
    if is_new_academy:
        academy_count = sum(1 for t in owned if t.league_tier == "academy")
        if academy_count >= MAX_ACADEMY_TEAMS_PER_COACH:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Έχεις φτάσει το όριο των {MAX_ACADEMY_TEAMS_PER_COACH} ακαδημιών "
                    "για τον λογαριασμό σου."
                ),
            )
    else:
        senior_count = sum(1 for t in owned if t.league_tier != "academy")
        if senior_count >= MAX_SENIOR_TEAMS_PER_COACH:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Μπορείς να δημιουργήσεις μόνο {MAX_SENIOR_TEAMS_PER_COACH} ανδρικό/"
                    "επαγγελματικό ή ερασιτεχνικό τμήμα. Χρησιμοποίησε \"Ακαδημία\" για τις "
                    "υπόλοιπες ηλικιακές κατηγορίες."
                ),
            )


def assert_no_duplicate_head_coach(db: Session, team_id: str, incoming_user_id: str, incoming_role) -> None:
    """Μια ομάδα δεν μπορεί να έχει πάνω από έναν Προπονητή (Head Coach) —
    ούτε ως owner ούτε μέσω TeamAccessGrant. Καλείται ΠΡΙΝ δοθεί νέα
    πρόσβαση/ρόλος σε κάποιον, ώστε να μπλοκάρεται ο δεύτερος."""
    role_value = incoming_role.value if hasattr(incoming_role, "value") else incoming_role
    if role_value != UserRole.HEAD_COACH.value:
        return

    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id and team.owner_id != incoming_user_id:
        owner = db.query(User).filter(User.id == team.owner_id).first()
        if owner and owner.role == UserRole.HEAD_COACH:
            raise HTTPException(
                status_code=400,
                detail="Η ομάδα έχει ήδη Προπονητή — δεν επιτρέπεται δεύτερος στην ίδια ομάδα.",
            )

    existing = (
        db.query(TeamAccessGrant)
        .join(User, User.id == TeamAccessGrant.user_id)
        .filter(
            TeamAccessGrant.team_id == team_id,
            TeamAccessGrant.user_id != incoming_user_id,
            User.role == UserRole.HEAD_COACH,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail="Η ομάδα έχει ήδη Προπονητή — δεν επιτρέπεται δεύτερος στην ίδια ομάδα.",
        )


def assert_player_access(db: Session, user: User, player) -> None:
    if sees_all_data(user):
        return
    if player is None or not player.current_team_id:
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")
    if player.current_team_id not in (owned_team_ids(db, user) or set()):
        raise HTTPException(status_code=404, detail="Ο παίκτης δεν βρέθηκε")


def assert_team_id_access(db: Session, user: User, team_id, not_found_message: str = "Δεν βρέθηκε") -> None:
    """Γενικό helper: ελέγχει ότι το team_id (αν υπάρχει) είναι προσβάσιμο
    από τον χρήστη. Χρησιμοποιείται για TrainingSession.team_id,
    Match.home/away_team_id, TacticalBoard.team_id κ.λπ."""
    if sees_all_data(user):
        return
    if not team_id or team_id not in (owned_team_ids(db, user) or set()):
        raise HTTPException(status_code=404, detail=not_found_message)


def assert_match_access(db: Session, user: User, match) -> None:
    """Ένας αγώνας είναι ορατός αν ο χρήστης κατέχει την γηπεδούχο Ή την
    φιλοξενούμενη ομάδα (τουλάχιστον μία από τις δύο, αφού η άλλη μπορεί να
    είναι εξωτερική/άγνωστη ομάδα)."""
    if sees_all_data(user):
        return
    if match is None:
        raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")
    owned = owned_team_ids(db, user) or set()
    if match.home_team_id in owned or match.away_team_id in owned:
        return
    raise HTTPException(status_code=404, detail="Ο αγώνας δεν βρέθηκε")


# ---------------------------------------------------------------------------
# Ιεραρχία έγκρισης αιτήσεων — ποιος ρόλος μπορεί να απαντήσει στην αίτηση
# ποιου ρόλου, μέσα στο πλαίσιο μιας συγκεκριμένης ομάδας.
# ---------------------------------------------------------------------------
def get_team_member_roles(db: Session, team_id: str) -> set:
    """Οι ρόλοι όλων όσων έχουν πρόσβαση σε μια ομάδα σήμερα (owner + όσοι
    έχουν TeamAccessGrant) — χρησιμοποιείται για τα fallback κανόνες
    έγκρισης (π.χ. 'αν δεν υπάρχει πρόεδρος ακόμα')."""
    roles = set()
    team = db.query(Team).filter(Team.id == team_id).first()
    if team and team.owner_id:
        owner = db.query(User).filter(User.id == team.owner_id).first()
        if owner:
            roles.add(owner.role)
    grantees = (
        db.query(User)
        .join(TeamAccessGrant, TeamAccessGrant.user_id == User.id)
        .filter(TeamAccessGrant.team_id == team_id)
        .all()
    )
    for u in grantees:
        roles.add(u.role)
    return roles


def get_allowed_approver_roles(applicant_role: UserRole, team_member_roles: set) -> set:
    """Επιστρέφει το σύνολο ρόλων που επιτρέπεται να εγκρίνουν/απορρίψουν
    μια αίτηση από κάποιον με ρόλο applicant_role, δεδομένης της τρέχουσας
    σύνθεσης του επιτελείου της ομάδας (team_member_roles)."""
    if applicant_role == UserRole.PLAYER:
        return {UserRole.HEAD_COACH, UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}
    if applicant_role == UserRole.HEAD_COACH:
        return {UserRole.TECHNICAL_DIRECTOR, UserRole.PRESIDENT}
    if applicant_role in {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}:
        # Αν υπάρχει ήδη Πρόεδρος/Τεχνικός Διευθυντής στην ομάδα (π.χ. ο
        # ένας από τους δύο έχει ήδη ενταχθεί), μόνο αυτός/αυτοί εγκρίνουν
        # τον άλλον. Αλλιώς — π.χ. η ομάδα δημιουργήθηκε απευθείας από
        # Head Coach χωρίς ηγεσία συλλόγου ακόμα — εγκρίνει όποιος ήδη τη
        # διαχειρίζεται σήμερα (ο owner ή όσοι έχουν access grant), ώστε ο
        # Πρόεδρος/Τεχνικός Διευθυντής να μπορεί να ενταχθεί σε ομάδα που
        # δεν δημιούργησε ο ίδιος.
        existing_leaders = team_member_roles & {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}
        if existing_leaders:
            return existing_leaders
        return team_member_roles or {UserRole.HEAD_COACH}
    if applicant_role == UserRole.ASSISTANT_COACH:
        return {UserRole.TECHNICAL_DIRECTOR, UserRole.PRESIDENT, UserRole.HEAD_COACH}
    if applicant_role in {UserRole.ANALYST, UserRole.SCOUT, UserRole.FITNESS_COACH}:
        if UserRole.TECHNICAL_DIRECTOR in team_member_roles or UserRole.PRESIDENT in team_member_roles:
            return {UserRole.TECHNICAL_DIRECTOR, UserRole.PRESIDENT}
        return {UserRole.HEAD_COACH}
    return {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}


def can_respond_to_request(db: Session, responder: User, applicant_role: UserRole, team_id: str) -> bool:
    if responder.role in {UserRole.SUPER_ADMIN, UserRole.ADMIN}:
        return True
    team_member_roles = get_team_member_roles(db, team_id)
    allowed = get_allowed_approver_roles(applicant_role, team_member_roles)
    return responder.role in allowed


def assert_can_respond_to_request(db: Session, responder: User, applicant_role: UserRole, team_id: str) -> None:
    """Ελέγχει ότι ο responder επιτρέπεται να απαντήσει (αποδοχή/απόρριψη) σε
    αίτηση από applicant_role, σύμφωνα με την ιεραρχία έγκρισης. Ο Admin/
    Super Admin μπορεί πάντα να επέμβει."""
    if can_respond_to_request(db, responder, applicant_role, team_id):
        return
    team_member_roles = get_team_member_roles(db, team_id)
    allowed = get_allowed_approver_roles(applicant_role, team_member_roles)
    allowed_labels = ", ".join(sorted(r.value for r in allowed))
    raise HTTPException(
        status_code=403,
        detail=f"Μόνο οι ρόλοι [{allowed_labels}] μπορούν να απαντήσουν σε αυτή την αίτηση.",
    )


# ---------------------------------------------------------------------------
# Επίπεδα επαλήθευσης (grey/blue/green) — όριο ταυτόχρονων ομάδων (grants)
# ανάλογα με την πιστότητα, ώστε ένας μη επαληθευμένος λογαριασμός να μην
# μπορεί να αποκτήσει πρόσβαση σε πολλές ομάδες ταυτόχρονα.
# ---------------------------------------------------------------------------
# Όριο ταυτόχρονων ομάδων (μέσω TeamAccessGrant) ανά ΡΟΛΟ *και* επίπεδο
# επαλήθευσης — η πιστότητα αυξάνει πόσες από τις επιτρεπόμενες ομάδες του
# ρόλου μπορεί να χρησιμοποιήσει κάποιος, αλλά ΠΟΤΕ δεν ξεπερνά το βασικό
# όριο του ρόλου του (π.χ. ένας Προπονητής έχει πάντα ανώτατο όριο 3 ομάδες,
# ακόμα κι αν είναι πλήρως επαληθευμένος — μόνο Πρόεδρος/Τεχνικός Διευθυντής
# φτάνουν έως 8).
GRANT_LIMITS_BY_ROLE_AND_LEVEL = {
    UserRole.HEAD_COACH: {0: 1, 1: 2, 2: 3},
    UserRole.ASSISTANT_COACH: {0: 1, 1: 2, 2: 3},
    UserRole.FITNESS_COACH: {0: 1, 1: 2, 2: 3},
    UserRole.ANALYST: {0: 1, 1: 2, 2: 3},
    UserRole.SCOUT: {0: 1, 1: 2, 2: 3},
    UserRole.TECHNICAL_DIRECTOR: {0: 1, 1: 3, 2: 8},
    UserRole.PRESIDENT: {0: 1, 1: 3, 2: 8},
}
VERIFICATION_LEVEL_LABELS = {0: "grey", 1: "blue", 2: "green"}


def get_max_grants_for_verification(user: User) -> int:
    role_limits = GRANT_LIMITS_BY_ROLE_AND_LEVEL.get(user.role, {0: 1, 1: 2, 2: 3})
    return role_limits.get(user.verification_level, 1)


def assert_can_receive_new_grant(db: Session, applicant: User) -> None:
    """Ελέγχει ότι ο υποψήφιος δεν έχει ήδη φτάσει το όριο ταυτόχρονων ομάδων
    που επιτρέπει το επίπεδο επαλήθευσής του, πριν του δοθεί νέο
    TeamAccessGrant."""
    max_grants = get_max_grants_for_verification(applicant)
    current_count = (
        db.query(TeamAccessGrant).filter(TeamAccessGrant.user_id == applicant.id).count()
    )
    if current_count >= max_grants:
        level_label = VERIFICATION_LEVEL_LABELS.get(applicant.verification_level, "grey")
        raise HTTPException(
            status_code=400,
            detail=(
                f"Ο/Η {applicant.full_name or applicant.username} έχει ήδη {current_count} ομάδες — "
                f"το επίπεδο επαλήθευσής του/της ({level_label}) επιτρέπει έως {max_grants}. "
                "Χρειάζεται να ανεβάσει περισσότερα έγγραφα επαλήθευσης για μεγαλύτερο όριο."
            ),
        )


# Ενότητα Scout Reports — scouts/αναλυτές/τεχνικοί διευθυντές/πρόεδροι/
# προπονητές/βοηθοί προπονητών μπορούν να δημιουργήσουν/δουν αναφορές.
SCOUT_REPORT_ROLES = {
    UserRole.SUPER_ADMIN,
    UserRole.ADMIN,
    UserRole.PRESIDENT,
    UserRole.TECHNICAL_DIRECTOR,
    UserRole.HEAD_COACH,
    UserRole.ASSISTANT_COACH,
    UserRole.ANALYST,
    UserRole.SCOUT,
}


def require_scout_report_access(current_user: User = Depends(get_current_user)) -> User:
    if current_user.role not in SCOUT_REPORT_ROLES:
        raise HTTPException(
            status_code=403,
            detail=(
                "Μόνο Scout, Αναλυτής, Πρόεδρος, Τεχνικός Διευθυντής, Head Coach ή "
                "Assistant Coach έχουν πρόσβαση στα Scout Reports."
            ),
        )
    return current_user


def _can_edit_scout_report(current_user: User, report: "ScoutReport") -> bool:
    if sees_all_data(current_user):
        return True
    if report.created_by == current_user.id:
        return True
    return current_user.role in {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR, UserRole.HEAD_COACH}


def assert_scout_report_access(current_user: User, report: "ScoutReport") -> None:
    """Επεξεργασία/διαγραφή: ο δημιουργός της αναφοράς, ή η ηγεσία του
    συλλόγου (Πρόεδρος/Τεχνικός Διευθυντής/Head Coach) για εποπτεία."""
    if not _can_edit_scout_report(current_user, report):
        raise HTTPException(
            status_code=403,
            detail="Μόνο ο δημιουργός της αναφοράς ή η ηγεσία του συλλόγου μπορούν να την επεξεργαστούν.",
        )


# Πρόεδρος/Τεχνικός Διευθυντής — δεν μπορούν να δημιουργήσουν ΚΑΜΙΑ ομάδα
# μέχρι ο admin να τους εγκρίνει προσωπικά (βλ. User.leadership_approved).
LEADERSHIP_APPROVAL_ROLES = {UserRole.PRESIDENT, UserRole.TECHNICAL_DIRECTOR}


def assert_leadership_approved(current_user: User) -> None:
    if sees_all_data(current_user):
        return
    if current_user.role in LEADERSHIP_APPROVAL_ROLES and not current_user.leadership_approved:
        raise HTTPException(
            status_code=403,
            detail=(
                "Ο λογαριασμός σου δεν έχει επαληθευτεί ακόμα από τον διαχειριστή — "
                "δεν μπορείς να δημιουργήσεις ή να ενταχθείς σε ομάδα μέχρι να εγκριθεί."
            ),
        )
