from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.models import PlayerPosition, PlayerStatus, PreferredFoot, UserRole

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
class UserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str = Field(min_length=8)
    full_name: Optional[str] = None
    role: Optional[UserRole] = None
    # Μόνο για role="player" — βοηθάει να ξεχωρίσουμε συνωνυμίες όταν
    # ταιριάζουμε αυτόματα τον λογαριασμό με εγγραφή παίκτη στο ρόστερ.
    # Δεν αποθηκεύεται στον λογαριασμό, χρησιμοποιείται μόνο τη στιγμή της
    # εγγραφής για το ταίριασμα.
    date_of_birth: Optional[date] = None
    # Μόνο για role="president" ή "technical_director" — ΑΦΜ ομάδας.
    tax_id: Optional[str] = None
    gdpr_consent: bool = False
    # --- Anti-bot ---
    # Honeypot: κρυφό πεδίο στη φόρμα εγγραφής, αόρατο σε πραγματικούς
    # χρήστες — αν γεμίσει, σχεδόν σίγουρα το γεμίζει bot.
    honeypot: Optional[str] = None
    # hCaptcha token (αν ο admin έχει ενεργοποιήσει CAPTCHA στις Ρυθμίσεις).
    captcha_token: Optional[str] = None


class UserOut(BaseModel):
    id: str
    email: str
    username: str
    full_name: Optional[str] = None
    role: UserRole
    is_active: bool
    linked_player_id: Optional[str] = None
    avatar_path: Optional[str] = None
    bio: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    is_staff_visible: bool = False
    staff_availability: str = "not_listed"
    desired_staff_role: Optional[str] = None
    origin_federation_id: Optional[str] = None
    desired_federation_ids: list[str] = []
    linkedin_url: Optional[str] = None
    show_linkedin: bool = False
    verification_level: int = 0
    club_verified: bool = False
    leadership_approved: bool = False

    @field_validator("desired_federation_ids", mode="before")
    @classmethod
    def _split_desired_federation_ids(cls, v):
        """Το πεδίο αποθηκεύεται στη βάση ως comma-separated string (ίδιο
        pattern με το TeamListing.role_needed) — εδώ το μετατρέπουμε σε λίστα
        πριν το validation, ώστε να δουλεύει διαφανώς με from_attributes=True
        πάνω σε raw SQLAlchemy User objects."""
        if v is None:
            return []
        if isinstance(v, str):
            return [x for x in v.split(",") if x]
        return v

    class Config:
        from_attributes = True


class UserMeOut(UserOut):
    """Ίδιο με UserOut, με επιπλέον το ΑΦΜ — επιστρέφεται ΜΟΝΟ σε endpoints
    που αφορούν τον ίδιο τον χρήστη (register/login/GET/PUT /me), ποτέ σε
    λίστες χρηστών ή σε προφίλ που βλέπουν άλλοι."""

    team_tax_id: Optional[str] = None


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    bio: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None


class UserRoleUpdate(BaseModel):
    role: UserRole


class UserActiveStatusUpdate(BaseModel):
    is_active: bool


class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8)


class ForgotPasswordRequest(BaseModel):
    username_or_email: str


class ForgotPasswordResponse(BaseModel):
    message: str
    # Σε πραγματικό production θα εστελνόταν με email. Εδώ, εφόσον δεν υπάρχει
    # ρυθμισμένος SMTP server, επιστρέφεται απευθείας για local single-admin χρήση
    # (τυπώνεται και στο console του backend).
    reset_token: Optional[str] = None


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(min_length=8)


class AISettingsOut(BaseModel):
    provider: str
    model: str
    api_key_set: bool


class AISettingsUpdate(BaseModel):
    provider: Optional[str] = None
    model: Optional[str] = None
    api_key: Optional[str] = None


class LoginRequest(BaseModel):
    username_or_email: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserMeOut


# ---------------------------------------------------------------------------
# Προφίλ χρήστη (Staff Scouting)
# ---------------------------------------------------------------------------
class QualificationIn(BaseModel):
    title: str
    year: Optional[int] = None


class QualificationOut(QualificationIn):
    id: str

    class Config:
        from_attributes = True


class WorkExperienceIn(BaseModel):
    organization: str
    role_title: Optional[str] = None
    start_year: Optional[int] = None
    end_year: Optional[int] = None
    description: Optional[str] = None


class WorkExperienceOut(WorkExperienceIn):
    id: str

    class Config:
        from_attributes = True


class AchievementIn(BaseModel):
    title: str
    year: Optional[int] = None
    description: Optional[str] = None


class AchievementOut(AchievementIn):
    id: str

    class Config:
        from_attributes = True


class StaffVisibilityUpdate(BaseModel):
    is_staff_visible: bool


class StaffAvailabilityUpdate(BaseModel):
    staff_availability: str = Field(description="not_listed | available | open_to_offers")


class StaffScoutingPrefsUpdate(BaseModel):
    # Ρόλος που ψάχνει ο χρήστης — π.χ. head_coach, technical_director,
    # assistant_coach, fitness_coach, analyst, scout. None = καθαρισμός.
    desired_staff_role: Optional[str] = None
    origin_federation_id: Optional[str] = None
    desired_federation_ids: list[str] = Field(default_factory=list, max_length=10)


class UserSearchResult(BaseModel):
    id: str
    full_name: Optional[str] = None
    username: str
    role: UserRole


class TeamStaffMemberIn(BaseModel):
    user_id: str
    role_title: Optional[str] = None


class TeamStaffMemberRoleUpdate(BaseModel):
    role_title: str


class TeamStaffMemberOut(BaseModel):
    id: str
    user_id: str
    full_name: Optional[str] = None
    username: str
    role_title: Optional[str] = None

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Αιτήσεις συνεργασίας (Scouting Hub) — coach/staff & player
# ---------------------------------------------------------------------------
class TeamJoinRequestCreate(BaseModel):
    message: Optional[str] = None


class TeamJoinRequestOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    applicant_user_id: str
    applicant_name: Optional[str] = None
    applicant_role: Optional[UserRole] = None
    message: Optional[str] = None
    status: str
    created_at: datetime
    expires_at: datetime
    can_respond: bool = True


class TeamJoinRequestRespond(BaseModel):
    accept: bool
    role_title: Optional[str] = None
    # Επιπλέον ομάδες (πέραν αυτής στην οποία έγινε η αίτηση) που θέλει να
    # αναθέσει ο owner στον coach — μέχρι 2 ακόμα (σύνολο έως 3).
    additional_team_ids: list[str] = []


class TeamAccessGrantOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    user_id: str
    full_name: Optional[str] = None
    username: Optional[str] = None
    role_title: Optional[str] = None

    class Config:
        from_attributes = True


class PlayerJoinRequestCreate(BaseModel):
    message: Optional[str] = None
    # Προαιρετικό — βοηθάει να ξεχωρίσουμε συνωνυμίες όταν ταιριάζουμε τον
    # αιτούντα με υπάρχουσα εγγραφή παίκτη στο ρόστερ της ομάδας.
    date_of_birth: Optional[date] = None


class PlayerJoinRequestOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    applicant_user_id: str
    applicant_name: Optional[str] = None
    message: Optional[str] = None
    status: str
    created_at: datetime
    expires_at: datetime
    can_respond: bool = True


class PlayerJoinRequestRespond(BaseModel):
    accept: bool
    # Προαιρετικό — δίνει στον εγκρίνοντα (coach/president/technical
    # director) την ευκαιρία να συνδέσει χειροκίνητα τον αιτούντα με
    # συγκεκριμένη υπάρχουσα εγγραφή παίκτη στο ρόστερ, αντί να βασιστεί
    # μόνο στο αυτόματο ταίριασμα ονόματος/ημερομηνίας γέννησης.
    link_to_player_id: Optional[str] = None


class UnlinkedPlayerOut(BaseModel):
    id: str
    first_name: str
    last_name: str


class PlayerClaimResult(BaseModel):
    message: str
    player_id: str


class StaffTeamHistoryEntry(BaseModel):
    team_id: str
    team_name: str
    role_title: Optional[str] = None


class ScoutingStaffOut(BaseModel):
    id: str
    full_name: Optional[str] = None
    role: UserRole
    avatar_path: Optional[str] = None
    bio: Optional[str] = None
    staff_availability: str = "not_listed"
    desired_staff_role: Optional[str] = None
    origin_federation_id: Optional[str] = None
    origin_federation_name: Optional[str] = None
    desired_federation_ids: list[str] = []
    desired_federation_names: list[str] = []
    linkedin_url: Optional[str] = None
    verification_level: int = 0
    qualifications: list[QualificationOut] = []
    achievements: list[AchievementOut] = []
    experience: list[WorkExperienceOut] = []
    teams: list[StaffTeamHistoryEntry] = []
    # True αν ο χρήστης που κάνει το αίτημα έχει ήδη στείλει εκκρεμή
    # προσφορά (StaffAssignmentOffer) σε αυτό το στέλεχος — ώστε το
    # frontend να αποτρέψει διπλή/επαναλαμβανόμενη προσφορά.
    has_pending_offer_from_me: bool = False


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------
class TeamBase(BaseModel):
    name: str
    category: Optional[str] = None
    division: Optional[str] = None
    league: Optional[str] = None
    season: Optional[str] = None
    description: Optional[str] = None
    home_stadium: Optional[str] = None
    primary_color: Optional[str] = None
    secondary_color: Optional[str] = None
    coach_name: Optional[str] = None
    notes: Optional[str] = None
    country_id: Optional[str] = None
    federation_id: Optional[str] = None
    league_level_id: Optional[str] = None
    league_group_id: Optional[str] = None
    league_tier: Optional[str] = Field(
        default="regional",
        description="top_division | second_division | third_division | regional | u19",
    )
    academy_age_group: Optional[str] = None
    is_public_scouting: Optional[bool] = True


class TeamCreate(TeamBase):
    pass


class TeamUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    division: Optional[str] = None
    league: Optional[str] = None
    season: Optional[str] = None
    description: Optional[str] = None
    home_stadium: Optional[str] = None
    primary_color: Optional[str] = None
    secondary_color: Optional[str] = None
    coach_name: Optional[str] = None
    notes: Optional[str] = None
    country_id: Optional[str] = None
    federation_id: Optional[str] = None
    league_level_id: Optional[str] = None
    league_group_id: Optional[str] = None
    league_tier: Optional[str] = None
    academy_age_group: Optional[str] = None
    is_public_scouting: Optional[bool] = None


class TeamOut(TeamBase):
    id: str
    logo_path: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    player_count: int = 0
    country_name: Optional[str] = None
    region_name: Optional[str] = None
    federation_name: Optional[str] = None
    league_level_name: Optional[str] = None
    league_group_name: Optional[str] = None
    is_publicly_shared: bool = False
    public_slug: Optional[str] = None
    public_show_roster: bool = True
    # Το πλήρες όνομα του πραγματικού, συνδεδεμένου λογαριασμού Προέδρου
    # (owner_id) — υπολογίζεται δυναμικά, ΟΧΙ επεξεργάσιμο πεδίο (σε
    # αντίθεση με το coach_name, που είναι ελεύθερο κείμενο).
    president_name: Optional[str] = None

    class Config:
        from_attributes = True


class TeamPublishUpdate(BaseModel):
    is_publicly_shared: bool
    public_show_roster: Optional[bool] = None


class CSVImportRowError(BaseModel):
    row: int
    message: str


class CSVImportResult(BaseModel):
    created: int
    errors: list[CSVImportRowError]


# ---------------------------------------------------------------------------
# Players
# ---------------------------------------------------------------------------
class PlayerBase(BaseModel):
    first_name: str
    last_name: str
    date_of_birth: Optional[date] = None
    nationality: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    player_number: Optional[int] = None
    preferred_foot: Optional[PreferredFoot] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    position: Optional[PlayerPosition] = None
    secondary_position: Optional[PlayerPosition] = None
    current_team_id: Optional[str] = None
    contract_notes: Optional[str] = None
    status: Optional[PlayerStatus] = PlayerStatus.FIT
    availability_notes: Optional[str] = None
    injury_status: Optional[str] = None
    injury_type: Optional[str] = None
    injury_date: Optional[date] = None
    expected_return: Optional[date] = None
    medical_notes: Optional[str] = None


class PlayerCreate(PlayerBase):
    pass


class PlayerUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    nationality: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    player_number: Optional[int] = None
    preferred_foot: Optional[PreferredFoot] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    position: Optional[PlayerPosition] = None
    secondary_position: Optional[PlayerPosition] = None
    current_team_id: Optional[str] = None
    contract_notes: Optional[str] = None
    status: Optional[PlayerStatus] = None
    availability_notes: Optional[str] = None
    injury_status: Optional[str] = None
    injury_type: Optional[str] = None
    injury_date: Optional[date] = None
    expected_return: Optional[date] = None
    medical_notes: Optional[str] = None


class PlayerOut(PlayerBase):
    id: str
    photo_path: Optional[str] = None
    age: Optional[int] = None
    team_name: Optional[str] = None
    goals: int = 0
    matches_played: int = 0
    transfer_status: str = "not_listed"
    transfer_notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------
class TrainingSessionBase(BaseModel):
    team_id: str
    date: date
    time: Optional[str] = None
    location: Optional[str] = None
    training_type: Optional[str] = None
    duration_minutes: Optional[int] = None
    objectives: Optional[str] = None
    exercises: Optional[str] = None
    coach_notes: Optional[str] = None


class TrainingSessionCreate(TrainingSessionBase):
    pass


class TrainingSessionUpdate(BaseModel):
    team_id: Optional[str] = None
    date: Optional[date] = None
    time: Optional[str] = None
    location: Optional[str] = None
    training_type: Optional[str] = None
    duration_minutes: Optional[int] = None
    objectives: Optional[str] = None
    exercises: Optional[str] = None
    coach_notes: Optional[str] = None


class TrainingSessionOut(TrainingSessionBase):
    id: str
    team_name: Optional[str] = None
    attendance_present: int = 0
    attendance_total: int = 0
    created_at: datetime

    class Config:
        from_attributes = True


class TrainingAttendanceIn(BaseModel):
    player_id: str
    status: str = Field(description="present | absent | late | injured | excused")
    notes: Optional[str] = None


class TrainingAttendanceOut(BaseModel):
    id: str
    player_id: str
    player_name: str
    status: str
    notes: Optional[str] = None

    class Config:
        from_attributes = True


class PlayerAttendanceSummary(BaseModel):
    player_id: str
    player_name: str
    total_sessions: int
    attended: int
    attendance_percentage: float


# ---------------------------------------------------------------------------
# Matches
# ---------------------------------------------------------------------------
class MatchBase(BaseModel):
    home_team_id: Optional[str] = None
    away_team_id: Optional[str] = None
    home_team_name_external: Optional[str] = None
    away_team_name_external: Optional[str] = None
    date: date
    time: Optional[str] = None
    stadium: Optional[str] = None
    competition: Optional[str] = None
    season: Optional[str] = None
    home_score: Optional[int] = None
    away_score: Optional[int] = None
    half_time_home_score: Optional[int] = None
    half_time_away_score: Optional[int] = None
    status: Optional[str] = "scheduled"


class MatchCreate(MatchBase):
    pass


class MatchUpdate(BaseModel):
    home_team_id: Optional[str] = None
    away_team_id: Optional[str] = None
    home_team_name_external: Optional[str] = None
    away_team_name_external: Optional[str] = None
    date: Optional[date] = None
    time: Optional[str] = None
    stadium: Optional[str] = None
    competition: Optional[str] = None
    season: Optional[str] = None
    home_score: Optional[int] = None
    away_score: Optional[int] = None
    half_time_home_score: Optional[int] = None
    half_time_away_score: Optional[int] = None
    status: Optional[str] = None


class MatchReportUpdate(BaseModel):
    team_performance_notes: Optional[str] = None
    opponent_analysis: Optional[str] = None
    coach_notes: Optional[str] = None
    general_description: Optional[str] = None


class MatchOut(MatchBase):
    id: str
    home_team_name: Optional[str] = None
    away_team_name: Optional[str] = None
    team_performance_notes: Optional[str] = None
    opponent_analysis: Optional[str] = None
    coach_notes: Optional[str] = None
    general_description: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class MatchPlayerIn(BaseModel):
    player_id: str
    is_starting: bool = False
    position_played: Optional[PlayerPosition] = None
    minutes_played: Optional[int] = None
    goals: int = 0
    assists: int = 0
    yellow_cards: int = 0
    red_cards: int = 0
    fouls: int = 0
    rating: Optional[float] = None
    coach_rating: Optional[float] = None
    is_mvp: bool = False
    notes: Optional[str] = None


class MatchPlayerOut(MatchPlayerIn):
    id: str
    player_name: str
    player_number: Optional[int] = None

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Calendar
# ---------------------------------------------------------------------------
class CalendarEventCreate(BaseModel):
    title: str
    event_type: str = "other"  # match | training | injury | other
    date: date
    time: Optional[str] = None
    team_id: Optional[str] = None
    notes: Optional[str] = None


class CalendarEventUpdate(BaseModel):
    title: Optional[str] = None
    date: Optional[date] = None
    time: Optional[str] = None
    team_id: Optional[str] = None
    notes: Optional[str] = None


class CalendarEventOut(BaseModel):
    id: str
    title: str
    event_type: str
    date: date
    time: Optional[str] = None
    team_id: Optional[str] = None
    team_name: Optional[str] = None
    related_entity_type: Optional[str] = None
    related_entity_id: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[str] = None  # για matches: scheduled/finished κλπ.
    editable: bool = True  # false για auto-generated events (matches/trainings)

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Tactical Board
# ---------------------------------------------------------------------------
class TacticalObjectIn(BaseModel):
    object_type: str = Field(description="player | arrow | zone | text")
    player_id: Optional[str] = None
    coordinates: list[dict] = []
    color: Optional[str] = None
    label: Optional[str] = None


class TacticalObjectOut(BaseModel):
    id: str
    object_type: str
    player_id: Optional[str] = None
    player_name: Optional[str] = None
    player_number: Optional[int] = None
    coordinates: list[dict] = []
    color: Optional[str] = None
    label: Optional[str] = None


class TacticalBoardBase(BaseModel):
    team_id: Optional[str] = None
    match_id: Optional[str] = None
    training_session_id: Optional[str] = None
    name: str
    formation: Optional[str] = None
    scenario_type: Optional[str] = None
    notes: Optional[str] = None


class TacticalBoardCreate(TacticalBoardBase):
    pass


class TacticalBoardUpdate(BaseModel):
    name: Optional[str] = None
    formation: Optional[str] = None
    scenario_type: Optional[str] = None
    notes: Optional[str] = None


class TacticalBoardListOut(TacticalBoardBase):
    id: str
    team_name: Optional[str] = None
    training_label: Optional[str] = None
    object_count: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class TacticalBoardDetailOut(TacticalBoardListOut):
    objects: list[TacticalObjectOut] = []


# ---------------------------------------------------------------------------
# Player statistics (quick-edit: goals, matches, cards)
# ---------------------------------------------------------------------------
class MatchHistoryEntry(BaseModel):
    match_id: str
    date: date
    opponent: Optional[str] = None
    rating: Optional[float] = None
    goals: int = 0
    assists: int = 0


class PlayerStatisticsOut(BaseModel):
    id: str
    player_id: str
    team_id: Optional[str] = None
    season: Optional[str] = None
    matches_played: int = 0
    starts: int = 0
    substitute_appearances: int = 0
    minutes_played: int = 0
    goals: int = 0
    assists: int = 0
    yellow_cards: int = 0
    red_cards: int = 0
    fouls_committed: int = 0
    fouls_suffered: int = 0
    shots: int = 0
    shots_on_target: int = 0
    passes: int = 0
    tackles: int = 0
    interceptions: int = 0
    clearances: int = 0
    saves: int = 0
    clean_sheets: int = 0
    # Δεν αποθηκεύεται ως πεδίο — υπολογίζεται δυναμικά από τα rating του
    # Match Rating (MatchPlayer), ίδιο pattern με το Scouting Hub.
    avg_rating: Optional[float] = None

    class Config:
        from_attributes = True


class PlayerStatisticsUpdate(BaseModel):
    matches_played: Optional[int] = None
    goals: Optional[int] = None
    assists: Optional[int] = None
    yellow_cards: Optional[int] = None
    red_cards: Optional[int] = None
    minutes_played: Optional[int] = None


class PlayerStatisticsIncrement(BaseModel):
    field: str = Field(description="matches_played | goals | yellow_cards | red_cards | assists")
    delta: int = 1


# ---------------------------------------------------------------------------
# Injuries
# ---------------------------------------------------------------------------
class InjuryOut(BaseModel):
    id: str
    player_id: str
    injury_type: Optional[str] = None
    status: str
    injury_date: Optional[date] = None
    expected_return: Optional[date] = None
    actual_return: Optional[date] = None
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


VALID_ABSENCE_REASONS = {
    "red_card",
    "suspension",
    "travel",
    "unexcused",
    "tutoring",
    "illness",
    "personal",
    "family",
    "school",
    "military",
    "national_team",
    "other",
}


class PlayerAbsenceCreate(BaseModel):
    player_id: str
    reason: str = Field(description=", ".join(sorted(VALID_ABSENCE_REASONS)))
    start_date: date
    end_date: Optional[date] = None
    notes: Optional[str] = None

    @field_validator("reason")
    @classmethod
    def _validate_reason(cls, v):
        if v not in VALID_ABSENCE_REASONS:
            raise ValueError(f"Μη έγκυρος λόγος απουσίας: {v}")
        return v


class PlayerAbsenceUpdate(BaseModel):
    reason: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    notes: Optional[str] = None

    @field_validator("reason")
    @classmethod
    def _validate_reason(cls, v):
        if v is not None and v not in VALID_ABSENCE_REASONS:
            raise ValueError(f"Μη έγκυρος λόγος απουσίας: {v}")
        return v


class PlayerAbsenceOut(BaseModel):
    id: str
    player_id: str
    player_name: Optional[str] = None
    team_id: Optional[str] = None
    team_name: Optional[str] = None
    reason: str
    start_date: date
    end_date: Optional[date] = None
    notes: Optional[str] = None
    created_by: Optional[str] = None
    created_by_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    is_active: bool = True
    # False για "εικονικές" εγγραφές που προκύπτουν αυτόματα από το status
    # του παίκτη ή από ενεργό Injury (όχι πραγματική γραμμή στον πίνακα
    # PlayerAbsence) — το frontend κρύβει τα κουμπιά Επεξεργασία/Διαγραφή.
    is_editable: bool = True

    class Config:
        from_attributes = True


class InjuryUpdate(BaseModel):
    injury_type: Optional[str] = None
    status: Optional[str] = None
    expected_return: Optional[date] = None
    actual_return: Optional[date] = None
    notes: Optional[str] = None


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------
class NotificationOut(BaseModel):
    id: str
    type: str
    title: str
    message: Optional[str] = None
    is_read: bool
    related_entity_type: Optional[str] = None
    related_entity_id: Optional[str] = None
    related_team_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# AI Reports
# ---------------------------------------------------------------------------
class AIReportOut(BaseModel):
    id: str
    report_type: str
    match_id: Optional[str] = None
    player_id: Optional[str] = None
    team_id: Optional[str] = None
    content: str
    model_used: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Performance (monthly aggregation)
# ---------------------------------------------------------------------------
class PlayerMonthlyPerformance(BaseModel):
    player_id: str
    player_name: str
    team_name: Optional[str] = None
    matches_played: int
    avg_rating: Optional[float] = None
    goals: int
    assists: int
    yellow_cards: int
    red_cards: int
    mvp_count: int


# ---------------------------------------------------------------------------
# Scouting Hub
# ---------------------------------------------------------------------------
class CountryOut(BaseModel):
    id: str
    name: str
    code: Optional[str] = None

    class Config:
        from_attributes = True


class RegionOut(BaseModel):
    id: str
    country_id: str
    name: str

    class Config:
        from_attributes = True


class FederationOut(BaseModel):
    id: str
    region_id: str
    name: str

    class Config:
        from_attributes = True


class LeagueLevelOut(BaseModel):
    id: str
    federation_id: str
    name: str
    order_index: int = 0
    applies_to: str = "regional"
    group_count: int = 0

    class Config:
        from_attributes = True


class LeagueLevelCreate(BaseModel):
    federation_id: str
    name: str
    order_index: int = 0
    applies_to: str = Field(default="regional", description="regional|academy")


class LeagueGroupOut(BaseModel):
    id: str
    league_level_id: str
    name: str

    class Config:
        from_attributes = True


class LeagueGroupCreate(BaseModel):
    league_level_id: str
    name: str


class ScoutingTeamOut(BaseModel):
    id: str
    name: str
    logo_path: Optional[str] = None
    category: Optional[str] = None
    league_tier: str
    academy_age_group: Optional[str] = None
    federation_name: Optional[str] = None
    league_level_name: Optional[str] = None
    league_group_name: Optional[str] = None
    region_name: Optional[str] = None
    country_name: Optional[str] = None
    player_count: int = 0


class PlayerAttributesOut(BaseModel):
    potential: Optional[float] = None
    passing: Optional[float] = None
    shooting: Optional[float] = None
    dribbling: Optional[float] = None
    defending: Optional[float] = None
    attacking: Optional[float] = None
    physical: Optional[float] = None

    class Config:
        from_attributes = True


class PlayerAttributesUpdate(BaseModel):
    potential: Optional[float] = Field(default=None, ge=1, le=10)
    passing: Optional[float] = Field(default=None, ge=1, le=10)
    shooting: Optional[float] = Field(default=None, ge=1, le=10)
    dribbling: Optional[float] = Field(default=None, ge=1, le=10)
    defending: Optional[float] = Field(default=None, ge=1, le=10)
    attacking: Optional[float] = Field(default=None, ge=1, le=10)
    physical: Optional[float] = Field(default=None, ge=1, le=10)


class ScoutingSeasonStats(BaseModel):
    matches_played: int = 0
    goals: int = 0
    assists: int = 0
    avg_rating: Optional[float] = None


class ScoutingPlayerOut(BaseModel):
    id: str
    first_name: str
    last_name: str
    photo_path: Optional[str] = None
    age: Optional[int] = None
    nationality: Optional[str] = None
    position: Optional[PlayerPosition] = None
    secondary_position: Optional[PlayerPosition] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    preferred_foot: Optional[PreferredFoot] = None
    team_id: Optional[str] = None
    team_name: Optional[str] = None
    league_tier: Optional[str] = None
    transfer_status: str
    transfer_notes: Optional[str] = None
    attributes: Optional[PlayerAttributesOut] = None
    season_stats: ScoutingSeasonStats
    is_shortlisted: bool = False
    linked_user_id: Optional[str] = None


# ---------------------------------------------------------------------------
# Αγγελίες (Scouting Hub job listings) — ομάδα ψάχνει staff ή παίκτη
# ---------------------------------------------------------------------------
class TeamListingCreate(BaseModel):
    listing_type: str = Field(description="staff | player")
    # Staff — έως 5 διαφορετικοί ρόλοι στην ίδια αγγελία
    role_needed: Optional[list[UserRole]] = Field(default=None, max_length=5)
    season: Optional[str] = None
    employment_type: Optional[str] = Field(default=None, description="paid | unpaid")
    # Player — έως 5 διαφορετικές θέσεις στην ίδια αγγελία
    position_needed: Optional[list[PlayerPosition]] = Field(default=None, max_length=5)
    min_age: Optional[int] = None
    max_age: Optional[int] = None
    # Ποιες ΕΠΣ (νομούς) στοχεύει η αγγελία — κενό/None = οπουδήποτε.
    target_federation_ids: Optional[list[str]] = Field(default=None, max_length=10)
    description: Optional[str] = None


class TeamListingOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    posted_by: str
    listing_type: str
    status: str
    role_needed: list[str] = []
    season: Optional[str] = None
    employment_type: Optional[str] = None
    position_needed: list[str] = []
    min_age: Optional[int] = None
    max_age: Optional[int] = None
    target_federation_ids: list[str] = []
    target_federation_names: list[str] = []
    description: Optional[str] = None
    created_at: datetime
    expires_at: Optional[datetime] = None
    application_count: int = 0


class ListingApplicationCreate(BaseModel):
    message: Optional[str] = None


class ListingApplicationOut(BaseModel):
    id: str
    listing_id: str
    applicant_user_id: str
    applicant_name: Optional[str] = None
    applicant_role: Optional[UserRole] = None
    message: Optional[str] = None
    status: str
    created_at: datetime
    can_respond: bool = True
    # Αν ο αιτών είναι παίκτης με συνδεδεμένη εγγραφή, το ιστορικό/στατιστικά
    # του — ώστε ο πρόεδρος/τεχνικός/scout/αναλυτής/προπονητής να τα δουν
    # αμέσως μόλις αιτηθεί.
    applicant_player: Optional[ScoutingPlayerOut] = None


class ListingApplicationRespond(BaseModel):
    accept: bool


# ---------------------------------------------------------------------------
# Συνομιλίες
# ---------------------------------------------------------------------------
class MessageOut(BaseModel):
    id: str
    conversation_id: str
    sender_id: str
    content: str
    created_at: datetime
    read_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class MessageCreate(BaseModel):
    content: str = Field(min_length=1)


class ConversationOut(BaseModel):
    id: str
    other_user_id: str
    other_user_name: Optional[str] = None
    other_user_avatar: Optional[str] = None
    context_label: Optional[str] = None
    related_team_id: Optional[str] = None
    last_message: Optional[str] = None
    last_message_at: Optional[datetime] = None
    unread_count: int = 0
    created_at: datetime


# ---------------------------------------------------------------------------
# Ετήσια ανανέωση σεζόν
# ---------------------------------------------------------------------------
class RenewalRequestOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    user_id: str
    user_name: Optional[str] = None
    current_season: str
    next_season: str
    status: str
    hold_reason: Optional[str] = None
    hold_deadline: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class RenewalDecisionRequest(BaseModel):
    decision: str = Field(description="accept | hold | reject")
    hold_reason: Optional[str] = None


class ClubRenewalResolveRequest(BaseModel):
    action: str = Field(description="confirm | release")


# ---------------------------------------------------------------------------
# Προσφορές συμβολαίου σε παίκτη
# ---------------------------------------------------------------------------
class ContractOfferCreate(BaseModel):
    player_user_id: str
    years: Optional[int] = None
    salary_details: Optional[str] = None
    bonus_details: Optional[str] = None


class ContractOfferOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    sender_id: str
    sender_name: Optional[str] = None
    player_user_id: str
    years: Optional[int] = None
    salary_details: Optional[str] = None
    bonus_details: Optional[str] = None
    status: str
    created_at: datetime


class ContractOfferRespond(BaseModel):
    accept: bool


# ---------------------------------------------------------------------------
# Προσφορές ανάθεσης επιπλέον ομάδας σε υπάρχον staff (εσωτερική μετάθεση)
# ---------------------------------------------------------------------------
class StaffAssignmentOfferCreate(BaseModel):
    recipient_user_id: str
    role_title: Optional[str] = None
    # Αν δοθεί, στην αποδοχή αλλάζει ο ρόλος του λογαριασμού του παραλήπτη
    # (π.χ. Player -> Assistant Coach, Head Coach -> Technical Director).
    new_role: Optional[UserRole] = None
    season: Optional[str] = None
    incentive_details: Optional[str] = None
    message: Optional[str] = None


class StaffAssignmentOfferOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    sender_id: str
    sender_name: Optional[str] = None
    recipient_user_id: str
    recipient_name: Optional[str] = None
    role_title: Optional[str] = None
    new_role: Optional[UserRole] = None
    season: Optional[str] = None
    incentive_details: Optional[str] = None
    message: Optional[str] = None
    status: str
    created_at: datetime


class StaffAssignmentOfferRespond(BaseModel):
    accept: bool


# ---------------------------------------------------------------------------
# Ενότητα Staff — διαχείριση επιτελείου ανά ομάδα/σύλλογο
# ---------------------------------------------------------------------------
class StaffEvaluationCreate(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: Optional[str] = None


class StaffEvaluationOut(BaseModel):
    id: str
    evaluator_id: str
    evaluator_name: Optional[str] = None
    rating: int
    comment: Optional[str] = None
    created_at: datetime


class StaffMemberOut(BaseModel):
    user_id: str
    full_name: Optional[str] = None
    username: str
    role: UserRole
    avatar_path: Optional[str] = None
    role_title: Optional[str] = None
    staff_availability: str = "not_listed"
    avg_rating: Optional[float] = None
    evaluation_count: int = 0
    can_fire: bool = False


class MyTeamMembershipOut(BaseModel):
    team_id: str
    team_name: str
    role_title: Optional[str] = None


class StaffTeamGroup(BaseModel):
    team_id: str
    team_name: str
    members: list[StaffMemberOut] = []


# ---------------------------------------------------------------------------
# LinkedIn
# ---------------------------------------------------------------------------
class LinkedInUpdate(BaseModel):
    linkedin_url: Optional[str] = None
    show_linkedin: bool = False


# ---------------------------------------------------------------------------
# Επαλήθευση αξιοπιστίας (verification tiers)
# ---------------------------------------------------------------------------
class VerificationDocumentOut(BaseModel):
    id: str
    document_type: str
    status: str
    rejection_reason: Optional[str] = None
    uploaded_at: datetime
    reviewed_at: Optional[datetime] = None
    auto_verified: bool = False

    class Config:
        from_attributes = True


class VerificationDocumentAdminOut(VerificationDocumentOut):
    user_id: str
    user_name: Optional[str] = None
    user_role: Optional[UserRole] = None


class VerificationReviewRequest(BaseModel):
    approve: bool
    rejection_reason: Optional[str] = None


class VerificationStatusOut(BaseModel):
    verification_level: int
    level_label: str = Field(description="grey | blue | green")
    documents: list[VerificationDocumentOut] = []
    max_simultaneous_teams: int
    club_verified: bool = False


class TransferStatusUpdate(BaseModel):
    transfer_status: str = Field(description="not_listed | free_agent | for_transfer | loan_listed")
    transfer_notes: Optional[str] = None


class TransferStatusSelfUpdate(BaseModel):
    transfer_status: str = Field(description="not_listed | free_agent | for_transfer | loan_listed")


class LinkPlayerAccountRequest(BaseModel):
    player_id: str


class ShortlistItemOut(BaseModel):
    player: ScoutingPlayerOut


# ---------------------------------------------------------------------------
# Public Club Page (χωρίς login — μοιράσιμο link)
# ---------------------------------------------------------------------------
class PublicClubPlayerOut(BaseModel):
    id: str
    first_name: str
    last_name: str
    photo_path: Optional[str] = None
    player_number: Optional[int] = None
    position: Optional[PlayerPosition] = None


class PublicClubMatchOut(BaseModel):
    date: date
    time: Optional[str] = None
    stadium: Optional[str] = None
    competition: Optional[str] = None
    home_team_name: Optional[str] = None
    away_team_name: Optional[str] = None
    home_score: Optional[int] = None
    away_score: Optional[int] = None
    status: str
    result: Optional[str] = None  # "W" | "D" | "L" — μόνο για ολοκληρωμένους αγώνες


class PublicClubPageOut(BaseModel):
    name: str
    logo_path: Optional[str] = None
    category: Optional[str] = None
    league_tier: Optional[str] = None
    federation_name: Optional[str] = None
    region_name: Optional[str] = None
    home_stadium: Optional[str] = None
    primary_color: Optional[str] = None
    secondary_color: Optional[str] = None
    description: Optional[str] = None
    coach_name: Optional[str] = None
    next_match: Optional[PublicClubMatchOut] = None
    recent_form: list[PublicClubMatchOut] = []
    roster: Optional[list[PublicClubPlayerOut]] = None


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
class DashboardActivityItem(BaseModel):
    type: str
    text: str
    timestamp: str
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None


class UpcomingMatchInfo(BaseModel):
    id: str
    date: date
    days_until: int
    team_id: str
    team_name: str
    opponent_name: Optional[str] = None
    is_home: bool
    stadium: Optional[str] = None
    competition: Optional[str] = None


class UpcomingTrainingInfo(BaseModel):
    id: str
    date: date
    days_until: int
    team_id: str
    team_name: str
    training_type: Optional[str] = None
    location: Optional[str] = None


class TopPlayerStat(BaseModel):
    player_id: str
    player_name: str
    team_id: str
    team_name: Optional[str] = None
    value: float
    label: str


class DashboardStats(BaseModel):
    total_teams: int
    total_players: int
    injured_players: int
    # Ενεργές απουσίες εκτός ιατρικού τραυματισμού (κόκκινη κάρτα, ταξίδι,
    # αδικαιολόγητος κ.λπ.) — βλ. PlayerAbsence, ενότητα "Τραυματισμοί /
    # Απουσίες".
    active_absences_count: int = 0
    upcoming_trainings_count: int
    trainings_this_week: int = 0
    # Ένα στοιχείο ανά ομάδα (όχι ένα καθολικό "καλύτερο") — ώστε κάποιος με
    # πολλές ομάδες (π.χ. Τεχνικός Διευθυντής με έως 8) να τις βλέπει ΟΛΕΣ,
    # ταξινομημένα με την πιο επείγουσα/καλύτερη πρώτα.
    upcoming_matches: list[UpcomingMatchInfo] = []
    upcoming_trainings: list[UpcomingTrainingInfo] = []
    top_scorers: list[TopPlayerStat] = []
    best_avg_rating_players: list[TopPlayerStat] = []
    top_performers_this_month: list[TopPlayerStat] = []
    recent_activity: list[DashboardActivityItem]


# ---------------------------------------------------------------------------
# Συνδρομές Ακαδημιών
# ---------------------------------------------------------------------------
class AcademyTeamSummaryOut(BaseModel):
    team_id: str
    team_name: str
    category: Optional[str] = None
    player_count: int = 0
    players_with_debt: int = 0
    total_owed: float = 0.0


class AcademyFeeSettingsOut(BaseModel):
    team_id: str
    monthly_fee: Optional[float] = None
    annual_fee: Optional[float] = None
    registration_fee: Optional[float] = None
    payment_due_day: int = 10
    kit_template: list[str] = []


class AcademyFeeSettingsUpdate(BaseModel):
    monthly_fee: Optional[float] = None
    annual_fee: Optional[float] = None
    registration_fee: Optional[float] = None
    payment_due_day: int = Field(default=10, ge=1, le=28)
    kit_template: list[str] = []


class AcademyPlayerAccountUpdate(BaseModel):
    plan_type: str = Field(default="monthly", description="monthly | annual")
    parent_name: Optional[str] = None
    parent_phone: Optional[str] = None
    enrollment_date: Optional[date] = None
    notes: Optional[str] = None


class AcademyPaymentCreate(BaseModel):
    payment_type: str = Field(description="monthly | annual | registration")
    period_year: Optional[int] = None
    period_month: Optional[int] = Field(default=None, ge=1, le=12)
    amount: float
    paid_date: Optional[date] = None
    notes: Optional[str] = None


class AcademyPaymentOut(BaseModel):
    id: str
    payment_type: str
    period_year: Optional[int] = None
    period_month: Optional[int] = None
    amount: float
    paid_date: date
    recorded_by_name: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime


class AcademyKitItemCreate(BaseModel):
    item_name: str
    price: Optional[float] = None
    received: bool = False
    paid: bool = False


class AcademyKitItemUpdate(BaseModel):
    received: Optional[bool] = None
    paid: Optional[bool] = None
    price: Optional[float] = None


class AcademyKitItemOut(BaseModel):
    id: str
    item_name: str
    received: bool
    paid: bool
    price: Optional[float] = None


class AcademyOwedMonth(BaseModel):
    year: int
    month: int
    amount: float


class AcademyPlayerSummaryOut(BaseModel):
    player_id: str
    player_name: str
    photo_path: Optional[str] = None
    plan_type: str = "monthly"
    parent_name: Optional[str] = None
    parent_phone: Optional[str] = None
    enrollment_date: Optional[date] = None
    registration_paid: bool = False
    annual_paid_in_full: bool = False
    total_owed: float = 0.0
    unpaid_months: list[AcademyOwedMonth] = []
    is_overdue: bool = False
    kit_items: list[AcademyKitItemOut] = []
    kit_owed: float = 0.0
    has_account: bool = False


class AcademyPlayerDetailOut(AcademyPlayerSummaryOut):
    team_id: str
    team_name: Optional[str] = None
    notes: Optional[str] = None
    payments: list[AcademyPaymentOut] = []


class AcademyAnnouncementCreate(BaseModel):
    title: str
    description: Optional[str] = None
    event_date: Optional[date] = None
    event_time: Optional[str] = None
    location_name: Optional[str] = None
    location_maps_url: Optional[str] = None


class AcademyAnnouncementOut(BaseModel):
    id: str
    team_id: str
    title: str
    description: Optional[str] = None
    event_date: Optional[date] = None
    event_time: Optional[str] = None
    location_name: Optional[str] = None
    location_maps_url: Optional[str] = None
    created_by_name: Optional[str] = None
    created_at: datetime


# ---------------------------------------------------------------------------
# CRM — directory επαφών + θέματα/προβλήματα
# ---------------------------------------------------------------------------
class CrmContactOut(BaseModel):
    user_id: str
    full_name: Optional[str] = None
    username: str
    role: UserRole
    avatar_path: Optional[str] = None
    email: str
    phone: Optional[str] = None
    teams: list[str] = []


class CrmTopicCreate(BaseModel):
    team_id: str
    title: str
    description: Optional[str] = None
    category: str = Field(default="general", description="general|stadium|parents|event|other")
    priority: str = Field(default="normal", description="urgent|normal|low")
    expires_at: Optional[datetime] = None


class CrmTopicUpdate(BaseModel):
    status: Optional[str] = Field(default=None, description="open|in_progress|resolved")
    priority: Optional[str] = None
    category: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    expires_at: Optional[datetime] = None


class CrmTopicCommentCreate(BaseModel):
    content: str


class CrmTopicCommentOut(BaseModel):
    id: str
    author_id: str
    author_name: Optional[str] = None
    author_avatar: Optional[str] = None
    content: str
    created_at: datetime


class CrmTopicOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    title: str
    description: Optional[str] = None
    category: str
    priority: str
    status: str
    expires_at: Optional[datetime] = None
    is_expired: bool = False
    created_by: str
    created_by_name: Optional[str] = None
    created_by_avatar: Optional[str] = None
    comment_count: int = 0
    created_at: datetime
    updated_at: datetime
    resolved_at: Optional[datetime] = None


class CrmTopicDetailOut(CrmTopicOut):
    comments: list[CrmTopicCommentOut] = []


class CrmStatsOut(BaseModel):
    by_category: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    by_status: dict[str, int] = {}
    urgent_open_count: int = 0
    expired_count: int = 0
    total_topics: int = 0
    resolved_this_month: int = 0


# ---------------------------------------------------------------------------
# Scout Reports
# ---------------------------------------------------------------------------
VALID_STRONG_FOOT = {"right", "left", "both"}


class ScoutReportBase(BaseModel):
    full_name: str
    club_name: Optional[str] = None
    age: Optional[int] = None
    position: Optional[str] = None
    role: Optional[str] = None
    league: Optional[str] = None
    jersey_number: Optional[int] = None
    nationality: Optional[str] = None
    strong_foot: Optional[str] = None
    goals_per_season: Optional[int] = None
    team_id: Optional[str] = None

    positive_rating: Optional[int] = None
    positive_notes: Optional[str] = None
    negative_rating: Optional[int] = None
    negative_notes: Optional[str] = None
    physical_mental_rating: Optional[int] = None
    physical_mental_notes: Optional[str] = None

    detailed_attributes: dict[str, int] = {}

    conclusion_text: Optional[str] = None
    recommended: Optional[bool] = None
    potential_rating: Optional[int] = None

    @field_validator("strong_foot")
    @classmethod
    def _validate_foot(cls, v):
        if v is not None and v not in VALID_STRONG_FOOT:
            raise ValueError("Μη έγκυρο δυνατό πόδι — right | left | both")
        return v

    @field_validator("positive_rating", "negative_rating", "physical_mental_rating")
    @classmethod
    def _validate_star_rating(cls, v):
        if v is not None and not (1 <= v <= 5):
            raise ValueError("Η βαθμολογία αστεριών πρέπει να είναι από 1 έως 5")
        return v

    @field_validator("potential_rating")
    @classmethod
    def _validate_potential(cls, v):
        if v is not None and not (1 <= v <= 10):
            raise ValueError("Το potential πρέπει να είναι από 1 έως 10")
        return v

    @field_validator("detailed_attributes")
    @classmethod
    def _validate_detailed_attributes(cls, v):
        for key, value in v.items():
            if not (1 <= value <= 10):
                raise ValueError(f"Το χαρακτηριστικό '{key}' πρέπει να είναι από 1 έως 10")
        return v


class ScoutReportCreate(ScoutReportBase):
    pass


class ScoutReportUpdate(BaseModel):
    full_name: Optional[str] = None
    club_name: Optional[str] = None
    age: Optional[int] = None
    position: Optional[str] = None
    role: Optional[str] = None
    league: Optional[str] = None
    jersey_number: Optional[int] = None
    nationality: Optional[str] = None
    strong_foot: Optional[str] = None
    goals_per_season: Optional[int] = None

    positive_rating: Optional[int] = None
    positive_notes: Optional[str] = None
    negative_rating: Optional[int] = None
    negative_notes: Optional[str] = None
    physical_mental_rating: Optional[int] = None
    physical_mental_notes: Optional[str] = None

    detailed_attributes: Optional[dict[str, int]] = None

    conclusion_text: Optional[str] = None
    recommended: Optional[bool] = None
    potential_rating: Optional[int] = None

    @field_validator("strong_foot")
    @classmethod
    def _validate_foot(cls, v):
        if v is not None and v not in VALID_STRONG_FOOT:
            raise ValueError("Μη έγκυρο δυνατό πόδι — right | left | both")
        return v

    @field_validator("positive_rating", "negative_rating", "physical_mental_rating")
    @classmethod
    def _validate_star_rating(cls, v):
        if v is not None and not (1 <= v <= 5):
            raise ValueError("Η βαθμολογία αστεριών πρέπει να είναι από 1 έως 5")
        return v

    @field_validator("potential_rating")
    @classmethod
    def _validate_potential(cls, v):
        if v is not None and not (1 <= v <= 10):
            raise ValueError("Το potential πρέπει να είναι από 1 έως 10")
        return v

    @field_validator("detailed_attributes")
    @classmethod
    def _validate_detailed_attributes(cls, v):
        if v is None:
            return v
        for key, value in v.items():
            if not (1 <= value <= 10):
                raise ValueError(f"Το χαρακτηριστικό '{key}' πρέπει να είναι από 1 έως 10")
        return v


class ScoutReportOut(BaseModel):
    id: str
    full_name: str
    club_name: Optional[str] = None
    age: Optional[int] = None
    position: Optional[str] = None
    role: Optional[str] = None
    league: Optional[str] = None
    jersey_number: Optional[int] = None
    nationality: Optional[str] = None
    strong_foot: Optional[str] = None
    goals_per_season: Optional[int] = None
    photo_path: Optional[str] = None
    team_id: Optional[str] = None
    team_name: Optional[str] = None

    positive_rating: Optional[int] = None
    positive_notes: Optional[str] = None
    negative_rating: Optional[int] = None
    negative_notes: Optional[str] = None
    physical_mental_rating: Optional[int] = None
    physical_mental_notes: Optional[str] = None

    detailed_attributes: dict[str, int] = {}

    conclusion_text: Optional[str] = None
    recommended: Optional[bool] = None
    potential_rating: Optional[int] = None

    created_by: Optional[str] = None
    created_by_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    is_mine: bool = False
    is_shortlisted: bool = False
    can_edit: bool = False
    is_publicly_shared: bool = False
    public_slug: Optional[str] = None


class ScoutReportPublishUpdate(BaseModel):
    is_publicly_shared: bool


class PublicScoutReportOut(BaseModel):
    """Δημόσια, μόνο-ανάγνωσης προβολή μιας αναφοράς scout — χωρίς login,
    ακόμα και για εξωτερικό άτομο. Δεν περιλαμβάνει εσωτερικά/ευαίσθητα
    πεδία (created_by, is_mine, can_edit, is_shortlisted, team_id)."""

    full_name: str
    club_name: Optional[str] = None
    age: Optional[int] = None
    position: Optional[str] = None
    role: Optional[str] = None
    league: Optional[str] = None
    jersey_number: Optional[int] = None
    nationality: Optional[str] = None
    strong_foot: Optional[str] = None
    goals_per_season: Optional[int] = None
    photo_path: Optional[str] = None

    positive_rating: Optional[int] = None
    positive_notes: Optional[str] = None
    negative_rating: Optional[int] = None
    negative_notes: Optional[str] = None
    physical_mental_rating: Optional[int] = None
    physical_mental_notes: Optional[str] = None

    detailed_attributes: dict[str, int] = {}

    conclusion_text: Optional[str] = None
    recommended: Optional[bool] = None
    potential_rating: Optional[int] = None



# ---------------------------------------------------------------------------
# Video Editing (ανάλυση βίντεο, τύπου Hudl Studio)
# ---------------------------------------------------------------------------
VALID_SHAPE_TYPES = {"circle", "arrow", "line", "rectangle", "freehand", "spotlight", "text"}


class StorageSettingsOut(BaseModel):
    configured: bool = False
    endpoint_url: Optional[str] = None
    bucket_name: Optional[str] = None
    region: Optional[str] = None


class StorageSettingsUpdate(BaseModel):
    endpoint_url: Optional[str] = None
    bucket_name: Optional[str] = None
    access_key_id: Optional[str] = None
    secret_access_key: Optional[str] = None
    region: Optional[str] = None


class VideoAnalysisOut(BaseModel):
    id: str
    team_id: str
    team_name: Optional[str] = None
    title: str
    description: Optional[str] = None
    duration_seconds: Optional[int] = None
    file_size_bytes: Optional[int] = None
    status: str
    uploaded_by: Optional[str] = None
    uploaded_by_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    playback_url: Optional[str] = None
    can_edit: bool = False


class VideoAnnotationCreate(BaseModel):
    shape_type: str
    shape_data: dict
    start_time: float
    end_time: float

    @field_validator("shape_type")
    @classmethod
    def _validate_shape_type(cls, v):
        if v not in VALID_SHAPE_TYPES:
            raise ValueError(f"Μη έγκυρος τύπος σχήματος — επιτρέπονται: {', '.join(sorted(VALID_SHAPE_TYPES))}")
        return v

    @field_validator("end_time")
    @classmethod
    def _validate_time_range(cls, v, info):
        start = info.data.get("start_time")
        if start is not None and v < start:
            raise ValueError("Το end_time δεν μπορεί να είναι πριν το start_time")
        return v


class VideoAnnotationUpdate(BaseModel):
    shape_data: Optional[dict] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None


class VideoAnnotationOut(BaseModel):
    id: str
    video_id: str
    shape_type: str
    shape_data: dict
    start_time: float
    end_time: float
    created_by: Optional[str] = None
    created_at: datetime


# ---------------------------------------------------------------------------
# Ασφάλεια — μπλοκαρισμένα IP και καταγραφή ύποπτης δραστηριότητας
# ---------------------------------------------------------------------------
class BannedIPOut(BaseModel):
    id: str
    ip_address: str
    reason: str
    strike_count: int
    is_permanent: bool
    banned_at: datetime
    banned_until: Optional[datetime] = None
    banned_by: Optional[str] = None
    banned_by_name: Optional[str] = None


class BanIPRequest(BaseModel):
    ip_address: str
    reason: str
    permanent: bool = True


class SecurityEventOut(BaseModel):
    id: str
    ip_address: str
    event_type: str
    detail: Optional[str] = None
    endpoint: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class CaptchaSettingsOut(BaseModel):
    configured: bool = False
    site_key: Optional[str] = None


class CaptchaSettingsUpdate(BaseModel):
    site_key: Optional[str] = None
    secret_key: Optional[str] = None


class PublicCaptchaConfigOut(BaseModel):
    """Δημόσιο endpoint (χωρίς authentication) — μόνο το site_key, ΠΟΤΕ το
    secret_key. Χρησιμοποιείται από τη φόρμα εγγραφής για να αποφασίσει αν
    θα δείξει το widget του CAPTCHA."""

    enabled: bool = False
    site_key: Optional[str] = None


# ---------------------------------------------------------------------------
# SMTP (αποστολή email — καλωσόρισμα, επαναφορά κωδικού)
# ---------------------------------------------------------------------------
class SMTPSettingsOut(BaseModel):
    configured: bool = False
    host: Optional[str] = None
    port: Optional[str] = None
    username: Optional[str] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None


class SMTPSettingsUpdate(BaseModel):
    host: Optional[str] = None
    port: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None


# ---------------------------------------------------------------------------
# Ενιαία, εμπλουτισμένη λίστα χρηστών για τη σελίδα Διαχείρισης Χρηστών
# (admin) — μαζεύει σε ένα μόνο API call ό,τι χρειάζεται για αναζήτηση,
# ταξινόμηση, προτεραιότητα εγκρίσεων, και προεπισκόπηση εγγράφων.
# ---------------------------------------------------------------------------
class AdminUserDocumentOut(BaseModel):
    id: str
    document_type: str
    status: str
    content_type: Optional[str] = None
    rejection_reason: Optional[str] = None
    auto_verified: bool = False
    uploaded_at: datetime


class AdminUserListItem(BaseModel):
    id: str
    email: str
    username: str
    full_name: Optional[str] = None
    role: UserRole
    is_active: bool
    avatar_path: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    verification_level: int = 0
    leadership_approved: bool = False
    needs_approval: bool = False
    created_at: datetime
    documents: list[AdminUserDocumentOut] = []


# ---------------------------------------------------------------------------
# Ομαδικές συνομιλίες
# ---------------------------------------------------------------------------
class GroupMessageOut(BaseModel):
    id: str
    group_conversation_id: str
    sender_id: str
    sender_name: Optional[str] = None
    sender_avatar: Optional[str] = None
    content: str
    created_at: datetime

    class Config:
        from_attributes = True


class GroupMessageCreate(BaseModel):
    content: str = Field(min_length=1)


class GroupConversationParticipantOut(BaseModel):
    user_id: str
    full_name: Optional[str] = None
    avatar_path: Optional[str] = None


class GroupConversationOut(BaseModel):
    id: str
    name: Optional[str] = None
    related_team_id: Optional[str] = None
    related_team_name: Optional[str] = None
    participants: list[GroupConversationParticipantOut] = []
    last_message: Optional[str] = None
    last_message_sender_name: Optional[str] = None
    last_message_at: Optional[datetime] = None
    unread_count: int = 0
    created_at: datetime


class GroupConversationCreate(BaseModel):
    participant_ids: list[str] = Field(min_length=1)
    name: Optional[str] = None


class ClubPersonOut(BaseModel):
    id: str
    full_name: Optional[str] = None
    username: str
    avatar_path: Optional[str] = None
    role: UserRole
    team_id: str
    team_name: str


class StartConversationRequest(BaseModel):
    other_user_id: str


class StaffRoleTitleUpdate(BaseModel):
    role_title: str


class AdminCreateUserRequest(BaseModel):
    email: EmailStr
    username: str
    password: str = Field(min_length=8)
    full_name: Optional[str] = None
    role: UserRole
    # ΑΦΜ ομάδας — προαιρετικό εδώ (σε αντίθεση με τη δημόσια εγγραφή),
    # αφού ο admin δημιουργεί προσωπικά τον λογαριασμό.
    tax_id: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
