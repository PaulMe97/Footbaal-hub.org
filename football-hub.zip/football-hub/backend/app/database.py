from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import DATABASE_URL

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency: δίνει ένα DB session ανά request και το κλείνει μετά."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def run_light_migrations():
    """Lightweight dev-only migration: προσθέτει νέες στήλες σε υπάρχοντα SQLite
    tables χωρίς να χρειάζεται να διαγράψεις τη βάση. Δεν κάνει τίποτα σε
    production (PostgreSQL) — εκεί χρησιμοποίησε Alembic."""
    if not DATABASE_URL.startswith("sqlite"):
        return
    inspector = inspect(engine)

    if inspector.has_table("match_players"):
        existing_columns = {c["name"] for c in inspector.get_columns("match_players")}
        if "is_mvp" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE match_players ADD COLUMN is_mvp BOOLEAN DEFAULT 0"))
                conn.commit()

    if inspector.has_table("tactical_boards"):
        existing_columns = {c["name"] for c in inspector.get_columns("tactical_boards")}
        if "training_session_id" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(
                    text("ALTER TABLE tactical_boards ADD COLUMN training_session_id VARCHAR")
                )
                conn.commit()

    if inspector.has_table("teams"):
        existing_columns = {c["name"] for c in inspector.get_columns("teams")}
        if "owner_id" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE teams ADD COLUMN owner_id VARCHAR"))
                # Backfill: όλες οι υπάρχουσες ομάδες ανατίθενται στον πρώτο Super
                # Admin, ώστε οι εγκαταστάσεις με έναν χρήστη να συνεχίσουν να
                # βλέπουν τα δεδομένα τους όπως πριν — χωρίς να γίνουν ορατές σε
                # νέους coach λογαριασμούς που θα δημιουργηθούν στο εξής.
                first_admin = conn.execute(
                    text("SELECT id FROM users WHERE role = 'super_admin' ORDER BY created_at LIMIT 1")
                ).fetchone()
                if first_admin:
                    conn.execute(
                        text("UPDATE teams SET owner_id = :owner_id WHERE owner_id IS NULL"),
                        {"owner_id": first_admin[0]},
                    )
                conn.commit()

    if inspector.has_table("teams"):
        existing_columns = {c["name"] for c in inspector.get_columns("teams")}
        with engine.connect() as conn:
            if "country_id" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN country_id VARCHAR"))
            if "federation_id" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN federation_id VARCHAR"))
            if "league_tier" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE teams ADD COLUMN league_tier VARCHAR DEFAULT 'regional'")
                )
            if "is_public_scouting" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE teams ADD COLUMN is_public_scouting BOOLEAN DEFAULT 1")
                )
            if "is_publicly_shared" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE teams ADD COLUMN is_publicly_shared BOOLEAN DEFAULT 0")
                )
            if "public_slug" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN public_slug VARCHAR"))
            if "public_show_roster" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE teams ADD COLUMN public_show_roster BOOLEAN DEFAULT 1")
                )
            # Το tier "u19" μετονομάστηκε σε γενικότερο "academy" (καλύπτει
            # όλες τις ηλικίες ακαδημίας, όχι μόνο Κ19).
            conn.execute(text("UPDATE teams SET league_tier = 'academy' WHERE league_tier = 'u19'"))
            conn.commit()

    if inspector.has_table("team_listings"):
        existing_columns = {c["name"] for c in inspector.get_columns("team_listings")}
        if "expires_at" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE team_listings ADD COLUMN expires_at DATETIME"))
                # Αγγελίες που υπήρχαν πριν από αυτό το feature παίρνουν 3 μέρες
                # προθεσμία από τώρα, ώστε να μη μείνουν επ' αόριστον ανοιχτές.
                conn.execute(
                    text(
                        "UPDATE team_listings SET expires_at = datetime(created_at, '+3 days') "
                        "WHERE expires_at IS NULL"
                    )
                )
                conn.commit()

    if inspector.has_table("player_join_requests"):
        existing_columns = {c["name"] for c in inspector.get_columns("player_join_requests")}
        if "date_of_birth" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE player_join_requests ADD COLUMN date_of_birth DATE"))
                conn.commit()

    if inspector.has_table("notifications"):
        existing_columns = {c["name"] for c in inspector.get_columns("notifications")}
        if "related_team_id" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE notifications ADD COLUMN related_team_id VARCHAR"))
                conn.commit()

    if inspector.has_table("staff_assignment_offers"):
        existing_columns = {c["name"] for c in inspector.get_columns("staff_assignment_offers")}
        with engine.connect() as conn:
            if "new_role" not in existing_columns:
                conn.execute(text("ALTER TABLE staff_assignment_offers ADD COLUMN new_role VARCHAR"))
            if "season" not in existing_columns:
                conn.execute(text("ALTER TABLE staff_assignment_offers ADD COLUMN season VARCHAR"))
            conn.commit()

    if inspector.has_table("academy_fee_settings"):
        existing_columns = {c["name"] for c in inspector.get_columns("academy_fee_settings")}
        if "kit_template" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE academy_fee_settings ADD COLUMN kit_template VARCHAR"))
                conn.commit()

    if inspector.has_table("users"):
        existing_columns = {c["name"] for c in inspector.get_columns("users")}
        if "phone" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE users ADD COLUMN phone VARCHAR"))
                conn.commit()

    if inspector.has_table("teams"):
        existing_columns = {c["name"] for c in inspector.get_columns("teams")}
        with engine.connect() as conn:
            if "league_level_id" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN league_level_id VARCHAR"))
            if "league_group_id" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN league_group_id VARCHAR"))
            if "academy_age_group" not in existing_columns:
                conn.execute(text("ALTER TABLE teams ADD COLUMN academy_age_group VARCHAR"))
            conn.commit()

    if inspector.has_table("players"):
        existing_columns = {c["name"] for c in inspector.get_columns("players")}
        with engine.connect() as conn:
            if "transfer_status" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE players ADD COLUMN transfer_status VARCHAR DEFAULT 'not_listed'")
                )
            if "transfer_notes" not in existing_columns:
                conn.execute(text("ALTER TABLE players ADD COLUMN transfer_notes TEXT"))
            if "transfer_status_change_count" not in existing_columns:
                conn.execute(
                    text(
                        "ALTER TABLE players ADD COLUMN transfer_status_change_count INTEGER DEFAULT 0"
                    )
                )
            if "transfer_status_season_key" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE players ADD COLUMN transfer_status_season_key VARCHAR")
                )
            conn.commit()

    if inspector.has_table("users"):
        existing_columns = {c["name"] for c in inspector.get_columns("users")}
        with engine.connect() as conn:
            if "linked_player_id" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN linked_player_id VARCHAR"))
            if "avatar_path" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN avatar_path VARCHAR"))
            if "bio" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN bio TEXT"))
            if "is_staff_visible" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN is_staff_visible BOOLEAN DEFAULT 0"))
            if "team_tax_id" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN team_tax_id VARCHAR"))
            if "gdpr_consent_at" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN gdpr_consent_at DATETIME"))
            if "staff_availability" not in existing_columns:
                conn.execute(
                    text("ALTER TABLE users ADD COLUMN staff_availability VARCHAR DEFAULT 'not_listed'")
                )
            if "linkedin_url" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN linkedin_url VARCHAR"))
            if "show_linkedin" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN show_linkedin BOOLEAN DEFAULT 0"))
            if "verification_level" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN verification_level INTEGER DEFAULT 0"))
            if "document_consent_at" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN document_consent_at DATETIME"))
            conn.commit()

    if inspector.has_table("users"):
        existing_columns = {c["name"] for c in inspector.get_columns("users")}
        with engine.connect() as conn:
            if "desired_staff_role" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN desired_staff_role VARCHAR"))
            if "origin_federation_id" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN origin_federation_id VARCHAR"))
            if "desired_federation_ids" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN desired_federation_ids VARCHAR"))
            if "club_verified" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN club_verified BOOLEAN DEFAULT 0"))
            if "leadership_approved" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN leadership_approved BOOLEAN DEFAULT 0"))
            if "date_of_birth" not in existing_columns:
                conn.execute(text("ALTER TABLE users ADD COLUMN date_of_birth DATE"))
            conn.commit()

    if inspector.has_table("team_listings"):
        existing_columns = {c["name"] for c in inspector.get_columns("team_listings")}
        if "target_federation_ids" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE team_listings ADD COLUMN target_federation_ids VARCHAR"))
                conn.commit()

    if inspector.has_table("verification_documents"):
        existing_columns = {c["name"] for c in inspector.get_columns("verification_documents")}
        if "auto_verified" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(
                    text("ALTER TABLE verification_documents ADD COLUMN auto_verified BOOLEAN DEFAULT 0")
                )
                conn.commit()
        if "content_type" not in existing_columns:
            with engine.connect() as conn:
                conn.execute(text("ALTER TABLE verification_documents ADD COLUMN content_type VARCHAR"))
                conn.commit()

    # Καθαρισμός: παλιές "καθολικές" ειδοποιήσεις (user_id IS NULL) που
    # δημιουργήθηκαν πριν διορθωθεί το bug όπου νέος αγώνας/προπόνηση/
    # τραυματισμός έστελνε ειδοποίηση σε ΟΛΟΥΣ τους χρήστες της πλατφόρμας
    # αντί μόνο σε όσους σχετίζονται με τη συγκεκριμένη ομάδα. Τρέχει σε κάθε
    # εκκίνηση — μετά την πρώτη φορά δεν βρίσκει τίποτα να διαγράψει.
    if inspector.has_table("notifications"):
        with engine.connect() as conn:
            conn.execute(text("DELETE FROM notifications WHERE user_id IS NULL"))
            conn.commit()
