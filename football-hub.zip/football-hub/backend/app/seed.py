"""
Δημιουργεί demo δεδομένα για testing.
Εκτέλεση: python -m app.seed
"""
from datetime import date

from app.auth import hash_password
from app.database import Base, SessionLocal, engine
from app.models import Player, PlayerPosition, PlayerStatus, PreferredFoot, Team, User, UserRole

Base.metadata.create_all(bind=engine)

db = SessionLocal()

try:
    if db.query(User).count() == 0:
        admin = User(
            email="admin@footballhub.local",
            username="admin",
            full_name="Super Admin",
            hashed_password=hash_password("admin12345"),
            role=UserRole.SUPER_ADMIN,
        )
        db.add(admin)
        print("✔ Δημιουργήθηκε ο χρήστης admin / admin12345")

    if db.query(Team).count() == 0:
        team_a = Team(
            name="Α Ερασιτεχνικό",
            category="Ανδρικό",
            division="Α Ερασιτεχνική",
            league="ΕΠΣ",
            season="2025-2026",
            home_stadium="Δημοτικό Στάδιο",
            primary_color="#3E7D52",
            secondary_color="#0A0F0D",
            coach_name="Γιώργος Παπαδόπουλος",
            description="Πρώτη ανδρική ομάδα του συλλόγου.",
        )
        academy = Team(
            name="Ακαδημία Κ16",
            category="Ακαδημία",
            division="Κ16",
            league="Τοπικό Πρωτάθλημα Νέων",
            season="2025-2026",
            home_stadium="Δημοτικό Στάδιο",
            primary_color="#D8FF5C",
            secondary_color="#0A0F0D",
            coach_name="Νίκος Ιωάννου",
            league_tier="academy",
        )
        db.add_all([team_a, academy])
        db.commit()

        players = [
            Player(
                first_name="Γιάννης",
                last_name="Καραγιάννης",
                date_of_birth=date(1999, 3, 12),
                nationality="Ελλάδα",
                player_number=1,
                preferred_foot=PreferredFoot.RIGHT,
                height_cm=188,
                weight_kg=82,
                position=PlayerPosition.GK,
                current_team_id=team_a.id,
                status=PlayerStatus.FIT,
            ),
            Player(
                first_name="Δημήτρης",
                last_name="Νικολάου",
                date_of_birth=date(2001, 7, 5),
                nationality="Ελλάδα",
                player_number=4,
                preferred_foot=PreferredFoot.RIGHT,
                height_cm=184,
                weight_kg=78,
                position=PlayerPosition.CB,
                current_team_id=team_a.id,
                status=PlayerStatus.FIT,
            ),
            Player(
                first_name="Κώστας",
                last_name="Αντωνίου",
                date_of_birth=date(2000, 11, 20),
                nationality="Ελλάδα",
                player_number=10,
                preferred_foot=PreferredFoot.LEFT,
                height_cm=176,
                weight_kg=70,
                position=PlayerPosition.AM,
                current_team_id=team_a.id,
                status=PlayerStatus.INJURED,
                injury_status="Ενεργός τραυματισμός",
                injury_type="Διάστρεμμα αστραγάλου",
                injury_date=date(2026, 7, 10),
                expected_return=date(2026, 8, 15),
            ),
            Player(
                first_name="Μιχάλης",
                last_name="Σταύρου",
                date_of_birth=date(2010, 2, 18),
                nationality="Ελλάδα",
                player_number=9,
                preferred_foot=PreferredFoot.RIGHT,
                height_cm=165,
                weight_kg=55,
                position=PlayerPosition.ST,
                current_team_id=academy.id,
                status=PlayerStatus.FIT,
            ),
        ]
        db.add_all(players)
        db.commit()
        print("✔ Δημιουργήθηκαν demo ομάδες και παίκτες")

    db.commit()
    print("Seeding ολοκληρώθηκε.")
finally:
    db.close()
