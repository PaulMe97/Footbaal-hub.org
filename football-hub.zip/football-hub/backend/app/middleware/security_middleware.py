"""
Middleware ασφάλειας — τρέχει σε ΚΑΘΕ request πριν φτάσει σε οποιονδήποτε
router. Ελέγχει (με αυτή τη σειρά):
  1. Είναι το IP ήδη μπλοκαρισμένο; -> 403 άμεσα, χωρίς να προχωρήσει άλλο.
  2. (Μόνο για μη-τοπικά IPs) Ξεπέρασε το IP το γενικό όριο αιτημάτων
     (rate limit); -> 429. Το τοπικό/ιδιωτικό δίκτυο (π.χ. localhost)
     εξαιρείται εντελώς από αυτό τον έλεγχο.
  3. Είναι το User-Agent γνωστό εργαλείο επίθεσης (sqlmap, nikto κ.λπ.);
     -> μπλοκάρισμα άμεσα.
  4. Περιέχει το path/query string pattern SQL injection, XSS ή path
     traversal; -> καταγραφή· μετά από STRIKE_THRESHOLD τέτοια μέσα σε
     STRIKE_WINDOW_MINUTES, αυτόματο μπλοκάρισμα (εξαιρείται επίσης το
     τοπικό/ιδιωτικό δίκτυο).
Προσθέτει επίσης βασικά security headers σε κάθε response.
"""
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from app.database import SessionLocal
from app.services import security_service

# Paths που εξαιρούνται από τον έλεγχο κακόβουλων patterns (στατικά αρχεία,
# API docs) — εκεί τα query strings/παράμετροι δεν αντιπροσωπεύουν είσοδο
# χρήστη προς επεξεργασία, οπότε δεν χρειάζεται ανίχνευση.
EXEMPT_PATH_PREFIXES = ("/media/", "/docs", "/openapi.json", "/redoc")

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=63072000; includeSubDomains",
}


class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        ip = security_service.get_client_ip(dict(request.headers), request.client.host if request.client else "")
        path = request.url.path
        is_exempt = path.startswith(EXEMPT_PATH_PREFIXES)
        # Τοπικό/ιδιωτικό δίκτυο (π.χ. localhost κατά την ανάπτυξη) — δεν
        # έχει νόημα rate limiting εκεί, μιας που όλη η κίνηση ενός developer
        # (πολλαπλά tabs, polling ειδοποιήσεων/μηνυμάτων) μοιράζεται το ίδιο
        # IP. Δεν επηρεάζει καθόλου την ασφάλεια σε πραγματικό deployment.
        is_local = security_service.is_private_or_loopback_ip(ip)

        db = SessionLocal()
        try:
            banned = security_service.is_banned(db, ip)
            if banned:
                return self._blocked_response(
                    403, "Η πρόσβασή σου έχει μπλοκαριστεί λόγω ύποπτης δραστηριότητας."
                )

            if not is_local and security_service.check_rate_limit(ip):
                security_service.record_security_event(
                    db, ip, "rate_limit_exceeded", endpoint=path, user_agent=request.headers.get("user-agent")
                )
                return self._blocked_response(429, "Πάρα πολλά αιτήματα — δοκίμασε ξανά σε λίγο.")

            if not is_exempt:
                user_agent = request.headers.get("user-agent")
                if security_service.check_malicious_user_agent(user_agent):
                    security_service.record_security_event(
                        db, ip, "known_attack_tool", detail=user_agent, endpoint=path, user_agent=user_agent
                    )
                    return self._blocked_response(403, "Η πρόσβασή σου έχει μπλοκαριστεί.")

                pattern_hit = security_service.check_malicious_patterns(path, request.url.query)
                if pattern_hit:
                    security_service.record_security_event(
                        db, ip, pattern_hit, detail=str(request.url), endpoint=path, user_agent=user_agent
                    )
                    return self._blocked_response(403, "Το αίτημα απορρίφθηκε.")
        finally:
            db.close()

        response = await call_next(request)
        for header, value in SECURITY_HEADERS.items():
            response.headers[header] = value
        return response

    @staticmethod
    def _blocked_response(status_code: int, message: str) -> JSONResponse:
        response = JSONResponse(status_code=status_code, content={"detail": message})
        for header, value in SECURITY_HEADERS.items():
            response.headers[header] = value
        return response
