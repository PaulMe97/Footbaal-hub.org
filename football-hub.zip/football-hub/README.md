# FootballHub — Football Manager & Analysis Platform

Πλήρες σύστημα διαχείρισης ποδοσφαιρικών ομάδων, παικτών, προπονήσεων, αγώνων και
tactical analysis. Αυτή η **Φάση 1** παραδίδει ένα πραγματικά λειτουργικό core:

- Authentication (JWT, ο πρώτος χρήστης γίνεται αυτόματα Super Admin)
- Dashboard με πραγματικά στατιστικά (όχι mock data)
- Πλήρες Team management (CRUD + upload λογότυπου + roster)
- Πλήρες Player management (CRUD + upload φωτογραφίας + ιατρικές πληροφορίες)
- Πλήρες relational database schema για ΟΛΑ τα modules (Matches, Trainings,
  Injuries, Tactical Board, Player Movement, Notifications, Calendar, AI Reports,
  Documents) — έτοιμο ώστε οι επόμενες φάσεις να προσθέτουν μόνο routers/UI.

Τα modules Matches / Trainings / Calendar / Tactical Board / Reports /
Notifications / Settings εμφανίζονται στο sidebar ως "έρχεται σύντομα" και θα
ενεργοποιηθούν σε επόμενες φάσεις πάνω στην ίδια αρχιτεκτονική.

---

## 1. Τεχνολογίες

| Layer     | Τεχνολογία                                    |
|-----------|------------------------------------------------|
| Frontend  | React 18 + TypeScript + Vite + Tailwind CSS     |
| Backend   | Python 3.11+ + FastAPI + SQLAlchemy             |
| Database  | SQLite (development) / PostgreSQL (production)  |
| Auth      | JWT (python-jose) + bcrypt (passlib)            |
| AI        | Modular service layer (Anthropic/OpenAI-ready)  |

---

## 2. Προαπαιτούμενα (Windows)

Εγκατέστησε πρώτα:

1. **Python 3.11 ή νεότερο** — https://www.python.org/downloads/
   Κατά την εγκατάσταση, τσέκαρε το **"Add python.exe to PATH"**.
2. **Node.js 18 LTS ή νεότερο** — https://nodejs.org/
3. (Προαιρετικό) **Git** — https://git-scm.com/download/win
4. (Προαιρετικό, μόνο για production) **PostgreSQL** — https://www.postgresql.org/download/windows/

Άνοιξε **PowerShell** ή **Command Prompt** και επιβεβαίωσε τις εγκαταστάσεις:

```powershell
python --version
node --version
npm --version
```

---

## 3. Αποσυμπίεση project

Αποσυμπίεσε το `football-hub.zip` κάπου βολικά, π.χ. `C:\Projects\football-hub`.

Θα δεις δύο φακέλους:

```
football-hub/
  backend/     ← FastAPI API + database
  frontend/    ← React app
```

Άνοιξε τον φάκελο `football-hub` στο **VS Code** (`File > Open Folder`).

---

## 4. Εγκατάσταση Backend

Στο VS Code, άνοιξε ένα terminal (`Terminal > New Terminal`) και εκτέλεσε:

```powershell
cd backend

# Δημιουργία virtual environment
python -m venv venv

# Ενεργοποίηση (PowerShell)
.\venv\Scripts\Activate.ps1

# Αν το PowerShell μπλοκάρει το script, τρέξε πρώτα μία φορά ως admin:
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Εγκατάσταση dependencies
pip install -r requirements.txt

# Αντιγραφή του .env
copy .env.example .env
```

Άνοιξε το `backend\.env` και άλλαξε το `JWT_SECRET_KEY` σε ένα δικό σου τυχαίο string
(π.χ. οποιοδήποτε μεγάλο κείμενο). Για development, το `DATABASE_URL` μπορεί να μείνει
σχολιασμένο — θα χρησιμοποιηθεί αυτόματα SQLite.

### Δημιουργία demo δεδομένων (προαιρετικό αλλά συνιστάται για πρώτο test)

```powershell
python -m app.seed
```

Αυτό δημιουργεί:
- Χρήστη `admin` / κωδικό `admin12345` (Super Admin)
- 2 demo ομάδες (Α Ερασιτεχνικό, Ακαδημία Κ16)
- 4 demo παίκτες

### Εκκίνηση backend server

```powershell
uvicorn app.main:app --reload --reload-dir app --port 8000
```

Το API τρέχει στο `http://localhost:8000`. Interactive docs (Swagger UI) στο
`http://localhost:8000/docs`.

**Άφησε αυτό το terminal ανοιχτό** — ο server πρέπει να τρέχει συνέχεια όσο
χρησιμοποιείς την εφαρμογή.

---

## 5. Εγκατάσταση Frontend

Άνοιξε **δεύτερο terminal** στο VS Code (`+` στο terminal panel) και εκτέλεσε:

```powershell
cd frontend

npm install

copy .env.example .env
```

Το `frontend\.env` δείχνει ήδη στο `http://localhost:8000` — δεν χρειάζεται αλλαγή
αν το backend τρέχει τοπικά με τις default ρυθμίσεις.

### Εκκίνηση frontend

```powershell
npm run dev
```

Άνοιξε τον browser σου στο `http://localhost:5173`.

Κάνε login με `admin` / `admin12345` (αν έτρεξες το seed script) ή δημιούργησε
νέο λογαριασμό μέσω του endpoint `/api/auth/register` (π.χ. από το Swagger UI).

---

## 6. Καθημερινή χρήση

Κάθε φορά που θέλεις να δουλέψεις στην εφαρμογή, χρειάζεσαι **2 terminals ανοιχτά**:

**Terminal 1 — Backend:**
```powershell
cd backend
.\venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --reload-dir app --port 8000
```

**Terminal 2 — Frontend:**
```powershell
cd frontend
npm run dev
```

---

## 7. Δομή Backend

```
backend/
  app/
    main.py          ← FastAPI entrypoint, CORS, static media mount
    config.py        ← Ρυθμίσεις από environment variables
    database.py      ← SQLAlchemy engine/session
    models.py         ← Πλήρες relational schema (όλα τα entities)
    schemas.py        ← Pydantic request/response models
    auth.py           ← JWT + password hashing
    seed.py            ← Demo δεδομένα
    routers/
      auth.py          ← /api/auth/*
      teams.py         ← /api/teams/*
      players.py       ← /api/players/*
      dashboard.py     ← /api/dashboard/*
    storage/           ← Uploaded αρχεία (φωτογραφίες, λογότυπα)
  requirements.txt
  .env.example
```

## 8. Δομή Frontend

```
frontend/
  src/
    api/              ← Axios API calls (client, auth, teams, players, dashboard)
    context/           ← AuthContext (persistent login)
    components/
      layout/           ← Sidebar, Topbar, AppLayout
      ui/                ← Button, Input, Card, Badge, Modal, Toast, EmptyState
      ProtectedRoute.tsx
    pages/
      Login.tsx
      Dashboard.tsx
      teams/            ← TeamsList, TeamDetail, TeamForm
      players/           ← PlayersList, PlayerDetail, PlayerForm
      Placeholder.tsx    ← "έρχεται σύντομα" σελίδα για μελλοντικά modules
    App.tsx              ← Routing
  package.json
  tailwind.config.js     ← Design tokens (χρώματα, γραμματοσειρές)
  .env.example
```

---

## 8α. Πολλοί Προπονητές — Απομόνωση Δεδομένων

Κάθε ομάδα ανήκει στον χρήστη (coach) που την δημιούργησε (`owner_id`). Ένας
προπονητής (ρόλος διαφορετικός από Super Admin) βλέπει **μόνο** τις δικές
του ομάδες και ό,τι συνδέεται με αυτές (παίκτες, αγώνες, προπονήσεις,
tactical boards, ημερολόγιο, AI reports). Ο ρόλος **Super Admin** βλέπει τα
πάντα.

- Κάθε coach μπορεί να δημιουργήσει έως **3 ομάδες**.
- Οι υπάρχουσες ομάδες (από πριν αυτό το feature) ανατίθενται αυτόματα στον
  πρώτο Super Admin κατά το πρώτο restart του backend μετά το update — δεν
  χάνεις δεδομένα, απλά πλέον ανήκουν επίσημα σε λογαριασμό.
- Ο ρόλος **Player** έχει πρόσβαση μόνο για ανάγνωση και δεν βλέπει καθόλου
  τις ενότητες Προπονήσεις, Ημερολόγιο, Tactical Board, Αναφορές.

## 9. Μετάβαση σε PostgreSQL (production)

1. Δημιούργησε μια βάση:
   ```sql
   CREATE DATABASE footballhub;
   CREATE USER footballhub_user WITH PASSWORD 'your-password';
   GRANT ALL PRIVILEGES ON DATABASE footballhub TO footballhub_user;
   ```
2. Στο `backend\.env`, όρισε:
   ```
   DATABASE_URL=postgresql://footballhub_user:your-password@localhost:5432/footballhub
   ```
3. Επανεκκίνησε τον backend server — οι πίνακες δημιουργούνται αυτόματα.

## 10. AI Setup (μελλοντικό feature)

Το AI service layer είναι ήδη modular (`AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL` στο
`.env`). Θα ενεργοποιηθεί σε επόμενη φάση μαζί με τα Match Reports.

## 11. File Storage

Οι φωτογραφίες παικτών και τα λογότυπα ομάδων αποθηκεύονται τοπικά στο
`backend/app/storage/` και σερβίρονται μέσω `http://localhost:8000/media/...`.
Επιτρέπονται μόνο JPG, PNG, WEBP, έως 5MB (ρυθμίζεται στο `.env`).

---

## 12. Επόμενες φάσεις (roadmap)

Η βάση δεδομένων έχει ήδη το schema έτοιμο για:

- Training sessions + attendance tracking
- Match management + match reports + player performance
- Tactical board (formations, drag & drop, saved scenarios)
- Player movement analysis πάνω στο γήπεδο
- Notifications center
- Calendar (month/week/day views)
- AI-generated match/player/team analysis
- PDF export για όλα τα reports

Κάθε επόμενη φάση θα προσθέτει routers στο backend και σελίδες/components στο
frontend, χωρίς αλλαγές στο υπάρχον schema.

---

## 13. Συνηθισμένα προβλήματα

**"Δεν αναγνωρίζεται το python/node ως εντολή"**
→ Δεν έγινε προσθήκη στο PATH κατά την εγκατάσταση. Επανεγκατάστησε τσεκάροντας
  "Add to PATH", ή πρόσθεσέ το χειροκίνητα στις Environment Variables των Windows.

**PowerShell: "cannot be loaded because running scripts is disabled"**
→ Τρέξε ως Administrator: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

**Το frontend δεν συνδέεται με το backend (CORS ή Network Error)**
→ Βεβαιώσου ότι ο backend server τρέχει στο port 8000 και ότι το
  `frontend/.env` έχει `VITE_API_URL=http://localhost:8000`.

**Επαναλαμβανόμενα "Network Error" ειδικά όταν αποθηκεύεις συχνά (π.χ. Tactical
Board, γρήγορες αλλαγές)**
→ Αυτό συμβαίνει αν ξεκίνησες τον server με απλό `uvicorn app.main:app
  --reload` (χωρίς `--reload-dir app`): το SQLite αρχείο `footballhub.db`
  βρίσκεται στον ίδιο φάκελο `backend/` που παρακολουθεί ο file-watcher, οπότε
  κάθε αποθήκευση (που γράφει στη βάση) εκλαμβάνεται ως "αλλαγή κώδικα" και
  κάνει restart τον server ΜΕΣΑ στο ίδιο το request — εξ ου και το τυχαίο
  σφάλμα. Χρησιμοποίησε πάντα `--reload-dir app` (βλ. πάνω) ώστε ο watcher να
  παρακολουθεί μόνο τον πηγαίο κώδικα, όχι τη βάση δεδομένων.

**"Address already in use" στο port 8000 ή 5173**
→ Κάποια άλλη διεργασία χρησιμοποιεί το port. Άλλαξε port
  (`uvicorn app.main:app --reload --reload-dir app --port 8001`, και ενημέρωσε αντίστοιχα το
  `VITE_API_URL`) ή τερμάτισε τη διεργασία που το κατέχει.
