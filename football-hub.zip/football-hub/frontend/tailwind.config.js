/** @type {import('tailwindcss').Config} */
function withOpacity(varName) {
  return ({ opacityValue }) =>
    opacityValue !== undefined
      ? `rgb(var(${varName}) / ${opacityValue})`
      : `rgb(var(${varName}))`;
}

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        void: withOpacity("--color-void"),
        surface: withOpacity("--color-surface"),
        "surface-raised": withOpacity("--color-surface-raised"),
        line: withOpacity("--color-line"),
        "text-primary": withOpacity("--color-text-primary"),
        "text-muted": withOpacity("--color-text-muted"),
        pitch: {
          DEFAULT: withOpacity("--color-pitch"),
          light: withOpacity("--color-pitch-light"),
          dark: withOpacity("--color-pitch-dark"),
        },
        chalk: withOpacity("--color-chalk"),
        status: {
          fit: withOpacity("--color-status-fit"),
          injured: withOpacity("--color-status-injured"),
          doubtful: withOpacity("--color-status-doubtful"),
          suspended: withOpacity("--color-status-suspended"),
          unavailable: withOpacity("--color-status-unavailable"),
        },
      },
      fontFamily: {
        display: ["Oswald", "sans-serif"],
        body: ["Inter", "system-ui", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
      backgroundImage: {
        "pitch-lines": "repeating-linear-gradient(90deg, transparent, transparent 39px, rgba(216,255,92,0.05) 39px, rgba(216,255,92,0.05) 40px)",
      },
    },
  },
  plugins: [],
};
