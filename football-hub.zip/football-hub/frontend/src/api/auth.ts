import { apiClient } from "./client";
import type { User } from "../types";

export interface TokenResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export async function login(usernameOrEmail: string, password: string): Promise<TokenResponse> {
  const { data } = await apiClient.post<TokenResponse>("/api/auth/login", {
    username_or_email: usernameOrEmail,
    password,
  });
  return data;
}

export async function register(
  email: string,
  username: string,
  password: string,
  fullName?: string,
  role?: string,
  dateOfBirth?: string,
  taxId?: string,
  gdprConsent?: boolean,
  honeypot?: string,
  captchaToken?: string
): Promise<TokenResponse> {
  const { data } = await apiClient.post<TokenResponse>("/api/auth/register", {
    email,
    username,
    password,
    full_name: fullName,
    role,
    date_of_birth: dateOfBirth || undefined,
    tax_id: taxId || undefined,
    gdpr_consent: gdprConsent ?? false,
    honeypot: honeypot || undefined,
    captcha_token: captchaToken || undefined,
  });
  return data;
}

export async function fetchMe(): Promise<User> {
  const { data } = await apiClient.get<User>("/api/auth/me");
  return data;
}

export async function updateMe(payload: {
  full_name?: string;
  email?: string;
  bio?: string;
  phone?: string;
  date_of_birth?: string;
}): Promise<User> {
  const { data } = await apiClient.put<User>("/api/auth/me", payload);
  return data;
}

export async function changePassword(currentPassword: string, newPassword: string): Promise<void> {
  await apiClient.post("/api/auth/change-password", {
    current_password: currentPassword,
    new_password: newPassword,
  });
}

export interface ForgotPasswordResponse {
  message: string;
  reset_token?: string | null;
}

export async function forgotPassword(usernameOrEmail: string): Promise<ForgotPasswordResponse> {
  const { data } = await apiClient.post<ForgotPasswordResponse>("/api/auth/forgot-password", {
    username_or_email: usernameOrEmail,
  });
  return data;
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  await apiClient.post("/api/auth/reset-password", { token, new_password: newPassword });
}

export async function listUsers(): Promise<User[]> {
  const { data } = await apiClient.get<User[]>("/api/auth/users");
  return data;
}

export async function updateUserRole(userId: string, role: string): Promise<User> {
  const { data } = await apiClient.put<User>(`/api/auth/users/${userId}/role`, { role });
  return data;
}

export async function approveLeadership(userId: string): Promise<User> {
  const { data } = await apiClient.put<User>(`/api/auth/users/${userId}/approve-leadership`);
  return data;
}

export async function getAdminContact(): Promise<{ emails: string[] }> {
  const { data } = await apiClient.get<{ emails: string[] }>("/api/auth/admin-contact");
  return data;
}
