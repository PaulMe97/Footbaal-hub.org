import { apiClient } from "./client";
import type { PublicClubPage } from "../types";

export async function getPublicClubPage(slug: string): Promise<PublicClubPage> {
  const { data } = await apiClient.get<PublicClubPage>(`/api/public/club/${slug}`);
  return data;
}

export interface PublicScoutReport {
  full_name: string;
  club_name?: string | null;
  age?: number | null;
  position?: string | null;
  role?: string | null;
  league?: string | null;
  jersey_number?: number | null;
  nationality?: string | null;
  strong_foot?: string | null;
  goals_per_season?: number | null;
  photo_path?: string | null;

  positive_rating?: number | null;
  positive_notes?: string | null;
  negative_rating?: number | null;
  negative_notes?: string | null;
  physical_mental_rating?: number | null;
  physical_mental_notes?: string | null;

  detailed_attributes: Record<string, number>;

  conclusion_text?: string | null;
  recommended?: boolean | null;
  potential_rating?: number | null;
}

export async function getPublicScoutReport(slug: string): Promise<PublicScoutReport> {
  const { data } = await apiClient.get<PublicScoutReport>(`/api/public/scout-report/${slug}`);
  return data;
}
