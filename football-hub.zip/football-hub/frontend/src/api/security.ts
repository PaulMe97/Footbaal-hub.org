import { apiClient } from "./client";

export interface BannedIPItem {
  id: string;
  ip_address: string;
  reason: string;
  strike_count: number;
  is_permanent: boolean;
  banned_at: string;
  banned_until?: string | null;
  banned_by?: string | null;
  banned_by_name?: string | null;
}

export interface SecurityEventItem {
  id: string;
  ip_address: string;
  event_type: string;
  detail?: string | null;
  endpoint?: string | null;
  user_agent?: string | null;
  created_at: string;
}

export async function listBannedIPs(): Promise<BannedIPItem[]> {
  const { data } = await apiClient.get<BannedIPItem[]>("/api/security/banned-ips");
  return data;
}

export async function banIP(payload: {
  ip_address: string;
  reason: string;
  permanent?: boolean;
}): Promise<BannedIPItem> {
  const { data } = await apiClient.post<BannedIPItem>("/api/security/banned-ips", payload);
  return data;
}

export async function unbanIP(ipAddress: string): Promise<void> {
  await apiClient.delete(`/api/security/banned-ips/${encodeURIComponent(ipAddress)}`);
}

export async function listSecurityEvents(limit = 100): Promise<SecurityEventItem[]> {
  const { data } = await apiClient.get<SecurityEventItem[]>("/api/security/events", { params: { limit } });
  return data;
}

export interface CaptchaSettings {
  configured: boolean;
  site_key?: string | null;
}

export interface PublicCaptchaConfig {
  enabled: boolean;
  site_key?: string | null;
}

export async function getCaptchaSettings(): Promise<CaptchaSettings> {
  const { data } = await apiClient.get<CaptchaSettings>("/api/settings/captcha");
  return data;
}

export async function updateCaptchaSettings(payload: { site_key?: string; secret_key?: string }): Promise<CaptchaSettings> {
  const { data } = await apiClient.put<CaptchaSettings>("/api/settings/captcha", payload);
  return data;
}

export async function getPublicCaptchaConfig(): Promise<PublicCaptchaConfig> {
  const { data } = await apiClient.get<PublicCaptchaConfig>("/api/settings/captcha-public");
  return data;
}
