import { apiClient } from "./client";
import type { PlayerMonthlyPerformance } from "../types";

export async function getMonthlyPerformance(
  year: number,
  month: number,
  teamId?: string
): Promise<PlayerMonthlyPerformance[]> {
  const { data } = await apiClient.get<PlayerMonthlyPerformance[]>("/api/performance/monthly", {
    params: { year, month, team_id: teamId || undefined },
  });
  return data;
}
