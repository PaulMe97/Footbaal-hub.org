import { apiClient } from "./client";
import type { Injury, Player, PlayerStatistics } from "../types";

export interface PlayerFilters {
  search?: string;
  team_id?: string;
  position?: string;
  status?: string;
}

export async function listPlayers(filters: PlayerFilters = {}): Promise<Player[]> {
  const { data } = await apiClient.get<Player[]>("/api/players", { params: filters });
  return data;
}

export async function getPlayer(id: string): Promise<Player> {
  const { data } = await apiClient.get<Player>(`/api/players/${id}`);
  return data;
}

export async function createPlayer(payload: Partial<Player>): Promise<Player> {
  const { data } = await apiClient.post<Player>("/api/players", payload);
  return data;
}

export async function updatePlayer(id: string, payload: Partial<Player>): Promise<Player> {
  const { data } = await apiClient.put<Player>(`/api/players/${id}`, payload);
  return data;
}

export async function deletePlayer(id: string): Promise<void> {
  await apiClient.delete(`/api/players/${id}`);
}

export async function uploadPlayerPhoto(id: string, file: File): Promise<Player> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<Player>(`/api/players/${id}/photo`, form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function deletePlayerPhoto(id: string): Promise<Player> {
  const { data } = await apiClient.delete<Player>(`/api/players/${id}/photo`);
  return data;
}

export async function listPlayerInjuries(id: string): Promise<Injury[]> {
  const { data } = await apiClient.get<Injury[]>(`/api/players/${id}/injuries`);
  return data;
}

export interface MatchHistoryEntry {
  match_id: string;
  date: string;
  opponent?: string | null;
  rating?: number | null;
  goals: number;
  assists: number;
}

export async function getPlayerMatchHistory(id: string): Promise<MatchHistoryEntry[]> {
  const { data } = await apiClient.get<MatchHistoryEntry[]>(`/api/players/${id}/match-history`);
  return data;
}

export async function updatePlayerInjury(
  playerId: string,
  injuryId: string,
  payload: Partial<Pick<Injury, "injury_type" | "status" | "expected_return" | "actual_return" | "notes">>
): Promise<Injury> {
  const { data } = await apiClient.put<Injury>(
    `/api/players/${playerId}/injuries/${injuryId}`,
    payload
  );
  return data;
}

export async function deletePlayerInjury(playerId: string, injuryId: string): Promise<void> {
  await apiClient.delete(`/api/players/${playerId}/injuries/${injuryId}`);
}

export async function getPlayerStatistics(id: string): Promise<PlayerStatistics> {
  const { data } = await apiClient.get<PlayerStatistics>(`/api/players/${id}/statistics`);
  return data;
}

export async function updatePlayerStatistics(
  id: string,
  payload: Partial<Pick<PlayerStatistics, "matches_played" | "goals" | "assists" | "yellow_cards" | "red_cards">>
): Promise<PlayerStatistics> {
  const { data } = await apiClient.put<PlayerStatistics>(`/api/players/${id}/statistics`, payload);
  return data;
}

export async function incrementPlayerStatistic(
  id: string,
  field: "matches_played" | "goals" | "assists" | "yellow_cards" | "red_cards",
  delta = 1
): Promise<PlayerStatistics> {
  const { data } = await apiClient.post<PlayerStatistics>(`/api/players/${id}/statistics/increment`, {
    field,
    delta,
  });
  return data;
}

export async function getPlayerLinkedUser(playerId: string): Promise<string | null> {
  const { data } = await apiClient.get<{ user_id: string | null }>(`/api/players/${playerId}/linked-user`);
  return data.user_id;
}
