import { apiClient } from "./client";

export interface RenewalRequestItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  user_id: string;
  user_name?: string | null;
  current_season: string;
  next_season: string;
  status: string;
  hold_reason?: string | null;
  hold_deadline?: string | null;
  created_at: string;
}

export async function getPendingRenewals(): Promise<RenewalRequestItem[]> {
  const { data } = await apiClient.get<RenewalRequestItem[]>("/api/renewals/pending");
  return data;
}

export async function respondToRenewal(
  renewalId: string,
  decision: "accept" | "hold" | "reject",
  holdReason?: string
): Promise<RenewalRequestItem> {
  const { data } = await apiClient.post<RenewalRequestItem>(`/api/renewals/${renewalId}/respond`, {
    decision,
    hold_reason: holdReason,
  });
  return data;
}

export async function listTeamRenewals(teamId: string): Promise<RenewalRequestItem[]> {
  const { data } = await apiClient.get<RenewalRequestItem[]>(`/api/renewals/teams/${teamId}`);
  return data;
}

export async function resolveTeamRenewal(
  teamId: string,
  renewalId: string,
  action: "confirm" | "release"
): Promise<RenewalRequestItem> {
  const { data } = await apiClient.put<RenewalRequestItem>(
    `/api/renewals/teams/${teamId}/${renewalId}/resolve`,
    { action }
  );
  return data;
}
