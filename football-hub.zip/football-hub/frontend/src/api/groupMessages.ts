import { apiClient } from "./client";

export interface ClubPerson {
  id: string;
  full_name?: string | null;
  username: string;
  avatar_path?: string | null;
  role: string;
  team_id: string;
  team_name: string;
}

export interface GroupConversationParticipant {
  user_id: string;
  full_name?: string | null;
  avatar_path?: string | null;
}

export interface GroupConversationItem {
  id: string;
  name?: string | null;
  related_team_id?: string | null;
  related_team_name?: string | null;
  participants: GroupConversationParticipant[];
  last_message?: string | null;
  last_message_sender_name?: string | null;
  last_message_at?: string | null;
  unread_count: number;
  created_at: string;
}

export interface GroupMessageItem {
  id: string;
  group_conversation_id: string;
  sender_id: string;
  sender_name?: string | null;
  sender_avatar?: string | null;
  content: string;
  created_at: string;
}

export async function listClubPeople(): Promise<ClubPerson[]> {
  const { data } = await apiClient.get<ClubPerson[]>("/api/group-conversations/club-people");
  return data;
}

export async function listGroupConversations(): Promise<GroupConversationItem[]> {
  const { data } = await apiClient.get<GroupConversationItem[]>("/api/group-conversations");
  return data;
}

export async function createGroupConversation(
  participantIds: string[],
  name?: string
): Promise<GroupConversationItem> {
  const { data } = await apiClient.post<GroupConversationItem>("/api/group-conversations", {
    participant_ids: participantIds,
    name: name || undefined,
  });
  return data;
}

export async function getOrCreateTeamGroupChat(teamId: string): Promise<GroupConversationItem> {
  const { data } = await apiClient.post<GroupConversationItem>(`/api/group-conversations/team/${teamId}`);
  return data;
}

export async function getGroupMessages(conversationId: string): Promise<GroupMessageItem[]> {
  const { data } = await apiClient.get<GroupMessageItem[]>(
    `/api/group-conversations/${conversationId}/messages`
  );
  return data;
}

export async function sendGroupMessage(conversationId: string, content: string): Promise<GroupMessageItem> {
  const { data } = await apiClient.post<GroupMessageItem>(
    `/api/group-conversations/${conversationId}/messages`,
    { content }
  );
  return data;
}

export async function getGroupUnreadCount(): Promise<number> {
  const { data } = await apiClient.get<{ count: number }>("/api/group-conversations/unread-count");
  return data.count;
}
