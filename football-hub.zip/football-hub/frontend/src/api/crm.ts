import { apiClient } from "./client";

export interface CrmContact {
  user_id: string;
  full_name?: string | null;
  username: string;
  role: string;
  avatar_path?: string | null;
  email: string;
  phone?: string | null;
  teams: string[];
}

export interface CrmTeamOption {
  id: string;
  name: string;
}

export interface CrmTopic {
  id: string;
  team_id: string;
  team_name?: string | null;
  title: string;
  description?: string | null;
  category: string;
  priority: string;
  status: string;
  expires_at?: string | null;
  is_expired: boolean;
  created_by: string;
  created_by_name?: string | null;
  created_by_avatar?: string | null;
  comment_count: number;
  created_at: string;
  updated_at: string;
  resolved_at?: string | null;
}

export interface CrmTopicComment {
  id: string;
  author_id: string;
  author_name?: string | null;
  author_avatar?: string | null;
  content: string;
  created_at: string;
}

export interface CrmTopicDetail extends CrmTopic {
  comments: CrmTopicComment[];
}

export interface CrmStats {
  by_category: Record<string, number>;
  by_priority: Record<string, number>;
  by_status: Record<string, number>;
  urgent_open_count: number;
  expired_count: number;
  total_topics: number;
  resolved_this_month: number;
}

export async function listCrmContacts(): Promise<CrmContact[]> {
  const { data } = await apiClient.get<CrmContact[]>("/api/crm/contacts");
  return data;
}

export async function listCrmTeams(): Promise<CrmTeamOption[]> {
  const { data } = await apiClient.get<CrmTeamOption[]>("/api/crm/teams");
  return data;
}

export async function listCrmTopics(filters?: {
  team_id?: string;
  category?: string;
  priority?: string;
  status?: string;
}): Promise<CrmTopic[]> {
  const { data } = await apiClient.get<CrmTopic[]>("/api/crm/topics", { params: filters });
  return data;
}

export async function createCrmTopic(payload: {
  team_id: string;
  title: string;
  description?: string;
  category?: string;
  priority?: string;
  expires_at?: string;
}): Promise<CrmTopic> {
  const { data } = await apiClient.post<CrmTopic>("/api/crm/topics", payload);
  return data;
}

export async function getCrmTopic(topicId: string): Promise<CrmTopicDetail> {
  const { data } = await apiClient.get<CrmTopicDetail>(`/api/crm/topics/${topicId}`);
  return data;
}

export async function updateCrmTopic(
  topicId: string,
  payload: { status?: string; priority?: string; category?: string; title?: string; description?: string }
): Promise<CrmTopic> {
  const { data } = await apiClient.put<CrmTopic>(`/api/crm/topics/${topicId}`, payload);
  return data;
}

export async function deleteCrmTopic(topicId: string): Promise<void> {
  await apiClient.delete(`/api/crm/topics/${topicId}`);
}

export async function addCrmComment(topicId: string, content: string): Promise<CrmTopicDetail> {
  const { data } = await apiClient.post<CrmTopicDetail>(`/api/crm/topics/${topicId}/comments`, { content });
  return data;
}

export async function getCrmStats(): Promise<CrmStats> {
  const { data } = await apiClient.get<CrmStats>("/api/crm/stats");
  return data;
}
