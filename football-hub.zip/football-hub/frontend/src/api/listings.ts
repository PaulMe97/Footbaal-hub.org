import { apiClient } from "./client";
import type { ScoutingPlayer } from "../types";

export interface TeamListingItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  posted_by: string;
  listing_type: "staff" | "player";
  status: string;
  role_needed: string[];
  season?: string | null;
  employment_type?: string | null;
  position_needed: string[];
  min_age?: number | null;
  max_age?: number | null;
  target_federation_ids: string[];
  target_federation_names: string[];
  description?: string | null;
  created_at: string;
  expires_at?: string | null;
  application_count: number;
}

export interface ListingApplicationItem {
  id: string;
  listing_id: string;
  applicant_user_id: string;
  applicant_name?: string | null;
  applicant_role?: string | null;
  message?: string | null;
  status: string;
  created_at: string;
  can_respond: boolean;
  applicant_player?: ScoutingPlayer | null;
}

export interface TeamListingCreatePayload {
  listing_type: "staff" | "player";
  role_needed?: string[];
  season?: string;
  employment_type?: string;
  position_needed?: string[];
  min_age?: number;
  max_age?: number;
  target_federation_ids?: string[];
  description?: string;
}

export async function createListing(
  teamId: string,
  payload: TeamListingCreatePayload
): Promise<TeamListingItem> {
  const { data } = await apiClient.post<TeamListingItem>(`/api/teams/${teamId}/listings`, payload);
  return data;
}

export async function listTeamListings(teamId: string): Promise<TeamListingItem[]> {
  const { data } = await apiClient.get<TeamListingItem[]>(`/api/teams/${teamId}/listings`);
  return data;
}

export async function closeListing(teamId: string, listingId: string): Promise<TeamListingItem> {
  const { data } = await apiClient.put<TeamListingItem>(
    `/api/teams/${teamId}/listings/${listingId}/close`
  );
  return data;
}

export interface BrowseListingsFilters {
  listing_type?: string;
  role_needed?: string;
  position_needed?: string;
  season?: string;
  employment_type?: string;
  max_age?: number;
}

export async function browseListings(filters: BrowseListingsFilters = {}): Promise<TeamListingItem[]> {
  const { data } = await apiClient.get<TeamListingItem[]>("/api/scouting/listings", { params: filters });
  return data;
}

export async function applyToListing(
  listingId: string,
  message?: string
): Promise<ListingApplicationItem> {
  const { data } = await apiClient.post<ListingApplicationItem>(`/api/listings/${listingId}/apply`, {
    message,
  });
  return data;
}

export async function listListingApplications(listingId: string): Promise<ListingApplicationItem[]> {
  const { data } = await apiClient.get<ListingApplicationItem[]>(
    `/api/listings/${listingId}/applications`
  );
  return data;
}

export async function respondToListingApplication(
  listingId: string,
  applicationId: string,
  accept: boolean
): Promise<ListingApplicationItem> {
  const { data } = await apiClient.put<ListingApplicationItem>(
    `/api/listings/${listingId}/applications/${applicationId}/respond`,
    { accept }
  );
  return data;
}
