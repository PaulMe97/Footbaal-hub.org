import { apiClient } from "./client";

export interface ContractOfferItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  sender_id: string;
  sender_name?: string | null;
  player_user_id: string;
  years?: number | null;
  salary_details?: string | null;
  bonus_details?: string | null;
  status: string;
  created_at: string;
}

export async function sendContractOffer(
  teamId: string,
  payload: { player_user_id: string; years?: number; salary_details?: string; bonus_details?: string }
): Promise<ContractOfferItem> {
  const { data } = await apiClient.post<ContractOfferItem>(
    `/api/teams/${teamId}/contract-offers`,
    payload
  );
  return data;
}

export async function listMyContractOffers(): Promise<ContractOfferItem[]> {
  const { data } = await apiClient.get<ContractOfferItem[]>("/api/contract-offers/mine");
  return data;
}

export async function listTeamContractOffers(teamId: string): Promise<ContractOfferItem[]> {
  const { data } = await apiClient.get<ContractOfferItem[]>(`/api/teams/${teamId}/contract-offers`);
  return data;
}

export async function respondToContractOffer(
  offerId: string,
  accept: boolean
): Promise<ContractOfferItem> {
  const { data } = await apiClient.put<ContractOfferItem>(`/api/contract-offers/${offerId}/respond`, {
    accept,
  });
  return data;
}
