import { apiClient } from "./client";

export interface VideoAnalysisItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  title: string;
  description?: string | null;
  duration_seconds?: number | null;
  file_size_bytes?: number | null;
  status: "uploading" | "ready" | "failed";
  uploaded_by?: string | null;
  uploaded_by_name?: string | null;
  created_at: string;
  updated_at: string;
  playback_url?: string | null;
  can_edit: boolean;
}

export interface VideoAnnotationItem {
  id: string;
  video_id: string;
  shape_type: "circle" | "arrow" | "line" | "rectangle" | "freehand" | "spotlight" | "text";
  shape_data: Record<string, unknown>;
  start_time: number;
  end_time: number;
  created_by?: string | null;
  created_at: string;
}

export async function listVideos(teamId?: string): Promise<VideoAnalysisItem[]> {
  const { data } = await apiClient.get<VideoAnalysisItem[]>("/api/video-analysis", {
    params: teamId ? { team_id: teamId } : {},
  });
  return data;
}

export async function getVideo(id: string): Promise<VideoAnalysisItem> {
  const { data } = await apiClient.get<VideoAnalysisItem>(`/api/video-analysis/${id}`);
  return data;
}

export async function uploadVideo(
  payload: { team_id: string; title: string; description: string; duration_seconds: number; file: File },
  onProgress?: (percent: number) => void
): Promise<VideoAnalysisItem> {
  const form = new FormData();
  form.append("team_id", payload.team_id);
  form.append("title", payload.title);
  form.append("description", payload.description);
  form.append("duration_seconds", String(Math.round(payload.duration_seconds)));
  form.append("file", payload.file);
  const { data } = await apiClient.post<VideoAnalysisItem>("/api/video-analysis/upload", form, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: (evt) => {
      if (onProgress && evt.total) {
        onProgress(Math.round((evt.loaded / evt.total) * 100));
      }
    },
  });
  return data;
}

export async function deleteVideo(id: string): Promise<void> {
  await apiClient.delete(`/api/video-analysis/${id}`);
}

export async function listAnnotations(videoId: string): Promise<VideoAnnotationItem[]> {
  const { data } = await apiClient.get<VideoAnnotationItem[]>(`/api/video-analysis/${videoId}/annotations`);
  return data;
}

export async function createAnnotation(
  videoId: string,
  payload: {
    shape_type: VideoAnnotationItem["shape_type"];
    shape_data: Record<string, unknown>;
    start_time: number;
    end_time: number;
  }
): Promise<VideoAnnotationItem> {
  const { data } = await apiClient.post<VideoAnnotationItem>(
    `/api/video-analysis/${videoId}/annotations`,
    payload
  );
  return data;
}

export async function updateAnnotation(
  videoId: string,
  annotationId: string,
  payload: Partial<Pick<VideoAnnotationItem, "shape_data" | "start_time" | "end_time">>
): Promise<VideoAnnotationItem> {
  const { data } = await apiClient.put<VideoAnnotationItem>(
    `/api/video-analysis/${videoId}/annotations/${annotationId}`,
    payload
  );
  return data;
}

export async function deleteAnnotation(videoId: string, annotationId: string): Promise<void> {
  await apiClient.delete(`/api/video-analysis/${videoId}/annotations/${annotationId}`);
}
