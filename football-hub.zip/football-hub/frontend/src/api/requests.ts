import { apiClient } from "./client";

export interface TeamJoinRequestItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  applicant_user_id: string;
  applicant_name?: string | null;
  applicant_role?: string | null;
  message?: string | null;
  status: string;
  created_at: string;
  expires_at: string;
  can_respond: boolean;
}

export interface PlayerJoinRequestItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  applicant_user_id: string;
  applicant_name?: string | null;
  message?: string | null;
  status: string;
  created_at: string;
  expires_at: string;
  can_respond: boolean;
}

export interface TeamAccessGrantItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  user_id: string;
  full_name?: string | null;
  username?: string | null;
  role_title?: string | null;
}

// --- Team (coach/staff) join requests ---------------------------------------
export async function applyToTeam(teamId: string, message?: string): Promise<TeamJoinRequestItem> {
  const { data } = await apiClient.post<TeamJoinRequestItem>(`/api/teams/${teamId}/join-requests`, {
    message,
  });
  return data;
}

export async function listMyTeamRequests(): Promise<TeamJoinRequestItem[]> {
  const { data } = await apiClient.get<TeamJoinRequestItem[]>("/api/join-requests/mine");
  return data;
}

export async function listTeamJoinRequests(teamId: string): Promise<TeamJoinRequestItem[]> {
  const { data } = await apiClient.get<TeamJoinRequestItem[]>(`/api/teams/${teamId}/join-requests`);
  return data;
}

export async function respondToTeamRequest(
  teamId: string,
  requestId: string,
  accept: boolean,
  roleTitle?: string,
  additionalTeamIds: string[] = []
): Promise<TeamJoinRequestItem> {
  const { data } = await apiClient.put<TeamJoinRequestItem>(
    `/api/teams/${teamId}/join-requests/${requestId}/respond`,
    { accept, role_title: roleTitle, additional_team_ids: additionalTeamIds }
  );
  return data;
}

// --- Team access grants ------------------------------------------------------
export async function listTeamAccessGrants(teamId: string): Promise<TeamAccessGrantItem[]> {
  const { data } = await apiClient.get<TeamAccessGrantItem[]>(`/api/teams/${teamId}/access-grants`);
  return data;
}

export async function revokeTeamAccessGrant(teamId: string, grantId: string): Promise<void> {
  await apiClient.delete(`/api/teams/${teamId}/access-grants/${grantId}`);
}

// --- Player join requests -----------------------------------------------------
export async function applyAsPlayer(teamId: string, message?: string): Promise<PlayerJoinRequestItem> {
  const { data } = await apiClient.post<PlayerJoinRequestItem>(
    `/api/teams/${teamId}/player-join-requests`,
    { message }
  );
  return data;
}

export async function listMyPlayerRequests(): Promise<PlayerJoinRequestItem[]> {
  const { data } = await apiClient.get<PlayerJoinRequestItem[]>("/api/player-join-requests/mine");
  return data;
}

export async function listTeamPlayerRequests(teamId: string): Promise<PlayerJoinRequestItem[]> {
  const { data } = await apiClient.get<PlayerJoinRequestItem[]>(
    `/api/teams/${teamId}/player-join-requests`
  );
  return data;
}

export async function respondToPlayerRequest(
  teamId: string,
  requestId: string,
  accept: boolean,
  linkToPlayerId?: string
): Promise<PlayerJoinRequestItem> {
  const { data } = await apiClient.put<PlayerJoinRequestItem>(
    `/api/teams/${teamId}/player-join-requests/${requestId}/respond`,
    { accept, link_to_player_id: linkToPlayerId }
  );
  return data;
}

export interface UnlinkedPlayerItem {
  id: string;
  first_name: string;
  last_name: string;
}

export async function listUnlinkedPlayers(teamId: string): Promise<UnlinkedPlayerItem[]> {
  const { data } = await apiClient.get<UnlinkedPlayerItem[]>(`/api/teams/${teamId}/unlinked-players`);
  return data;
}

// --- Player self-claim ---------------------------------------------------------
export async function claimPlayer(playerId: string): Promise<{ message: string; player_id: string }> {
  const { data } = await apiClient.post<{ message: string; player_id: string }>(
    `/api/scouting/players/${playerId}/claim`
  );
  return data;
}
