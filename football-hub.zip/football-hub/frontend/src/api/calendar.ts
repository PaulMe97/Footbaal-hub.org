import { apiClient } from "./client";
import type { CalendarEvent } from "../types";

export interface CalendarFilters {
  start?: string;
  end?: string;
  team_id?: string;
}

export async function listCalendarEvents(filters: CalendarFilters = {}): Promise<CalendarEvent[]> {
  const { data } = await apiClient.get<CalendarEvent[]>("/api/calendar/events", { params: filters });
  return data;
}

export async function createCalendarEvent(payload: {
  title: string;
  event_type: string;
  date: string;
  time?: string | null;
  team_id?: string | null;
  notes?: string | null;
}): Promise<CalendarEvent> {
  const { data } = await apiClient.post<CalendarEvent>("/api/calendar/events", payload);
  return data;
}

export async function updateCalendarEvent(
  id: string,
  payload: Partial<{
    title: string;
    date: string;
    time: string | null;
    team_id: string | null;
    notes: string | null;
  }>
): Promise<CalendarEvent> {
  const { data } = await apiClient.put<CalendarEvent>(`/api/calendar/events/${id}`, payload);
  return data;
}

export async function deleteCalendarEvent(id: string): Promise<void> {
  await apiClient.delete(`/api/calendar/events/${id}`);
}
