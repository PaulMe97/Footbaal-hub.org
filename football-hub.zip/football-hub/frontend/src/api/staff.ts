import { apiClient } from "./client";
import type { ConversationItem } from "./messages";

export interface StaffMemberItem {
  user_id: string;
  full_name?: string | null;
  username: string;
  role: string;
  avatar_path?: string | null;
  role_title?: string | null;
  staff_availability: string;
  avg_rating?: number | null;
  evaluation_count: number;
  can_fire: boolean;
}

export interface StaffTeamGroupItem {
  team_id: string;
  team_name: string;
  members: StaffMemberItem[];
}

export interface StaffEvaluationItem {
  id: string;
  evaluator_id: string;
  evaluator_name?: string | null;
  rating: number;
  comment?: string | null;
  created_at: string;
}

export async function listMyStaff(): Promise<StaffTeamGroupItem[]> {
  const { data } = await apiClient.get<StaffTeamGroupItem[]>("/api/staff/my-teams");
  return data;
}

export async function fireStaffMember(teamId: string, userId: string): Promise<void> {
  await apiClient.delete(`/api/staff/teams/${teamId}/members/${userId}`);
}

export async function updateStaffRoleTitle(
  teamId: string,
  userId: string,
  roleTitle: string
): Promise<StaffMemberItem> {
  const { data } = await apiClient.put<StaffMemberItem>(
    `/api/staff/teams/${teamId}/members/${userId}/role-title`,
    { role_title: roleTitle }
  );
  return data;
}

export async function addStaffEvaluation(
  teamId: string,
  userId: string,
  rating: number,
  comment?: string
): Promise<StaffEvaluationItem> {
  const { data } = await apiClient.post<StaffEvaluationItem>(
    `/api/staff/teams/${teamId}/members/${userId}/evaluations`,
    { rating, comment }
  );
  return data;
}

export async function listStaffEvaluations(teamId: string, userId: string): Promise<StaffEvaluationItem[]> {
  const { data } = await apiClient.get<StaffEvaluationItem[]>(
    `/api/staff/teams/${teamId}/members/${userId}/evaluations`
  );
  return data;
}

export async function startConversationWithStaff(
  teamId: string,
  userId: string
): Promise<ConversationItem> {
  const { data } = await apiClient.post<ConversationItem>(
    `/api/staff/teams/${teamId}/members/${userId}/start-conversation`
  );
  return data;
}
