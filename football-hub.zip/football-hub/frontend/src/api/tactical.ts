import { apiClient } from "./client";
import type { TacticalBoard, TacticalBoardDetail, TacticalObject } from "../types";

export interface TacticalBoardFilters {
  team_id?: string;
  match_id?: string;
  training_session_id?: string;
}

export async function listTacticalBoards(filters: TacticalBoardFilters = {}): Promise<TacticalBoard[]> {
  const { data } = await apiClient.get<TacticalBoard[]>("/api/tactical-boards", { params: filters });
  return data;
}

export async function getTacticalBoard(id: string): Promise<TacticalBoardDetail> {
  const { data } = await apiClient.get<TacticalBoardDetail>(`/api/tactical-boards/${id}`);
  return data;
}

export async function createTacticalBoard(payload: {
  team_id?: string | null;
  match_id?: string | null;
  training_session_id?: string | null;
  name: string;
  formation?: string | null;
  scenario_type?: string | null;
  notes?: string | null;
}): Promise<TacticalBoardDetail> {
  const { data } = await apiClient.post<TacticalBoardDetail>("/api/tactical-boards", payload);
  return data;
}

export async function updateTacticalBoard(
  id: string,
  payload: Partial<{
    name: string;
    formation: string | null;
    scenario_type: string | null;
    notes: string | null;
  }>
): Promise<TacticalBoardDetail> {
  const { data } = await apiClient.put<TacticalBoardDetail>(`/api/tactical-boards/${id}`, payload);
  return data;
}

export async function deleteTacticalBoard(id: string): Promise<void> {
  await apiClient.delete(`/api/tactical-boards/${id}`);
}

export async function saveTacticalObjects(
  id: string,
  objects: Pick<TacticalObject, "object_type" | "player_id" | "coordinates" | "color" | "label">[]
): Promise<TacticalBoardDetail> {
  const { data } = await apiClient.put<TacticalBoardDetail>(`/api/tactical-boards/${id}/objects`, objects);
  return data;
}

export async function downloadTacticalBoardPdf(id: string, filename: string): Promise<void> {
  const response = await apiClient.get(`/api/tactical-boards/${id}/export/pdf`, {
    responseType: "blob",
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: "application/pdf" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
