import { apiClient } from "./client";

export interface AISettings {
  provider: string;
  model: string;
  api_key_set: boolean;
}

export async function getAISettings(): Promise<AISettings> {
  const { data } = await apiClient.get<AISettings>("/api/settings/ai");
  return data;
}

export async function updateAISettings(payload: {
  provider?: string;
  model?: string;
  api_key?: string;
}): Promise<AISettings> {
  const { data } = await apiClient.put<AISettings>("/api/settings/ai", payload);
  return data;
}

export interface StorageSettings {
  configured: boolean;
  endpoint_url?: string | null;
  bucket_name?: string | null;
  region?: string | null;
}

export async function getStorageSettings(): Promise<StorageSettings> {
  const { data } = await apiClient.get<StorageSettings>("/api/settings/storage");
  return data;
}

export async function updateStorageSettings(payload: {
  endpoint_url?: string;
  bucket_name?: string;
  access_key_id?: string;
  secret_access_key?: string;
  region?: string;
}): Promise<StorageSettings> {
  const { data } = await apiClient.put<StorageSettings>("/api/settings/storage", payload);
  return data;
}

export interface SMTPSettings {
  configured: boolean;
  host?: string | null;
  port?: string | null;
  username?: string | null;
  from_email?: string | null;
  from_name?: string | null;
}

export async function getSMTPSettings(): Promise<SMTPSettings> {
  const { data } = await apiClient.get<SMTPSettings>("/api/settings/smtp");
  return data;
}

export async function updateSMTPSettings(payload: {
  host?: string;
  port?: string;
  username?: string;
  password?: string;
  from_email?: string;
  from_name?: string;
}): Promise<SMTPSettings> {
  const { data } = await apiClient.put<SMTPSettings>("/api/settings/smtp", payload);
  return data;
}
