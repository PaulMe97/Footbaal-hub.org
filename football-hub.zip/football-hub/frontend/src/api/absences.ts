import { apiClient } from "./client";
import type { AbsenceReason } from "../types";

export interface PlayerAbsenceItem {
  id: string;
  player_id: string;
  player_name?: string | null;
  team_id?: string | null;
  team_name?: string | null;
  reason: AbsenceReason;
  start_date: string;
  end_date?: string | null;
  notes?: string | null;
  created_by?: string | null;
  created_by_name?: string | null;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  is_editable: boolean;
}

export interface AbsenceFilters {
  team_id?: string;
  player_id?: string;
  active_only?: boolean;
}

export interface AbsenceCreatePayload {
  player_id: string;
  reason: AbsenceReason;
  start_date: string;
  end_date?: string;
  notes?: string;
}

export interface AbsenceUpdatePayload {
  reason?: AbsenceReason;
  start_date?: string;
  end_date?: string | null;
  notes?: string;
}

export async function listAbsences(filters: AbsenceFilters = {}): Promise<PlayerAbsenceItem[]> {
  const { data } = await apiClient.get<PlayerAbsenceItem[]>("/api/absences", { params: filters });
  return data;
}

export async function createAbsence(payload: AbsenceCreatePayload): Promise<PlayerAbsenceItem> {
  const { data } = await apiClient.post<PlayerAbsenceItem>("/api/absences", payload);
  return data;
}

export async function updateAbsence(id: string, payload: AbsenceUpdatePayload): Promise<PlayerAbsenceItem> {
  const { data } = await apiClient.put<PlayerAbsenceItem>(`/api/absences/${id}`, payload);
  return data;
}

export async function deleteAbsence(id: string): Promise<void> {
  await apiClient.delete(`/api/absences/${id}`);
}
