import { apiClient } from "./client";
import type { AppNotification } from "../types";

export async function listNotifications(unreadOnly = false): Promise<AppNotification[]> {
  const { data } = await apiClient.get<AppNotification[]>("/api/notifications", {
    params: { unread_only: unreadOnly },
  });
  return data;
}

export async function getUnreadCount(): Promise<number> {
  const { data } = await apiClient.get<{ count: number }>("/api/notifications/unread-count");
  return data.count;
}

export async function markNotificationRead(id: string): Promise<AppNotification> {
  const { data } = await apiClient.put<AppNotification>(`/api/notifications/${id}/read`);
  return data;
}

export async function markAllNotificationsRead(): Promise<void> {
  await apiClient.put("/api/notifications/read-all");
}

export async function deleteNotification(id: string): Promise<void> {
  await apiClient.delete(`/api/notifications/${id}`);
}
