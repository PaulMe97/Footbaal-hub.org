import { apiClient } from "./client";
import type { PlayerAttendanceSummary, TrainingAttendanceEntry, TrainingSession } from "../types";

export async function listTrainings(teamId?: string): Promise<TrainingSession[]> {
  const { data } = await apiClient.get<TrainingSession[]>("/api/trainings", {
    params: teamId ? { team_id: teamId } : {},
  });
  return data;
}

export async function getTraining(id: string): Promise<TrainingSession> {
  const { data } = await apiClient.get<TrainingSession>(`/api/trainings/${id}`);
  return data;
}

export async function createTraining(payload: Partial<TrainingSession>): Promise<TrainingSession> {
  const { data } = await apiClient.post<TrainingSession>("/api/trainings", payload);
  return data;
}

export async function updateTraining(
  id: string,
  payload: Partial<TrainingSession>
): Promise<TrainingSession> {
  const { data } = await apiClient.put<TrainingSession>(`/api/trainings/${id}`, payload);
  return data;
}

export async function deleteTraining(id: string): Promise<void> {
  await apiClient.delete(`/api/trainings/${id}`);
}

export async function getAttendance(sessionId: string): Promise<TrainingAttendanceEntry[]> {
  const { data } = await apiClient.get<TrainingAttendanceEntry[]>(
    `/api/trainings/${sessionId}/attendance`
  );
  return data;
}

export async function setAttendance(
  sessionId: string,
  entries: { player_id: string; status: string; notes?: string | null }[]
): Promise<TrainingAttendanceEntry[]> {
  const { data } = await apiClient.put<TrainingAttendanceEntry[]>(
    `/api/trainings/${sessionId}/attendance`,
    entries
  );
  return data;
}

export async function getTeamAttendanceStats(teamId: string): Promise<PlayerAttendanceSummary[]> {
  const { data } = await apiClient.get<PlayerAttendanceSummary[]>(
    `/api/trainings/stats/team/${teamId}`
  );
  return data;
}
