import { apiClient, downloadFile } from "./client";
import type { Team, TeamStaffMember } from "../types";

export interface TeamFilters {
  search?: string;
  category?: string;
  season?: string;
}

export async function listTeams(filters: TeamFilters = {}): Promise<Team[]> {
  const { data } = await apiClient.get<Team[]>("/api/teams", { params: filters });
  return data;
}

export async function getTeam(id: string): Promise<Team> {
  const { data } = await apiClient.get<Team>(`/api/teams/${id}`);
  return data;
}

export async function createTeam(payload: Partial<Team>): Promise<Team> {
  const { data } = await apiClient.post<Team>("/api/teams", payload);
  return data;
}

export async function updateTeam(id: string, payload: Partial<Team>): Promise<Team> {
  const { data } = await apiClient.put<Team>(`/api/teams/${id}`, payload);
  return data;
}

export async function deleteTeam(id: string): Promise<void> {
  await apiClient.delete(`/api/teams/${id}`);
}

export async function uploadTeamLogo(id: string, file: File): Promise<Team> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<Team>(`/api/teams/${id}/logo`, form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export interface CSVImportRowError {
  row: number;
  message: string;
}

export interface CSVImportResult {
  created: number;
  errors: CSVImportRowError[];
}

export async function importPlayersCsv(teamId: string, file: File): Promise<CSVImportResult> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<CSVImportResult>(
    `/api/teams/${teamId}/players/import-csv`,
    form,
    { headers: { "Content-Type": "multipart/form-data" } }
  );
  return data;
}

export async function publishTeam(
  teamId: string,
  payload: { is_publicly_shared: boolean; public_show_roster?: boolean }
): Promise<Team> {
  const { data } = await apiClient.put<Team>(`/api/teams/${teamId}/publish`, payload);
  return data;
}

export async function listTeamStaff(teamId: string): Promise<TeamStaffMember[]> {
  const { data } = await apiClient.get<TeamStaffMember[]>(`/api/teams/${teamId}/staff`);
  return data;
}

export async function addTeamStaff(
  teamId: string,
  userId: string,
  roleTitle?: string
): Promise<TeamStaffMember> {
  const { data } = await apiClient.post<TeamStaffMember>(`/api/teams/${teamId}/staff`, {
    user_id: userId,
    role_title: roleTitle,
  });
  return data;
}

export async function removeTeamStaff(teamId: string, staffId: string): Promise<void> {
  await apiClient.delete(`/api/teams/${teamId}/staff/${staffId}`);
}

export async function updateTeamStaffRole(
  teamId: string,
  staffId: string,
  roleTitle: string
): Promise<TeamStaffMember> {
  const { data } = await apiClient.put<TeamStaffMember>(`/api/teams/${teamId}/staff/${staffId}`, {
    role_title: roleTitle,
  });
  return data;
}

export async function exportRosterExcel(teamId: string, teamName: string): Promise<void> {
  await downloadFile(`/api/teams/${teamId}/export/excel`, `roster-${teamName.replace(/\s+/g, "-")}.xlsx`);
}

export async function exportRosterPdf(teamId: string, teamName: string): Promise<void> {
  await downloadFile(`/api/teams/${teamId}/export/pdf`, `roster-${teamName.replace(/\s+/g, "-")}.pdf`);
}
