import { apiClient } from "./client";
import type { ConversationItem } from "./messages";
import type {
  Country,
  Federation,
  PlayerAttributes,
  Region,
  ScoutingPlayer,
  ScoutingStaff,
  ScoutingTeam,
} from "../types";

export async function listCountries(): Promise<Country[]> {
  const { data } = await apiClient.get<Country[]>("/api/scouting/countries");
  return data;
}

export async function listRegions(countryId?: string): Promise<Region[]> {
  const { data } = await apiClient.get<Region[]>("/api/scouting/regions", {
    params: { country_id: countryId },
  });
  return data;
}

export async function listFederations(regionId?: string): Promise<Federation[]> {
  const { data } = await apiClient.get<Federation[]>("/api/scouting/federations", {
    params: { region_id: regionId },
  });
  return data;
}

export interface ScoutingTeamFilters {
  search?: string;
  country_id?: string;
  region_id?: string;
  federation_id?: string;
  league_tier?: string;
  league_level_id?: string;
  league_group_id?: string;
  academy_only?: boolean;
  academy_age_group?: string;
}

export interface LeagueLevelItem {
  id: string;
  federation_id: string;
  name: string;
  order_index: number;
  applies_to: string;
  group_count: number;
}

export interface LeagueGroupItem {
  id: string;
  league_level_id: string;
  name: string;
}

export async function listLeagueLevels(federationId: string, appliesTo: string): Promise<LeagueLevelItem[]> {
  const { data } = await apiClient.get<LeagueLevelItem[]>("/api/scouting/league-levels", {
    params: { federation_id: federationId, applies_to: appliesTo },
  });
  return data;
}

export async function createLeagueLevel(payload: {
  federation_id: string;
  name: string;
  order_index?: number;
  applies_to: string;
}): Promise<LeagueLevelItem> {
  const { data } = await apiClient.post<LeagueLevelItem>("/api/scouting/league-levels", payload);
  return data;
}

export async function deleteLeagueLevel(levelId: string): Promise<void> {
  await apiClient.delete(`/api/scouting/league-levels/${levelId}`);
}

export async function listLeagueGroups(leagueLevelId: string): Promise<LeagueGroupItem[]> {
  const { data } = await apiClient.get<LeagueGroupItem[]>("/api/scouting/league-groups", {
    params: { league_level_id: leagueLevelId },
  });
  return data;
}

export async function createLeagueGroup(payload: { league_level_id: string; name: string }): Promise<LeagueGroupItem> {
  const { data } = await apiClient.post<LeagueGroupItem>("/api/scouting/league-groups", payload);
  return data;
}

export async function deleteLeagueGroup(groupId: string): Promise<void> {
  await apiClient.delete(`/api/scouting/league-groups/${groupId}`);
}

export async function listScoutingTeams(filters: ScoutingTeamFilters = {}): Promise<ScoutingTeam[]> {
  const { data } = await apiClient.get<ScoutingTeam[]>("/api/scouting/teams", { params: filters });
  return data;
}

export async function listTeamScoutingPlayers(teamId: string): Promise<ScoutingPlayer[]> {
  const { data } = await apiClient.get<ScoutingPlayer[]>(`/api/scouting/teams/${teamId}/players`);
  return data;
}

export interface ScoutingPlayerFilters {
  search?: string;
  position?: string;
  transfer_status?: string;
  min_age?: number;
  max_age?: number;
  country_id?: string;
  region_id?: string;
  federation_id?: string;
  league_tier?: string;
}

export async function searchScoutingPlayers(
  filters: ScoutingPlayerFilters = {}
): Promise<ScoutingPlayer[]> {
  const { data } = await apiClient.get<ScoutingPlayer[]>("/api/scouting/players", { params: filters });
  return data;
}

export async function getShortlist(): Promise<ScoutingPlayer[]> {
  const { data } = await apiClient.get<ScoutingPlayer[]>("/api/scouting/shortlist");
  return data;
}

export async function addToShortlist(playerId: string): Promise<void> {
  await apiClient.post(`/api/scouting/shortlist/${playerId}`);
}

export async function removeFromShortlist(playerId: string): Promise<void> {
  await apiClient.delete(`/api/scouting/shortlist/${playerId}`);
}

export async function updateOwnTransferStatus(transferStatus: string): Promise<ScoutingPlayer> {
  const { data } = await apiClient.put<ScoutingPlayer>("/api/scouting/self/transfer-status", {
    transfer_status: transferStatus,
  });
  return data;
}

export async function getPlayerAttributes(playerId: string): Promise<PlayerAttributes> {
  const { data } = await apiClient.get<PlayerAttributes>(`/api/players/${playerId}/attributes`);
  return data;
}

export async function updatePlayerAttributes(
  playerId: string,
  payload: PlayerAttributes
): Promise<PlayerAttributes> {
  const { data } = await apiClient.put<PlayerAttributes>(
    `/api/players/${playerId}/attributes`,
    payload
  );
  return data;
}

export async function updatePlayerTransferStatus(
  playerId: string,
  transferStatus: string,
  transferNotes?: string | null
): Promise<void> {
  await apiClient.put(`/api/players/${playerId}/transfer-status`, {
    transfer_status: transferStatus,
    transfer_notes: transferNotes,
  });
}

export async function linkUserToPlayer(userId: string, playerId: string): Promise<void> {
  await apiClient.put(`/api/auth/users/${userId}/link-player`, { player_id: playerId });
}

export async function listScoutingStaff(search?: string): Promise<ScoutingStaff[]> {
  const { data } = await apiClient.get<ScoutingStaff[]>("/api/scouting/staff", {
    params: { search: search || undefined },
  });
  return data;
}

export async function getScoutingStaff(userId: string): Promise<ScoutingStaff> {
  const { data } = await apiClient.get<ScoutingStaff>(`/api/scouting/staff/${userId}`);
  return data;
}

export async function startConversationWithScoutingStaff(userId: string): Promise<ConversationItem> {
  const { data } = await apiClient.post<ConversationItem>(`/api/scouting/staff/${userId}/start-conversation`);
  return data;
}
