import { apiClient } from "./client";

export interface ConversationItem {
  id: string;
  other_user_id: string;
  other_user_name?: string | null;
  other_user_avatar?: string | null;
  context_label?: string | null;
  related_team_id?: string | null;
  last_message?: string | null;
  last_message_at?: string | null;
  unread_count: number;
  created_at: string;
}

export interface MessageItem {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  read_at?: string | null;
}

export async function listConversations(): Promise<ConversationItem[]> {
  const { data } = await apiClient.get<ConversationItem[]>("/api/conversations");
  return data;
}

export async function startConversation(otherUserId: string): Promise<ConversationItem> {
  const { data } = await apiClient.post<ConversationItem>("/api/conversations/start", {
    other_user_id: otherUserId,
  });
  return data;
}

export async function getMessages(conversationId: string): Promise<MessageItem[]> {
  const { data } = await apiClient.get<MessageItem[]>(`/api/conversations/${conversationId}/messages`);
  return data;
}

export async function sendMessage(conversationId: string, content: string): Promise<MessageItem> {
  const { data } = await apiClient.post<MessageItem>(`/api/conversations/${conversationId}/messages`, {
    content,
  });
  return data;
}

export async function getUnreadMessageCount(): Promise<number> {
  const { data } = await apiClient.get<{ count: number }>("/api/conversations/unread-count");
  return data.count;
}
