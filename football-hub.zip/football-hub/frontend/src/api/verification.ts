import { apiClient } from "./client";

export interface VerificationDocumentItem {
  id: string;
  document_type: string;
  status: string;
  rejection_reason?: string | null;
  uploaded_at: string;
  reviewed_at?: string | null;
  auto_verified?: boolean;
}

export interface VerificationDocumentAdminItem extends VerificationDocumentItem {
  user_id: string;
  user_name?: string | null;
  user_role?: string | null;
}

export interface VerificationStatus {
  verification_level: number;
  level_label: string;
  documents: VerificationDocumentItem[];
  max_simultaneous_teams: number;
  club_verified?: boolean;
}

export async function getMyVerificationStatus(): Promise<VerificationStatus> {
  const { data } = await apiClient.get<VerificationStatus>("/api/verification/me");
  return data;
}

export async function uploadVerificationDocument(
  documentType: string,
  file: File,
  consent: boolean
): Promise<VerificationDocumentItem> {
  const form = new FormData();
  form.append("document_type", documentType);
  form.append("consent", String(consent));
  form.append("file", file);
  const { data } = await apiClient.post<VerificationDocumentItem>("/api/verification/documents", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function deleteMyDocument(documentId: string): Promise<void> {
  await apiClient.delete(`/api/verification/documents/${documentId}`);
}

export async function listPendingDocuments(): Promise<VerificationDocumentAdminItem[]> {
  const { data } = await apiClient.get<VerificationDocumentAdminItem[]>("/api/verification/admin/pending");
  return data;
}

export async function reviewDocument(
  documentId: string,
  approve: boolean,
  rejectionReason?: string
): Promise<VerificationDocumentAdminItem> {
  const { data } = await apiClient.put<VerificationDocumentAdminItem>(
    `/api/verification/admin/documents/${documentId}/review`,
    { approve, rejection_reason: rejectionReason }
  );
  return data;
}
