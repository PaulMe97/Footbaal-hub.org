import { apiClient } from "./client";

export interface ScoutReportItem {
  id: string;
  full_name: string;
  club_name?: string | null;
  age?: number | null;
  position?: string | null;
  role?: string | null;
  league?: string | null;
  jersey_number?: number | null;
  nationality?: string | null;
  strong_foot?: string | null;
  goals_per_season?: number | null;
  photo_path?: string | null;
  team_id?: string | null;
  team_name?: string | null;

  positive_rating?: number | null;
  positive_notes?: string | null;
  negative_rating?: number | null;
  negative_notes?: string | null;
  physical_mental_rating?: number | null;
  physical_mental_notes?: string | null;

  detailed_attributes: Record<string, number>;

  conclusion_text?: string | null;
  recommended?: boolean | null;
  potential_rating?: number | null;

  created_by?: string | null;
  created_by_name?: string | null;
  created_at: string;
  updated_at: string;
  is_mine: boolean;
  is_shortlisted: boolean;
  can_edit: boolean;
  is_publicly_shared: boolean;
  public_slug?: string | null;
}

export interface ScoutReportFilters {
  team_id?: string;
  position?: string;
  my_list?: boolean;
}

export interface ScoutReportPayload {
  full_name: string;
  club_name?: string;
  age?: number;
  position?: string;
  role?: string;
  league?: string;
  jersey_number?: number;
  nationality?: string;
  strong_foot?: string;
  goals_per_season?: number;
  team_id?: string;

  positive_rating?: number;
  positive_notes?: string;
  negative_rating?: number;
  negative_notes?: string;
  physical_mental_rating?: number;
  physical_mental_notes?: string;

  detailed_attributes?: Record<string, number>;

  conclusion_text?: string;
  recommended?: boolean;
  potential_rating?: number;
}

export async function listScoutReports(filters: ScoutReportFilters = {}): Promise<ScoutReportItem[]> {
  const { data } = await apiClient.get<ScoutReportItem[]>("/api/scout-reports", { params: filters });
  return data;
}

export async function getScoutReport(id: string): Promise<ScoutReportItem> {
  const { data } = await apiClient.get<ScoutReportItem>(`/api/scout-reports/${id}`);
  return data;
}

export async function createScoutReport(payload: ScoutReportPayload): Promise<ScoutReportItem> {
  const { data } = await apiClient.post<ScoutReportItem>("/api/scout-reports", payload);
  return data;
}

export async function updateScoutReport(
  id: string,
  payload: Partial<ScoutReportPayload>
): Promise<ScoutReportItem> {
  const { data } = await apiClient.put<ScoutReportItem>(`/api/scout-reports/${id}`, payload);
  return data;
}

export async function deleteScoutReport(id: string): Promise<void> {
  await apiClient.delete(`/api/scout-reports/${id}`);
}

export async function uploadScoutReportPhoto(id: string, file: File): Promise<ScoutReportItem> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<ScoutReportItem>(`/api/scout-reports/${id}/photo`, form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function addScoutReportToShortlist(id: string): Promise<void> {
  await apiClient.post(`/api/scout-reports/${id}/shortlist`);
}

export async function removeScoutReportFromShortlist(id: string): Promise<void> {
  await apiClient.delete(`/api/scout-reports/${id}/shortlist`);
}

export async function downloadScoutReportPdf(id: string, filename: string): Promise<void> {
  const response = await apiClient.get(`/api/scout-reports/${id}/export/pdf`, {
    responseType: "blob",
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: "application/pdf" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export async function publishScoutReport(id: string, isPubliclyShared: boolean): Promise<ScoutReportItem> {
  const { data } = await apiClient.put<ScoutReportItem>(`/api/scout-reports/${id}/publish`, {
    is_publicly_shared: isPubliclyShared,
  });
  return data;
}
