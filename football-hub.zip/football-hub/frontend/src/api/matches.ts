import { apiClient } from "./client";
import type { Match, MatchPlayerPerformance } from "../types";

export interface MatchFilters {
  team_id?: string;
  status?: string;
  season?: string;
}

export async function listMatches(filters: MatchFilters = {}): Promise<Match[]> {
  const { data } = await apiClient.get<Match[]>("/api/matches", { params: filters });
  return data;
}

export async function getMatch(id: string): Promise<Match> {
  const { data } = await apiClient.get<Match>(`/api/matches/${id}`);
  return data;
}

export async function createMatch(payload: Partial<Match>): Promise<Match> {
  const { data } = await apiClient.post<Match>("/api/matches", payload);
  return data;
}

export async function updateMatch(id: string, payload: Partial<Match>): Promise<Match> {
  const { data } = await apiClient.put<Match>(`/api/matches/${id}`, payload);
  return data;
}

export async function updateMatchReport(id: string, payload: Partial<Match>): Promise<Match> {
  const { data } = await apiClient.put<Match>(`/api/matches/${id}/report`, payload);
  return data;
}

export async function deleteMatch(id: string): Promise<void> {
  await apiClient.delete(`/api/matches/${id}`);
}

export async function listMatchPlayers(matchId: string): Promise<MatchPlayerPerformance[]> {
  const { data } = await apiClient.get<MatchPlayerPerformance[]>(`/api/matches/${matchId}/players`);
  return data;
}

export interface MatchPlayerBulkEntry {
  player_id: string;
  is_starting: boolean;
  position_played?: string | null;
  minutes_played?: number | null;
  goals: number;
  assists: number;
  yellow_cards: number;
  red_cards: number;
  fouls: number;
  rating?: number | null;
  coach_rating?: number | null;
  is_mvp: boolean;
  notes?: string | null;
}

export async function bulkUpsertMatchPlayers(
  matchId: string,
  entries: MatchPlayerBulkEntry[]
): Promise<MatchPlayerPerformance[]> {
  const { data } = await apiClient.put<MatchPlayerPerformance[]>(
    `/api/matches/${matchId}/players/bulk`,
    entries
  );
  return data;
}

export async function addMatchPlayer(
  matchId: string,
  payload: Partial<MatchPlayerPerformance> & { player_id: string }
): Promise<MatchPlayerPerformance> {
  const { data } = await apiClient.post<MatchPlayerPerformance>(
    `/api/matches/${matchId}/players`,
    payload
  );
  return data;
}

export async function updateMatchPlayer(
  matchId: string,
  matchPlayerId: string,
  payload: Partial<MatchPlayerPerformance> & { player_id: string }
): Promise<MatchPlayerPerformance> {
  const { data } = await apiClient.put<MatchPlayerPerformance>(
    `/api/matches/${matchId}/players/${matchPlayerId}`,
    payload
  );
  return data;
}

export async function removeMatchPlayer(matchId: string, matchPlayerId: string): Promise<void> {
  await apiClient.delete(`/api/matches/${matchId}/players/${matchPlayerId}`);
}

export async function setMatchMvp(matchId: string, matchPlayerId: string): Promise<MatchPlayerPerformance> {
  const { data } = await apiClient.put<MatchPlayerPerformance>(
    `/api/matches/${matchId}/players/${matchPlayerId}/mvp`
  );
  return data;
}

export async function clearMatchMvp(matchId: string, matchPlayerId: string): Promise<MatchPlayerPerformance> {
  const { data } = await apiClient.delete<MatchPlayerPerformance>(
    `/api/matches/${matchId}/players/${matchPlayerId}/mvp`
  );
  return data;
}

export async function downloadMatchRatingPdf(matchId: string, filename: string): Promise<void> {
  const response = await apiClient.get(`/api/matches/${matchId}/export/pdf`, {
    responseType: "blob",
  });
  const url = window.URL.createObjectURL(new Blob([response.data], { type: "application/pdf" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
