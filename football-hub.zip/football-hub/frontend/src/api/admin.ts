import { apiClient } from "./client";
import type { User } from "../types";

export interface AdminUserDocumentItem {
  id: string;
  document_type: string;
  status: string;
  content_type?: string | null;
  rejection_reason?: string | null;
  auto_verified: boolean;
  uploaded_at: string;
}

export interface AdminUserListItem extends User {
  created_at: string;
  documents: AdminUserDocumentItem[];
  needs_approval: boolean;
}

export async function listAdminUsers(): Promise<AdminUserListItem[]> {
  const { data } = await apiClient.get<AdminUserListItem[]>("/api/verification/admin/users");
  return data;
}

export async function updateUserActiveStatus(userId: string, isActive: boolean): Promise<User> {
  const { data } = await apiClient.put<User>(`/api/auth/users/${userId}/active-status`, {
    is_active: isActive,
  });
  return data;
}

export interface AdminCreateUserPayload {
  email: string;
  username: string;
  password: string;
  full_name?: string;
  role: string;
  tax_id?: string;
  phone?: string;
  date_of_birth?: string;
}

export async function adminCreateUser(payload: AdminCreateUserPayload): Promise<User> {
  const { data } = await apiClient.post<User>("/api/auth/admin/create-user", payload);
  return data;
}

/** Κατεβάζει το ΠΕΡΙΕΧΟΜΕΝΟ ενός εγγράφου επαλήθευσης (ως blob, με το
 * authenticated axios client — ΠΟΤΕ ένα ακατοχύρωτο <img src> URL, αφού το
 * endpoint απαιτεί admin auth). Ο caller μετατρέπει το blob σε object URL
 * με URL.createObjectURL() για προβολή, και το ανακαλεί (revokeObjectURL)
 * όταν δεν χρειάζεται πια. */
export async function fetchDocumentBlob(documentId: string): Promise<Blob> {
  const { data } = await apiClient.get(`/api/verification/admin/documents/${documentId}/file`, {
    responseType: "blob",
  });
  return data;
}
