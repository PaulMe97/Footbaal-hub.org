import { apiClient, downloadFile } from "./client";

export interface AcademyTeamSummary {
  team_id: string;
  team_name: string;
  category?: string | null;
  player_count: number;
  players_with_debt: number;
  total_owed: number;
}

export interface AcademyFeeSettings {
  team_id: string;
  monthly_fee?: number | null;
  annual_fee?: number | null;
  registration_fee?: number | null;
  payment_due_day: number;
  kit_template: string[];
}

export interface AcademyOwedMonth {
  year: number;
  month: number;
  amount: number;
}

export interface AcademyKitItem {
  id: string;
  item_name: string;
  received: boolean;
  paid: boolean;
  price?: number | null;
}

export interface AcademyPlayerSummary {
  player_id: string;
  player_name: string;
  photo_path?: string | null;
  plan_type: string;
  parent_name?: string | null;
  parent_phone?: string | null;
  enrollment_date?: string | null;
  registration_paid: boolean;
  annual_paid_in_full: boolean;
  total_owed: number;
  unpaid_months: AcademyOwedMonth[];
  is_overdue: boolean;
  kit_items: AcademyKitItem[];
  kit_owed: number;
  has_account: boolean;
}

export interface AcademyPayment {
  id: string;
  payment_type: string;
  period_year?: number | null;
  period_month?: number | null;
  amount: number;
  paid_date: string;
  recorded_by_name?: string | null;
  notes?: string | null;
  created_at: string;
}

export interface AcademyPlayerDetail extends AcademyPlayerSummary {
  team_id: string;
  team_name?: string | null;
  notes?: string | null;
  payments: AcademyPayment[];
}

export interface AcademyAnnouncement {
  id: string;
  team_id: string;
  title: string;
  description?: string | null;
  event_date?: string | null;
  event_time?: string | null;
  location_name?: string | null;
  location_maps_url?: string | null;
  created_by_name?: string | null;
  created_at: string;
}

export async function listAcademyTeams(): Promise<AcademyTeamSummary[]> {
  const { data } = await apiClient.get<AcademyTeamSummary[]>("/api/academy/teams");
  return data;
}

export async function getFeeSettings(teamId: string): Promise<AcademyFeeSettings> {
  const { data } = await apiClient.get<AcademyFeeSettings>(`/api/academy/teams/${teamId}/settings`);
  return data;
}

export async function updateFeeSettings(
  teamId: string,
  payload: {
    monthly_fee?: number;
    annual_fee?: number;
    registration_fee?: number;
    payment_due_day: number;
    kit_template: string[];
  }
): Promise<AcademyFeeSettings> {
  const { data } = await apiClient.put<AcademyFeeSettings>(`/api/academy/teams/${teamId}/settings`, payload);
  return data;
}

export async function applyKitTemplate(teamId: string): Promise<AcademyPlayerSummary[]> {
  const { data } = await apiClient.post<AcademyPlayerSummary[]>(`/api/academy/teams/${teamId}/apply-kit-template`);
  return data;
}

export async function listAcademyPlayers(teamId: string): Promise<AcademyPlayerSummary[]> {
  const { data } = await apiClient.get<AcademyPlayerSummary[]>(`/api/academy/teams/${teamId}/players`);
  return data;
}

export async function getAcademyPlayer(playerId: string): Promise<AcademyPlayerDetail> {
  const { data } = await apiClient.get<AcademyPlayerDetail>(`/api/academy/players/${playerId}`);
  return data;
}

export async function updateAcademyAccount(
  playerId: string,
  payload: {
    plan_type: string;
    parent_name?: string;
    parent_phone?: string;
    enrollment_date?: string;
    notes?: string;
  }
): Promise<AcademyPlayerDetail> {
  const { data } = await apiClient.put<AcademyPlayerDetail>(
    `/api/academy/players/${playerId}/account`,
    payload
  );
  return data;
}

export async function addPayment(
  playerId: string,
  payload: {
    payment_type: string;
    period_year?: number;
    period_month?: number;
    amount: number;
    paid_date?: string;
    notes?: string;
  }
): Promise<AcademyPlayerDetail> {
  const { data } = await apiClient.post<AcademyPlayerDetail>(
    `/api/academy/players/${playerId}/payments`,
    payload
  );
  return data;
}

export async function deletePayment(paymentId: string): Promise<void> {
  await apiClient.delete(`/api/academy/payments/${paymentId}`);
}

export async function addKitItem(
  playerId: string,
  payload: { item_name: string; price?: number; received?: boolean; paid?: boolean }
): Promise<AcademyPlayerDetail> {
  const { data } = await apiClient.post<AcademyPlayerDetail>(`/api/academy/players/${playerId}/kit`, payload);
  return data;
}

export async function updateKitItem(
  itemId: string,
  payload: { received?: boolean; paid?: boolean; price?: number }
): Promise<AcademyPlayerDetail> {
  const { data } = await apiClient.put<AcademyPlayerDetail>(`/api/academy/kit/${itemId}`, payload);
  return data;
}

export async function deleteKitItem(itemId: string): Promise<void> {
  await apiClient.delete(`/api/academy/kit/${itemId}`);
}

export async function listAnnouncements(teamId: string): Promise<AcademyAnnouncement[]> {
  const { data } = await apiClient.get<AcademyAnnouncement[]>(`/api/academy/teams/${teamId}/announcements`);
  return data;
}

export async function createAnnouncement(
  teamId: string,
  payload: {
    title: string;
    description?: string;
    event_date?: string;
    event_time?: string;
    location_name?: string;
    location_maps_url?: string;
  }
): Promise<AcademyAnnouncement> {
  const { data } = await apiClient.post<AcademyAnnouncement>(
    `/api/academy/teams/${teamId}/announcements`,
    payload
  );
  return data;
}

export async function deleteAnnouncement(announcementId: string): Promise<void> {
  await apiClient.delete(`/api/academy/announcements/${announcementId}`);
}

export async function exportAcademyExcel(teamId: string, teamName: string): Promise<void> {
  await downloadFile(
    `/api/academy/teams/${teamId}/export/excel`,
    `academy-subscriptions-${teamName.replace(/\s+/g, "-")}.xlsx`
  );
}

export async function exportAcademyPdf(teamId: string, teamName: string): Promise<void> {
  await downloadFile(
    `/api/academy/teams/${teamId}/export/pdf`,
    `academy-subscriptions-${teamName.replace(/\s+/g, "-")}.pdf`
  );
}
