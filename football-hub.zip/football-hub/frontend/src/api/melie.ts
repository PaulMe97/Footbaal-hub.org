import { apiClient } from "./client";

export interface MelieChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface MelieChatResponse {
  reply: string;
  ai_configured: boolean;
}

export async function sendMelieMessage(
  section: string,
  language: string,
  message: string,
  history: MelieChatMessage[]
): Promise<MelieChatResponse> {
  const { data } = await apiClient.post<MelieChatResponse>("/api/melie/chat", {
    section,
    language,
    message,
    history,
  });
  return data;
}
