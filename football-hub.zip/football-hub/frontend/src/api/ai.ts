import { apiClient } from "./client";
import type { AIReport } from "../types";

export async function listAIReports(): Promise<AIReport[]> {
  const { data } = await apiClient.get<AIReport[]>("/api/ai-reports");
  return data;
}

export async function getReportContext(id: string): Promise<{ title: string }> {
  const { data } = await apiClient.get<{ title: string }>(`/api/ai-reports/${id}/context`);
  return data;
}

export async function listMatchAIReports(matchId: string): Promise<AIReport[]> {
  const { data } = await apiClient.get<AIReport[]>(`/api/matches/${matchId}/ai-reports`);
  return data;
}

export async function generateMatchAISummary(matchId: string): Promise<AIReport> {
  const { data } = await apiClient.post<AIReport>(`/api/matches/${matchId}/ai-summary`);
  return data;
}
