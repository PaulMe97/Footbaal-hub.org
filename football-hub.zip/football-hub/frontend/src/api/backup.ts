import { apiClient } from "./client";

export async function downloadBackup(): Promise<void> {
  const response = await apiClient.get("/api/backup/export", { responseType: "blob" });
  const disposition = response.headers["content-disposition"] as string | undefined;
  const match = disposition?.match(/filename="?([^"]+)"?/);
  const filename = match?.[1] || `footballhub-backup-${Date.now()}.db`;
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

export async function uploadBackup(file: File): Promise<{ message: string }> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<{ message: string }>("/api/backup/import", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function downloadMyDataExport(): Promise<void> {
  const response = await apiClient.get("/api/backup/export-my-data", { responseType: "blob" });
  const disposition = response.headers["content-disposition"] as string | undefined;
  const match = disposition?.match(/filename="?([^"]+)"?/);
  const filename = match?.[1] || `footballhub-export-${Date.now()}.json`;
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
