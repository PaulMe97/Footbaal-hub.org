import { apiClient } from "./client";
import type { Achievement, Qualification, User, UserSearchResult, WorkExperience } from "../types";

export async function uploadAvatar(file: File): Promise<User> {
  const form = new FormData();
  form.append("file", file);
  const { data } = await apiClient.post<User>("/api/profile/me/avatar", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

export async function updateStaffVisibility(isStaffVisible: boolean): Promise<User> {
  const { data } = await apiClient.put<User>("/api/profile/me/visibility", {
    is_staff_visible: isStaffVisible,
  });
  return data;
}

export async function updateStaffAvailability(staffAvailability: string): Promise<User> {
  const { data } = await apiClient.put<User>("/api/profile/me/availability", {
    staff_availability: staffAvailability,
  });
  return data;
}

export async function updateStaffScoutingPrefs(payload: {
  desired_staff_role?: string | null;
  origin_federation_id?: string | null;
  desired_federation_ids?: string[];
}): Promise<User> {
  const { data } = await apiClient.put<User>("/api/profile/me/staff-scouting-prefs", payload);
  return data;
}

export async function updateLinkedIn(linkedinUrl: string, showLinkedin: boolean): Promise<User> {
  const { data } = await apiClient.put<User>("/api/profile/me/linkedin", {
    linkedin_url: linkedinUrl || null,
    show_linkedin: showLinkedin,
  });
  return data;
}

export async function listMyQualifications(): Promise<Qualification[]> {
  const { data } = await apiClient.get<Qualification[]>("/api/profile/me/qualifications");
  return data;
}

export async function addQualification(title: string, year?: number): Promise<Qualification> {
  const { data } = await apiClient.post<Qualification>("/api/profile/me/qualifications", {
    title,
    year,
  });
  return data;
}

export async function deleteQualification(id: string): Promise<void> {
  await apiClient.delete(`/api/profile/me/qualifications/${id}`);
}

export async function listMyExperience(): Promise<WorkExperience[]> {
  const { data } = await apiClient.get<WorkExperience[]>("/api/profile/me/experience");
  return data;
}

export async function addExperience(payload: {
  organization: string;
  role_title?: string;
  start_year?: number;
  end_year?: number;
  description?: string;
}): Promise<WorkExperience> {
  const { data } = await apiClient.post<WorkExperience>("/api/profile/me/experience", payload);
  return data;
}

export async function deleteExperience(id: string): Promise<void> {
  await apiClient.delete(`/api/profile/me/experience/${id}`);
}

export async function listMyAchievements(): Promise<Achievement[]> {
  const { data } = await apiClient.get<Achievement[]>("/api/profile/me/achievements");
  return data;
}

export async function addAchievement(
  title: string,
  year?: number,
  description?: string
): Promise<Achievement> {
  const { data } = await apiClient.post<Achievement>("/api/profile/me/achievements", {
    title,
    year,
    description,
  });
  return data;
}

export async function deleteAchievement(id: string): Promise<void> {
  await apiClient.delete(`/api/profile/me/achievements/${id}`);
}

export async function searchUsers(query: string): Promise<UserSearchResult[]> {
  const { data } = await apiClient.get<UserSearchResult[]>("/api/profile/search", {
    params: { q: query },
  });
  return data;
}

export interface MyTeamMembership {
  team_id: string;
  team_name: string;
  role_title?: string | null;
}

export async function listMyTeamMemberships(): Promise<MyTeamMembership[]> {
  const { data } = await apiClient.get<MyTeamMembership[]>("/api/profile/me/team-memberships");
  return data;
}

export async function leaveTeam(teamId: string): Promise<void> {
  await apiClient.delete(`/api/profile/me/team-memberships/${teamId}`);
}
