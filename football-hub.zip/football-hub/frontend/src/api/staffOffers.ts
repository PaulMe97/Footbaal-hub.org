import { apiClient } from "./client";

export interface StaffAssignmentOfferItem {
  id: string;
  team_id: string;
  team_name?: string | null;
  sender_id: string;
  sender_name?: string | null;
  recipient_user_id: string;
  recipient_name?: string | null;
  role_title?: string | null;
  new_role?: string | null;
  season?: string | null;
  incentive_details?: string | null;
  message?: string | null;
  status: string;
  created_at: string;
}

export async function sendStaffAssignmentOffer(
  teamId: string,
  payload: {
    recipient_user_id: string;
    role_title?: string;
    new_role?: string;
    season?: string;
    incentive_details?: string;
    message?: string;
  }
): Promise<StaffAssignmentOfferItem> {
  const { data } = await apiClient.post<StaffAssignmentOfferItem>(
    `/api/teams/${teamId}/staff-offers`,
    payload
  );
  return data;
}

export async function listMyStaffOffers(): Promise<StaffAssignmentOfferItem[]> {
  const { data } = await apiClient.get<StaffAssignmentOfferItem[]>("/api/staff-offers/mine");
  return data;
}

export async function listTeamStaffOffers(teamId: string): Promise<StaffAssignmentOfferItem[]> {
  const { data } = await apiClient.get<StaffAssignmentOfferItem[]>(`/api/teams/${teamId}/staff-offers`);
  return data;
}

export async function respondToStaffAssignmentOffer(
  offerId: string,
  accept: boolean
): Promise<StaffAssignmentOfferItem> {
  const { data } = await apiClient.put<StaffAssignmentOfferItem>(
    `/api/staff-offers/${offerId}/respond`,
    { accept }
  );
  return data;
}
