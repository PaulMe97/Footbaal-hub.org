import type { AcademyPlayerDetail, AcademyPlayerSummary } from "../api/academy";
import { getStoredLanguage } from "../i18n/languageStore";

const MONTH_NAMES_EL = [
  "Ιανουάριος",
  "Φεβρουάριος",
  "Μάρτιος",
  "Απρίλιος",
  "Μάιος",
  "Ιούνιος",
  "Ιούλιος",
  "Αύγουστος",
  "Σεπτέμβριος",
  "Οκτώβριος",
  "Νοέμβριος",
  "Δεκέμβριος",
];

const MONTH_NAMES_EN = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export function monthLabel(month: number): string {
  const names = getStoredLanguage() === "en" ? MONTH_NAMES_EN : MONTH_NAMES_EL;
  return names[month - 1] || String(month);
}

export function normalizePhone(phone: string): string {
  return phone.replace(/[^\d+]/g, "");
}

export function viberChatLink(phone: string, message?: string): string {
  const params = new URLSearchParams();
  params.set("number", normalizePhone(phone));
  if (message) params.set("text", message);
  return `viber://chat?${params.toString()}`;
}

export interface MessageTemplate {
  label: string;
  text: string;
}

/** Δημιουργεί έτοιμα, φυσικά μηνύματα προς τον γονέα, βάσει της
 * πραγματικής οικονομικής εικόνας του παίκτη — όχι γενικά templates. */
export function buildMessageTemplates(
  player: AcademyPlayerSummary | AcademyPlayerDetail,
  dueDay: number
): MessageTemplate[] {
  const lang = getStoredLanguage();
  const templates: MessageTemplate[] = [];
  const name = player.player_name;

  if (player.is_overdue && player.unpaid_months.length > 0) {
    const current = player.unpaid_months[player.unpaid_months.length - 1];
    templates.push({
      label: lang === "en" ? "Overdue installment" : "Εκπρόθεσμη δόση",
      text:
        lang === "en"
          ? `Hello, this is to inform you that the monthly fee of €${current.amount} for ${name} (${monthLabel(current.month)}) is overdue (due by the ${dueDay} of the month). Please settle it as soon as possible. Thank you!`
          : `Καλησπέρα σας, σας ενημερώνουμε ότι οφείλεται η μηνιαία συνδρομή των €${current.amount} για τον/την ${name} (${monthLabel(current.month)}) και έχει περάσει η προθεσμία πληρωμής (μέχρι τις ${dueDay} του μήνα). Παρακαλούμε τακτοποιήστε το το συντομότερο δυνατό. Ευχαριστούμε!`,
    });
  }

  if (player.total_owed > 0) {
    templates.push({
      label: lang === "en" ? "Total balance due" : "Συνολική οφειλή",
      text:
        lang === "en"
          ? `Hello, the current outstanding balance for ${name} is €${player.total_owed.toFixed(2)} (${player.unpaid_months.length} ${player.unpaid_months.length === 1 ? "month" : "months"}). Please get in touch with us to settle it.`
          : `Καλησπέρα σας, το τρέχον υπόλοιπο οφειλών για τον/την ${name} είναι €${player.total_owed.toFixed(2)} (${player.unpaid_months.length} ${player.unpaid_months.length === 1 ? "μήνας" : "μήνες"}). Παρακαλούμε επικοινωνήστε μαζί μας για την τακτοποίηση.`,
    });
  }

  if (!player.registration_paid) {
    templates.push({
      label: lang === "en" ? "Registration reminder" : "Υπενθύμιση εγγραφής",
      text:
        lang === "en"
          ? `Hello, the registration for ${name} for this season has not been completed yet. Please get in touch with us to complete it.`
          : `Καλησπέρα σας, η εγγραφή του/της ${name} για τη φετινή σεζόν δεν έχει ολοκληρωθεί ακόμα. Παρακαλούμε επικοινωνήστε μαζί μας για να την τακτοποιήσουμε.`,
    });
  }

  const missingItems = player.kit_items.filter((k) => !k.received).map((k) => k.item_name);
  if (missingItems.length > 0 || player.kit_owed > 0) {
    const parts: string[] = [];
    if (lang === "en") {
      if (missingItems.length > 0) parts.push(`still to collect: ${missingItems.join(", ")}`);
      if (player.kit_owed > 0) parts.push(`kit balance due €${player.kit_owed.toFixed(2)}`);
      templates.push({
        label: "Kit",
        text: `Hello, regarding ${name}'s kit: ${parts.join(" · ")}. Please get in touch with us.`,
      });
    } else {
      if (missingItems.length > 0) parts.push(`εκκρεμεί η παραλαβή: ${missingItems.join(", ")}`);
      if (player.kit_owed > 0) parts.push(`οφειλή ρουχισμού €${player.kit_owed.toFixed(2)}`);
      templates.push({
        label: "Ρουχισμός",
        text: `Καλησπέρα σας, σχετικά με τον ρουχισμό του/της ${name}: ${parts.join(" · ")}. Παρακαλούμε επικοινωνήστε μαζί μας.`,
      });
    }
  }

  templates.push({
    label: lang === "en" ? "General reminder" : "Γενική υπενθύμιση",
    text:
      lang === "en"
        ? `Hello, we'd like to touch base about ${name}'s account. Please get in touch with us whenever you can. Thank you!`
        : `Καλησπέρα σας, θα θέλαμε να συνεννοηθούμε για το λογαριασμό του/της ${name}. Επικοινωνήστε μαζί μας όποτε μπορείτε. Ευχαριστούμε!`,
  });

  return templates;
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

export function viberForwardLink(message: string): string {
  const params = new URLSearchParams();
  params.set("text", message);
  return `viber://forward?${params.toString()}`;
}

export function whatsappShareLink(message: string): string {
  const params = new URLSearchParams();
  params.set("text", message);
  return `https://wa.me/?${params.toString()}`;
}

export interface ShareableAnnouncement {
  title: string;
  description?: string | null;
  event_date?: string | null;
  event_time?: string | null;
  location_name?: string | null;
  location_maps_url?: string | null;
}

/** Μορφοποιεί μια ενημέρωση σε φυσικό μήνυμα, έτοιμο για κοινοποίηση — ο
 * χρήστης επιλέγει ΜΕΣΑ στο Viber/WhatsApp σε ποια ομάδα/επαφή θα το
 * στείλει (native forward/share picker), δεν χρειάζεται να το ξέρουμε εμείς. */
export function buildAnnouncementMessage(a: ShareableAnnouncement): string {
  const lines = [`📢 ${a.title}`];
  const when = [a.event_date, a.event_time].filter(Boolean).join(" · ");
  if (when) lines.push(`📅 ${when}`);
  if (a.location_name) lines.push(`📍 ${a.location_name}`);
  if (a.description) lines.push("", a.description);
  if (a.location_maps_url) lines.push("", a.location_maps_url);
  return lines.join("\n");
}

