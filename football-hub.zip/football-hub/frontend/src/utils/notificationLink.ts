import type { AppNotification } from "../types";

/** Καθορίζει πού πρέπει να πλοηγηθεί ο χρήστης όταν πατάει μια ειδοποίηση
 * — ανάλογα με το είδος/στοιχεία της. Επιστρέφει null αν δεν υπάρχει
 * κατάλληλος προορισμός (τότε το κλικ απλά τη σημειώνει ως διαβασμένη). */
export function notificationLink(n: AppNotification): string | null {
  if (n.related_entity_type === "player" && n.related_entity_id) return `/players/${n.related_entity_id}`;
  if (n.related_entity_type === "match" && n.related_entity_id) return `/matches/${n.related_entity_id}`;
  if (n.related_entity_type === "training" && n.related_entity_id) return `/trainings/${n.related_entity_id}`;
  // Νέα εγγραφή Προέδρου/Τεχνικού Διευθυντή που χρειάζεται έγκριση — η
  // ενέργεια γίνεται στις Ρυθμίσεις → Διαχείριση Χρηστών.
  if (n.related_entity_type === "user") return "/settings";
  // Προσφορές (συμβόλαιο παίκτη ή ανάθεση staff) — πάντα στο Προφίλ, με
  // hash που πηγαίνει ΑΚΡΙΒΩΣ στη λίστα εκκρεμών προσφορών (η σελίδα κάνει
  // scroll+highlight εκεί) — ΠΟΤΕ στη σελίδα ομάδας: ο παραλήπτης μιας
  // πρότασης staff συχνά δεν έχει καν πρόσβαση στην ομάδα ακόμα, αφού η
  // προσφορά δεν έχει γίνει αποδεκτή.
  if (n.related_entity_type === "contract_offer") return "/profile#player-offers-section";
  if (n.related_entity_type === "staff_assignment_offer") return "/profile#team-offers-section";
  // Αιτήσεις/αγγελίες/ανανεώσεις/team events — όλα φαίνονται στη σελίδα
  // της σχετικής ομάδας.
  if (n.related_team_id) return `/teams/${n.related_team_id}`;
  return null;
}
