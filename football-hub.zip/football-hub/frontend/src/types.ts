import { createBilingualLabels } from "./i18n/languageStore";

export type UserRole =
  | "super_admin"
  | "admin"
  | "president"
  | "technical_director"
  | "head_coach"
  | "assistant_coach"
  | "fitness_coach"
  | "analyst"
  | "scout"
  | "player";

export interface User {
  id: string;
  email: string;
  username: string;
  full_name?: string | null;
  role: UserRole;
  is_active: boolean;
  linked_player_id?: string | null;
  avatar_path?: string | null;
  bio?: string | null;
  phone?: string | null;
  date_of_birth?: string | null;
  is_staff_visible?: boolean;
  staff_availability?: string;
  desired_staff_role?: string | null;
  origin_federation_id?: string | null;
  desired_federation_ids?: string[];
  linkedin_url?: string | null;
  show_linkedin?: boolean;
  verification_level?: number;
  club_verified?: boolean;
  leadership_approved?: boolean;
  /** Μόνο για ρόλο "president" — επιστρέφεται ΜΟΝΟ όταν αφορά τον ίδιο τον
   * συνδεδεμένο χρήστη (ποτέ σε λίστες άλλων χρηστών). */
  team_tax_id?: string | null;
}

export interface Team {
  id: string;
  name: string;
  logo_path?: string | null;
  category?: string | null;
  division?: string | null;
  league?: string | null;
  season?: string | null;
  description?: string | null;
  home_stadium?: string | null;
  primary_color?: string | null;
  secondary_color?: string | null;
  coach_name?: string | null;
  president_name?: string | null;
  notes?: string | null;
  country_id?: string | null;
  federation_id?: string | null;
  league_level_id?: string | null;
  league_group_id?: string | null;
  league_tier?: string | null;
  academy_age_group?: string | null;
  is_public_scouting?: boolean;
  country_name?: string | null;
  region_name?: string | null;
  federation_name?: string | null;
  league_level_name?: string | null;
  league_group_name?: string | null;
  is_publicly_shared?: boolean;
  public_slug?: string | null;
  public_show_roster?: boolean;
  created_at: string;
  updated_at: string;
  player_count: number;
}

export type PlayerPosition =
  | "GK"
  | "CB"
  | "LB"
  | "RB"
  | "LWB"
  | "RWB"
  | "DM"
  | "CM"
  | "AM"
  | "LW"
  | "RW"
  | "ST";

export type PreferredFoot = "left" | "right" | "both";

export type PlayerStatus = "fit" | "injured" | "suspended" | "unavailable" | "doubtful";

export interface Player {
  id: string;
  first_name: string;
  last_name: string;
  photo_path?: string | null;
  date_of_birth?: string | null;
  age?: number | null;
  nationality?: string | null;
  phone?: string | null;
  email?: string | null;
  player_number?: number | null;
  preferred_foot?: PreferredFoot | null;
  height_cm?: number | null;
  weight_kg?: number | null;
  position?: PlayerPosition | null;
  secondary_position?: PlayerPosition | null;
  current_team_id?: string | null;
  team_name?: string | null;
  contract_notes?: string | null;
  status?: PlayerStatus | null;
  availability_notes?: string | null;
  injury_status?: string | null;
  injury_type?: string | null;
  injury_date?: string | null;
  expected_return?: string | null;
  medical_notes?: string | null;
  goals: number;
  matches_played: number;
  transfer_status: string;
  transfer_notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface DashboardActivityItem {
  type: string;
  text: string;
  timestamp: string;
  entity_type?: "player" | "team" | "contract_offer" | "renewal_request" | null;
  entity_id?: string | null;
}

export interface UpcomingMatchInfo {
  id: string;
  date: string;
  days_until: number;
  team_id: string;
  team_name: string;
  opponent_name?: string | null;
  is_home: boolean;
  stadium?: string | null;
  competition?: string | null;
}

export interface UpcomingTrainingInfo {
  id: string;
  date: string;
  days_until: number;
  team_id: string;
  team_name: string;
  training_type?: string | null;
  location?: string | null;
}

export interface TopPlayerStat {
  player_id: string;
  team_id: string;
  player_name: string;
  team_name?: string | null;
  value: number;
  label: string;
}

export interface DashboardStats {
  total_teams: number;
  total_players: number;
  injured_players: number;
  active_absences_count: number;
  upcoming_trainings_count: number;
  trainings_this_week: number;
  upcoming_matches: UpcomingMatchInfo[];
  upcoming_trainings: UpcomingTrainingInfo[];
  top_scorers: TopPlayerStat[];
  best_avg_rating_players: TopPlayerStat[];
  top_performers_this_month: TopPlayerStat[];
  recent_activity: DashboardActivityItem[];
}

export type NotificationType =
  | "upcoming_match"
  | "upcoming_training"
  | "player_injury"
  | "player_return"
  | "low_attendance"
  | "team_event"
  | "match_report_pending"
  | "ai_report_ready"
  | "renewal_on_hold"
  | "contract_offer"
  | "new_application"
  | "crm_topic"
  | "new_leadership_registration";

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message?: string | null;
  is_read: boolean;
  related_entity_type?: string | null;
  related_entity_id?: string | null;
  related_team_id?: string | null;
  created_at: string;
}

export const NOTIFICATION_ICONS: Record<NotificationType, string> = {
  upcoming_match: "⚽",
  upcoming_training: "◈",
  player_injury: "🩹",
  player_return: "✅",
  low_attendance: "⚠",
  team_event: "★",
  match_report_pending: "📝",
  ai_report_ready: "✨",
  renewal_on_hold: "⏳",
  contract_offer: "📝",
  new_application: "📩",
  crm_topic: "💬",
  new_leadership_registration: "🛂",
};

// Κάθε "ενότητα" ειδοποιήσεων έχει το δικό της χρώμα, ώστε να ξεχωρίζουν
// οπτικά με μια ματιά. Οι αιτήσεις προς έγκριση (new_application) παίρνουν
// επίτηδες το πιο έντονο/επείγον χρώμα (ίδιο με τραυματισμό) — χρειάζονται
// άμεση προσοχή από το staff.
export const NOTIFICATION_COLORS: Record<NotificationType, string> = {
  upcoming_match: "text-sky-400",
  upcoming_training: "text-sky-400",
  team_event: "text-sky-400",
  player_injury: "text-status-injured",
  player_return: "text-status-fit",
  low_attendance: "text-status-doubtful",
  match_report_pending: "text-amber-400",
  ai_report_ready: "text-status-suspended",
  renewal_on_hold: "text-orange-400",
  contract_offer: "text-chalk",
  new_application: "text-status-injured",
  crm_topic: "text-pink-400",
  new_leadership_registration: "text-status-injured",
};

// Τύποι που θεωρούνται επείγοντες/απαιτούν άμεση ενέργεια από το staff
// (π.χ. αίτηση παίκτη/coach προς αποδοχή) — δείχνονται με ειδική "URGENT"
// σήμανση στη λίστα ειδοποιήσεων.
export const URGENT_NOTIFICATION_TYPES: NotificationType[] = ["new_application", "new_leadership_registration"];

export interface AIReport {
  id: string;
  report_type: string;
  match_id?: string | null;
  player_id?: string | null;
  team_id?: string | null;
  content: string;
  model_used?: string | null;
  created_at: string;
}

export type InjuryStatus = "active" | "recovering" | "recovered";

export interface Injury {
  id: string;
  player_id: string;
  injury_type?: string | null;
  status: InjuryStatus;
  injury_date?: string | null;
  expected_return?: string | null;
  actual_return?: string | null;
  notes?: string | null;
  created_at: string;
}

const INJURY_STATUS_LABELS_EL: Record<InjuryStatus, string> = {
  active: "Ενεργός",
  recovering: "Σε αποθεραπεία",
  recovered: "Αποθεραπεύτηκε",
};
const INJURY_STATUS_LABELS_EN: Record<InjuryStatus, string> = {
  active: "Active",
  recovering: "Recovering",
  recovered: "Recovered",
};
export const INJURY_STATUS_LABELS = createBilingualLabels(INJURY_STATUS_LABELS_EL, INJURY_STATUS_LABELS_EN);

export interface PlayerStatistics {
  id: string;
  player_id: string;
  team_id?: string | null;
  season?: string | null;
  matches_played: number;
  starts: number;
  substitute_appearances: number;
  minutes_played: number;
  goals: number;
  assists: number;
  yellow_cards: number;
  red_cards: number;
  fouls_committed: number;
  fouls_suffered: number;
  shots: number;
  shots_on_target: number;
  passes: number;
  tackles: number;
  interceptions: number;
  clearances: number;
  saves: number;
  clean_sheets: number;
  avg_rating?: number | null;
}

export type AttendanceStatus = "present" | "absent" | "late" | "injured" | "excused";

export interface TrainingSession {
  id: string;
  team_id: string;
  team_name?: string | null;
  date: string;
  time?: string | null;
  location?: string | null;
  training_type?: string | null;
  duration_minutes?: number | null;
  objectives?: string | null;
  exercises?: string | null;
  coach_notes?: string | null;
  attendance_present: number;
  attendance_total: number;
  created_at: string;
}

export interface TrainingAttendanceEntry {
  id: string;
  player_id: string;
  player_name: string;
  status: AttendanceStatus;
  notes?: string | null;
}

export interface PlayerAttendanceSummary {
  player_id: string;
  player_name: string;
  total_sessions: number;
  attended: number;
  attendance_percentage: number;
}

const ATTENDANCE_LABELS_EL: Record<AttendanceStatus, string> = {
  present: "Παρών",
  absent: "Απών",
  late: "Καθυστέρησε",
  injured: "Τραυματίας",
  excused: "Δικαιολογημένος",
};
const ATTENDANCE_LABELS_EN: Record<AttendanceStatus, string> = {
  present: "Present",
  absent: "Absent",
  late: "Late",
  injured: "Injured",
  excused: "Excused",
};
export const ATTENDANCE_LABELS = createBilingualLabels(ATTENDANCE_LABELS_EL, ATTENDANCE_LABELS_EN);

export type MatchStatus = "scheduled" | "live" | "finished" | "postponed" | "cancelled";

const MATCH_STATUS_LABELS_EL: Record<MatchStatus, string> = {
  scheduled: "Προγραμματισμένος",
  live: "Live",
  finished: "Ολοκληρώθηκε",
  postponed: "Αναβλήθηκε",
  cancelled: "Ακυρώθηκε",
};
const MATCH_STATUS_LABELS_EN: Record<MatchStatus, string> = {
  scheduled: "Scheduled",
  live: "Live",
  finished: "Finished",
  postponed: "Postponed",
  cancelled: "Cancelled",
};
export const MATCH_STATUS_LABELS = createBilingualLabels(MATCH_STATUS_LABELS_EL, MATCH_STATUS_LABELS_EN);

export interface Match {
  id: string;
  home_team_id?: string | null;
  away_team_id?: string | null;
  home_team_name_external?: string | null;
  away_team_name_external?: string | null;
  home_team_name?: string | null;
  away_team_name?: string | null;
  date: string;
  time?: string | null;
  stadium?: string | null;
  competition?: string | null;
  season?: string | null;
  home_score?: number | null;
  away_score?: number | null;
  half_time_home_score?: number | null;
  half_time_away_score?: number | null;
  status: MatchStatus;
  team_performance_notes?: string | null;
  opponent_analysis?: string | null;
  coach_notes?: string | null;
  general_description?: string | null;
  created_at: string;
  updated_at: string;
}

export interface MatchPlayerPerformance {
  id: string;
  player_id: string;
  player_name: string;
  player_number?: number | null;
  is_starting: boolean;
  position_played?: PlayerPosition | null;
  minutes_played?: number | null;
  goals: number;
  assists: number;
  yellow_cards: number;
  red_cards: number;
  fouls: number;
  rating?: number | null;
  coach_rating?: number | null;
  is_mvp: boolean;
  notes?: string | null;
}

export interface PlayerMonthlyPerformance {
  player_id: string;
  player_name: string;
  team_name?: string | null;
  matches_played: number;
  avg_rating?: number | null;
  goals: number;
  assists: number;
  yellow_cards: number;
  red_cards: number;
  mvp_count: number;
}

export type CalendarEventType = "match" | "training" | "injury" | "other";

export interface CalendarEvent {
  id: string;
  title: string;
  event_type: CalendarEventType;
  date: string;
  time?: string | null;
  team_id?: string | null;
  team_name?: string | null;
  related_entity_type?: string | null;
  related_entity_id?: string | null;
  notes?: string | null;
  status?: string | null;
  editable: boolean;
}

export interface TacticalObjectPoint {
  x: number;
  y: number;
}

export interface TacticalObject {
  id: string;
  object_type: "player" | "arrow" | "zone" | "text" | "cone";
  player_id?: string | null;
  player_name?: string | null;
  player_number?: number | null;
  coordinates: Record<string, number>[];
  color?: string | null;
  label?: string | null;
}

export interface TacticalBoard {
  id: string;
  team_id?: string | null;
  team_name?: string | null;
  match_id?: string | null;
  training_session_id?: string | null;
  training_label?: string | null;
  name: string;
  formation?: string | null;
  scenario_type?: string | null;
  notes?: string | null;
  object_count: number;
  created_at: string;
  updated_at: string;
}

export interface TacticalBoardDetail extends TacticalBoard {
  objects: TacticalObject[];
}

export const FORMATIONS = ["4-4-2", "4-3-3", "4-2-3-1", "3-5-2", "3-4-3", "5-3-2", "Custom"] as const;

export const SCENARIO_TYPES = [
  "Build-up",
  "Attacking phase",
  "Defensive phase",
  "Pressing",
  "Counterattack",
  "Set pieces",
  "Corner kicks",
  "Free kicks",
] as const;

// Formation presets: 11 points (x,y in % of pitch, 0-100), GK first.
// Orientation: attacking from bottom (y=95, own goal) to top (y=5, opponent goal).
export const FORMATION_PRESETS: Record<string, { x: number; y: number }[]> = {
  "4-4-2": [
    { x: 50, y: 92 },
    { x: 18, y: 75 }, { x: 38, y: 78 }, { x: 62, y: 78 }, { x: 82, y: 75 },
    { x: 18, y: 50 }, { x: 38, y: 55 }, { x: 62, y: 55 }, { x: 82, y: 50 },
    { x: 38, y: 25 }, { x: 62, y: 25 },
  ],
  "4-3-3": [
    { x: 50, y: 92 },
    { x: 18, y: 75 }, { x: 38, y: 78 }, { x: 62, y: 78 }, { x: 82, y: 75 },
    { x: 30, y: 52 }, { x: 50, y: 48 }, { x: 70, y: 52 },
    { x: 20, y: 22 }, { x: 50, y: 18 }, { x: 80, y: 22 },
  ],
  "4-2-3-1": [
    { x: 50, y: 92 },
    { x: 18, y: 75 }, { x: 38, y: 78 }, { x: 62, y: 78 }, { x: 82, y: 75 },
    { x: 38, y: 58 }, { x: 62, y: 58 },
    { x: 20, y: 35 }, { x: 50, y: 32 }, { x: 80, y: 35 },
    { x: 50, y: 14 },
  ],
  "3-5-2": [
    { x: 50, y: 92 },
    { x: 30, y: 76 }, { x: 50, y: 80 }, { x: 70, y: 76 },
    { x: 12, y: 52 }, { x: 32, y: 48 }, { x: 50, y: 44 }, { x: 68, y: 48 }, { x: 88, y: 52 },
    { x: 38, y: 20 }, { x: 62, y: 20 },
  ],
  "3-4-3": [
    { x: 50, y: 92 },
    { x: 30, y: 76 }, { x: 50, y: 80 }, { x: 70, y: 76 },
    { x: 16, y: 50 }, { x: 40, y: 52 }, { x: 60, y: 52 }, { x: 84, y: 50 },
    { x: 20, y: 20 }, { x: 50, y: 16 }, { x: 80, y: 20 },
  ],
  "5-3-2": [
    { x: 50, y: 92 },
    { x: 10, y: 70 }, { x: 30, y: 78 }, { x: 50, y: 80 }, { x: 70, y: 78 }, { x: 90, y: 70 },
    { x: 30, y: 50 }, { x: 50, y: 46 }, { x: 70, y: 50 },
    { x: 38, y: 20 }, { x: 62, y: 20 },
  ],
  Custom: [
    { x: 50, y: 92 },
    { x: 20, y: 75 }, { x: 40, y: 75 }, { x: 60, y: 75 }, { x: 80, y: 75 },
    { x: 20, y: 50 }, { x: 40, y: 50 }, { x: 60, y: 50 }, { x: 80, y: 50 },
    { x: 38, y: 22 }, { x: 62, y: 22 },
  ],
};

export const POSITIONS: PlayerPosition[] = [
  "GK",
  "CB",
  "LB",
  "RB",
  "LWB",
  "RWB",
  "DM",
  "CM",
  "AM",
  "LW",
  "RW",
  "ST",
];

const STATUS_LABELS_EL: Record<PlayerStatus, string> = {
  fit: "Διαθέσιμος",
  injured: "Τραυματίας",
  suspended: "Τιμωρημένος",
  unavailable: "Μη διαθέσιμος",
  doubtful: "Αμφίβολος",
};
const STATUS_LABELS_EN: Record<PlayerStatus, string> = {
  fit: "Available",
  injured: "Injured",
  suspended: "Suspended",
  unavailable: "Unavailable",
  doubtful: "Doubtful",
};
export const STATUS_LABELS = createBilingualLabels(STATUS_LABELS_EL, STATUS_LABELS_EN);

// ---------------------------------------------------------------------------
// Scouting Hub
// ---------------------------------------------------------------------------
export interface Country {
  id: string;
  name: string;
  code?: string | null;
}

export interface Region {
  id: string;
  country_id: string;
  name: string;
}

export interface Federation {
  id: string;
  region_id: string;
  name: string;
}

export type LeagueTier = "top_division" | "second_division" | "third_division" | "regional" | "academy";

const LEAGUE_TIER_LABELS_EL: Record<LeagueTier, string> = {
  top_division: "Α Εθνική",
  second_division: "Β Εθνική",
  third_division: "Γ Εθνική",
  regional: "ΕΠΣ (Ερασιτεχνικό)",
  academy: "Ακαδημία",
};
const LEAGUE_TIER_LABELS_EN: Record<LeagueTier, string> = {
  top_division: "1st Division",
  second_division: "2nd Division",
  third_division: "3rd Division",
  regional: "Regional (Amateur)",
  academy: "Academy",
};
export const LEAGUE_TIER_LABELS = createBilingualLabels(LEAGUE_TIER_LABELS_EL, LEAGUE_TIER_LABELS_EN);

export const GREECE_LEAGUE_TIERS: LeagueTier[] = [
  "top_division",
  "second_division",
  "third_division",
  "regional",
  "academy",
];

export const DEFAULT_LEAGUE_TIERS: LeagueTier[] = ["top_division", "academy"];

// Ηλικιακές κατηγορίες ακαδημίας (Κ19 ως πιο κοντά στην ανδρική ομάδα, έως
// Κ5) — χρησιμοποιούνται όταν μια ομάδα top_division/second_division/
// third_division είναι ακαδημία (όχι η ίδια η ανδρική ομάδα) του συλλόγου.
export const ACADEMY_AGE_GROUPS: string[] = [
  "K19",
  "K18",
  "K17",
  "K16",
  "K15",
  "K14",
  "K13",
  "K12",
  "K11",
  "K10",
  "K9",
  "K8",
  "K7",
  "K6",
  "K5",
];

export interface ScoutingTeam {
  id: string;
  name: string;
  logo_path?: string | null;
  category?: string | null;
  league_tier: LeagueTier;
  academy_age_group?: string | null;
  federation_name?: string | null;
  league_level_name?: string | null;
  league_group_name?: string | null;
  region_name?: string | null;
  country_name?: string | null;
  player_count: number;
}

export type TransferStatus = "not_listed" | "free_agent" | "for_transfer" | "loan_listed";

const TRANSFER_STATUS_LABELS_EL: Record<TransferStatus, string> = {
  not_listed: "Χωρίς καταχώρηση",
  free_agent: "Ελεύθερος",
  for_transfer: "Προς Μεταγραφή",
  loan_listed: "Διαθέσιμος για Δανεισμό",
};
const TRANSFER_STATUS_LABELS_EN: Record<TransferStatus, string> = {
  not_listed: "Not Listed",
  free_agent: "Free Agent",
  for_transfer: "For Transfer",
  loan_listed: "Available for Loan",
};
export const TRANSFER_STATUS_LABELS = createBilingualLabels(TRANSFER_STATUS_LABELS_EL, TRANSFER_STATUS_LABELS_EN);

export const TRANSFER_STATUS_COLORS: Record<TransferStatus, string> = {
  not_listed: "text-text-muted border-line",
  free_agent: "text-status-fit border-status-fit/40 bg-status-fit/10",
  for_transfer: "text-chalk border-chalk/40 bg-chalk/10",
  loan_listed: "text-status-doubtful border-status-doubtful/40 bg-status-doubtful/10",
};

export interface PlayerAttributes {
  potential?: number | null;
  passing?: number | null;
  shooting?: number | null;
  dribbling?: number | null;
  defending?: number | null;
  attacking?: number | null;
  physical?: number | null;
}

const ATTRIBUTE_LABELS_EL: Record<keyof PlayerAttributes, string> = {
  potential: "Δυναμικό",
  passing: "Πάσα",
  shooting: "Σουτ",
  dribbling: "Ντρίμπλα",
  defending: "Άμυνα",
  attacking: "Επίθεση",
  physical: "Φυσική Κατάσταση",
};
const ATTRIBUTE_LABELS_EN: Record<keyof PlayerAttributes, string> = {
  potential: "Potential",
  passing: "Passing",
  shooting: "Shooting",
  dribbling: "Dribbling",
  defending: "Defending",
  attacking: "Attacking",
  physical: "Physical",
};
export const ATTRIBUTE_LABELS = createBilingualLabels(ATTRIBUTE_LABELS_EL, ATTRIBUTE_LABELS_EN);

// ---------------------------------------------------------------------------
// Scout Reports — κατηγοριοποίηση θέσεων + αναλυτικά χαρακτηριστικά (1-10)
// ανά κατηγορία (τερματοφύλακας/αμυντικός/μέσος/επιθετικός).
// ---------------------------------------------------------------------------
export type PositionCategory = "goalkeeper" | "defender" | "midfielder" | "attacker";

export const POSITION_CATEGORY: Record<PlayerPosition, PositionCategory> = {
  GK: "goalkeeper",
  CB: "defender",
  LB: "defender",
  RB: "defender",
  LWB: "defender",
  RWB: "defender",
  DM: "midfielder",
  CM: "midfielder",
  AM: "midfielder",
  LW: "attacker",
  RW: "attacker",
  ST: "attacker",
};

export const SCOUT_ATTRIBUTE_KEYS_BY_CATEGORY: Record<PositionCategory, string[]> = {
  attacker: [
    "finishing",
    "heading",
    "dribbling",
    "pace",
    "strength",
    "team_play",
    "off_ball_movement",
    "final_ball",
    "composure",
    "positioning",
    "ball_control",
  ],
  defender: [
    "build_up",
    "defending",
    "heading",
    "strength",
    "passing",
    "game_reading",
    "leadership",
    "pace",
    "one_on_one",
    "composure",
  ],
  midfielder: [
    "passing",
    "through_balls",
    "vision",
    "defensive_contribution",
    "offensive_contribution",
    "physical",
    "ball_control",
    "pace",
    "strength",
    "team_play",
  ],
  goalkeeper: [
    "claiming",
    "game_reading",
    "ball_playing",
    "reflexes",
    "one_on_one",
    "composure",
    "communication",
    "handling",
  ],
};

const SCOUT_ATTRIBUTE_LABELS_EL: Record<string, string> = {
  finishing: "Τελειώματα",
  heading: "Κεφαλιές",
  dribbling: "Ντρίμπλα",
  pace: "Ταχύτητα",
  strength: "Δύναμη",
  team_play: "Ομαδικότητα",
  off_ball_movement: "Κινήσεις Χωρίς Μπάλα",
  final_ball: "Τελευταία Πάσα",
  composure: "Ψυχραιμία",
  positioning: "Τοποθέτηση",
  ball_control: "Έλεγχος Μπάλας",
  build_up: "Οικοδόμηση Παιχνιδιού",
  defending: "Αμυντικά Στοιχεία",
  passing: "Πάσες",
  game_reading: "Αντίληψη",
  leadership: "Ηγετικότητα",
  one_on_one: "Δυναμικό 1-1",
  through_balls: "Προωθημένες Πάσες",
  vision: "Αντίληψη Παιχνιδιού",
  defensive_contribution: "Αμυντική Συνεισφορά",
  offensive_contribution: "Επιθετική Συνεισφορά",
  physical: "Φυσική Κατάσταση",
  claiming: "Εξόδους",
  ball_playing: "Με τη Μπάλα στα Πόδια",
  reflexes: "Αντανακλαστικά",
  communication: "Επικοινωνία / Ηγετικότητα",
  handling: "Πιάσιμο Μπάλας",
};
const SCOUT_ATTRIBUTE_LABELS_EN: Record<string, string> = {
  finishing: "Finishing",
  heading: "Heading",
  dribbling: "Dribbling",
  pace: "Pace",
  strength: "Strength",
  team_play: "Team Play",
  off_ball_movement: "Off-ball Movement",
  final_ball: "Final Ball",
  composure: "Composure",
  positioning: "Positioning",
  ball_control: "Ball Control",
  build_up: "Build Up",
  defending: "Defending",
  passing: "Passing",
  game_reading: "Game Reading",
  leadership: "Leadership",
  one_on_one: "1v1 Ability",
  through_balls: "Through Balls",
  vision: "Vision",
  defensive_contribution: "Defensive Contribution",
  offensive_contribution: "Offensive Contribution",
  physical: "Physical",
  claiming: "Claiming Crosses",
  ball_playing: "Ball Playing",
  reflexes: "Reflexes",
  communication: "Communication / Leadership",
  handling: "Handling",
};
export const SCOUT_ATTRIBUTE_LABELS = createBilingualLabels(SCOUT_ATTRIBUTE_LABELS_EL, SCOUT_ATTRIBUTE_LABELS_EN);

const POSITION_CATEGORY_LABELS_EL: Record<PositionCategory, string> = {
  goalkeeper: "Τερματοφύλακας",
  defender: "Αμυντικός",
  midfielder: "Μέσος",
  attacker: "Επιθετικός",
};
const POSITION_CATEGORY_LABELS_EN: Record<PositionCategory, string> = {
  goalkeeper: "Goalkeeper",
  defender: "Defender",
  midfielder: "Midfielder",
  attacker: "Attacker",
};
export const POSITION_CATEGORY_LABELS = createBilingualLabels(
  POSITION_CATEGORY_LABELS_EL,
  POSITION_CATEGORY_LABELS_EN
);

export interface ScoutingSeasonStats {
  matches_played: number;
  goals: number;
  assists: number;
  avg_rating?: number | null;
}

export interface ScoutingPlayer {
  id: string;
  first_name: string;
  last_name: string;
  photo_path?: string | null;
  age?: number | null;
  nationality?: string | null;
  position?: PlayerPosition | null;
  secondary_position?: PlayerPosition | null;
  height_cm?: number | null;
  weight_kg?: number | null;
  preferred_foot?: PreferredFoot | null;
  team_id?: string | null;
  team_name?: string | null;
  league_tier?: LeagueTier | null;
  transfer_status: TransferStatus;
  transfer_notes?: string | null;
  attributes?: PlayerAttributes | null;
  season_stats: ScoutingSeasonStats;
  is_shortlisted: boolean;
  linked_user_id?: string | null;
}

// ---------------------------------------------------------------------------
// Public Club Page
// ---------------------------------------------------------------------------
export interface PublicClubPlayer {
  id: string;
  first_name: string;
  last_name: string;
  photo_path?: string | null;
  player_number?: number | null;
  position?: PlayerPosition | null;
}

export interface PublicClubMatch {
  date: string;
  time?: string | null;
  stadium?: string | null;
  competition?: string | null;
  home_team_name?: string | null;
  away_team_name?: string | null;
  home_score?: number | null;
  away_score?: number | null;
  status: string;
  result?: "W" | "D" | "L" | null;
}

export interface PublicClubPage {
  name: string;
  logo_path?: string | null;
  category?: string | null;
  league_tier?: string | null;
  federation_name?: string | null;
  region_name?: string | null;
  home_stadium?: string | null;
  primary_color?: string | null;
  secondary_color?: string | null;
  description?: string | null;
  coach_name?: string | null;
  next_match?: PublicClubMatch | null;
  recent_form: PublicClubMatch[];
  roster?: PublicClubPlayer[] | null;
}

// ---------------------------------------------------------------------------
// Προφίλ χρήστη / Staff Scouting
// ---------------------------------------------------------------------------
export interface Qualification {
  id: string;
  title: string;
  year?: number | null;
}

export interface WorkExperience {
  id: string;
  organization: string;
  role_title?: string | null;
  start_year?: number | null;
  end_year?: number | null;
  description?: string | null;
}

export interface Achievement {
  id: string;
  title: string;
  year?: number | null;
  description?: string | null;
}

export interface UserSearchResult {
  id: string;
  full_name?: string | null;
  username: string;
  role: UserRole;
}

export interface TeamStaffMember {
  id: string;
  user_id: string;
  full_name?: string | null;
  username: string;
  role_title?: string | null;
}

export interface StaffTeamHistoryEntry {
  team_id: string;
  team_name: string;
  role_title?: string | null;
}

export interface ScoutingStaff {
  id: string;
  full_name?: string | null;
  role: UserRole;
  avatar_path?: string | null;
  bio?: string | null;
  staff_availability: string;
  desired_staff_role?: string | null;
  origin_federation_id?: string | null;
  origin_federation_name?: string | null;
  desired_federation_ids?: string[];
  desired_federation_names?: string[];
  linkedin_url?: string | null;
  verification_level: number;
  qualifications: Qualification[];
  achievements: Achievement[];
  experience: WorkExperience[];
  teams: StaffTeamHistoryEntry[];
  has_pending_offer_from_me?: boolean;
}

const VERIFICATION_LEVEL_INFO_EL: Record<number, { label: string; color: string; dot: string }> = {
  0: { label: "Μη επαληθευμένος", color: "text-text-muted border-line", dot: "bg-text-muted" },
  1: { label: "Μερικώς επαληθευμένος", color: "text-blue-400 border-blue-400/40", dot: "bg-blue-400" },
  2: { label: "Πλήρως επαληθευμένος", color: "text-status-fit border-status-fit/40", dot: "bg-status-fit" },
};
const VERIFICATION_LEVEL_INFO_EN: Record<number, { label: string; color: string; dot: string }> = {
  0: { label: "Unverified", color: "text-text-muted border-line", dot: "bg-text-muted" },
  1: { label: "Partially Verified", color: "text-blue-400 border-blue-400/40", dot: "bg-blue-400" },
  2: { label: "Fully Verified", color: "text-status-fit border-status-fit/40", dot: "bg-status-fit" },
};
export const VERIFICATION_LEVEL_INFO = createBilingualLabels(VERIFICATION_LEVEL_INFO_EL, VERIFICATION_LEVEL_INFO_EN);

export type AbsenceReason =
  | "injury"
  | "red_card"
  | "suspension"
  | "travel"
  | "unexcused"
  | "tutoring"
  | "illness"
  | "personal"
  | "family"
  | "school"
  | "military"
  | "national_team"
  | "other";

const ABSENCE_REASON_INFO_EL: Record<AbsenceReason, { label: string; color: string; icon: string }> = {
  injury: { label: "Τραυματίας", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "🩹" },
  red_card: { label: "Κόκκινη Κάρτα", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "🟥" },
  suspension: { label: "Ποινή / Αποβολή", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "⛔" },
  travel: { label: "Ταξίδι", color: "text-blue-400 border-blue-400/40 bg-blue-400/10", icon: "✈️" },
  unexcused: { label: "Αδικαιολόγητος", color: "text-orange-400 border-orange-400/40 bg-orange-400/10", icon: "❌" },
  tutoring: { label: "Φροντιστήριο", color: "text-purple-400 border-purple-400/40 bg-purple-400/10", icon: "📚" },
  illness: { label: "Ασθένεια", color: "text-pink-400 border-pink-400/40 bg-pink-400/10", icon: "🤒" },
  personal: { label: "Προσωπικοί Λόγοι", color: "text-text-muted border-line bg-surface-raised", icon: "👤" },
  family: { label: "Οικογενειακοί Λόγοι", color: "text-text-muted border-line bg-surface-raised", icon: "👪" },
  school: { label: "Σχολικές Υποχρεώσεις", color: "text-amber-400 border-amber-400/40 bg-amber-400/10", icon: "🏫" },
  military: { label: "Στρατιωτικές Υποχρεώσεις", color: "text-teal-400 border-teal-400/40 bg-teal-400/10", icon: "🎖️" },
  national_team: { label: "Εθνική Ομάδα", color: "text-chalk border-chalk/40 bg-chalk/10", icon: "🌍" },
  other: { label: "Άλλο / Μη Διαθέσιμος", color: "text-text-muted border-line bg-surface-raised", icon: "📋" },
};
const ABSENCE_REASON_INFO_EN: Record<AbsenceReason, { label: string; color: string; icon: string }> = {
  injury: { label: "Injured", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "🩹" },
  red_card: { label: "Red Card", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "🟥" },
  suspension: { label: "Suspension", color: "text-status-injured border-status-injured/40 bg-status-injured/10", icon: "⛔" },
  travel: { label: "Travel", color: "text-blue-400 border-blue-400/40 bg-blue-400/10", icon: "✈️" },
  unexcused: { label: "Unexcused", color: "text-orange-400 border-orange-400/40 bg-orange-400/10", icon: "❌" },
  tutoring: { label: "Tutoring", color: "text-purple-400 border-purple-400/40 bg-purple-400/10", icon: "📚" },
  illness: { label: "Illness", color: "text-pink-400 border-pink-400/40 bg-pink-400/10", icon: "🤒" },
  personal: { label: "Personal Reasons", color: "text-text-muted border-line bg-surface-raised", icon: "👤" },
  family: { label: "Family Reasons", color: "text-text-muted border-line bg-surface-raised", icon: "👪" },
  school: { label: "School Obligations", color: "text-amber-400 border-amber-400/40 bg-amber-400/10", icon: "🏫" },
  military: { label: "Military Obligations", color: "text-teal-400 border-teal-400/40 bg-teal-400/10", icon: "🎖️" },
  national_team: { label: "National Team", color: "text-chalk border-chalk/40 bg-chalk/10", icon: "🌍" },
  other: { label: "Other / Unavailable", color: "text-text-muted border-line bg-surface-raised", icon: "📋" },
};
export const ABSENCE_REASON_INFO = createBilingualLabels(ABSENCE_REASON_INFO_EL, ABSENCE_REASON_INFO_EN);

export type InjuryTypePreset =
  | "ankle_sprain"
  | "hamstring_strain"
  | "adductor_strain"
  | "calf_strain"
  | "acl_tear"
  | "meniscus_tear"
  | "iliopsoas_strain"
  | "patellar_tendinitis"
  | "concussion"
  | "fracture"
  | "muscle_strain"
  | "other";

const INJURY_TYPE_LABELS_EL: Record<InjuryTypePreset, string> = {
  ankle_sprain: "Διάστρεμμα Αστραγάλου",
  hamstring_strain: "Θλάση Δικεφάλου Μηριαίου",
  adductor_strain: "Θλάση Προσαγωγών",
  calf_strain: "Θλάση Γαστροκνημίου",
  acl_tear: "Ρήξη Πρόσθιου Χιαστού",
  meniscus_tear: "Ρήξη Μηνίσκου",
  iliopsoas_strain: "Λαγονοψοΐτιδα",
  patellar_tendinitis: "Τενοντίτιδα Επιγονατίδας",
  concussion: "Διάσειση",
  fracture: "Κάταγμα",
  muscle_strain: "Μυϊκή Θλάση (γενική)",
  other: "Άλλο",
};
const INJURY_TYPE_LABELS_EN: Record<InjuryTypePreset, string> = {
  ankle_sprain: "Ankle Sprain",
  hamstring_strain: "Hamstring Strain",
  adductor_strain: "Adductor/Groin Strain",
  calf_strain: "Calf Strain",
  acl_tear: "ACL Tear",
  meniscus_tear: "Meniscus Tear",
  iliopsoas_strain: "Iliopsoas Strain",
  patellar_tendinitis: "Patellar Tendinitis",
  concussion: "Concussion",
  fracture: "Fracture",
  muscle_strain: "Muscle Strain (general)",
  other: "Other",
};
export const INJURY_TYPE_LABELS = createBilingualLabels(INJURY_TYPE_LABELS_EL, INJURY_TYPE_LABELS_EN);
export const INJURY_TYPE_PRESETS: InjuryTypePreset[] = Object.keys(INJURY_TYPE_LABELS_EL) as InjuryTypePreset[];

export type SuspensionReasonPreset =
  | "second_yellow"
  | "direct_red"
  | "violent_conduct"
  | "unsporting_behavior"
  | "offensive_language"
  | "disciplinary_committee"
  | "other";

const SUSPENSION_REASON_LABELS_EL: Record<SuspensionReasonPreset, string> = {
  second_yellow: "Δεύτερη Κίτρινη Κάρτα",
  direct_red: "Απευθείας Κόκκινη Κάρτα",
  violent_conduct: "Βίαιη Συμπεριφορά",
  unsporting_behavior: "Αντιαθλητική Συμπεριφορά",
  offensive_language: "Προσβλητικές Εκφράσεις",
  disciplinary_committee: "Απόφαση Πειθαρχικής Επιτροπής",
  other: "Άλλο",
};
const SUSPENSION_REASON_LABELS_EN: Record<SuspensionReasonPreset, string> = {
  second_yellow: "Second Yellow Card",
  direct_red: "Direct Red Card",
  violent_conduct: "Violent Conduct",
  unsporting_behavior: "Unsporting Behavior",
  offensive_language: "Offensive Language",
  disciplinary_committee: "Disciplinary Committee Decision",
  other: "Other",
};
export const SUSPENSION_REASON_LABELS = createBilingualLabels(SUSPENSION_REASON_LABELS_EL, SUSPENSION_REASON_LABELS_EN);
export const SUSPENSION_REASON_PRESETS: SuspensionReasonPreset[] = Object.keys(
  SUSPENSION_REASON_LABELS_EL
) as SuspensionReasonPreset[];

const VERIFICATION_DOCUMENT_TYPE_LABELS_EL: Record<string, string> = {
  id_document: "Ταυτότητα / Διαβατήριο",
  coaching_license: "Πτυχίο / Άδεια Προπονητή",
  reference_letter: "Σύσταση / Βεβαίωση Προϋπηρεσίας",
  club_registration: "Επίσημο Έγγραφο Συλλόγου",
};
const VERIFICATION_DOCUMENT_TYPE_LABELS_EN: Record<string, string> = {
  id_document: "ID / Passport",
  coaching_license: "Coaching Diploma / License",
  reference_letter: "Reference / Employment Letter",
  club_registration: "Official Club Document",
};
export const VERIFICATION_DOCUMENT_TYPE_LABELS = createBilingualLabels(
  VERIFICATION_DOCUMENT_TYPE_LABELS_EL,
  VERIFICATION_DOCUMENT_TYPE_LABELS_EN
);

const STAFF_AVAILABILITY_LABELS_EL: Record<string, string> = {
  not_listed: "Χωρίς καταχώρηση",
  available: "Ελεύθερος",
  open_to_offers: "Ψάχνει για εργασία",
};
const STAFF_AVAILABILITY_LABELS_EN: Record<string, string> = {
  not_listed: "Not Listed",
  available: "Available",
  open_to_offers: "Looking for Work",
};
export const STAFF_AVAILABILITY_LABELS = createBilingualLabels(STAFF_AVAILABILITY_LABELS_EL, STAFF_AVAILABILITY_LABELS_EN);
