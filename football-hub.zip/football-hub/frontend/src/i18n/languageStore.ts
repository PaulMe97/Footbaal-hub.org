import type { Language } from "./translations";

// Μικρό, εκτός React, "store" για την τρέχουσα γλώσσα. Χρησιμοποιείται από
// static LABEL constants (π.χ. στο types.ts) που δεν μπορούν να καλέσουν το
// useLanguage() hook, ώστε να παραμένουν σωστά μεταφρασμένα σε πραγματικό
// χρόνο χωρίς να χρειάζεται να περάσουμε το `t` σε κάθε σημείο χρήσης τους.
// Το LanguageProvider ενημερώνει αυτό το store κάθε φορά που αλλάζει η γλώσσα.

function getInitialStoredLanguage(): Language {
  try {
    const stored = localStorage.getItem("fh_language");
    if (stored === "en" || stored === "el") return stored;
  } catch {
    /* localStorage μπορεί να μην είναι διαθέσιμο (SSR/tests) */
  }
  return "el";
}

let currentLanguage: Language = getInitialStoredLanguage();

export function getStoredLanguage(): Language {
  return currentLanguage;
}

export function setStoredLanguage(lang: Language): void {
  currentLanguage = lang;
}

/**
 * Δημιουργεί ένα object που "δείχνει" σαν κανονικό Record<K, string> αλλά
 * στην πραγματικότητα διαβάζει δυναμικά την τρέχουσα γλώσσα σε κάθε πρόσβαση
 * (μέσω Proxy). Έτσι, module-level exports όπως το TRANSFER_STATUS_LABELS
 * παραμένουν σωστά μεταφρασμένα σε πραγματικό χρόνο, χωρίς να χρειάζεται να
 * περάσουμε το `t` σε κάθε ένα από τα δεκάδες σημεία χρήσης τους στο codebase.
 * Υποστηρίζει property access, Object.keys/values/entries, και spread.
 */
export function createBilingualLabels<K extends string | number, V>(
  el: Record<K, V>,
  en: Record<K, V>
): Record<K, V> {
  return new Proxy({} as Record<K, V>, {
    get(_target, prop) {
      const dict = getStoredLanguage() === "en" ? en : el;
      return (dict as Record<string | symbol, V>)[prop as string];
    },
    has(_target, prop) {
      return prop in el;
    },
    ownKeys() {
      return Reflect.ownKeys(el as object);
    },
    getOwnPropertyDescriptor(_target, prop) {
      const dict = getStoredLanguage() === "en" ? en : el;
      if (!(prop in el)) return undefined;
      return { enumerable: true, configurable: true, value: (dict as Record<string | symbol, V>)[prop as string] };
    },
  });
}
