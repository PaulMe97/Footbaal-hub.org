import { Navigate, Route, Routes } from "react-router-dom";

import { ProtectedRoute } from "./components/ProtectedRoute";
import { RenewalPrompt } from "./components/RenewalPrompt";
import CalendarPage from "./pages/Calendar";
import Dashboard from "./pages/Dashboard";
import Academy from "./pages/Academy";
import AcademyTeamDetail from "./pages/academy/AcademyTeamDetail";
import Crm from "./pages/Crm";
import Login from "./pages/Login";
import Messages from "./pages/Messages";
import ClubPage from "./pages/ClubPage";
import PublicScoutReportPage from "./pages/PublicScoutReportPage";
import Register from "./pages/Register";
import Notifications from "./pages/Notifications";
import Performance from "./pages/Performance";
import Reports from "./pages/Reports";
import Scouting from "./pages/Scouting";
import ScoutReports from "./pages/ScoutReports";
import VideoEditing from "./pages/VideoEditing";
import VideoStudio from "./pages/VideoStudio";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import UserManagement from "./pages/admin/UserManagement";
import Staff from "./pages/Staff";
import MatchDetail from "./pages/matches/MatchDetail";
import MatchesList from "./pages/matches/MatchesList";
import PlayerCompare from "./pages/players/PlayerCompare";
import PlayerDetail from "./pages/players/PlayerDetail";
import PlayersList from "./pages/players/PlayersList";
import Absences from "./pages/Absences";
import TacticalBoardEditor from "./pages/tactical/TacticalBoardEditor";
import TacticalBoardsList from "./pages/tactical/TacticalBoardsList";
import TeamDetail from "./pages/teams/TeamDetail";
import TeamsList from "./pages/teams/TeamsList";
import TrainingDetail from "./pages/trainings/TrainingDetail";
import TrainingsList from "./pages/trainings/TrainingsList";

export default function App() {
  return (
    <>
      <RenewalPrompt />
      <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/club/:slug" element={<ClubPage />} />
      <Route path="/scout-report/:slug" element={<PublicScoutReportPage />} />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="/teams"
        element={
          <ProtectedRoute>
            <TeamsList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/teams/:teamId"
        element={
          <ProtectedRoute>
            <TeamDetail />
          </ProtectedRoute>
        }
      />

      <Route
        path="/players"
        element={
          <ProtectedRoute>
            <PlayersList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/absences"
        element={
          <ProtectedRoute>
            <Absences />
          </ProtectedRoute>
        }
      />
      <Route
        path="/players/compare"
        element={
          <ProtectedRoute>
            <PlayerCompare />
          </ProtectedRoute>
        }
      />
      <Route
        path="/players/:playerId"
        element={
          <ProtectedRoute>
            <PlayerDetail />
          </ProtectedRoute>
        }
      />

      <Route
        path="/matches"
        element={
          <ProtectedRoute>
            <MatchesList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/matches/:matchId"
        element={
          <ProtectedRoute>
            <MatchDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="/trainings"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <TrainingsList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/trainings/:sessionId"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <TrainingDetail />
          </ProtectedRoute>
        }
      />

      {/* Modules της επόμενης φάσης - ίδια αρχιτεκτονική, θα ενεργοποιηθούν σταδιακά */}
      <Route
        path="/calendar"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <CalendarPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tactical-board"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <TacticalBoardsList />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tactical-board/:boardId"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <TacticalBoardEditor />
          </ProtectedRoute>
        }
      />
      <Route
        path="/reports"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <Reports />
          </ProtectedRoute>
        }
      />
      <Route
        path="/performance"
        element={
          <ProtectedRoute>
            <Performance />
          </ProtectedRoute>
        }
      />
      <Route
        path="/scouting"
        element={
          <ProtectedRoute>
            <Scouting />
          </ProtectedRoute>
        }
      />
      <Route
        path="/scout-reports"
        element={
          <ProtectedRoute>
            <ScoutReports />
          </ProtectedRoute>
        }
      />
      <Route
        path="/video-editing"
        element={
          <ProtectedRoute>
            <VideoEditing />
          </ProtectedRoute>
        }
      />
      <Route
        path="/video-editing/:id"
        element={
          <ProtectedRoute>
            <VideoStudio />
          </ProtectedRoute>
        }
      />
      <Route
        path="/messages"
        element={
          <ProtectedRoute>
            <Messages />
          </ProtectedRoute>
        }
      />
      <Route
        path="/staff"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <Staff />
          </ProtectedRoute>
        }
      />
      <Route
        path="/academy"
        element={
          <ProtectedRoute blockedRoles={["player", "assistant_coach", "fitness_coach", "analyst", "scout"]}>
            <Academy />
          </ProtectedRoute>
        }
      />
      <Route
        path="/academy/teams/:teamId"
        element={
          <ProtectedRoute blockedRoles={["player", "assistant_coach", "fitness_coach", "analyst", "scout"]}>
            <AcademyTeamDetail />
          </ProtectedRoute>
        }
      />
      <Route
        path="/crm"
        element={
          <ProtectedRoute blockedRoles={["player"]}>
            <Crm />
          </ProtectedRoute>
        }
      />
      <Route
        path="/notifications"
        element={
          <ProtectedRoute>
            <Notifications />
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/users"
        element={
          <ProtectedRoute>
            <UserManagement />
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
