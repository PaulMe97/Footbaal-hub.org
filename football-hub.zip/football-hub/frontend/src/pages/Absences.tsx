import { FormEvent, useEffect, useState } from "react";

import { extractErrorMessage } from "../api/client";
import {
  createAbsence,
  deleteAbsence,
  listAbsences,
  updateAbsence,
} from "../api/absences";
import type { AbsenceCreatePayload, PlayerAbsenceItem } from "../api/absences";
import { listPlayerInjuries, listPlayers, updatePlayerInjury } from "../api/players";
import { listMatches } from "../api/matches";
import { listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { PlayerHistoryModal } from "../components/PlayerHistoryModal";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { useContextMenu } from "../components/ui/ContextMenu";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog, Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import {
  ABSENCE_REASON_INFO,
  INJURY_TYPE_LABELS,
  INJURY_TYPE_PRESETS,
  SUSPENSION_REASON_LABELS,
  SUSPENSION_REASON_PRESETS,
} from "../types";
import type { AbsenceReason, InjuryTypePreset, Player, SuspensionReasonPreset, Team } from "../types";

const ABSENCE_REASONS: AbsenceReason[] = [
  "red_card",
  "suspension",
  "travel",
  "unexcused",
  "tutoring",
  "illness",
  "personal",
  "family",
  "school",
  "military",
  "national_team",
  "other",
];

function daysUntil(dateStr: string): number {
  const target = new Date(dateStr + "T00:00:00");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export default function Absences() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const toast = useToast();
  const canEdit = !!user && ["president", "technical_director", "head_coach"].includes(user.role);
  const menu = useContextMenu();

  const [absences, setAbsences] = useState<PlayerAbsenceItem[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [filterTeam, setFilterTeam] = useState("");
  const [filterReason, setFilterReason] = useState("");
  const [activeOnly, setActiveOnly] = useState(true);

  const [showForm, setShowForm] = useState(false);
  const [editingAbsence, setEditingAbsence] = useState<PlayerAbsenceItem | null>(null);
  const [editingInjuryId, setEditingInjuryId] = useState<string | null>(null);
  const [formPlayerId, setFormPlayerId] = useState("");
  const [formReason, setFormReason] = useState<AbsenceReason>("red_card");
  const [formStartDate, setFormStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [formEndDate, setFormEndDate] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // --- Πλουσιότερη επεξεργασία τραυματισμών (τύπος τραυματισμού) ---
  const [injuryTypePreset, setInjuryTypePreset] = useState<InjuryTypePreset | "">("");
  const [injuryTypeCustom, setInjuryTypeCustom] = useState("");
  const [injuryExpectedReturn, setInjuryExpectedReturn] = useState("");
  const [injuryNotes, setInjuryNotes] = useState("");

  // --- Πλουσιότερη επεξεργασία αποβολών (λόγος + ημέρες ή αγωνιστικές) ---
  const [suspensionReasonPreset, setSuspensionReasonPreset] = useState<SuspensionReasonPreset | "">("");
  const [suspensionReasonCustom, setSuspensionReasonCustom] = useState("");
  const [suspensionDays, setSuspensionDays] = useState("");
  const [durationUnit, setDurationUnit] = useState<"days" | "matches">("days");
  const [matchDays, setMatchDays] = useState("");

  const [deleteTarget, setDeleteTarget] = useState<PlayerAbsenceItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const [historyPlayerId, setHistoryPlayerId] = useState<string | null>(null);
  const [historyPlayerName, setHistoryPlayerName] = useState("");

  async function load() {
    setIsLoading(true);
    try {
      const [a, t2, p] = await Promise.all([
        listAbsences({
          team_id: filterTeam || undefined,
          active_only: activeOnly || undefined,
        }),
        listTeams(),
        listPlayers(),
      ]);
      setAbsences(a);
      setTeams(t2);
      setPlayers(p);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterTeam, activeOnly]);

  const filteredAbsences = filterReason ? absences.filter((a) => a.reason === filterReason) : absences;

  function matchInjuryPreset(storedType: string | null | undefined): { preset: InjuryTypePreset | ""; custom: string } {
    if (!storedType) return { preset: "", custom: "" };
    const match = INJURY_TYPE_PRESETS.find((p) => p !== "other" && INJURY_TYPE_LABELS[p] === storedType);
    if (match) return { preset: match, custom: "" };
    return { preset: "other", custom: storedType };
  }

  function matchSuspensionPreset(storedNotes: string | null | undefined): { preset: SuspensionReasonPreset | ""; custom: string } {
    if (!storedNotes) return { preset: "", custom: "" };
    const match = SUSPENSION_REASON_PRESETS.find((p) => p !== "other" && SUSPENSION_REASON_LABELS[p] === storedNotes);
    if (match) return { preset: match, custom: "" };
    return { preset: "other", custom: storedNotes };
  }

  function openNewForm() {
    setEditingAbsence(null);
    setEditingInjuryId(null);
    setFormPlayerId("");
    setFormReason("red_card");
    setFormStartDate(new Date().toISOString().slice(0, 10));
    setFormEndDate("");
    setFormNotes("");
    setSuspensionReasonPreset("");
    setSuspensionReasonCustom("");
    setSuspensionDays("");
    setDurationUnit("days");
    setMatchDays("");
    setShowForm(true);
  }

  async function openEditForm(absence: PlayerAbsenceItem) {
    setEditingAbsence(absence);
    setFormPlayerId(absence.player_id);
    setFormReason(absence.reason);
    setFormStartDate(absence.start_date);
    setFormEndDate(absence.end_date || "");

    if (absence.id.startsWith("injury:")) {
      const injuryId = absence.id.slice("injury:".length);
      setEditingInjuryId(injuryId);
      try {
        const injuries = await listPlayerInjuries(absence.player_id);
        const injury = injuries.find((i) => i.id === injuryId);
        const { preset, custom } = matchInjuryPreset(injury?.injury_type);
        setInjuryTypePreset(preset);
        setInjuryTypeCustom(custom);
        setInjuryExpectedReturn(injury?.expected_return || "");
        setInjuryNotes(injury?.notes || "");
      } catch (err) {
        toast.show(extractErrorMessage(err), "error");
      }
    } else {
      setEditingInjuryId(null);
      setFormNotes(absence.notes || "");
      if (absence.reason === "red_card" || absence.reason === "suspension") {
        const { preset, custom } = matchSuspensionPreset(absence.notes);
        setSuspensionReasonPreset(preset);
        setSuspensionReasonCustom(custom);
      } else {
        setSuspensionReasonPreset("");
        setSuspensionReasonCustom("");
      }
      setSuspensionDays("");
      setDurationUnit("days");
      setMatchDays("");
    }
    setShowForm(true);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!formPlayerId) return;
    setIsSubmitting(true);
    try {
      if (editingInjuryId) {
        const resolvedType =
          injuryTypePreset === "other" ? injuryTypeCustom : injuryTypePreset ? INJURY_TYPE_LABELS[injuryTypePreset] : undefined;
        await updatePlayerInjury(formPlayerId, editingInjuryId, {
          injury_type: resolvedType || undefined,
          expected_return: injuryExpectedReturn || undefined,
          notes: injuryNotes || undefined,
        });
        toast.show(t("absences.injuryUpdated"), "success");
      } else {
        let finalNotes = formNotes;
        let finalEndDate = formEndDate;
        if (formReason === "red_card" || formReason === "suspension") {
          const reasonText =
            suspensionReasonPreset === "other"
              ? suspensionReasonCustom
              : suspensionReasonPreset
                ? SUSPENSION_REASON_LABELS[suspensionReasonPreset]
                : "";
          finalNotes = [reasonText, formNotes].filter(Boolean).join(" — ");
          if (durationUnit === "days") {
            const days = parseInt(suspensionDays, 10);
            if (!isNaN(days) && days > 0) {
              const start = new Date(formStartDate + "T00:00:00");
              start.setDate(start.getDate() + days);
              finalEndDate = start.toISOString().slice(0, 10);
            }
          } else {
            const count = parseInt(matchDays, 10);
            if (!isNaN(count) && count > 0) {
              const suspendedPlayer = players.find((p) => p.id === formPlayerId);
              if (suspendedPlayer?.current_team_id) {
                try {
                  const teamMatches = await listMatches({ team_id: suspendedPlayer.current_team_id });
                  const upcoming = teamMatches
                    .filter((m) => m.date >= formStartDate)
                    .sort((a, b) => a.date.localeCompare(b.date));
                  if (upcoming.length >= count) {
                    finalEndDate = upcoming[count - 1].date;
                  } else {
                    toast.show(t("absences.notEnoughScheduledMatches"), "error");
                  }
                } catch {
                  toast.show(t("absences.notEnoughScheduledMatches"), "error");
                }
              }
            }
          }
        }
        if (editingAbsence) {
          await updateAbsence(editingAbsence.id, {
            reason: formReason,
            start_date: formStartDate,
            end_date: finalEndDate || null,
            notes: finalNotes || undefined,
          });
          toast.show(t("absences.absenceUpdated"), "success");
        } else {
          const payload: AbsenceCreatePayload = {
            player_id: formPlayerId,
            reason: formReason,
            start_date: formStartDate,
            end_date: finalEndDate || undefined,
            notes: finalNotes || undefined,
          };
          await createAbsence(payload);
          toast.show(t("absences.absenceCreated"), "success");
        }
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteAbsence(deleteTarget.id);
      toast.show(t("absences.absenceDeleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  async function handleMarkResolved(absence: PlayerAbsenceItem) {
    try {
      await updateAbsence(absence.id, { end_date: new Date().toISOString().slice(0, 10) });
      toast.show(t("absences.markedResolved"), "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleReturnFromInjury(absence: PlayerAbsenceItem) {
    const injuryId = absence.id.replace("injury:", "");
    try {
      await updatePlayerInjury(absence.player_id, injuryId, {
        status: "recovered",
        actual_return: new Date().toISOString().slice(0, 10),
      });
      toast.show(t("absences.playerReturnedFromInjury"), "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  function openCardMenu(e: { preventDefault: () => void; clientX: number; clientY: number }, a: PlayerAbsenceItem) {
    const isInjuryEntry = a.id.startsWith("injury:");
    menu.open(e, [
      {
        items: [
          {
            label: t("absences.contextViewHistory"),
            onClick: () => {
              setHistoryPlayerId(a.player_id);
              setHistoryPlayerName(a.player_name || "");
            },
          },
          ...(canEdit && a.is_editable && isInjuryEntry
            ? [
                { label: t("absences.contextEdit"), onClick: () => openEditForm(a) },
                ...(a.is_active
                  ? [{ label: t("absences.contextReturnFromInjury"), onClick: () => handleReturnFromInjury(a) }]
                  : []),
              ]
            : []),
          ...(canEdit && a.is_editable && !isInjuryEntry
            ? [
                { label: t("absences.contextEdit"), onClick: () => openEditForm(a) },
                ...(a.is_active
                  ? [{ label: t("absences.contextMarkResolved"), onClick: () => handleMarkResolved(a) }]
                  : []),
                { label: t("absences.contextDelete"), onClick: () => setDeleteTarget(a), danger: true },
              ]
            : []),
        ],
      },
    ]);
  }

  return (
    <AppLayout title={t("absences.pageTitle")}>
      <p className="mb-1 text-sm text-text-muted">{t("absences.introText")}</p>
      {!canEdit && <p className="mb-4 text-xs text-text-muted">{t("absences.editorHint")}</p>}

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)} className="w-48">
          <option value="">{t("absences.allTeams")}</option>
          {teams.map((tm) => (
            <option key={tm.id} value={tm.id}>
              {tm.name}
            </option>
          ))}
        </Select>
        <Select value={filterReason} onChange={(e) => setFilterReason(e.target.value)} className="w-48">
          <option value="">{t("absences.allReasons")}</option>
          {ABSENCE_REASONS.map((r) => (
            <option key={r} value={r}>
              {ABSENCE_REASON_INFO[r].icon} {ABSENCE_REASON_INFO[r].label}
            </option>
          ))}
        </Select>
        <label className="flex items-center gap-2 text-sm text-text-primary">
          <input
            type="checkbox"
            checked={activeOnly}
            onChange={(e) => setActiveOnly(e.target.checked)}
            className="h-3.5 w-3.5 accent-chalk"
          />
          {t("absences.showActiveOnly")}
        </label>
        {canEdit && (
          <Button onClick={openNewForm} className="ml-auto">
            {t("absences.newAbsence")}
          </Button>
        )}
      </div>

      {isLoading ? (
        <Spinner />
      ) : filteredAbsences.length === 0 ? (
        <EmptyState title={t("absences.noAbsencesFound")} />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filteredAbsences.map((a) => {
            const info = ABSENCE_REASON_INFO[a.reason];
            const returnDays = a.end_date ? daysUntil(a.end_date) : null;
            return (
              <Card
                key={a.id}
                corners
                className="flex cursor-pointer flex-col gap-2 p-4 transition-colors hover:border-chalk"
                onClick={() => {
                  setHistoryPlayerId(a.player_id);
                  setHistoryPlayerName(a.player_name || "");
                }}
                onContextMenu={(e) => openCardMenu(e, a)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    setHistoryPlayerId(a.player_id);
                    setHistoryPlayerName(a.player_name || "");
                  }
                }}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="truncate text-sm text-text-primary">{a.player_name || "—"}</p>
                  {!a.is_active && (
                    <span className="shrink-0 rounded-full border border-status-fit/40 bg-status-fit/10 px-2 py-0.5 text-[10px] text-status-fit">
                      {t("absences.resolvedBadge")}
                    </span>
                  )}
                </div>
                <p className="truncate text-xs text-text-muted">{a.team_name || "—"}</p>
                <span
                  className={`inline-flex w-fit items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${info.color}`}
                >
                  {info.icon} {info.label}
                </span>
                <p className="text-xs text-text-muted">
                  {a.end_date ? (
                    <>
                      {t("absences.returnsPrefix")}
                      {returnDays === 0 ? t("absences.returnsTodayLabel") : a.end_date}
                    </>
                  ) : (
                    t("absences.indefiniteLabel")
                  )}
                </p>
                {a.notes && <p className="text-xs text-text-muted">{a.notes}</p>}
                {a.created_by_name && (
                  <p className="text-[10px] text-text-muted">
                    {t("absences.createdByPrefix")}
                    {a.created_by_name}
                  </p>
                )}
                <div className="mt-auto flex items-center justify-between border-t border-line pt-2">
                  <span className="text-xs text-chalk">{t("absences.viewHistoryButton")}</span>
                  {!a.is_editable && (
                    <span className="text-[10px] text-text-muted">{t("absences.readOnlySourceNote")}</span>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={
          editingInjuryId
            ? t("absences.injuryEditTitle")
            : editingAbsence
              ? t("absences.formTitleEdit")
              : t("absences.formTitleNew")
        }
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Select
            label={t("absences.selectPlayerLabel")}
            value={formPlayerId}
            onChange={(e) => setFormPlayerId(e.target.value)}
            disabled={!!editingAbsence}
            required
          >
            <option value="">{t("absences.selectPlayerPlaceholder")}</option>
            {players.map((p) => (
              <option key={p.id} value={p.id}>
                {p.first_name} {p.last_name}
                {p.team_name ? ` — ${p.team_name}` : ""}
              </option>
            ))}
          </Select>

          {editingInjuryId ? (
            <>
              <Select
                label={t("absences.injuryTypeLabel")}
                value={injuryTypePreset}
                onChange={(e) => setInjuryTypePreset(e.target.value as InjuryTypePreset)}
              >
                <option value="">—</option>
                {INJURY_TYPE_PRESETS.map((p) => (
                  <option key={p} value={p}>
                    {INJURY_TYPE_LABELS[p]}
                  </option>
                ))}
              </Select>
              {injuryTypePreset === "other" && (
                <Input
                  placeholder={t("absences.customReasonPlaceholder")}
                  value={injuryTypeCustom}
                  onChange={(e) => setInjuryTypeCustom(e.target.value)}
                />
              )}
              <Input
                label={t("absences.expectedReturnLabel")}
                type="date"
                value={injuryExpectedReturn}
                onChange={(e) => setInjuryExpectedReturn(e.target.value)}
              />
              <Textarea
                label={t("absences.injuryNotesLabel")}
                value={injuryNotes}
                onChange={(e) => setInjuryNotes(e.target.value)}
              />
            </>
          ) : (
            <>
              <Select
                label={t("absences.selectReasonLabel")}
                value={formReason}
                onChange={(e) => setFormReason(e.target.value as AbsenceReason)}
              >
                {ABSENCE_REASONS.map((r) => (
                  <option key={r} value={r}>
                    {ABSENCE_REASON_INFO[r].icon} {ABSENCE_REASON_INFO[r].label}
                  </option>
                ))}
              </Select>
              {(formReason === "red_card" || formReason === "suspension") && (
                <>
                  <Select
                    label={t("absences.suspensionReasonLabel")}
                    value={suspensionReasonPreset}
                    onChange={(e) => setSuspensionReasonPreset(e.target.value as SuspensionReasonPreset)}
                  >
                    <option value="">—</option>
                    {SUSPENSION_REASON_PRESETS.map((p) => (
                      <option key={p} value={p}>
                        {SUSPENSION_REASON_LABELS[p]}
                      </option>
                    ))}
                  </Select>
                  {suspensionReasonPreset === "other" && (
                    <Input
                      placeholder={t("absences.customReasonPlaceholder")}
                      value={suspensionReasonCustom}
                      onChange={(e) => setSuspensionReasonCustom(e.target.value)}
                    />
                  )}
                  <div>
                    <p className="mb-1.5 text-xs text-text-muted">{t("absences.durationUnitLabel")}</p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setDurationUnit("days")}
                        className={`rounded-md border px-3 py-1.5 text-xs ${
                          durationUnit === "days"
                            ? "border-chalk/60 bg-chalk/10 text-chalk"
                            : "border-line text-text-muted hover:border-chalk"
                        }`}
                      >
                        {t("absences.durationUnitDays")}
                      </button>
                      <button
                        type="button"
                        onClick={() => setDurationUnit("matches")}
                        className={`rounded-md border px-3 py-1.5 text-xs ${
                          durationUnit === "matches"
                            ? "border-chalk/60 bg-chalk/10 text-chalk"
                            : "border-line text-text-muted hover:border-chalk"
                        }`}
                      >
                        {t("absences.durationUnitMatchDays")}
                      </button>
                    </div>
                  </div>
                  {durationUnit === "days" ? (
                    <>
                      <Input
                        label={t("absences.suspensionDaysLabel")}
                        type="number"
                        min="1"
                        value={suspensionDays}
                        onChange={(e) => setSuspensionDays(e.target.value)}
                      />
                      <p className="-mt-2 text-xs text-text-muted">{t("absences.suspensionDaysHint")}</p>
                    </>
                  ) : (
                    <>
                      <Input
                        label={t("absences.matchDaysLabel")}
                        type="number"
                        min="1"
                        value={matchDays}
                        onChange={(e) => setMatchDays(e.target.value)}
                      />
                      <p className="-mt-2 text-xs text-text-muted">{t("absences.matchDaysHint")}</p>
                    </>
                  )}
                </>
              )}
              <Input
                label={t("absences.startDateLabel")}
                type="date"
                value={formStartDate}
                onChange={(e) => setFormStartDate(e.target.value)}
                required
              />
              <Input
                label={t("absences.endDateLabel")}
                type="date"
                value={formEndDate}
                onChange={(e) => setFormEndDate(e.target.value)}
              />
              <Textarea label={t("absences.notesLabel")} value={formNotes} onChange={(e) => setFormNotes(e.target.value)} />
            </>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isSubmitting}>
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("absences.confirmDeleteTitle")}
        message={t("absences.confirmDeleteMessage")}
        isLoading={isDeleting}
      />

      <PlayerHistoryModal
        playerId={historyPlayerId}
        playerName={historyPlayerName}
        isOpen={!!historyPlayerId}
        onClose={() => setHistoryPlayerId(null)}
      />

      {menu.render()}
    </AppLayout>
  );
}
