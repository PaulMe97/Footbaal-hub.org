import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import { API_BASE_URL } from "../api/client";
import { getPublicScoutReport } from "../api/public";
import type { PublicScoutReport } from "../api/public";
import { Spinner } from "../components/ui/EmptyState";
import { SCOUT_ATTRIBUTE_LABELS } from "../types";
import { useLanguage } from "../context/LanguageContext";

function mediaUrl(path?: string | null): string | undefined {
  if (!path) return undefined;
  return `${API_BASE_URL}${path}`;
}

function PublicStars({ value }: { value: number }) {
  const rounded = Math.round(value);
  return (
    <span className="text-lg">
      <span className="text-amber-400">{"★".repeat(rounded)}</span>
      <span className="text-white/20">{"★".repeat(5 - rounded)}</span>
    </span>
  );
}

function PublicAttributeBar({ label, value }: { label: string; value: number }) {
  const segments = Array.from({ length: 10 }, (_, i) => i + 1);
  return (
    <div className="flex items-center gap-3 py-1">
      <span className="w-40 shrink-0 truncate text-sm text-white/80">{label}</span>
      <div className="flex flex-1 gap-1">
        {segments.map((n) => (
          <div key={n} className={`h-2.5 flex-1 rounded-sm ${n <= value ? "bg-lime-400" : "bg-white/10"}`} />
        ))}
      </div>
      <span className="w-10 shrink-0 text-right font-mono text-sm text-white/70">
        {value > 0 ? `${value}/10` : "—"}
      </span>
    </div>
  );
}

export default function PublicScoutReportPage() {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useLanguage();
  const [report, setReport] = useState<PublicScoutReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!slug) return;
    getPublicScoutReport(slug)
      .then(setReport)
      .catch(() => setNotFound(true))
      .finally(() => setIsLoading(false));
  }, [slug]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0A0F0D]">
        <Spinner />
      </div>
    );
  }

  if (notFound || !report) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#0A0F0D] px-4 text-center">
        <p className="font-display text-xl text-white">{t("publicScoutReport.notFoundTitle")}</p>
        <p className="text-sm text-white/50">{t("publicScoutReport.notFoundDescription")}</p>
        <Link to="/" className="mt-2 text-sm text-lime-400 hover:underline">
          ← FootballHub
        </Link>
      </div>
    );
  }

  const footLabel =
    report.strong_foot === "right"
      ? t("scoutReports.footRight")
      : report.strong_foot === "left"
        ? t("scoutReports.footLeft")
        : report.strong_foot === "both"
          ? t("scoutReports.footBoth")
          : null;

  return (
    <div className="min-h-screen bg-[#0A0F0D] text-white">
      <div className="px-4 py-14" style={{ background: "linear-gradient(160deg, #3E7D5233 0%, #0A0F0D 65%)" }}>
        <div className="mx-auto flex max-w-2xl flex-col items-center text-center">
          <div className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 border-lime-400 bg-white/5 font-display text-2xl">
            {report.photo_path ? (
              <img src={mediaUrl(report.photo_path)} alt="" className="h-full w-full object-cover" />
            ) : (
              report.full_name.slice(0, 2).toUpperCase()
            )}
          </div>
          <h1 className="mt-4 font-display text-3xl tracking-wide">{report.full_name}</h1>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-white/70">
            {[report.club_name, report.position, report.league].filter(Boolean).join(" · ") || null}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-2xl space-y-8 px-4 py-10">
        <section>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 rounded-lg border border-white/10 bg-white/5 p-4 text-sm sm:grid-cols-3">
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.fieldAge")}</dt>
              <dd className="text-white">{report.age ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.fieldJerseyNumber")}</dt>
              <dd className="text-white">{report.jersey_number ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.fieldNationality")}</dt>
              <dd className="text-white">{report.nationality || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.fieldStrongFoot")}</dt>
              <dd className="text-white">{footLabel || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.viewModalGoalsPerSeason")}</dt>
              <dd className="text-white">{report.goals_per_season ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-xs text-white/40">{t("scoutReports.fieldRole")}</dt>
              <dd className="text-white">{report.role || "—"}</dd>
            </div>
          </dl>
        </section>

        {(report.positive_rating || report.positive_notes) && (
          <section>
            <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-white/50">
              {t("scoutReports.sectionPositive")}
            </h2>
            <PublicStars value={report.positive_rating || 0} />
            {report.positive_notes && <p className="mt-2 text-sm text-white/80">{report.positive_notes}</p>}
          </section>
        )}

        {(report.negative_rating || report.negative_notes) && (
          <section>
            <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-white/50">
              {t("scoutReports.sectionNegative")}
            </h2>
            <PublicStars value={report.negative_rating || 0} />
            {report.negative_notes && <p className="mt-2 text-sm text-white/80">{report.negative_notes}</p>}
          </section>
        )}

        {(report.physical_mental_rating || report.physical_mental_notes) && (
          <section>
            <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-white/50">
              {t("scoutReports.sectionPhysicalMental")}
            </h2>
            <PublicStars value={report.physical_mental_rating || 0} />
            {report.physical_mental_notes && (
              <p className="mt-2 text-sm text-white/80">{report.physical_mental_notes}</p>
            )}
          </section>
        )}

        {Object.keys(report.detailed_attributes || {}).length > 0 && (
          <section>
            <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-white/50">
              {t("scoutReports.sectionDetailedAttributes")}
            </h2>
            {Object.entries(report.detailed_attributes).map(([key, value]) => (
              <PublicAttributeBar key={key} label={SCOUT_ATTRIBUTE_LABELS[key] || key} value={value} />
            ))}
          </section>
        )}

        {(report.conclusion_text || report.recommended != null || report.potential_rating != null) && (
          <section>
            <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-white/50">
              {t("scoutReports.sectionConclusion")}
            </h2>
            {report.conclusion_text && <p className="mb-3 text-sm text-white/80">{report.conclusion_text}</p>}
            <div className="flex flex-wrap items-center gap-2">
              {report.recommended != null && (
                <span
                  className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs ${
                    report.recommended
                      ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-400"
                      : "border-red-400/40 bg-red-400/10 text-red-400"
                  }`}
                >
                  {report.recommended ? t("scoutReports.recommendedYes") : t("scoutReports.recommendedNo")}
                </span>
              )}
              {report.potential_rating != null && (
                <span className="inline-flex items-center gap-1 rounded-full border border-lime-400/40 bg-lime-400/10 px-3 py-1 text-xs text-lime-400">
                  {t("scoutReports.fieldPotential")}: {report.potential_rating}/10
                </span>
              )}
            </div>
          </section>
        )}
      </div>

      <div className="border-t border-white/10 py-6 text-center text-xs text-white/30">
        Powered by{" "}
        <Link to="/" className="text-lime-400 hover:underline">
          FootballHub
        </Link>
      </div>
    </div>
  );
}
