import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { listAcademyTeams } from "../api/academy";
import type { AcademyTeamSummary } from "../api/academy";
import { extractErrorMessage } from "../api/client";
import { AppLayout } from "../components/layout/AppLayout";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";

export default function Academy() {
  const toast = useToast();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [teams, setTeams] = useState<AcademyTeamSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    listAcademyTeams()
      .then(setTeams)
      .catch((err) => toast.show(extractErrorMessage(err), "error"))
      .finally(() => setIsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AppLayout title={t("academy.title")}>
      <p className="mb-4 text-sm text-text-muted">{t("academy.introText")}</p>

      {isLoading ? (
        <Spinner />
      ) : teams.length === 0 ? (
        <EmptyState
          title={t("academy.noAcademyTeamsYet")}
          description={t("academy.noAcademyTeamsDescription")}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((academyTeam) => (
            <button
              key={academyTeam.team_id}
              onClick={() => navigate(`/academy/teams/${academyTeam.team_id}`)}
              className="text-left"
            >
              <Card corners className="p-5 transition-colors hover:border-chalk">
                <h3 className="font-display text-base text-text-primary">{academyTeam.team_name}</h3>
                {academyTeam.category && <p className="text-xs text-text-muted">{academyTeam.category}</p>}
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <p className="text-2xl font-display text-text-primary">{academyTeam.player_count}</p>
                    <p className="text-[11px] text-text-muted">{t("teams.playersUnit")}</p>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-2xl font-display ${
                        academyTeam.total_owed > 0 ? "text-status-injured" : "text-status-fit"
                      }`}
                    >
                      €{academyTeam.total_owed.toFixed(0)}
                    </p>
                    <p className="text-[11px] text-text-muted">
                      {academyTeam.players_with_debt > 0
                        ? `${academyTeam.players_with_debt}${t("academy.withDebtSuffix")}`
                        : t("academy.allSettled")}
                    </p>
                  </div>
                </div>
              </Card>
            </button>
          ))}
        </div>
      )}
    </AppLayout>
  );
}
