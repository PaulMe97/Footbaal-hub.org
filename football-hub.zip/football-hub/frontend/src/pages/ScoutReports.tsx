import { ChangeEvent, FormEvent, useEffect, useState } from "react";

import { extractErrorMessage, mediaUrl } from "../api/client";
import {
  addScoutReportToShortlist,
  createScoutReport,
  deleteScoutReport,
  downloadScoutReportPdf,
  listScoutReports,
  publishScoutReport,
  removeScoutReportFromShortlist,
  updateScoutReport,
  uploadScoutReportPhoto,
} from "../api/scoutReports";
import type { ScoutReportItem, ScoutReportPayload } from "../api/scoutReports";
import { listTeams } from "../api/teams";
import { AttributeBar } from "../components/AttributeBar";
import { StarRating } from "../components/StarRating";
import { QuickSuggestions, appendSuggestion } from "../components/QuickSuggestions";
import { useQuickSuggestions } from "../utils/quickSuggestions";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { useContextMenu } from "../components/ui/ContextMenu";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog, Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";
import {
  POSITION_CATEGORY,
  POSITION_CATEGORY_LABELS,
  POSITIONS,
  SCOUT_ATTRIBUTE_KEYS_BY_CATEGORY,
  SCOUT_ATTRIBUTE_LABELS,
} from "../types";
import type { PlayerPosition, PositionCategory, Team } from "../types";

const STRONG_FOOT_OPTIONS = ["right", "left", "both"] as const;

const EMPTY_FORM = {
  full_name: "",
  club_name: "",
  age: "",
  position: "" as PlayerPosition | "",
  role: "",
  league: "",
  jersey_number: "",
  nationality: "",
  strong_foot: "" as "" | (typeof STRONG_FOOT_OPTIONS)[number],
  goals_per_season: "",
  team_id: "",
  positive_rating: 0,
  positive_notes: "",
  negative_rating: 0,
  negative_notes: "",
  physical_mental_rating: 0,
  physical_mental_notes: "",
  conclusion_text: "",
  recommended: undefined as boolean | undefined,
  potential_rating: 0,
};

export default function ScoutReports() {
  const { t } = useLanguage();
  const toast = useToast();
  const menu = useContextMenu();

  const [reports, setReports] = useState<ScoutReportItem[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"all" | "mine">("all");
  const [filterPosition, setFilterPosition] = useState("");
  const [filterTeam, setFilterTeam] = useState("");

  const [showForm, setShowForm] = useState(false);
  const [editingReport, setEditingReport] = useState<ScoutReportItem | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [detailedAttrs, setDetailedAttrs] = useState<Record<string, number>>({});
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [viewingReport, setViewingReport] = useState<ScoutReportItem | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<ScoutReportItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  async function load() {
    setIsLoading(true);
    try {
      const [r, tm] = await Promise.all([
        listScoutReports({
          team_id: filterTeam || undefined,
          position: filterPosition || undefined,
          my_list: activeTab === "mine" || undefined,
        }),
        listTeams(),
      ]);
      setReports(r);
      setTeams(tm);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterTeam, filterPosition, activeTab]);

  function positionCategory(pos: string): PositionCategory | null {
    return POSITION_CATEGORY[pos as PlayerPosition] || null;
  }

  function handlePositionChange(pos: string) {
    setForm((f) => ({ ...f, position: pos as PlayerPosition | "" }));
    const category = positionCategory(pos);
    if (!category) {
      setDetailedAttrs({});
      return;
    }
    const keys = SCOUT_ATTRIBUTE_KEYS_BY_CATEGORY[category];
    setDetailedAttrs((prev) => {
      const next: Record<string, number> = {};
      for (const key of keys) {
        next[key] = prev[key] ?? 5;
      }
      return next;
    });
  }

  function openNewForm() {
    setEditingReport(null);
    setForm(EMPTY_FORM);
    setDetailedAttrs({});
    setPhotoFile(null);
    setPhotoPreview(null);
    setShowForm(true);
  }

  function openEditForm(report: ScoutReportItem) {
    setEditingReport(report);
    setForm({
      full_name: report.full_name,
      club_name: report.club_name || "",
      age: report.age?.toString() || "",
      position: (report.position as PlayerPosition) || "",
      role: report.role || "",
      league: report.league || "",
      jersey_number: report.jersey_number?.toString() || "",
      nationality: report.nationality || "",
      strong_foot: (report.strong_foot as "" | (typeof STRONG_FOOT_OPTIONS)[number]) || "",
      goals_per_season: report.goals_per_season?.toString() || "",
      team_id: report.team_id || "",
      positive_rating: report.positive_rating || 0,
      positive_notes: report.positive_notes || "",
      negative_rating: report.negative_rating || 0,
      negative_notes: report.negative_notes || "",
      physical_mental_rating: report.physical_mental_rating || 0,
      physical_mental_notes: report.physical_mental_notes || "",
      conclusion_text: report.conclusion_text || "",
      recommended: report.recommended === null ? undefined : report.recommended,
      potential_rating: report.potential_rating || 0,
    });
    setDetailedAttrs(report.detailed_attributes || {});
    setPhotoFile(null);
    setPhotoPreview(mediaUrl(report.photo_path) || null);
    setShowForm(true);
  }

  function openView(report: ScoutReportItem) {
    setViewingReport(report);
  }

  function handlePhotoChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!form.full_name.trim()) return;
    setIsSubmitting(true);
    try {
      const payload: ScoutReportPayload = {
        full_name: form.full_name.trim(),
        club_name: form.club_name || undefined,
        age: form.age ? parseInt(form.age, 10) : undefined,
        position: form.position || undefined,
        role: form.role || undefined,
        league: form.league || undefined,
        jersey_number: form.jersey_number ? parseInt(form.jersey_number, 10) : undefined,
        nationality: form.nationality || undefined,
        strong_foot: form.strong_foot || undefined,
        goals_per_season: form.goals_per_season ? parseInt(form.goals_per_season, 10) : undefined,
        team_id: form.team_id || undefined,
        positive_rating: form.positive_rating || undefined,
        positive_notes: form.positive_notes || undefined,
        negative_rating: form.negative_rating || undefined,
        negative_notes: form.negative_notes || undefined,
        physical_mental_rating: form.physical_mental_rating || undefined,
        physical_mental_notes: form.physical_mental_notes || undefined,
        detailed_attributes: Object.keys(detailedAttrs).length > 0 ? detailedAttrs : undefined,
        conclusion_text: form.conclusion_text || undefined,
        recommended: form.recommended,
        potential_rating: form.potential_rating || undefined,
      };

      let savedId: string;
      if (editingReport) {
        const updated = await updateScoutReport(editingReport.id, payload);
        savedId = updated.id;
        toast.show(t("scoutReports.reportUpdated"), "success");
      } else {
        const created = await createScoutReport(payload);
        savedId = created.id;
        toast.show(t("scoutReports.reportCreated"), "success");
      }
      if (photoFile) {
        await uploadScoutReportPhoto(savedId, photoFile);
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteScoutReport(deleteTarget.id);
      toast.show(t("scoutReports.reportDeleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  async function toggleShortlist(report: ScoutReportItem) {
    try {
      if (report.is_shortlisted) {
        await removeScoutReportFromShortlist(report.id);
        toast.show(t("scoutReports.removedFromMyList"), "success");
      } else {
        await addScoutReportToShortlist(report.id);
        toast.show(t("scoutReports.addedToMyList"), "success");
      }
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleExportPdf(report: ScoutReportItem) {
    setIsExportingPdf(true);
    try {
      await downloadScoutReportPdf(report.id, `scout-report-${report.full_name.replace(/\s+/g, "-")}.pdf`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExportingPdf(false);
    }
  }

  async function handleShareReport(report: ScoutReportItem) {
    setIsPublishing(true);
    try {
      let slug = report.public_slug;
      if (!report.is_publicly_shared || !slug) {
        const updated = await publishScoutReport(report.id, true);
        slug = updated.public_slug;
        setReports((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
        setViewingReport(updated);
      }
      const url = `${window.location.origin}/scout-report/${slug}`;
      await navigator.clipboard.writeText(url);
      toast.show(t("scoutReports.shareLinkCopied"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsPublishing(false);
    }
  }

  function openCardMenu(e: { preventDefault: () => void; clientX: number; clientY: number }, r: ScoutReportItem) {
    menu.open(e, [
      {
        items: [
          { label: t("scoutReports.contextView"), onClick: () => openView(r) },
          ...(r.can_edit
            ? [
                { label: t("scoutReports.contextEdit"), onClick: () => openEditForm(r) },
                { label: t("scoutReports.contextDelete"), onClick: () => setDeleteTarget(r), danger: true },
              ]
            : []),
          {
            label: r.is_shortlisted ? t("scoutReports.contextRemoveFromMyList") : t("scoutReports.contextAddToMyList"),
            onClick: () => toggleShortlist(r),
          },
        ],
      },
    ]);
  }

  const currentCategory = positionCategory(form.position);
  const currentAttrKeys = currentCategory ? SCOUT_ATTRIBUTE_KEYS_BY_CATEGORY[currentCategory] : [];

  const positiveSuggestions = useQuickSuggestions("scoutPositive");
  const negativeSuggestions = useQuickSuggestions("scoutNegative");
  const physicalMentalSuggestions = useQuickSuggestions("scoutPhysicalMental");
  const conclusionSuggestions = useQuickSuggestions("scoutConclusion");

  return (
    <AppLayout title={t("scoutReports.pageTitle")}>
      <p className="mb-4 text-sm text-text-muted">{t("scoutReports.introText")}</p>

      <div className="mb-4 flex gap-2">
        <button
          onClick={() => setActiveTab("all")}
          className={`rounded-md px-3 py-1.5 text-sm ${
            activeTab === "all" ? "bg-chalk text-void" : "border border-line text-text-muted hover:text-text-primary"
          }`}
        >
          {t("scoutReports.allReportsTab")}
        </button>
        <button
          onClick={() => setActiveTab("mine")}
          className={`rounded-md px-3 py-1.5 text-sm ${
            activeTab === "mine" ? "bg-chalk text-void" : "border border-line text-text-muted hover:text-text-primary"
          }`}
        >
          {t("scoutReports.myListTab")}
        </button>
      </div>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)} className="w-48">
          <option value="">{t("scoutReports.allTeams")}</option>
          {teams.map((tm) => (
            <option key={tm.id} value={tm.id}>
              {tm.name}
            </option>
          ))}
        </Select>
        <Select value={filterPosition} onChange={(e) => setFilterPosition(e.target.value)} className="w-48">
          <option value="">{t("scoutReports.allPositions")}</option>
          {POSITIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </Select>
        <Button onClick={openNewForm} className="ml-auto">
          {t("scoutReports.newReport")}
        </Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : reports.length === 0 ? (
        <EmptyState title={t("scoutReports.noReportsFound")} />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {reports.map((r) => (
            <Card
              key={r.id}
              corners
              className="flex cursor-pointer flex-col gap-2 p-4 transition-colors hover:border-chalk"
              onClick={() => openView(r)}
              onContextMenu={(e) => openCardMenu(e, r)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") openView(r);
              }}
            >
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm">
                  {r.photo_path ? (
                    <img src={mediaUrl(r.photo_path)} alt="" className="h-full w-full object-cover" />
                  ) : (
                    r.full_name.slice(0, 2).toUpperCase()
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-text-primary">{r.full_name}</p>
                  <p className="truncate text-xs text-text-muted">
                    {[r.club_name, r.position].filter(Boolean).join(" · ") || "—"}
                  </p>
                </div>
                {r.is_shortlisted && <span className="shrink-0 text-amber-400">⭐</span>}
              </div>
              {r.potential_rating != null && (
                <span className="inline-flex w-fit items-center gap-1 rounded-full border border-chalk/40 bg-chalk/10 px-2 py-0.5 text-xs text-chalk">
                  {t("scoutReports.potentialBadgeLabel")}: {r.potential_rating}/10
                </span>
              )}
              {r.recommended != null && (
                <span
                  className={`inline-flex w-fit items-center gap-1 rounded-full border px-2 py-0.5 text-xs ${
                    r.recommended
                      ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                      : "border-status-injured/40 bg-status-injured/10 text-status-injured"
                  }`}
                >
                  {r.recommended ? t("scoutReports.recommendedYes") : t("scoutReports.recommendedNo")}
                </span>
              )}
              <p className="mt-auto text-[10px] text-text-muted">
                {r.created_by_name ? `${t("scoutReports.viewModalScout")}: ${r.created_by_name}` : ""}
              </p>
            </Card>
          ))}
        </div>
      )}

      {menu.render()}

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("scoutReports.confirmDeleteTitle")}
        message={t("scoutReports.confirmDeleteMessage")}
        isLoading={isDeleting}
      />

      <Modal
        isOpen={showForm}
        onClose={() => setShowForm(false)}
        title={editingReport ? t("scoutReports.formTitleEdit") : t("scoutReports.formTitleNew")}
        wide
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <h3 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionBasicInfo")}
            </h3>
            <div className="mb-4 flex items-center gap-4">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised">
                {photoPreview ? (
                  <img src={photoPreview} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="text-xs text-text-muted">{t("scoutReports.noPhotoPlaceholder")}</span>
                )}
              </div>
              <label className="cursor-pointer rounded-md border border-line px-3 py-1.5 text-xs text-text-muted hover:border-chalk hover:text-text-primary">
                {t("scoutReports.fieldPhoto")}
                <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoChange} />
              </label>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                label={t("scoutReports.fieldFullName")}
                value={form.full_name}
                onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))}
                required
              />
              <Input
                label={t("scoutReports.fieldClubName")}
                value={form.club_name}
                onChange={(e) => setForm((f) => ({ ...f, club_name: e.target.value }))}
              />
              <Input
                label={t("scoutReports.fieldAge")}
                type="number"
                min="0"
                value={form.age}
                onChange={(e) => setForm((f) => ({ ...f, age: e.target.value }))}
              />
              <Select
                label={t("scoutReports.fieldPosition")}
                value={form.position}
                onChange={(e) => handlePositionChange(e.target.value)}
              >
                <option value="">{t("scoutReports.selectPositionPlaceholder")}</option>
                {POSITIONS.map((p) => (
                  <option key={p} value={p}>
                    {p} — {POSITION_CATEGORY_LABELS[POSITION_CATEGORY[p]]}
                  </option>
                ))}
              </Select>
              <Input
                label={t("scoutReports.fieldRole")}
                value={form.role}
                onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}
              />
              <Input
                label={t("scoutReports.fieldLeague")}
                value={form.league}
                onChange={(e) => setForm((f) => ({ ...f, league: e.target.value }))}
              />
              <Input
                label={t("scoutReports.fieldJerseyNumber")}
                type="number"
                min="0"
                value={form.jersey_number}
                onChange={(e) => setForm((f) => ({ ...f, jersey_number: e.target.value }))}
              />
              <Input
                label={t("scoutReports.fieldNationality")}
                value={form.nationality}
                onChange={(e) => setForm((f) => ({ ...f, nationality: e.target.value }))}
              />
              <Select
                label={t("scoutReports.fieldStrongFoot")}
                value={form.strong_foot}
                onChange={(e) =>
                  setForm((f) => ({ ...f, strong_foot: e.target.value as "" | (typeof STRONG_FOOT_OPTIONS)[number] }))
                }
              >
                <option value="">—</option>
                <option value="right">{t("scoutReports.footRight")}</option>
                <option value="left">{t("scoutReports.footLeft")}</option>
                <option value="both">{t("scoutReports.footBoth")}</option>
              </Select>
              <Input
                label={t("scoutReports.fieldGoalsPerSeason")}
                type="number"
                min="0"
                value={form.goals_per_season}
                onChange={(e) => setForm((f) => ({ ...f, goals_per_season: e.target.value }))}
              />
              <Select
                label={t("scoutReports.filterTeam")}
                value={form.team_id}
                onChange={(e) => setForm((f) => ({ ...f, team_id: e.target.value }))}
              >
                <option value="">—</option>
                {teams.map((tm) => (
                  <option key={tm.id} value={tm.id}>
                    {tm.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="border-t border-line pt-4">
            <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionPositive")}
            </h3>
            <StarRating value={form.positive_rating} onChange={(v) => setForm((f) => ({ ...f, positive_rating: v }))} />
            <Textarea
              className="mt-2"
              placeholder={t("scoutReports.notesPlaceholder")}
              value={form.positive_notes}
              onChange={(e) => setForm((f) => ({ ...f, positive_notes: e.target.value }))}
            />
            <QuickSuggestions
              suggestions={positiveSuggestions}
              onSelect={(s) => setForm((f) => ({ ...f, positive_notes: appendSuggestion(f.positive_notes, s) }))}
            />
          </div>

          <div className="border-t border-line pt-4">
            <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionNegative")}
            </h3>
            <StarRating value={form.negative_rating} onChange={(v) => setForm((f) => ({ ...f, negative_rating: v }))} />
            <Textarea
              className="mt-2"
              placeholder={t("scoutReports.notesPlaceholder")}
              value={form.negative_notes}
              onChange={(e) => setForm((f) => ({ ...f, negative_notes: e.target.value }))}
            />
            <QuickSuggestions
              suggestions={negativeSuggestions}
              onSelect={(s) => setForm((f) => ({ ...f, negative_notes: appendSuggestion(f.negative_notes, s) }))}
            />
          </div>

          <div className="border-t border-line pt-4">
            <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionPhysicalMental")}
            </h3>
            <StarRating
              value={form.physical_mental_rating}
              onChange={(v) => setForm((f) => ({ ...f, physical_mental_rating: v }))}
            />
            <Textarea
              className="mt-2"
              placeholder={t("scoutReports.notesPlaceholder")}
              value={form.physical_mental_notes}
              onChange={(e) => setForm((f) => ({ ...f, physical_mental_notes: e.target.value }))}
            />
            <QuickSuggestions
              suggestions={physicalMentalSuggestions}
              onSelect={(s) =>
                setForm((f) => ({ ...f, physical_mental_notes: appendSuggestion(f.physical_mental_notes, s) }))
              }
            />
          </div>

          <div className="border-t border-line pt-4">
            <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionDetailedAttributes")}
            </h3>
            {currentAttrKeys.length === 0 ? (
              <p className="text-xs text-text-muted">{t("scoutReports.detailedAttributesHint")}</p>
            ) : (
              <div>
                {currentAttrKeys.map((key) => (
                  <AttributeBar
                    key={key}
                    label={SCOUT_ATTRIBUTE_LABELS[key] || key}
                    value={detailedAttrs[key] ?? 5}
                    onChange={(v) => setDetailedAttrs((prev) => ({ ...prev, [key]: v }))}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-line pt-4">
            <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("scoutReports.sectionConclusion")}
            </h3>
            <Textarea
              label={t("scoutReports.fieldConclusionText")}
              value={form.conclusion_text}
              onChange={(e) => setForm((f) => ({ ...f, conclusion_text: e.target.value }))}
            />
            <QuickSuggestions
              suggestions={conclusionSuggestions}
              onSelect={(s) => setForm((f) => ({ ...f, conclusion_text: appendSuggestion(f.conclusion_text, s) }))}
            />
            <div className="mt-3">
              <p className="mb-1.5 text-xs text-text-muted">{t("scoutReports.fieldRecommended")}</p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, recommended: true }))}
                  className={`rounded-md border px-3 py-1.5 text-xs ${
                    form.recommended === true
                      ? "border-status-fit/60 bg-status-fit/15 text-status-fit"
                      : "border-line text-text-muted hover:border-chalk"
                  }`}
                >
                  {t("scoutReports.recommendedYes")}
                </button>
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, recommended: false }))}
                  className={`rounded-md border px-3 py-1.5 text-xs ${
                    form.recommended === false
                      ? "border-status-injured/60 bg-status-injured/15 text-status-injured"
                      : "border-line text-text-muted hover:border-chalk"
                  }`}
                >
                  {t("scoutReports.recommendedNo")}
                </button>
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, recommended: undefined }))}
                  className={`rounded-md border px-3 py-1.5 text-xs ${
                    form.recommended === undefined
                      ? "border-chalk/60 bg-chalk/10 text-chalk"
                      : "border-line text-text-muted hover:border-chalk"
                  }`}
                >
                  {t("scoutReports.recommendedUndecided")}
                </button>
              </div>
            </div>
            <div className="mt-3">
              <AttributeBar
                label={t("scoutReports.fieldPotential")}
                value={form.potential_rating}
                onChange={(v) => setForm((f) => ({ ...f, potential_rating: v }))}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t border-line pt-4">
            <Button type="button" variant="secondary" onClick={() => setShowForm(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isSubmitting}>
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={!!viewingReport}
        onClose={() => setViewingReport(null)}
        title={viewingReport?.full_name || ""}
        wide
      >
        {viewingReport && (
          <div className="space-y-5">
            <div className="flex items-start gap-4">
              <div className="flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised font-display text-2xl">
                {viewingReport.photo_path ? (
                  <img src={mediaUrl(viewingReport.photo_path)} alt="" className="h-full w-full object-cover" />
                ) : (
                  viewingReport.full_name.slice(0, 2).toUpperCase()
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-display text-lg text-text-primary">{viewingReport.full_name}</p>
                <p className="text-sm text-text-muted">
                  {[viewingReport.club_name, viewingReport.position, viewingReport.league].filter(Boolean).join(" · ") || "—"}
                </p>
                <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-xs sm:grid-cols-3">
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.fieldAge")}</dt>
                    <dd className="text-text-primary">{viewingReport.age ?? "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.fieldJerseyNumber")}</dt>
                    <dd className="text-text-primary">{viewingReport.jersey_number ?? "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.fieldNationality")}</dt>
                    <dd className="text-text-primary">{viewingReport.nationality || "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.fieldStrongFoot")}</dt>
                    <dd className="text-text-primary">
                      {viewingReport.strong_foot === "right"
                        ? t("scoutReports.footRight")
                        : viewingReport.strong_foot === "left"
                          ? t("scoutReports.footLeft")
                          : viewingReport.strong_foot === "both"
                            ? t("scoutReports.footBoth")
                            : "—"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.viewModalGoalsPerSeason")}</dt>
                    <dd className="text-text-primary">{viewingReport.goals_per_season ?? "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.fieldRole")}</dt>
                    <dd className="text-text-primary">{viewingReport.role || "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.viewModalScout")}</dt>
                    <dd className="text-text-primary">{viewingReport.created_by_name || "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-text-muted">{t("scoutReports.viewModalCreatedAt")}</dt>
                    <dd className="text-text-primary">{new Date(viewingReport.created_at).toLocaleDateString("el-GR")}</dd>
                  </div>
                </dl>
              </div>
            </div>

            {(viewingReport.positive_rating || viewingReport.positive_notes) && (
              <div className="border-t border-line pt-4">
                <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                  {t("scoutReports.sectionPositive")}
                </h3>
                <StarRating value={viewingReport.positive_rating || 0} readOnly />
                {viewingReport.positive_notes && (
                  <p className="mt-2 text-sm text-text-primary">{viewingReport.positive_notes}</p>
                )}
              </div>
            )}

            {(viewingReport.negative_rating || viewingReport.negative_notes) && (
              <div className="border-t border-line pt-4">
                <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                  {t("scoutReports.sectionNegative")}
                </h3>
                <StarRating value={viewingReport.negative_rating || 0} readOnly />
                {viewingReport.negative_notes && (
                  <p className="mt-2 text-sm text-text-primary">{viewingReport.negative_notes}</p>
                )}
              </div>
            )}

            {(viewingReport.physical_mental_rating || viewingReport.physical_mental_notes) && (
              <div className="border-t border-line pt-4">
                <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                  {t("scoutReports.sectionPhysicalMental")}
                </h3>
                <StarRating value={viewingReport.physical_mental_rating || 0} readOnly />
                {viewingReport.physical_mental_notes && (
                  <p className="mt-2 text-sm text-text-primary">{viewingReport.physical_mental_notes}</p>
                )}
              </div>
            )}

            {Object.keys(viewingReport.detailed_attributes || {}).length > 0 && (
              <div className="border-t border-line pt-4">
                <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                  {t("scoutReports.sectionDetailedAttributes")}
                </h3>
                {Object.entries(viewingReport.detailed_attributes).map(([key, value]) => (
                  <AttributeBar key={key} label={SCOUT_ATTRIBUTE_LABELS[key] || key} value={value} readOnly />
                ))}
              </div>
            )}

            <div className="border-t border-line pt-4">
              <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("scoutReports.sectionConclusion")}
              </h3>
              {viewingReport.conclusion_text && (
                <p className="mb-3 text-sm text-text-primary">{viewingReport.conclusion_text}</p>
              )}
              <div className="flex flex-wrap items-center gap-2">
                {viewingReport.recommended != null && (
                  <span
                    className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs ${
                      viewingReport.recommended
                        ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                        : "border-status-injured/40 bg-status-injured/10 text-status-injured"
                    }`}
                  >
                    {viewingReport.recommended ? t("scoutReports.recommendedYes") : t("scoutReports.recommendedNo")}
                  </span>
                )}
                {viewingReport.potential_rating != null && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-chalk/40 bg-chalk/10 px-3 py-1 text-xs text-chalk">
                    {t("scoutReports.fieldPotential")}: {viewingReport.potential_rating}/10
                  </span>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t border-line pt-4">
              {viewingReport.can_edit && (
                <Button
                  variant="secondary"
                  onClick={() => {
                    const r = viewingReport;
                    setViewingReport(null);
                    openEditForm(r);
                  }}
                >
                  {t("scoutReports.contextEdit")}
                </Button>
              )}
              <Button
                variant="secondary"
                onClick={() => handleShareReport(viewingReport)}
                isLoading={isPublishing}
              >
                🔗 {t("scoutReports.shareButton")}
              </Button>
              <Button onClick={() => handleExportPdf(viewingReport)} isLoading={isExportingPdf}>
                {t("scoutReports.exportPdfButton")}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </AppLayout>
  );
}
