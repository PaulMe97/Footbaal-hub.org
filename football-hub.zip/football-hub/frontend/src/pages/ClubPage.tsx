import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import { API_BASE_URL } from "../api/client";
import { getPublicClubPage } from "../api/public";
import { Spinner } from "../components/ui/EmptyState";
import { LEAGUE_TIER_LABELS } from "../types";
import type { LeagueTier, PlayerPosition, PublicClubMatch, PublicClubPage, PublicClubPlayer } from "../types";
import { useLanguage } from "../context/LanguageContext";

function mediaUrl(path?: string | null): string | undefined {
  if (!path) return undefined;
  return `${API_BASE_URL}${path}`;
}

// Σειρά προτεραιότητας θέσεων — GK πρώτα, μετά άμυνα, κέντρο, επίθεση.
// Χρησιμοποιείται ΚΑΙ για το flat "συμπαγές" ταξινομημένο grid ΚΑΙ για να
// βρεθεί σε ποια ενότητα ανήκει κάθε παίκτης στο "ομαδοποιημένο" view.
const POSITION_ORDER: PlayerPosition[] = [
  "GK",
  "CB",
  "LB",
  "RB",
  "LWB",
  "RWB",
  "DM",
  "CM",
  "AM",
  "LW",
  "RW",
  "ST",
];

function sortRosterByPosition(roster: PublicClubPlayer[]): PublicClubPlayer[] {
  return [...roster].sort((a, b) => {
    const ai = a.position ? POSITION_ORDER.indexOf(a.position) : POSITION_ORDER.length;
    const bi = b.position ? POSITION_ORDER.indexOf(b.position) : POSITION_ORDER.length;
    if (ai !== bi) return (ai === -1 ? POSITION_ORDER.length : ai) - (bi === -1 ? POSITION_ORDER.length : bi);
    return (a.player_number ?? 999) - (b.player_number ?? 999);
  });
}

function groupRosterByPosition(
  roster: PublicClubPlayer[],
  positionCategories: { label: string; positions: PlayerPosition[] }[],
  noPositionLabel: string
) {
  const groups = positionCategories.map((c) => ({ label: c.label, players: [] as PublicClubPlayer[] }));
  const other: PublicClubPlayer[] = [];
  for (const p of roster) {
    const group = groups.find((g) =>
      positionCategories.find((c) => c.label === g.label)!.positions.includes(p.position as PlayerPosition)
    );
    if (group) {
      group.players.push(p);
    } else {
      other.push(p);
    }
  }
  for (const g of groups) {
    g.players.sort((a, b) => (a.player_number ?? 999) - (b.player_number ?? 999));
  }
  if (other.length > 0) {
    groups.push({ label: noPositionLabel, players: other.sort((a, b) => (a.player_number ?? 999) - (b.player_number ?? 999)) });
  }
  return groups.filter((g) => g.players.length > 0);
}

const RESULT_STYLES: Record<string, string> = {
  W: "bg-emerald-500/20 text-emerald-400",
  D: "bg-amber-500/20 text-amber-400",
  L: "bg-red-500/20 text-red-400",
};

function MatchRow({ match, teamName }: { match: PublicClubMatch; teamName: string }) {
  const { t } = useLanguage();
  const isHome = match.home_team_name === teamName;
  const opponent = isHome ? match.away_team_name : match.home_team_name;
  return (
    <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-4 py-3">
      <div>
        <p className="text-sm text-white">
          {isHome ? "vs" : "@"} {opponent || "—"}
        </p>
        <p className="text-xs text-white/50">
          {new Date(match.date).toLocaleDateString("el-GR")}
          {match.time ? ` · ${match.time}` : ""}
          {match.stadium ? ` · ${match.stadium}` : ""}
        </p>
      </div>
      {match.result ? (
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm text-white">
            {match.home_score}-{match.away_score}
          </span>
          <span
            className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${RESULT_STYLES[match.result]}`}
          >
            {match.result}
          </span>
        </div>
      ) : (
        <span className="rounded-full border border-white/20 px-2 py-0.5 text-xs text-white/70">
          {t("clubPage.upcoming")}
        </span>
      )}
    </div>
  );
}

function PublicPlayerCard({ player }: { player: PublicClubPlayer }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-lg border border-white/10 bg-white/5 p-3 text-center">
      <div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-full border border-white/10 bg-white/10 font-mono text-sm">
        {player.photo_path ? (
          <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
        ) : (
          player.player_number ?? "-"
        )}
      </div>
      <div>
        <p className="text-xs text-white">
          {player.first_name} {player.last_name}
        </p>
        <p className="text-[10px] text-white/40">{player.position || "—"}</p>
      </div>
    </div>
  );
}

export default function ClubPage() {
  const { slug } = useParams<{ slug: string }>();
  const { t } = useLanguage();
  const [page, setPage] = useState<PublicClubPage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [rosterView, setRosterView] = useState<"grouped" | "compact">(
    () => (localStorage.getItem("fh_club_roster_view") as "grouped" | "compact") || "grouped"
  );

  function changeRosterView(mode: "grouped" | "compact") {
    setRosterView(mode);
    localStorage.setItem("fh_club_roster_view", mode);
  }

  const POSITION_CATEGORIES: { label: string; positions: PlayerPosition[] }[] = [
    { label: t("teamDetail.positionGoalkeepers"), positions: ["GK"] },
    { label: t("teamDetail.positionDefense"), positions: ["CB", "LB", "RB", "LWB", "RWB"] },
    { label: t("teamDetail.positionMidfield"), positions: ["DM", "CM", "AM"] },
    { label: t("teamDetail.positionAttack"), positions: ["LW", "RW", "ST"] },
  ];

  useEffect(() => {
    if (!slug) return;
    getPublicClubPage(slug)
      .then(setPage)
      .catch(() => setNotFound(true))
      .finally(() => setIsLoading(false));
  }, [slug]);

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0A0F0D]">
        <Spinner />
      </div>
    );
  }

  if (notFound || !page) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#0A0F0D] px-4 text-center">
        <p className="font-display text-xl text-white">{t("clubPage.notFoundTitle")}</p>
        <p className="text-sm text-white/50">
          {t("clubPage.notFoundDescription")}
        </p>
        <Link to="/" className="mt-2 text-sm text-lime-400 hover:underline">
          ← FootballHub
        </Link>
      </div>
    );
  }

  const primary = page.primary_color || "#3E7D52";
  const secondary = page.secondary_color || "#0A0F0D";

  return (
    <div className="min-h-screen bg-[#0A0F0D] text-white">
      <div
        className="px-4 py-14"
        style={{
          background: `linear-gradient(160deg, ${primary}33 0%, ${secondary} 65%)`,
        }}
      >
        <div className="mx-auto flex max-w-2xl flex-col items-center text-center">
          <div
            className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 bg-white/5 font-display text-2xl"
            style={{ borderColor: primary }}
          >
            {page.logo_path ? (
              <img src={mediaUrl(page.logo_path)} alt="" className="h-full w-full object-cover" />
            ) : (
              page.name.slice(0, 2).toUpperCase()
            )}
          </div>
          <h1 className="mt-4 font-display text-3xl tracking-wide">{page.name}</h1>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-white/70">
            {page.league_tier && (
              <span
                className="rounded-full border px-2.5 py-1"
                style={{ borderColor: primary, color: primary }}
              >
                {LEAGUE_TIER_LABELS[page.league_tier as LeagueTier] || page.league_tier}
              </span>
            )}
            {page.federation_name && <span>{page.federation_name}</span>}
            {page.region_name && <span>· {page.region_name}</span>}
          </div>
          {page.home_stadium && <p className="mt-2 text-sm text-white/50">🏟 {page.home_stadium}</p>}
          {page.description && <p className="mt-4 max-w-lg text-sm text-white/70">{page.description}</p>}
        </div>
      </div>

      <div className="mx-auto max-w-2xl space-y-8 px-4 py-10">
        {page.next_match && (
          <section>
            <h2 className="mb-3 font-display text-sm uppercase tracking-wide text-white/50">
              {t("clubPage.nextMatch")}
            </h2>
            <MatchRow match={page.next_match} teamName={page.name} />
          </section>
        )}

        {page.recent_form.length > 0 && (
          <section>
            <h2 className="mb-3 font-display text-sm uppercase tracking-wide text-white/50">
              {t("clubPage.recentResults")}
            </h2>
            <div className="space-y-2">
              {page.recent_form.map((m, i) => (
                <MatchRow key={i} match={m} teamName={page.name} />
              ))}
            </div>
          </section>
        )}

        {page.roster && page.roster.length > 0 && (
          <section>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-sm uppercase tracking-wide text-white/50">
                {t("clubPage.rosterPrefix")}{page.roster.length})
              </h2>
              <div className="flex gap-1 rounded-md border border-white/10 p-0.5">
                <button
                  onClick={() => changeRosterView("grouped")}
                  className={`rounded px-2 py-1 text-[11px] ${
                    rosterView === "grouped" ? "bg-white/15 text-white" : "text-white/50"
                  }`}
                >
                  {t("clubPage.viewGrouped")}
                </button>
                <button
                  onClick={() => changeRosterView("compact")}
                  className={`rounded px-2 py-1 text-[11px] ${
                    rosterView === "compact" ? "bg-white/15 text-white" : "text-white/50"
                  }`}
                >
                  {t("clubPage.viewCompact")}
                </button>
              </div>
            </div>

            {rosterView === "grouped" ? (
              <div className="space-y-4">
                {groupRosterByPosition(page.roster, POSITION_CATEGORIES, t("teamDetail.noPosition")).map((group) => (
                  <div key={group.label}>
                    <h3 className="mb-2 text-xs uppercase tracking-wide text-white/40">
                      {group.label} ({group.players.length})
                    </h3>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {group.players.map((p) => (
                        <PublicPlayerCard key={p.id} player={p} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {sortRosterByPosition(page.roster).map((p) => (
                  <PublicPlayerCard key={p.id} player={p} />
                ))}
              </div>
            )}
          </section>
        )}

        {page.coach_name && (
          <p className="text-center text-sm text-white/50">{t("clubPage.coachPrefix")}{page.coach_name}</p>
        )}
      </div>

      <div className="border-t border-white/10 py-6 text-center text-xs text-white/30">
        Powered by{" "}
        <Link to="/" className="text-lime-400 hover:underline">
          FootballHub
        </Link>
      </div>
    </div>
  );
}
