import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import { extractErrorMessage } from "../api/client";
import { deleteVideo, listVideos, uploadVideo } from "../api/videoAnalysis";
import type { VideoAnalysisItem } from "../api/videoAnalysis";
import { listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { useContextMenu } from "../components/ui/ContextMenu";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog, Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";
import type { Team } from "../types";

const MAX_DURATION_SECONDS = 15 * 60;

function formatDuration(seconds?: number | null): string {
  if (!seconds && seconds !== 0) return "—";
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function VideoEditing() {
  const { t } = useLanguage();
  const toast = useToast();
  const navigate = useNavigate();
  const menu = useContextMenu();

  const [videos, setVideos] = useState<VideoAnalysisItem[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterTeam, setFilterTeam] = useState("");

  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadTeamId, setUploadTeamId] = useState("");
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDescription, setUploadDescription] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [durationError, setDurationError] = useState("");
  const [isReadingDuration, setIsReadingDuration] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [deleteTarget, setDeleteTarget] = useState<VideoAnalysisItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  async function load() {
    setIsLoading(true);
    try {
      const [v, tm] = await Promise.all([listVideos(filterTeam || undefined), listTeams()]);
      setVideos(v);
      setTeams(tm);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterTeam]);

  function openUploadModal() {
    setUploadTeamId(filterTeam || teams[0]?.id || "");
    setUploadTitle("");
    setUploadDescription("");
    setSelectedFile(null);
    setVideoDuration(null);
    setDurationError("");
    setUploadProgress(0);
    setShowUploadModal(true);
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    setVideoDuration(null);
    setDurationError("");
    setIsReadingDuration(true);

    const probe = document.createElement("video");
    probe.preload = "metadata";
    const url = URL.createObjectURL(file);
    probe.src = url;
    probe.onloadedmetadata = () => {
      const duration = probe.duration;
      setVideoDuration(duration);
      setIsReadingDuration(false);
      if (duration > MAX_DURATION_SECONDS) {
        setDurationError(t("videoEditing.maxDurationError"));
      }
      URL.revokeObjectURL(url);
    };
    probe.onerror = () => {
      setIsReadingDuration(false);
      URL.revokeObjectURL(url);
    };
  }

  async function handleUpload(e: FormEvent) {
    e.preventDefault();
    if (!selectedFile || !uploadTeamId || videoDuration == null || durationError) return;
    setIsUploading(true);
    setUploadProgress(0);
    try {
      await uploadVideo(
        {
          team_id: uploadTeamId,
          title: uploadTitle.trim() || selectedFile.name,
          description: uploadDescription,
          duration_seconds: videoDuration,
          file: selectedFile,
        },
        setUploadProgress
      );
      toast.show(t("videoEditing.uploadSuccess"), "success");
      setShowUploadModal(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUploading(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteVideo(deleteTarget.id);
      toast.show(t("videoEditing.videoDeleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  function openCardMenu(e: { preventDefault: () => void; clientX: number; clientY: number }, v: VideoAnalysisItem) {
    menu.open(e, [
      {
        items: [
          { label: t("videoEditing.contextOpen"), onClick: () => navigate(`/video-editing/${v.id}`) },
          ...(v.can_edit
            ? [{ label: t("videoEditing.contextDelete"), onClick: () => setDeleteTarget(v), danger: true }]
            : []),
        ],
      },
    ]);
  }

  const statusColor: Record<string, string> = {
    ready: "text-status-fit",
    uploading: "text-status-doubtful",
    failed: "text-status-injured",
  };
  const statusLabel: Record<string, string> = {
    ready: t("videoEditing.statusReady"),
    uploading: t("videoEditing.statusUploading"),
    failed: t("videoEditing.statusFailed"),
  };

  const canSubmitUpload =
    !!selectedFile && !!uploadTeamId && videoDuration != null && !durationError && !isReadingDuration;

  return (
    <AppLayout title={t("videoEditing.pageTitle")}>
      <p className="mb-4 text-sm text-text-muted">{t("videoEditing.introText")}</p>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)} className="w-48">
          <option value="">{t("videoEditing.allTeams")}</option>
          {teams.map((tm) => (
            <option key={tm.id} value={tm.id}>
              {tm.name}
            </option>
          ))}
        </Select>
        <Button onClick={openUploadModal} className="ml-auto">
          {t("videoEditing.newVideo")}
        </Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : videos.length === 0 ? (
        <EmptyState title={t("videoEditing.noVideosFound")} action={<Button onClick={openUploadModal}>{t("videoEditing.newVideo")}</Button>} />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {videos.map((v) => (
            <Card
              key={v.id}
              corners
              className="flex cursor-pointer flex-col gap-2 p-4 transition-colors hover:border-chalk"
              onClick={() => navigate(`/video-editing/${v.id}`)}
              onContextMenu={(e) => openCardMenu(e, v)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") navigate(`/video-editing/${v.id}`);
              }}
            >
              <div className="flex h-28 items-center justify-center rounded-md bg-surface-raised text-4xl">🎬</div>
              <p className="truncate text-sm text-text-primary">{v.title}</p>
              <p className="truncate text-xs text-text-muted">{v.team_name || "—"}</p>
              <div className="mt-auto flex items-center justify-between text-xs">
                <span className="font-mono text-text-muted">{formatDuration(v.duration_seconds)}</span>
                <span className={statusColor[v.status] || "text-text-muted"}>{statusLabel[v.status] || v.status}</span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {menu.render()}

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("videoEditing.deleteConfirmTitle")}
        message={t("videoEditing.deleteConfirmMessage")}
        isLoading={isDeleting}
      />

      <Modal isOpen={showUploadModal} onClose={() => !isUploading && setShowUploadModal(false)} title={t("videoEditing.uploadModalTitle")}>
        <form onSubmit={handleUpload} className="space-y-4">
          <Select
            label={t("videoEditing.filterTeam")}
            value={uploadTeamId}
            onChange={(e) => setUploadTeamId(e.target.value)}
            required
          >
            <option value="">{t("videoEditing.selectTeamPlaceholder")}</option>
            {teams.map((tm) => (
              <option key={tm.id} value={tm.id}>
                {tm.name}
              </option>
            ))}
          </Select>
          <Input
            label={t("videoEditing.fieldTitle")}
            value={uploadTitle}
            onChange={(e) => setUploadTitle(e.target.value)}
          />
          <Textarea
            label={t("videoEditing.fieldDescription")}
            value={uploadDescription}
            onChange={(e) => setUploadDescription(e.target.value)}
          />
          <div>
            <label className="mb-1.5 block text-xs text-text-muted">{t("videoEditing.fieldFile")}</label>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/mp4,video/quicktime,video/x-msvideo,video/webm,video/x-matroska"
              onChange={handleFileChange}
              className="block w-full text-sm text-text-muted file:mr-3 file:rounded-md file:border file:border-line file:bg-surface-raised file:px-3 file:py-1.5 file:text-xs file:text-text-primary hover:file:border-chalk"
            />
            {isReadingDuration && <p className="mt-1.5 text-xs text-text-muted">{t("videoEditing.readingDuration")}</p>}
            {videoDuration != null && !isReadingDuration && (
              <p className={`mt-1.5 text-xs ${durationError ? "text-status-injured" : "text-text-muted"}`}>
                {t("videoEditing.durationLabel")}: {formatDuration(videoDuration)}
              </p>
            )}
            {durationError && <p className="mt-1 text-xs text-status-injured">{durationError}</p>}
          </div>
          {isUploading && (
            <div className="h-2 w-full overflow-hidden rounded-full bg-surface-raised">
              <div className="h-full bg-chalk transition-all" style={{ width: `${uploadProgress}%` }} />
            </div>
          )}
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowUploadModal(false)} disabled={isUploading}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isUploading} disabled={!canSubmitUpload}>
              {isUploading ? `${t("videoEditing.uploadingLabel")} ${uploadProgress}%` : t("videoEditing.uploadButton")}
            </Button>
          </div>
        </form>
      </Modal>
    </AppLayout>
  );
}
