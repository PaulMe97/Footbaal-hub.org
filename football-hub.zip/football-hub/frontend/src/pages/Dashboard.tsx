import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { extractErrorMessage } from "../api/client";
import { getDashboardStats } from "../api/dashboard";
import { getMonthlyPerformance } from "../api/performance";
import { getPlayer, listPlayers, updatePlayer } from "../api/players";
import { getTeam, listTeams, updateTeam } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Card } from "../components/ui/Card";
import { useContextMenu } from "../components/ui/ContextMenu";
import { Spinner } from "../components/ui/EmptyState";
import { Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { WidgetCard } from "../components/WidgetCard";
import { useLanguage } from "../context/LanguageContext";
import type {
  DashboardActivityItem,
  DashboardStats,
  Player,
  PlayerMonthlyPerformance,
  Team,
} from "../types";
import { PlayerForm, playerFormToPayload, type PlayerFormValues } from "./players/PlayerForm";
import { TeamForm, type TeamFormValues } from "./teams/TeamForm";

const HIDDEN_WIDGETS_KEY = "footballhub_dashboard_hidden_widgets";

function loadHiddenWidgets(): string[] {
  try {
    const raw = localStorage.getItem(HIDDEN_WIDGETS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveHiddenWidgets(ids: string[]) {
  localStorage.setItem(HIDDEN_WIDGETS_KEY, JSON.stringify(ids));
}

function StatTile({
  label,
  value,
  accent = false,
  onClick,
}: {
  label: string;
  value: string | number;
  accent?: boolean;
  onClick?: () => void;
}) {
  const content = (
    <>
      <p className="text-[10px] uppercase tracking-wide text-text-muted">{label}</p>
      <p className={`mt-1 font-display text-2xl ${accent ? "text-chalk" : "text-text-primary"}`}>{value}</p>
    </>
  );
  if (onClick) {
    return (
      <button
        onClick={onClick}
        className="block w-full rounded-md border border-line bg-surface-raised p-3 text-left transition-colors hover:border-chalk"
      >
        {content}
      </button>
    );
  }
  return <div className="rounded-md border border-line bg-surface-raised p-3">{content}</div>;
}

function QuickAction({ to, label }: { to: string; label: string }) {
  return (
    <Link
      to={to}
      className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-4 py-3 text-sm text-text-primary transition-colors hover:border-chalk hover:text-chalk"
    >
      {label}
      <span aria-hidden>→</span>
    </Link>
  );
}

function ActivityIcon({ type }: { type: string }) {
  const icons: Record<string, string> = {
    player_added: "👤",
    team_added: "🛡",
    player_injury: "🩹",
    contract_offer_accepted: "📝",
    renewal_accepted: "🔄",
  };
  return <span className="mr-2">{icons[type] || "•"}</span>;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [monthlyTop, setMonthlyTop] = useState<PlayerMonthlyPerformance[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const toast = useToast();
  const activityMenu = useContextMenu();

  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [formTeams, setFormTeams] = useState<Team[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  type DetailModalType =
    | "teams"
    | "players"
    | "injured"
    | "trainings"
    | "week_trainings"
    | "top_scorers"
    | "best_avg"
    | "month_performers"
    | null;
  const [detailModal, setDetailModal] = useState<DetailModalType>(null);
  const [detailTeams, setDetailTeams] = useState<Team[]>([]);
  const [detailPlayers, setDetailPlayers] = useState<Player[]>([]);
  const [isDetailLoading, setIsDetailLoading] = useState(false);

  async function openDetailModal(type: DetailModalType) {
    setDetailModal(type);
    if (type === "teams") {
      setIsDetailLoading(true);
      try {
        setDetailTeams(await listTeams());
      } catch (err) {
        toast.show(extractErrorMessage(err), "error");
      } finally {
        setIsDetailLoading(false);
      }
    } else if (type === "players") {
      setIsDetailLoading(true);
      try {
        setDetailPlayers(await listPlayers());
      } catch (err) {
        toast.show(extractErrorMessage(err), "error");
      } finally {
        setIsDetailLoading(false);
      }
    } else if (type === "injured") {
      setIsDetailLoading(true);
      try {
        setDetailPlayers(await listPlayers({ status: "injured" }));
      } catch (err) {
        toast.show(extractErrorMessage(err), "error");
      } finally {
        setIsDetailLoading(false);
      }
    }
    // trainings/week_trainings/top_scorers/best_avg/month_performers δεν
    // χρειάζονται API call — ήδη διαθέσιμα μέσα στο stats state.
  }

  const [hiddenWidgets, setHiddenWidgets] = useState<string[]>([]);

  function hideWidget(id: string) {
    setHiddenWidgets((prev) => {
      const next = [...prev, id];
      saveHiddenWidgets(next);
      return next;
    });
  }

  function resetWidgets() {
    setHiddenWidgets([]);
    saveHiddenWidgets([]);
  }

  async function load() {
    setIsLoading(true);
    try {
      const data = await getDashboardStats();
      setStats(data);
      const now = new Date();
      const monthly = await getMonthlyPerformance(now.getFullYear(), now.getMonth() + 1);
      setMonthlyTop(
        [...monthly]
          .filter((m) => m.avg_rating != null)
          .sort((a, b) => (b.avg_rating || 0) - (a.avg_rating || 0))
          .slice(0, 5)
      );
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    setHiddenWidgets(loadHiddenWidgets());
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function openActivity(item: DashboardActivityItem) {
    if (!item.entity_type || !item.entity_id) return;
    try {
      if (item.entity_type === "team") {
        const teamData = await getTeam(item.entity_id);
        setSelectedTeam(teamData);
      } else if (item.entity_type === "player") {
        const [p, teams] = await Promise.all([getPlayer(item.entity_id), listTeams()]);
        setFormTeams(teams);
        setSelectedPlayer(p);
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleTeamSubmit(values: TeamFormValues) {
    if (!selectedTeam) return;
    setIsSubmitting(true);
    try {
      await updateTeam(selectedTeam.id, values);
      toast.show(t("dashboard.changesSaved"), "success");
      setSelectedTeam(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handlePlayerSubmit(values: PlayerFormValues) {
    if (!selectedPlayer) return;
    setIsSubmitting(true);
    try {
      await updatePlayer(selectedPlayer.id, playerFormToPayload(values));
      toast.show(t("dashboard.changesSaved"), "success");
      setSelectedPlayer(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  const isHidden = (id: string) => hiddenWidgets.includes(id);

  return (
    <AppLayout title="Dashboard">
      {isLoading || !stats ? (
        <Spinner />
      ) : (
        <div className="space-y-6">
          {hiddenWidgets.length > 0 && (
            <button onClick={resetWidgets} className="text-xs text-chalk hover:underline">
              {t("dashboard.showAllWidgetsPrefix")}
              {hiddenWidgets.length}
              {t("dashboard.showAllWidgetsSuffix")}
            </button>
          )}

          {!isHidden("summary") && (
            <WidgetCard id="summary" title={t("dashboard.summary")} icon="📊" onHide={hideWidget} onRefresh={load}>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
                <StatTile label={t("dashboard.totalTeams")} value={stats.total_teams} onClick={() => openDetailModal("teams")} />
                <StatTile label={t("dashboard.totalPlayers")} value={stats.total_players} onClick={() => openDetailModal("players")} />
                <StatTile
                  label={t("dashboard.injured")}
                  value={stats.injured_players}
                  accent={stats.injured_players > 0}
                  onClick={() => openDetailModal("injured")}
                />
                <StatTile
                  label={t("dashboard.absences")}
                  value={stats.active_absences_count}
                  accent={stats.active_absences_count > 0}
                  onClick={() => navigate("/absences")}
                />
                <StatTile
                  label={t("dashboard.trainings")}
                  value={stats.upcoming_trainings_count}
                  onClick={() => openDetailModal("trainings")}
                />
              </div>
            </WidgetCard>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {!isHidden("next_match") && (
              <WidgetCard id="next_match" title={t("dashboard.upcomingMatches")} icon="⚽" onHide={hideWidget} onRefresh={load}>
                {stats.upcoming_matches.length > 0 ? (
                  <div className="max-h-48 space-y-2 overflow-y-auto pr-1">
                    {stats.upcoming_matches.map((m) => (
                      <Link
                        key={m.id}
                        to={`/matches/${m.id}`}
                        className="block border-b border-line pb-1.5 last:border-0 hover:text-chalk"
                      >
                        <p className="text-sm text-text-primary">
                          <span className="text-chalk">
                            {m.days_until === 0
                              ? t("dashboard.today")
                              : `${t("dashboard.inDaysPrefix")}${m.days_until}${t("dashboard.inDaysSuffix")}`}
                          </span>{" "}
                          {m.team_name} {m.is_home ? "vs" : "@"} {m.opponent_name || "—"}
                        </p>
                        <p className="text-xs text-text-muted">
                          {new Date(m.date).toLocaleDateString("el-GR")}
                          {m.stadium ? ` · ${m.stadium}` : ""}
                        </p>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-text-muted">{t("dashboard.noUpcomingMatch")}</p>
                )}
              </WidgetCard>
            )}

            {!isHidden("next_training") && (
              <WidgetCard
                id="next_training"
                title={t("dashboard.upcomingTrainings")}
                icon="🏃"
                onHide={hideWidget}
                onRefresh={load}
              >
                {stats.upcoming_trainings.length > 0 ? (
                  <div className="max-h-48 space-y-2 overflow-y-auto pr-1">
                    {stats.upcoming_trainings.map((t2) => (
                      <Link
                        key={t2.id}
                        to={`/trainings/${t2.id}`}
                        className="block border-b border-line pb-1.5 last:border-0 hover:text-chalk"
                      >
                        <p className="text-sm text-text-primary">
                          <span className="text-chalk">
                            {t2.days_until === 0
                              ? t("dashboard.today")
                              : `${t("dashboard.inDaysPrefix")}${t2.days_until}${t("dashboard.inDaysSuffix")}`}
                          </span>{" "}
                          {t2.team_name}
                        </p>
                        <p className="text-xs text-text-muted">
                          {new Date(t2.date).toLocaleDateString("el-GR")}
                          {t2.location ? ` · ${t2.location}` : ""}
                        </p>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-text-muted">{t("dashboard.noUpcomingTraining")}</p>
                )}
              </WidgetCard>
            )}

            {!isHidden("week_trainings") && (
              <WidgetCard
                id="week_trainings"
                title={t("dashboard.thisWeek")}
                icon="📅"
                onHide={hideWidget}
                onRefresh={load}
              >
                <button onClick={() => openDetailModal("week_trainings")} className="block w-full text-left hover:text-chalk">
                  <p className="font-display text-3xl text-chalk">{stats.trainings_this_week}</p>
                  <p className="text-sm text-text-muted">{t("dashboard.trainingsScheduled")}</p>
                </button>
              </WidgetCard>
            )}

            {!isHidden("top_scorer") && (
              <WidgetCard
                id="top_scorer"
                title={t("dashboard.topScorer")}
                icon="🎯"
                onHide={hideWidget}
                onRefresh={load}
                headerAction={
                  stats.top_scorers.length > 0 && (
                    <button
                      onClick={() => openDetailModal("top_scorers")}
                      aria-label={t("dashboard.viewAllAriaLabel")}
                      className="text-xs text-text-muted hover:text-chalk"
                    >
                      🔍
                    </button>
                  )
                }
              >
                {stats.top_scorers.length > 0 ? (
                  <div className="max-h-48 space-y-1.5 overflow-y-auto pr-1">
                    {stats.top_scorers.map((s) => (
                      <div key={s.team_id} className="flex items-center justify-between text-sm">
                        <div className="min-w-0">
                          <p className="truncate text-text-primary">{s.player_name}</p>
                          {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                        </div>
                        <span className="shrink-0 font-display text-chalk">{s.label}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-text-muted">{t("dashboard.noGoalsYet")}</p>
                )}
              </WidgetCard>
            )}

            {!isHidden("best_avg") && (
              <WidgetCard
                id="best_avg"
                title={t("dashboard.bestAvgRating")}
                icon="⭐"
                onHide={hideWidget}
                onRefresh={load}
                headerAction={
                  stats.best_avg_rating_players.length > 0 && (
                    <button
                      onClick={() => openDetailModal("best_avg")}
                      aria-label={t("dashboard.viewAllAriaLabel")}
                      className="text-xs text-text-muted hover:text-chalk"
                    >
                      🔍
                    </button>
                  )
                }
              >
                {stats.best_avg_rating_players.length > 0 ? (
                  <div className="max-h-48 space-y-1.5 overflow-y-auto pr-1">
                    {stats.best_avg_rating_players.map((s) => (
                      <div key={s.team_id} className="flex items-center justify-between text-sm">
                        <div className="min-w-0">
                          <p className="truncate text-text-primary">{s.player_name}</p>
                          {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                        </div>
                        <span className="shrink-0 font-display text-chalk">{s.value.toFixed(1)}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-text-muted">{t("dashboard.noRatedMatchesYet")}</p>
                )}
              </WidgetCard>
            )}

            {!isHidden("month_performer") && (
              <WidgetCard
                id="month_performer"
                title={t("dashboard.topPerformerMonth")}
                icon="🏆"
                onHide={hideWidget}
                onRefresh={load}
                headerAction={
                  stats.top_performers_this_month.length > 0 && (
                    <button
                      onClick={() => openDetailModal("month_performers")}
                      aria-label={t("dashboard.viewAllAriaLabel")}
                      className="text-xs text-text-muted hover:text-chalk"
                    >
                      🔍
                    </button>
                  )
                }
              >
                {stats.top_performers_this_month.length > 0 ? (
                  <div className="max-h-48 space-y-1.5 overflow-y-auto pr-1">
                    {stats.top_performers_this_month.map((s) => (
                      <div key={s.team_id} className="flex items-center justify-between text-sm">
                        <div className="min-w-0">
                          <p className="truncate text-text-primary">{s.player_name}</p>
                          {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                        </div>
                        <span className="shrink-0 font-display text-chalk">{s.value.toFixed(1)}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-text-muted">{t("dashboard.noMatchesThisMonth")}</p>
                )}
              </WidgetCard>
            )}
          </div>

          {!isHidden("monthly_chart") && monthlyTop.length > 0 && (
            <WidgetCard
              id="monthly_chart"
              title="Top 5 Μ.Ο. Βαθμολογίας — Αυτός ο Μήνας"
              icon="📈"
              onHide={hideWidget}
              onRefresh={load}
            >
              <div style={{ width: "100%", height: 220 }}>
                <ResponsiveContainer>
                  <BarChart data={monthlyTop} margin={{ top: 8, right: 8, left: -20, bottom: 8 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--color-line))" />
                    <XAxis dataKey="player_name" tick={{ fontSize: 11, fill: "rgb(var(--color-text-muted))" }} />
                    <YAxis domain={[0, 10]} tick={{ fontSize: 11, fill: "rgb(var(--color-text-muted))" }} />
                    <Tooltip
                      contentStyle={{
                        background: "rgb(var(--color-surface-raised))",
                        border: "1px solid rgb(var(--color-line))",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    />
                    <Bar
                      dataKey="avg_rating"
                      fill="rgb(var(--color-chalk))"
                      radius={[4, 4, 0, 0]}
                      cursor="pointer"
                      onClick={(data: any) => data?.player_id && navigate(`/players/${data.player_id}`)}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </WidgetCard>
          )}

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {!isHidden("recent_activity") && (
              <Card
                className="lg:col-span-2"
                onContextMenu={(e) =>
                  activityMenu.open(e, [
                    {
                      heading: t("dashboard.recentActivity"),
                      items: [
                        { label: t("dashboard.refresh"), onClick: load },
                        { label: t("dashboard.hideWidget"), onClick: () => hideWidget("recent_activity"), danger: true },
                      ],
                    },
                  ])
                }
              >
                <div className="flex items-center justify-between border-b border-line px-4 py-3">
                  <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                    {t("dashboard.recentActivity")}
                  </h3>
                  <span className="text-xs text-text-muted">{t("dashboard.clickToEdit")}</span>
                </div>
                <div className="divide-y divide-line">
                  {stats.recent_activity.length === 0 ? (
                    <p className="px-4 py-8 text-center text-sm text-text-muted">
                      {t("dashboard.noActivityYet")}
                    </p>
                  ) : (
                    stats.recent_activity.map((a, i) => (
                      <button
                        key={i}
                        onClick={() => openActivity(a)}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          openActivity(a);
                        }}
                        className="flex w-full items-center justify-between px-4 py-3 text-left text-sm hover:bg-surface-raised"
                      >
                        <span className="flex items-center text-text-primary">
                          <ActivityIcon type={a.type} />
                          {a.text}
                        </span>
                        <span className="shrink-0 text-xs text-text-muted">
                          {new Date(a.timestamp).toLocaleDateString("el-GR")}
                        </span>
                      </button>
                    ))
                  )}
                </div>
                {activityMenu.render()}
              </Card>
            )}

            {!isHidden("quick_actions") && (
              <WidgetCard id="quick_actions" title={t("dashboard.quickActions")} icon="⚡" onHide={hideWidget}>
                <div className="space-y-2">
                  <QuickAction to="/teams" label={t("dashboard.createTeam")} />
                  <QuickAction to="/players" label={t("dashboard.addPlayer")} />
                  <QuickAction to="/matches" label={t("dashboard.createMatch")} />
                  <QuickAction to="/trainings" label={t("dashboard.addTraining")} />
                  <QuickAction to="/tactical-board" label="Tactical Board" />
                </div>
              </WidgetCard>
            )}
          </div>
        </div>
      )}

      <Modal
        isOpen={!!selectedTeam}
        onClose={() => setSelectedTeam(null)}
        title={selectedTeam ? `${t("dashboard.team")} — ${selectedTeam.name}` : t("dashboard.team")}
        wide
      >
        {selectedTeam && (
          <TeamForm
            team={selectedTeam}
            onSubmit={handleTeamSubmit}
            onCancel={() => setSelectedTeam(null)}
            isSubmitting={isSubmitting}
          />
        )}
      </Modal>

      <Modal
        isOpen={!!selectedPlayer}
        onClose={() => setSelectedPlayer(null)}
        title={
          selectedPlayer
            ? `${t("dashboard.player")} — ${selectedPlayer.first_name} ${selectedPlayer.last_name}`
            : t("dashboard.player")
        }
        wide
      >
        {selectedPlayer && (
          <PlayerForm
            player={selectedPlayer}
            teams={formTeams}
            onSubmit={handlePlayerSubmit}
            onCancel={() => setSelectedPlayer(null)}
            isSubmitting={isSubmitting}
          />
        )}
      </Modal>

      <Modal
        isOpen={detailModal !== null}
        onClose={() => setDetailModal(null)}
        title={
          detailModal === "teams"
            ? t("dashboard.allTeamsTitle")
            : detailModal === "players"
              ? t("dashboard.allPlayersTitle")
              : detailModal === "injured"
                ? t("dashboard.injuredPlayersTitle")
                : detailModal === "trainings"
                  ? t("dashboard.upcomingTrainings")
                  : detailModal === "week_trainings"
                    ? t("dashboard.weekTrainingsTitle")
                    : detailModal === "top_scorers"
                      ? t("dashboard.topScorer")
                      : detailModal === "best_avg"
                        ? t("dashboard.bestAvgRating")
                        : detailModal === "month_performers"
                          ? t("dashboard.topPerformerMonth")
                          : ""
        }
      >
        {isDetailLoading ? (
          <Spinner />
        ) : detailModal === "teams" ? (
          detailTeams.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {detailTeams.map((tm) => (
                <div key={tm.id} className="flex items-center justify-between border-b border-line pb-2 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">{tm.name}</p>
                    <p className="truncate text-xs text-text-muted">
                      {[tm.category, tm.season].filter(Boolean).join(" · ") || "—"}
                    </p>
                  </div>
                  <span className="shrink-0 text-xs text-text-muted">
                    {tm.player_count} {t("teams.playersUnit")}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("teams.noTeamsYet")}</p>
          )
        ) : detailModal === "players" || detailModal === "injured" ? (
          detailPlayers.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {detailPlayers.map((p) => (
                <div key={p.id} className="flex items-center justify-between border-b border-line pb-2 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">
                      {p.first_name} {p.last_name}
                    </p>
                    <p className="truncate text-xs text-text-muted">
                      {[p.team_name, p.position].filter(Boolean).join(" · ") || "—"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">
              {detailModal === "injured" ? t("dashboard.noInjuredPlayers") : t("dashboard.noPlayersInModal")}
            </p>
          )
        ) : detailModal === "trainings" ? (
          stats && stats.upcoming_trainings.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {stats.upcoming_trainings.map((tr) => (
                <div key={tr.id} className="border-b border-line pb-2 last:border-0">
                  <p className="text-sm text-text-primary">{tr.team_name}</p>
                  <p className="text-xs text-text-muted">
                    {new Date(tr.date).toLocaleDateString("el-GR")}
                    {tr.location ? ` · ${tr.location}` : ""}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("dashboard.noUpcomingTraining")}</p>
          )
        ) : detailModal === "week_trainings" ? (
          stats && stats.upcoming_trainings.filter((tr) => tr.days_until <= 7).length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {stats.upcoming_trainings
                .filter((tr) => tr.days_until <= 7)
                .map((tr) => (
                  <div key={tr.id} className="border-b border-line pb-2 last:border-0">
                    <p className="text-sm text-text-primary">{tr.team_name}</p>
                    <p className="text-xs text-text-muted">
                      {new Date(tr.date).toLocaleDateString("el-GR")}
                      {tr.location ? ` · ${tr.location}` : ""}
                    </p>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("dashboard.noTrainingsThisWeek")}</p>
          )
        ) : detailModal === "top_scorers" ? (
          stats && stats.top_scorers.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {stats.top_scorers.map((s) => (
                <div key={s.team_id} className="flex items-center justify-between border-b border-line pb-2 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">{s.player_name}</p>
                    {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                  </div>
                  <span className="shrink-0 font-display text-chalk">{s.label}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("dashboard.noGoalsYet")}</p>
          )
        ) : detailModal === "best_avg" ? (
          stats && stats.best_avg_rating_players.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {stats.best_avg_rating_players.map((s) => (
                <div key={s.team_id} className="flex items-center justify-between border-b border-line pb-2 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">{s.player_name}</p>
                    {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                  </div>
                  <span className="shrink-0 font-display text-chalk">{s.value.toFixed(1)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("dashboard.noRatedMatchesYet")}</p>
          )
        ) : detailModal === "month_performers" ? (
          stats && stats.top_performers_this_month.length > 0 ? (
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1">
              {stats.top_performers_this_month.map((s) => (
                <div key={s.team_id} className="flex items-center justify-between border-b border-line pb-2 last:border-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">{s.player_name}</p>
                    {s.team_name && <p className="truncate text-xs text-text-muted">{s.team_name}</p>}
                  </div>
                  <span className="shrink-0 font-display text-chalk">{s.value.toFixed(1)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-text-muted">{t("dashboard.noMatchesThisMonth")}</p>
          )
        ) : null}
      </Modal>
    </AppLayout>
  );
}
