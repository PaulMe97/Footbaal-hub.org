import { MouseEvent as ReactMouseEvent, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { extractErrorMessage } from "../api/client";
import {
  createAnnotation,
  deleteAnnotation,
  getVideo,
  listAnnotations,
} from "../api/videoAnalysis";
import type { VideoAnalysisItem, VideoAnnotationItem } from "../api/videoAnalysis";
import { AnnotationOverlay, draftToShapeData } from "../components/video/AnnotationOverlay";
import type { DraftShape, DrawTool, Point } from "../components/video/AnnotationOverlay";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { ConfirmDialog } from "../components/ui/Modal";
import { Spinner } from "../components/ui/EmptyState";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";

const ANNOTATION_DISPLAY_SECONDS = 4;
const COLORS = ["#FFD400", "#FF3B30", "#34C759", "#0A84FF", "#FFFFFF", "#000000"];

const TOOLS: { key: DrawTool; labelKey: string; icon: string }[] = [
  { key: "select", labelKey: "videoStudio.toolSelect", icon: "↖" },
  { key: "circle", labelKey: "videoStudio.toolCircle", icon: "○" },
  { key: "arrow", labelKey: "videoStudio.toolArrow", icon: "↗" },
  { key: "line", labelKey: "videoStudio.toolLine", icon: "╱" },
  { key: "rectangle", labelKey: "videoStudio.toolRectangle", icon: "▭" },
  { key: "freehand", labelKey: "videoStudio.toolFreehand", icon: "✎" },
  { key: "spotlight", labelKey: "videoStudio.toolSpotlight", icon: "◉" },
  { key: "text", labelKey: "videoStudio.toolText", icon: "T" },
];

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function VideoStudio() {
  const { id } = useParams<{ id: string }>();
  const { t } = useLanguage();
  const toast = useToast();
  const navigate = useNavigate();

  const [video, setVideo] = useState<VideoAnalysisItem | null>(null);
  const [annotations, setAnnotations] = useState<VideoAnnotationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTool, setActiveTool] = useState<DrawTool>("select");
  const [activeColor, setActiveColor] = useState(COLORS[0]);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [draft, setDraft] = useState<DraftShape | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [textPromptPos, setTextPromptPos] = useState<Point | null>(null);
  const [textPromptValue, setTextPromptValue] = useState("");

  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const isDrawingRef = useRef(false);
  const freehandPointsRef = useRef<Point[]>([]);

  async function load() {
    if (!id) return;
    setIsLoading(true);
    try {
      const [v, a] = await Promise.all([getVideo(id), listAnnotations(id)]);
      setVideo(v);
      setAnnotations(a);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function getRelativePoint(e: { clientX: number; clientY: number }): Point | null {
    const el = overlayRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    return { x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) };
  }

  function handleOverlayMouseDown(e: ReactMouseEvent) {
    if (activeTool === "select") return;
    const point = getRelativePoint(e);
    if (!point) return;

    if (activeTool === "text") {
      setTextPromptPos(point);
      setTextPromptValue("");
      return;
    }

    isDrawingRef.current = true;
    if (activeTool === "freehand") {
      freehandPointsRef.current = [point];
    }
    setDraft({ tool: activeTool, start: point, current: point, points: [point], color: activeColor });
  }

  function handleOverlayMouseMove(e: ReactMouseEvent) {
    if (!isDrawingRef.current) return;
    const point = getRelativePoint(e);
    if (!point) return;
    if (activeTool === "freehand") {
      freehandPointsRef.current = [...freehandPointsRef.current, point];
      setDraft((prev) => (prev ? { ...prev, current: point, points: [...freehandPointsRef.current] } : prev));
    } else {
      setDraft((prev) => (prev ? { ...prev, current: point } : prev));
    }
  }

  async function handleOverlayMouseUp() {
    if (!isDrawingRef.current || !draft || !id) {
      isDrawingRef.current = false;
      return;
    }
    isDrawingRef.current = false;
    const shapeData = draftToShapeData(draft);
    setDraft(null);
    if (!shapeData) return;

    const startTime = currentTime;
    const endTime = Math.min(duration || currentTime + ANNOTATION_DISPLAY_SECONDS, currentTime + ANNOTATION_DISPLAY_SECONDS);
    try {
      const created = await createAnnotation(id, {
        shape_type: activeTool,
        shape_data: shapeData,
        start_time: startTime,
        end_time: endTime,
      });
      setAnnotations((prev) => [...prev, created]);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleTextSubmit() {
    if (!id || !textPromptPos || !textPromptValue.trim()) {
      setTextPromptPos(null);
      return;
    }
    const startTime = currentTime;
    const endTime = Math.min(duration || currentTime + ANNOTATION_DISPLAY_SECONDS, currentTime + ANNOTATION_DISPLAY_SECONDS);
    try {
      const created = await createAnnotation(id, {
        shape_type: "text",
        shape_data: { x: textPromptPos.x, y: textPromptPos.y, text: textPromptValue.trim(), color: activeColor },
        start_time: startTime,
        end_time: endTime,
      });
      setAnnotations((prev) => [...prev, created]);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setTextPromptPos(null);
      setTextPromptValue("");
    }
  }

  async function handleUndo() {
    if (!id || annotations.length === 0) return;
    const last = annotations[annotations.length - 1];
    try {
      await deleteAnnotation(id, last.id);
      setAnnotations((prev) => prev.slice(0, -1));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleClearAll() {
    if (!id) return;
    setIsClearing(true);
    try {
      await Promise.all(annotations.map((a) => deleteAnnotation(id, a.id)));
      setAnnotations([]);
      setShowClearConfirm(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsClearing(false);
    }
  }

  async function handleDeleteAnnotation(annotationId: string) {
    if (!id) return;
    try {
      await deleteAnnotation(id, annotationId);
      setAnnotations((prev) => prev.filter((a) => a.id !== annotationId));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  function togglePlay() {
    const el = videoRef.current;
    if (!el) return;
    if (el.paused) {
      el.play();
    } else {
      el.pause();
    }
  }

  const annotationsHere = annotations.filter((a) => currentTime >= a.start_time && currentTime <= a.end_time);

  if (isLoading) {
    return (
      <AppLayout title={t("videoEditing.pageTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  if (!video || !video.playback_url) {
    return (
      <AppLayout title={t("videoEditing.pageTitle")}>
        <p className="text-sm text-text-muted">{t("videoStudio.videoNotReady")}</p>
        <Button variant="secondary" className="mt-4" onClick={() => navigate("/video-editing")}>
          {t("videoStudio.backToList")}
        </Button>
      </AppLayout>
    );
  }

  return (
    <AppLayout title={video.title}>
      <button
        onClick={() => navigate("/video-editing")}
        className="mb-4 text-xs text-text-muted hover:text-chalk"
      >
        {t("videoStudio.backToList")}
      </button>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <div className="lg:col-span-3">
          <div className="relative overflow-hidden rounded-lg border border-line bg-black">
            <video
              ref={videoRef}
              src={video.playback_url}
              className="w-full"
              onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
              onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              controls={false}
            />
            <div
              ref={overlayRef}
              className={`absolute inset-0 ${activeTool !== "select" ? "cursor-crosshair" : ""}`}
              onMouseDown={handleOverlayMouseDown}
              onMouseMove={handleOverlayMouseMove}
              onMouseUp={handleOverlayMouseUp}
            >
              <AnnotationOverlay annotations={annotations} currentTime={currentTime} draft={draft} />
              {textPromptPos && (
                <div
                  className="pointer-events-auto absolute z-10 -translate-x-1/2 -translate-y-1/2 rounded-md border border-line bg-surface-raised p-2 shadow-xl"
                  style={{ left: `${textPromptPos.x * 100}%`, top: `${textPromptPos.y * 100}%` }}
                  onMouseDown={(e) => e.stopPropagation()}
                >
                  <input
                    autoFocus
                    value={textPromptValue}
                    onChange={(e) => setTextPromptValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleTextSubmit();
                      if (e.key === "Escape") setTextPromptPos(null);
                    }}
                    placeholder={t("videoStudio.textPromptPlaceholder")}
                    className="w-40 rounded border border-line bg-void px-2 py-1 text-xs text-text-primary"
                  />
                  <div className="mt-1 flex justify-end gap-1">
                    <button
                      onClick={() => setTextPromptPos(null)}
                      className="text-[10px] text-text-muted hover:text-text-primary"
                    >
                      {t("common.cancel")}
                    </button>
                    <button onClick={handleTextSubmit} className="text-[10px] text-chalk hover:underline">
                      OK
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-line text-text-primary hover:border-chalk"
            >
              {isPlaying ? "⏸" : "▶"}
            </button>
            <div className="relative flex-1">
              <input
                type="range"
                min={0}
                max={duration || 0}
                step={0.1}
                value={currentTime}
                onChange={(e) => {
                  const t2 = parseFloat(e.target.value);
                  if (videoRef.current) videoRef.current.currentTime = t2;
                  setCurrentTime(t2);
                }}
                className="w-full accent-chalk"
              />
              <div className="pointer-events-none absolute left-0 top-1/2 h-1 w-full -translate-y-1/2">
                {duration > 0 &&
                  annotations.map((a) => (
                    <span
                      key={a.id}
                      className="absolute top-0 h-1 w-1 rounded-full bg-chalk"
                      style={{ left: `${(a.start_time / duration) * 100}%` }}
                    />
                  ))}
              </div>
            </div>
            <span className="w-20 shrink-0 text-right font-mono text-xs text-text-muted">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>

          <div className="mt-4 rounded-lg border border-line p-3">
            <div className="flex flex-wrap items-center gap-2">
              {TOOLS.map((tool) => (
                <button
                  key={tool.key}
                  onClick={() => setActiveTool(tool.key)}
                  title={t(tool.labelKey)}
                  className={`flex h-9 w-9 items-center justify-center rounded-md border text-sm ${
                    activeTool === tool.key
                      ? "border-chalk bg-chalk/15 text-chalk"
                      : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                  }`}
                >
                  {tool.icon}
                </button>
              ))}
              <div className="mx-2 h-6 w-px bg-line" />
              {COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveColor(c)}
                  title={c}
                  className={`h-7 w-7 rounded-full border-2 ${activeColor === c ? "border-chalk" : "border-line"}`}
                  style={{ backgroundColor: c }}
                />
              ))}
              <div className="mx-2 h-6 w-px bg-line" />
              <Button variant="secondary" onClick={handleUndo} disabled={annotations.length === 0}>
                {t("videoStudio.undoButton")}
              </Button>
              <Button
                variant="secondary"
                onClick={() => setShowClearConfirm(true)}
                disabled={annotations.length === 0}
              >
                {t("videoStudio.clearButton")}
              </Button>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-line p-3">
          <h3 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
            {t("videoStudio.annotationsAtTime")}
          </h3>
          {annotationsHere.length === 0 ? (
            <p className="text-xs text-text-muted">{t("videoStudio.noAnnotationsHere")}</p>
          ) : (
            <div className="space-y-2">
              {annotationsHere.map((a) => (
                <div
                  key={a.id}
                  className="flex items-center justify-between rounded-md border border-line px-2 py-1.5 text-xs"
                >
                  <span className="flex items-center gap-1.5 text-text-primary">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ backgroundColor: (a.shape_data.color as string) || "#FFD400" }}
                    />
                    {t(`videoStudio.tool${a.shape_type.charAt(0).toUpperCase()}${a.shape_type.slice(1)}`)}
                  </span>
                  <button
                    onClick={() => handleDeleteAnnotation(a.id)}
                    className="text-status-injured hover:underline"
                  >
                    {t("videoStudio.deleteAnnotation")}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        isOpen={showClearConfirm}
        onClose={() => setShowClearConfirm(false)}
        onConfirm={handleClearAll}
        title={t("videoStudio.clearConfirmTitle")}
        message={t("videoStudio.clearConfirmMessage")}
        isLoading={isClearing}
      />
    </AppLayout>
  );
}
