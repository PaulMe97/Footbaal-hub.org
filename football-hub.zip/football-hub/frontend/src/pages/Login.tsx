import { FormEvent, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";

import { forgotPassword, resetPassword } from "../api/auth";
import { extractErrorMessage } from "../api/client";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";
import { Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";

function ForgotPasswordModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const toast = useToast();
  const { t } = useLanguage();
  const [step, setStep] = useState<"request" | "reset">("request");
  const [usernameOrEmail, setUsernameOrEmail] = useState("");
  const [token, setToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [info, setInfo] = useState<string | null>(null);

  function reset() {
    setStep("request");
    setUsernameOrEmail("");
    setToken("");
    setNewPassword("");
    setConfirmPassword("");
    setInfo(null);
  }

  async function handleRequest(e: FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await forgotPassword(usernameOrEmail);
      setInfo(res.message);
      if (res.reset_token) {
        setToken(res.reset_token);
      }
      setStep("reset");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleReset(e: FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.show(t("auth.passwordsDontMatch"), "error");
      return;
    }
    setIsSubmitting(true);
    try {
      await resetPassword(token, newPassword);
      toast.show(t("auth.passwordChanged"), "success");
      onClose();
      reset();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
        reset();
      }}
      title={t("auth.resetPasswordTitle")}
    >
      {step === "request" ? (
        <form onSubmit={handleRequest} className="space-y-4">
          <p className="text-sm text-text-muted">{t("auth.resetPasswordIntro")}</p>
          <Input
            label={t("auth.usernameOrEmail")}
            required
            autoFocus
            value={usernameOrEmail}
            onChange={(e) => setUsernameOrEmail(e.target.value)}
          />
          <Button type="submit" isLoading={isSubmitting} className="w-full">
            {t("auth.generateResetCode")}
          </Button>
        </form>
      ) : (
        <form onSubmit={handleReset} className="space-y-4">
          {info && <p className="text-sm text-text-muted">{info}</p>}
          <Input
            label={t("auth.resetCodeLabel")}
            required
            value={token}
            onChange={(e) => setToken(e.target.value)}
            hint={t("auth.resetCodeHint")}
          />
          <Input
            label={t("auth.newPassword")}
            type="password"
            required
            minLength={8}
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <Input
            label={t("auth.confirmNewPassword")}
            type="password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
          <Button type="submit" isLoading={isSubmitting} className="w-full">
            {t("auth.changePassword")}
          </Button>
        </form>
      )}
    </Modal>
  );
}

export default function Login() {
  const { user, login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const toast = useToast();

  const [usernameOrEmail, setUsernameOrEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgot, setShowForgot] = useState(false);

  if (user) return <Navigate to="/" replace />;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    try {
      await login(usernameOrEmail, password);
      toast.show(t("auth.welcomeBack"), "success");
      navigate("/");
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-void px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-chalk">
            <span className="font-display text-xl text-chalk">FH</span>
          </div>
          <h1 className="font-display text-2xl tracking-wide text-text-primary">FootballHub</h1>
          <p className="text-sm text-text-muted">
            Football Hub &amp; Analysis Platform
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="corner-card space-y-4 rounded-lg border border-line bg-surface p-6"
        >
          <Input
            label={t("auth.usernameOrEmail")}
            value={usernameOrEmail}
            onChange={(e) => setUsernameOrEmail(e.target.value)}
            required
            autoFocus
          />
          <Input
            label={t("auth.password")}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <p className="text-sm text-status-injured">{error}</p>}
          <Button type="submit" isLoading={isLoading} className="w-full">
            {t("auth.login")}
          </Button>
          <button
            type="button"
            onClick={() => setShowForgot(true)}
            className="block w-full text-center text-xs text-text-muted hover:text-chalk"
          >
            {t("auth.forgotPassword")}
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-text-muted">
          {t("auth.noAccount")}{" "}
          <Link to="/register" className="text-chalk hover:underline">
            {t("auth.createAccount")}
          </Link>
        </p>

        <p className="mt-4 text-center text-xs text-text-muted">
          {t("auth.firstTimeIntro")}{" "}
          <code className="rounded bg-surface-raised px-1 py-0.5">python -m app.seed</code>{" "}
          {t("auth.firstTimeOutro")}
        </p>
      </div>

      <ForgotPasswordModal isOpen={showForgot} onClose={() => setShowForgot(false)} />
    </div>
  );
}
