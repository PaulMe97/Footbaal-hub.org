import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import { extractErrorMessage, mediaUrl } from "../api/client";
import {
  addStaffEvaluation,
  fireStaffMember,
  listMyStaff,
  listStaffEvaluations,
  startConversationWithStaff,
} from "../api/staff";
import type { StaffEvaluationItem, StaffMemberItem, StaffTeamGroupItem } from "../api/staff";
import { sendStaffAssignmentOffer } from "../api/staffOffers";
import { listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog, Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { STAFF_AVAILABILITY_LABELS } from "../types";
import type { Team } from "../types";

function Stars({ value }: { value: number }) {
  return (
    <span className="text-chalk">
      {"★".repeat(Math.round(value))}
      <span className="text-line">{"★".repeat(5 - Math.round(value))}</span>
    </span>
  );
}

interface TeamMembership {
  team_id: string;
  team_name: string;
  role_title?: string | null;
  can_fire: boolean;
}

interface UniqueMember {
  member: StaffMemberItem;
  teams: TeamMembership[];
  overallRating: number | null;
  totalEvaluations: number;
}

export default function Staff() {
  const toast = useToast();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();
  const canSendOffer = user?.role === "president" || user?.role === "technical_director";

  const ROLE_LABELS: Record<string, string> = {
    super_admin: t("crm.roleSuperAdmin"),
    admin: t("crm.roleAdmin"),
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
  };

  const NEW_ROLE_OPTIONS = [
    { value: "technical_director", label: t("crm.roleTechnicalDirector") },
    { value: "head_coach", label: t("crm.roleHeadCoach") },
    { value: "assistant_coach", label: t("crm.roleAssistantCoach") },
    { value: "fitness_coach", label: t("crm.roleFitnessCoach") },
    { value: "analyst", label: t("crm.roleAnalyst") },
    { value: "scout", label: "Scout" },
  ];

  const [groups, setGroups] = useState<StaffTeamGroupItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [myTeams, setMyTeams] = useState<Team[]>([]);

  const [fireTarget, setFireTarget] = useState<{ teamId: string; teamName: string; member: StaffMemberItem } | null>(
    null
  );
  const [isFiring, setIsFiring] = useState(false);

  const [evalTarget, setEvalTarget] = useState<UniqueMember | null>(null);
  const [evalTeamId, setEvalTeamId] = useState("");
  const [evalRating, setEvalRating] = useState(5);
  const [evalComment, setEvalComment] = useState("");
  const [isSubmittingEval, setIsSubmittingEval] = useState(false);

  const [profileTarget, setProfileTarget] = useState<UniqueMember | null>(null);
  const [evaluations, setEvaluations] = useState<(StaffEvaluationItem & { team_name: string })[]>([]);
  const [isLoadingEvals, setIsLoadingEvals] = useState(false);

  const [offerTarget, setOfferTarget] = useState<StaffMemberItem | null>(null);
  const [offerTeamId, setOfferTeamId] = useState("");
  const [offerRoleTitle, setOfferRoleTitle] = useState("");
  const [offerNewRole, setOfferNewRole] = useState("");
  const [offerSeason, setOfferSeason] = useState("");
  const [offerIncentive, setOfferIncentive] = useState("");
  const [offerMessage, setOfferMessage] = useState("");
  const [isSendingOffer, setIsSendingOffer] = useState(false);

  const [startingChatId, setStartingChatId] = useState<string | null>(null);

  // Ένα άτομο μπορεί να έχει πρόσβαση σε πολλές από τις ομάδες μας — τον
  // δείχνουμε ΜΙΑ φορά, με τις ομάδες του συγκεντρωμένες στο προφίλ του.
  const uniqueMembers: UniqueMember[] = useMemo(() => {
    const byUser = new Map<string, UniqueMember>();
    for (const group of groups) {
      for (const m of group.members) {
        const existing = byUser.get(m.user_id);
        const membership: TeamMembership = {
          team_id: group.team_id,
          team_name: group.team_name,
          role_title: m.role_title,
          can_fire: m.can_fire,
        };
        if (existing) {
          existing.teams.push(membership);
          if (m.avg_rating != null) {
            existing.overallRating =
              ((existing.overallRating || 0) * existing.totalEvaluations + m.avg_rating * m.evaluation_count) /
              (existing.totalEvaluations + m.evaluation_count || 1);
            existing.totalEvaluations += m.evaluation_count;
          }
        } else {
          byUser.set(m.user_id, {
            member: m,
            teams: [membership],
            overallRating: m.avg_rating ?? null,
            totalEvaluations: m.evaluation_count,
          });
        }
      }
    }
    return Array.from(byUser.values()).sort((a, b) =>
      (a.member.full_name || a.member.username).localeCompare(b.member.full_name || b.member.username)
    );
  }, [groups]);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listMyStaff();
      setGroups(data);
      if (canSendOffer) {
        const teams = await listTeams();
        setMyTeams(teams);
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function openProfile(um: UniqueMember) {
    setProfileTarget(um);
    setIsLoadingEvals(true);
    try {
      const results = await Promise.all(
        um.teams.map(async (teamRef) => {
          const evals = await listStaffEvaluations(teamRef.team_id, um.member.user_id);
          return evals.map((e) => ({ ...e, team_name: teamRef.team_name }));
        })
      );
      const merged = results
        .flat()
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      setEvaluations(merged);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingEvals(false);
    }
  }

  async function handleFire() {
    if (!fireTarget) return;
    setIsFiring(true);
    try {
      await fireStaffMember(fireTarget.teamId, fireTarget.member.user_id);
      toast.show(t("staff.collabTerminated"), "success");
      setFireTarget(null);
      setProfileTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsFiring(false);
    }
  }

  async function handleSubmitEvaluation() {
    if (!evalTarget || !evalTeamId) return;
    setIsSubmittingEval(true);
    try {
      await addStaffEvaluation(evalTeamId, evalTarget.member.user_id, evalRating, evalComment || undefined);
      toast.show(t("staff.evaluationSubmitted"), "success");
      setEvalTarget(null);
      setEvalRating(5);
      setEvalComment("");
      load();
      if (profileTarget) openProfile(profileTarget);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmittingEval(false);
    }
  }

  async function handleStartChat(teamId: string, userId: string) {
    setStartingChatId(userId);
    try {
      await startConversationWithStaff(teamId, userId);
      navigate("/messages");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setStartingChatId(null);
    }
  }

  async function handleSendOffer() {
    if (!offerTarget || !offerTeamId) return;
    setIsSendingOffer(true);
    try {
      await sendStaffAssignmentOffer(offerTeamId, {
        recipient_user_id: offerTarget.user_id,
        role_title: offerRoleTitle || undefined,
        new_role: offerNewRole || undefined,
        season: offerSeason || undefined,
        incentive_details: offerIncentive || undefined,
        message: offerMessage || undefined,
      });
      toast.show(t("staff.offerSentToast"), "success");
      setOfferTarget(null);
      setOfferTeamId("");
      setOfferRoleTitle("");
      setOfferNewRole("");
      setOfferSeason("");
      setOfferIncentive("");
      setOfferMessage("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSendingOffer(false);
    }
  }

  return (
    <AppLayout title="Staff">
      <p className="mb-4 text-sm text-text-muted">{t("staff.intro")}</p>

      {isLoading ? (
        <Spinner />
      ) : uniqueMembers.length === 0 ? (
        <EmptyState
          title={t("staff.noStaffYet")}
          description={t("staff.noStaffDescription")}
        />
      ) : (
        <Card corners>
          <div className="divide-y divide-line">
            {uniqueMembers.map((um) => (
              <button
                key={um.member.user_id}
                onClick={() => openProfile(um)}
                className="flex w-full flex-wrap items-center gap-3 px-4 py-3 text-left hover:bg-surface-raised"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xs text-text-muted">
                  {um.member.avatar_path ? (
                    <img src={mediaUrl(um.member.avatar_path)} alt="" className="h-full w-full object-cover" />
                  ) : (
                    (um.member.full_name || um.member.username).charAt(0).toUpperCase()
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-text-primary">
                    {um.member.full_name || um.member.username}
                  </p>
                  <p className="truncate text-xs text-text-muted">
                    {ROLE_LABELS[um.member.role] || um.member.role}
                    {" · "}
                    {um.teams.length === 1 ? um.teams[0].team_name : `${um.teams.length}${t("staff.teamsCountSuffix")}`}
                    {um.member.staff_availability !== "not_listed"
                      ? ` · ${STAFF_AVAILABILITY_LABELS[um.member.staff_availability]}`
                      : ""}
                  </p>
                  {um.overallRating != null && (
                    <p className="mt-0.5 text-xs">
                      <Stars value={um.overallRating} /> ({um.totalEvaluations})
                    </p>
                  )}
                </div>
                <span className="shrink-0 text-xs text-chalk">{t("staff.view")}</span>
              </button>
            ))}
          </div>
        </Card>
      )}

      {/* Profile modal */}
      <Modal isOpen={!!profileTarget} onClose={() => setProfileTarget(null)} title={t("staff.profileTitle")} wide>
        {profileTarget && (
          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-lg text-text-muted">
                  {profileTarget.member.avatar_path ? (
                    <img
                      src={mediaUrl(profileTarget.member.avatar_path)}
                      alt=""
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    (profileTarget.member.full_name || profileTarget.member.username).charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <p className="text-text-primary">
                    {profileTarget.member.full_name || profileTarget.member.username}
                  </p>
                  <p className="text-xs text-text-muted">
                    {ROLE_LABELS[profileTarget.member.role] || profileTarget.member.role}
                    {profileTarget.member.staff_availability !== "not_listed"
                      ? ` · ${STAFF_AVAILABILITY_LABELS[profileTarget.member.staff_availability]}`
                      : ""}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleStartChat(profileTarget.teams[0].team_id, profileTarget.member.user_id)}
                  disabled={startingChatId === profileTarget.member.user_id}
                  className="rounded-md border border-line px-3 py-1.5 text-xs text-text-primary hover:border-chalk disabled:opacity-50"
                >
                  {t("staff.chat")}
                </button>
                <button
                  onClick={() => {
                    setEvalTarget(profileTarget);
                    setEvalTeamId(profileTarget.teams[0].team_id);
                  }}
                  className="rounded-md border border-line px-3 py-1.5 text-xs text-text-primary hover:border-chalk"
                >
                  {t("staff.evaluation")}
                </button>
                {canSendOffer && profileTarget.member.role !== "president" && (
                  <button
                    onClick={() => setOfferTarget(profileTarget.member)}
                    className="rounded-md border border-line px-3 py-1.5 text-xs text-text-primary hover:border-chalk"
                  >
                    {t("staff.offer")}
                  </button>
                )}
              </div>
            </div>

            <div className="mt-5 border-t border-line pt-4">
              <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("staff.managedTeamsPrefix")}{profileTarget.teams.length})
              </h4>
              <div className="space-y-1.5">
                {profileTarget.teams.map((teamRef) => (
                  <div
                    key={teamRef.team_id}
                    className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2"
                  >
                    <div>
                      <p className="text-sm text-text-primary">{teamRef.team_name}</p>
                      {teamRef.role_title && <p className="text-xs text-text-muted">{teamRef.role_title}</p>}
                    </div>
                    {teamRef.can_fire && (
                      <button
                        onClick={() =>
                          setFireTarget({ teamId: teamRef.team_id, teamName: teamRef.team_name, member: profileTarget.member })
                        }
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("staff.fire")}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 border-t border-line pt-4">
              <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("staff.evaluationHistory")}
              </h4>
              {isLoadingEvals ? (
                <Spinner />
              ) : evaluations.length === 0 ? (
                <p className="text-sm text-text-muted">{t("staff.noEvaluationsYet")}</p>
              ) : (
                <div className="space-y-2">
                  {evaluations.map((e) => (
                    <div key={e.id} className="rounded-md border border-line bg-surface-raised p-2.5">
                      <div className="flex items-center justify-between">
                        <Stars value={e.rating} />
                        <span className="text-xs text-text-muted">
                          {new Date(e.created_at).toLocaleDateString("el-GR")}
                        </span>
                      </div>
                      {e.comment && <p className="mt-1 text-sm text-text-primary">{e.comment}</p>}
                      <p className="mt-1 text-xs text-text-muted">
                        {t("staff.evaluatorPrefix")}{e.evaluator_name} · {e.team_name}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Evaluation form */}
      <Modal isOpen={!!evalTarget} onClose={() => setEvalTarget(null)} title={t("staff.newEvaluationModalTitle")}>
        {evalTarget && (
          <div className="space-y-4">
            <p className="text-sm text-text-muted">
              {t("staff.evaluationForPrefix")}{" "}
              <span className="text-text-primary">{evalTarget.member.full_name || evalTarget.member.username}</span>
            </p>
            {evalTarget.teams.length > 1 && (
              <Select label={t("crm.team")} value={evalTeamId} onChange={(e) => setEvalTeamId(e.target.value)}>
                {evalTarget.teams.map((teamRef) => (
                  <option key={teamRef.team_id} value={teamRef.team_id}>
                    {teamRef.team_name}
                  </option>
                ))}
              </Select>
            )}
            <div className="flex gap-1 text-2xl">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  onClick={() => setEvalRating(n)}
                  className={n <= evalRating ? "text-chalk" : "text-line"}
                >
                  ★
                </button>
              ))}
            </div>
            <Textarea
              label={t("staff.commentOptional")}
              value={evalComment}
              onChange={(e) => setEvalComment(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => setEvalTarget(null)}>
                {t("common.cancel")}
              </Button>
              <Button type="button" onClick={handleSubmitEvaluation} isLoading={isSubmittingEval}>
                {t("staff.submit")}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Staff assignment offer form */}
      <Modal isOpen={!!offerTarget} onClose={() => setOfferTarget(null)} title={t("staff.newOfferModalTitle")}>
        {offerTarget && (
          <div className="space-y-4">
            <p className="text-sm text-text-muted">
              {t("staff.offerToPrefix")}<span className="text-text-primary">{offerTarget.full_name}</span>
              {t("staff.offerIntroSuffix")}
            </p>
            <Select label={t("crm.team")} value={offerTeamId} onChange={(e) => setOfferTeamId(e.target.value)}>
              <option value="">{t("crm.selectTeam")}</option>
              {myTeams.map((teamOpt) => (
                <option key={teamOpt.id} value={teamOpt.id}>
                  {teamOpt.name}
                </option>
              ))}
            </Select>
            <Input
              label={t("staff.roleTitleOptional")}
              placeholder={t("staff.roleTitlePlaceholder")}
              value={offerRoleTitle}
              onChange={(e) => setOfferRoleTitle(e.target.value)}
            />
            <Select
              label={t("staff.accountRoleChangeOptional")}
              value={offerNewRole}
              onChange={(e) => setOfferNewRole(e.target.value)}
            >
              <option value="">{t("staff.noRoleChange")}</option>
              {NEW_ROLE_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </Select>
            <Input
              label={t("staff.seasonOptional")}
              placeholder="2026-2027"
              value={offerSeason}
              onChange={(e) => setOfferSeason(e.target.value)}
            />
            <Textarea
              label={t("staff.incentiveOptional")}
              placeholder={t("staff.incentivePlaceholder")}
              value={offerIncentive}
              onChange={(e) => setOfferIncentive(e.target.value)}
            />
            <Textarea
              label={t("staff.messageOptional")}
              value={offerMessage}
              onChange={(e) => setOfferMessage(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => setOfferTarget(null)}>
                {t("common.cancel")}
              </Button>
              <Button type="button" onClick={handleSendOffer} isLoading={isSendingOffer} disabled={!offerTeamId}>
                {t("staff.sendOffer")}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={!!fireTarget}
        onClose={() => setFireTarget(null)}
        onConfirm={handleFire}
        title={t("staff.terminateCollabTitle")}
        message={
          fireTarget
            ? `${t("staff.terminateConfirmPrefix")}${fireTarget.member.full_name}${t("staff.terminateConfirmMiddle")}${fireTarget.teamName}${t("staff.terminateConfirmSuffix")}`
            : ""
        }
        confirmLabel={t("staff.fire")}
        isLoading={isFiring}
      />
    </AppLayout>
  );
}
