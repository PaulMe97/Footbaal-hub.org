import { FormEvent, useEffect, useRef, useState, type ChangeEvent } from "react";

import { changePassword, updateMe } from "../api/auth";
import { downloadBackup, downloadMyDataExport, uploadBackup } from "../api/backup";
import { extractErrorMessage } from "../api/client";
import { getAISettings, getStorageSettings, updateAISettings, updateStorageSettings, getSMTPSettings, updateSMTPSettings } from "../api/settings";
import { listBannedIPs, unbanIP, getCaptchaSettings, updateCaptchaSettings } from "../api/security";
import type { BannedIPItem } from "../api/security";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input, Select } from "../components/ui/Input";
import { ConfirmDialog } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";

const ADMIN_ROLES = ["super_admin", "admin"];
const TEAM_LEADERSHIP_ROLES = ["president", "technical_director", "head_coach", "assistant_coach"];

export default function Settings() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const { t } = useLanguage();

  const ROLE_LABELS: Record<string, string> = {
    super_admin: "Super Admin",
    admin: "Admin",
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
    player: t("settings.rolePlayerLabel"),
  };

  const [fullName, setFullName] = useState(user?.full_name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  const [aiProvider, setAiProvider] = useState("anthropic");
  const [aiModel, setAiModel] = useState("");
  const [aiApiKey, setAiApiKey] = useState("");
  const [aiKeySet, setAiKeySet] = useState(false);
  const [isSavingAI, setIsSavingAI] = useState(false);

  const [storageConfigured, setStorageConfigured] = useState(false);
  const [storageEndpointUrl, setStorageEndpointUrl] = useState("");
  const [storageBucketName, setStorageBucketName] = useState("");
  const [storageRegion, setStorageRegion] = useState("");
  const [storageAccessKeyId, setStorageAccessKeyId] = useState("");
  const [storageSecretAccessKey, setStorageSecretAccessKey] = useState("");
  const [isSavingStorage, setIsSavingStorage] = useState(false);

  const [bannedIPs, setBannedIPs] = useState<BannedIPItem[]>([]);
  const [unbanTarget, setUnbanTarget] = useState<BannedIPItem | null>(null);
  const [isUnbanning, setIsUnbanning] = useState(false);

  const [captchaConfigured, setCaptchaConfigured] = useState(false);
  const [captchaSiteKey, setCaptchaSiteKey] = useState("");
  const [captchaSecretKey, setCaptchaSecretKey] = useState("");
  const [isSavingCaptcha, setIsSavingCaptcha] = useState(false);

  const [smtpConfigured, setSmtpConfigured] = useState(false);
  const [smtpHost, setSmtpHost] = useState("");
  const [smtpPort, setSmtpPort] = useState("587");
  const [smtpUsername, setSmtpUsername] = useState("");
  const [smtpPassword, setSmtpPassword] = useState("");
  const [smtpFromEmail, setSmtpFromEmail] = useState("");
  const [smtpFromName, setSmtpFromName] = useState("");
  const [isSavingSmtp, setIsSavingSmtp] = useState(false);

  const isAdmin = !!user?.role && ADMIN_ROLES.includes(user.role);
  const canExportOwnData = !!user?.role && TEAM_LEADERSHIP_ROLES.includes(user.role);
  const [isExportingData, setIsExportingData] = useState(false);

  const [isExportingBackup, setIsExportingBackup] = useState(false);
  const [isImportingBackup, setIsImportingBackup] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isAdmin) return;
    getAISettings()
      .then((s) => {
        setAiProvider(s.provider);
        setAiModel(s.model);
        setAiKeySet(s.api_key_set);
      })
      .catch(() => {
        /* σιωπηλή αποτυχία — η κάρτα δείχνει τα defaults */
      });
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    getStorageSettings()
      .then((s) => {
        setStorageConfigured(s.configured);
        setStorageEndpointUrl(s.endpoint_url || "");
        setStorageBucketName(s.bucket_name || "");
        setStorageRegion(s.region || "");
      })
      .catch(() => {
        /* σιωπηλή αποτυχία — η κάρτα δείχνει τα defaults */
      });
  }, [isAdmin]);

  async function loadBannedIPs() {
    try {
      const ips = await listBannedIPs();
      setBannedIPs(ips);
    } catch {
      /* σιωπηλή αποτυχία */
    }
  }

  useEffect(() => {
    if (!isAdmin) return;
    loadBannedIPs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    getCaptchaSettings()
      .then((cfg) => {
        setCaptchaConfigured(cfg.configured);
        setCaptchaSiteKey(cfg.site_key || "");
      })
      .catch(() => {
        /* σιωπηλή αποτυχία — η κάρτα δείχνει τα defaults */
      });
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    getSMTPSettings()
      .then((cfg) => {
        setSmtpConfigured(cfg.configured);
        setSmtpHost(cfg.host || "");
        setSmtpPort(cfg.port || "587");
        setSmtpUsername(cfg.username || "");
        setSmtpFromEmail(cfg.from_email || "");
        setSmtpFromName(cfg.from_name || "");
      })
      .catch(() => {
        /* σιωπηλή αποτυχία — η κάρτα δείχνει τα defaults */
      });
  }, [isAdmin]);

  async function handleExportBackup() {
    setIsExportingBackup(true);
    try {
      await downloadBackup();
      toast.show(t("settings.backupDownloaded"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExportingBackup(false);
    }
  }

  async function handleExportMyData() {
    setIsExportingData(true);
    try {
      await downloadMyDataExport();
      toast.show(t("settings.exportDownloaded"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExportingData(false);
    }
  }

  function handlePickRestoreFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      setPendingFile(file);
      setShowRestoreConfirm(true);
    }
  }

  async function handleConfirmRestore() {
    if (!pendingFile) return;
    setIsImportingBackup(true);
    try {
      const res = await uploadBackup(pendingFile);
      toast.show(res.message, "success");
      setShowRestoreConfirm(false);
      setPendingFile(null);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsImportingBackup(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleProfileSubmit(e: FormEvent) {
    e.preventDefault();
    setIsSavingProfile(true);
    try {
      const updated = await updateMe({ full_name: fullName, email });
      updateUser(updated);
      toast.show(t("settings.profileUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingProfile(false);
    }
  }

  async function handlePasswordSubmit(e: FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.show(t("profile.passwordsDontMatch"), "error");
      return;
    }
    if (newPassword.length < 8) {
      toast.show(t("profile.passwordTooShort"), "error");
      return;
    }
    setIsSavingPassword(true);
    try {
      await changePassword(currentPassword, newPassword);
      toast.show(t("profile.passwordChangedSuccess"), "success");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingPassword(false);
    }
  }

  async function handleAISubmit(e: FormEvent) {
    e.preventDefault();
    setIsSavingAI(true);
    try {
      const updated = await updateAISettings({
        provider: aiProvider,
        model: aiModel,
        api_key: aiApiKey || undefined,
      });
      setAiKeySet(updated.api_key_set);
      setAiApiKey("");
      toast.show(t("settings.aiSettingsSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingAI(false);
    }
  }

  async function handleStorageSubmit(e: FormEvent) {
    e.preventDefault();
    setIsSavingStorage(true);
    try {
      const updated = await updateStorageSettings({
        endpoint_url: storageEndpointUrl,
        bucket_name: storageBucketName,
        region: storageRegion,
        access_key_id: storageAccessKeyId || undefined,
        secret_access_key: storageSecretAccessKey || undefined,
      });
      setStorageConfigured(updated.configured);
      setStorageAccessKeyId("");
      setStorageSecretAccessKey("");
      toast.show(t("settings.storageSettingsSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingStorage(false);
    }
  }

  async function handleUnban() {
    if (!unbanTarget) return;
    setIsUnbanning(true);
    try {
      await unbanIP(unbanTarget.ip_address);
      toast.show(t("settings.unbanSuccess"), "success");
      setUnbanTarget(null);
      loadBannedIPs();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUnbanning(false);
    }
  }

  async function handleCaptchaSubmit(e: FormEvent) {
    e.preventDefault();
    setIsSavingCaptcha(true);
    try {
      const updated = await updateCaptchaSettings({
        site_key: captchaSiteKey,
        secret_key: captchaSecretKey || undefined,
      });
      setCaptchaConfigured(updated.configured);
      setCaptchaSecretKey("");
      toast.show(t("settings.captchaSettingsSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingCaptcha(false);
    }
  }

  async function handleSmtpSubmit(e: FormEvent) {
    e.preventDefault();
    setIsSavingSmtp(true);
    try {
      const updated = await updateSMTPSettings({
        host: smtpHost,
        port: smtpPort,
        username: smtpUsername,
        password: smtpPassword || undefined,
        from_email: smtpFromEmail,
        from_name: smtpFromName,
      });
      setSmtpConfigured(updated.configured);
      setSmtpPassword("");
      toast.show(t("settings.smtpSettingsSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingSmtp(false);
    }
  }

  return (
    <AppLayout title={t("settings.title")}>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card corners className="p-5">
          <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("settings.account")}
          </h3>
          <div className="mb-4 space-y-1 border-b border-line pb-4 text-sm">
            <div className="flex justify-between">
              <span className="text-text-muted">Username</span>
              <span className="font-mono text-text-primary">{user?.username}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-muted">{t("settings.role")}</span>
              <span className="text-text-primary">{user?.role ? ROLE_LABELS[user.role] : "—"}</span>
            </div>
          </div>

          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("settings.profile")}
          </h3>
          <form onSubmit={handleProfileSubmit} className="space-y-4">
            <Input label={t("settings.fullName")} value={fullName} onChange={(e) => setFullName(e.target.value)} />
            <Input
              label="Email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <div className="flex justify-end">
              <Button type="submit" isLoading={isSavingProfile}>
                {t("settings.saveProfile")}
              </Button>
            </div>
          </form>
        </Card>

        <Card corners className="p-5">
          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.changePasswordHeading")}
          </h3>
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <Input
              label={t("profile.currentPassword")}
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
            <Input
              label={t("profile.newPassword")}
              type="password"
              required
              minLength={8}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              hint={t("settings.atLeast8Chars")}
            />
            <Input
              label={t("auth.confirmNewPassword")}
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            <div className="flex justify-end">
              <Button type="submit" isLoading={isSavingPassword}>
                {t("profile.changePasswordHeading")}
              </Button>
            </div>
          </form>
        </Card>

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <div className="mb-1 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                AI Configuration
              </h3>
              <span
                className={`text-xs ${aiKeySet ? "text-status-fit" : "text-status-doubtful"}`}
              >
                {aiKeySet ? t("settings.aiConfigured") : t("settings.aiNotConfigured")}
              </span>
            </div>
            <p className="mb-4 text-xs text-text-muted">
              {t("settings.aiIntroPart1")}{" "}
              <a
                href="https://console.anthropic.com/"
              target="_blank"
              rel="noreferrer"
              className="text-chalk hover:underline"
            >
              Anthropic
            </a>{" "}
            {t("settings.aiIntroOr")}{" "}
            <a
              href="https://platform.openai.com/api-keys"
              target="_blank"
              rel="noreferrer"
              className="text-chalk hover:underline"
            >
              OpenAI
            </a>
            {t("settings.aiIntroPart2")}
          </p>
          <form onSubmit={handleAISubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Select label="Provider" value={aiProvider} onChange={(e) => setAiProvider(e.target.value)}>
              <option value="anthropic">Anthropic</option>
              <option value="openai">OpenAI</option>
            </Select>
            <Input
              label="Model"
              value={aiModel}
              onChange={(e) => setAiModel(e.target.value)}
              placeholder="claude-sonnet-4-6"
            />
            <Input
              label="API Key"
              type="password"
              value={aiApiKey}
              onChange={(e) => setAiApiKey(e.target.value)}
              placeholder={aiKeySet ? `••••••••••••••••${t("settings.keyConfiguredSuffix")}` : "sk-..."}
            />
            <div className="sm:col-span-3 flex justify-end">
              <Button type="submit" isLoading={isSavingAI}>
                {t("settings.saveAISettings")}
              </Button>
            </div>
          </form>
          </Card>
        )}

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <div className="mb-1 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("settings.storageConfigTitle")}
              </h3>
              <span className={`text-xs ${storageConfigured ? "text-status-fit" : "text-status-doubtful"}`}>
                {storageConfigured ? t("settings.storageConfigured") : t("settings.storageNotConfigured")}
              </span>
            </div>
            <p className="mb-4 text-xs text-text-muted">{t("settings.storageIntro")}</p>
            <form onSubmit={handleStorageSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Input
                label={t("settings.storageEndpointUrl")}
                value={storageEndpointUrl}
                onChange={(e) => setStorageEndpointUrl(e.target.value)}
                placeholder="https://xxxx.r2.cloudflarestorage.com"
              />
              <Input
                label={t("settings.storageBucketName")}
                value={storageBucketName}
                onChange={(e) => setStorageBucketName(e.target.value)}
                placeholder="football-hub-videos"
              />
              <Input
                label={t("settings.storageRegion")}
                value={storageRegion}
                onChange={(e) => setStorageRegion(e.target.value)}
                placeholder="auto"
              />
              <Input
                label={t("settings.storageAccessKeyId")}
                type="password"
                value={storageAccessKeyId}
                onChange={(e) => setStorageAccessKeyId(e.target.value)}
                placeholder={storageConfigured ? `••••••••••••••••${t("settings.keyConfiguredSuffix")}` : ""}
              />
              <Input
                label={t("settings.storageSecretAccessKey")}
                type="password"
                value={storageSecretAccessKey}
                onChange={(e) => setStorageSecretAccessKey(e.target.value)}
                placeholder={storageConfigured ? `••••••••••••••••${t("settings.keyConfiguredSuffix")}` : ""}
              />
              <div className="flex items-end justify-end">
                <Button type="submit" isLoading={isSavingStorage}>
                  {t("settings.saveStorageSettings")}
                </Button>
              </div>
            </form>
          </Card>
        )}

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("settings.securityConfigTitle")}
            </h3>
            <p className="mb-4 text-xs text-text-muted">{t("settings.securityIntro")}</p>
            {bannedIPs.length === 0 ? (
              <p className="text-xs text-text-muted">{t("settings.noBannedIPs")}</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-line text-xs uppercase tracking-wide text-text-muted">
                      <th className="pb-2 pr-3">{t("settings.bannedIPColumn")}</th>
                      <th className="pb-2 pr-3">{t("settings.reasonColumn")}</th>
                      <th className="pb-2 pr-3">{t("settings.bannedAtColumn")}</th>
                      <th className="pb-2 pr-3">{t("settings.durationColumn")}</th>
                      <th className="pb-2"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {bannedIPs.map((b) => (
                      <tr key={b.id} className="border-b border-line last:border-0">
                        <td className="py-2 pr-3 font-mono text-xs text-text-primary">{b.ip_address}</td>
                        <td className="py-2 pr-3 text-xs text-text-muted">{b.reason}</td>
                        <td className="py-2 pr-3 text-xs text-text-muted">
                          {new Date(b.banned_at).toLocaleString("el-GR")}
                        </td>
                        <td className="py-2 pr-3 text-xs text-text-muted">
                          {b.is_permanent
                            ? t("settings.permanentLabel")
                            : b.banned_until
                              ? new Date(b.banned_until).toLocaleString("el-GR")
                              : "—"}
                        </td>
                        <td className="py-2 text-right">
                          <button
                            onClick={() => setUnbanTarget(b)}
                            className="text-xs text-chalk hover:underline"
                          >
                            {t("settings.unbanButton")}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <div className="mb-1 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("settings.captchaConfigTitle")}
              </h3>
              <span className={`text-xs ${captchaConfigured ? "text-status-fit" : "text-status-doubtful"}`}>
                {captchaConfigured ? t("settings.captchaConfigured") : t("settings.captchaNotConfigured")}
              </span>
            </div>
            <p className="mb-4 text-xs text-text-muted">{t("settings.captchaIntro")}</p>
            <form onSubmit={handleCaptchaSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Input
                label={t("settings.captchaSiteKey")}
                value={captchaSiteKey}
                onChange={(e) => setCaptchaSiteKey(e.target.value)}
              />
              <Input
                label={t("settings.captchaSecretKey")}
                type="password"
                value={captchaSecretKey}
                onChange={(e) => setCaptchaSecretKey(e.target.value)}
                placeholder={captchaConfigured ? `••••••••••••••••${t("settings.keyConfiguredSuffix")}` : ""}
              />
              <div className="flex items-end justify-end">
                <Button type="submit" isLoading={isSavingCaptcha}>
                  {t("settings.saveCaptchaSettings")}
                </Button>
              </div>
            </form>
          </Card>
        )}

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <div className="mb-1 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("settings.smtpConfigTitle")}
              </h3>
              <span className={`text-xs ${smtpConfigured ? "text-status-fit" : "text-status-doubtful"}`}>
                {smtpConfigured ? t("settings.smtpConfigured") : t("settings.smtpNotConfigured")}
              </span>
            </div>
            <p className="mb-4 text-xs text-text-muted">{t("settings.smtpIntro")}</p>
            <form onSubmit={handleSmtpSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Input
                label={t("settings.smtpHost")}
                value={smtpHost}
                onChange={(e) => setSmtpHost(e.target.value)}
                placeholder="smtp.gmail.com"
              />
              <Input
                label={t("settings.smtpPort")}
                value={smtpPort}
                onChange={(e) => setSmtpPort(e.target.value)}
                placeholder="587"
              />
              <Input
                label={t("settings.smtpUsername")}
                value={smtpUsername}
                onChange={(e) => setSmtpUsername(e.target.value)}
                placeholder="you@gmail.com"
              />
              <Input
                label={t("settings.smtpPassword")}
                type="password"
                value={smtpPassword}
                onChange={(e) => setSmtpPassword(e.target.value)}
                placeholder={smtpConfigured ? `••••••••••••••••${t("settings.keyConfiguredSuffix")}` : ""}
              />
              <Input
                label={t("settings.smtpFromEmail")}
                value={smtpFromEmail}
                onChange={(e) => setSmtpFromEmail(e.target.value)}
                placeholder="you@gmail.com"
              />
              <Input
                label={t("settings.smtpFromName")}
                value={smtpFromName}
                onChange={(e) => setSmtpFromName(e.target.value)}
                placeholder="FootballHub"
              />
              <div className="flex items-end justify-end sm:col-span-3">
                <Button type="submit" isLoading={isSavingSmtp}>
                  {t("settings.saveSmtpSettings")}
                </Button>
              </div>
            </form>
          </Card>
        )}


        {canExportOwnData && (
          <Card corners className="p-5 lg:col-span-2">
            <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("settings.exportData")}
            </h3>
            <p className="mb-4 text-xs text-text-muted">
              {t("settings.exportDataIntro")}
            </p>
            <Button variant="secondary" onClick={handleExportMyData} isLoading={isExportingData}>
              {t("settings.exportMyTeamsData")}
            </Button>
          </Card>
        )}

        {isAdmin && (
          <Card corners className="p-5 lg:col-span-2">
            <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("settings.backupRestore")}
            </h3>
            <p className="mb-4 text-xs text-text-muted">
              {t("settings.backupRestoreIntro")}
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <Button variant="secondary" onClick={handleExportBackup} isLoading={isExportingBackup}>
                {t("settings.downloadBackup")}
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".db"
                className="hidden"
                onChange={handlePickRestoreFile}
              />
              <Button variant="danger" onClick={() => fileInputRef.current?.click()}>
                {t("settings.restoreFromBackup")}
              </Button>
            </div>
          </Card>
        )}
      </div>

      <ConfirmDialog
        isOpen={showRestoreConfirm}
        onClose={() => {
          setShowRestoreConfirm(false);
          setPendingFile(null);
          if (fileInputRef.current) fileInputRef.current.value = "";
        }}
        onConfirm={handleConfirmRestore}
        title={t("settings.restoreDbTitle")}
        message={`${t("settings.restoreConfirmPrefix")}${pendingFile?.name}${t("settings.restoreConfirmSuffix")}`}
        confirmLabel={t("settings.restore")}
        isLoading={isImportingBackup}
      />

      <ConfirmDialog
        isOpen={!!unbanTarget}
        onClose={() => setUnbanTarget(null)}
        onConfirm={handleUnban}
        title={t("settings.unbanConfirmTitle")}
        message={t("settings.unbanConfirmMessage")}
        isLoading={isUnbanning}
      />
    </AppLayout>
  );
}
