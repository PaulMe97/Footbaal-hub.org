import { useEffect, useState, type MouseEvent } from "react";
import { Link } from "react-router-dom";

import { extractErrorMessage } from "../api/client";
import {
  deleteNotification,
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
} from "../api/notifications";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { useToast } from "../components/ui/Toast";
import type { AppNotification } from "../types";
import { NOTIFICATION_COLORS, NOTIFICATION_ICONS, URGENT_NOTIFICATION_TYPES } from "../types";
import { notificationLink } from "../utils/notificationLink";
import { useLanguage } from "../context/LanguageContext";

export default function Notifications() {
  const toast = useToast();
  const { t } = useLanguage();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listNotifications(unreadOnly);
      setNotifications(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unreadOnly]);

  async function handleMarkRead(n: AppNotification) {
    if (n.is_read) return;
    try {
      await markNotificationRead(n.id);
      setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, is_read: true } : x)));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleMarkAllRead() {
    try {
      await markAllNotificationsRead();
      toast.show(t("notifications.allReadSuccess"), "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleDelete(id: string, e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    try {
      await deleteNotification(id);
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <AppLayout title={t("notificationBell.title")}>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <button
          onClick={() => setUnreadOnly(false)}
          className={`rounded-md border px-3 py-1.5 text-sm ${
            !unreadOnly ? "border-chalk text-chalk" : "border-line text-text-muted"
          }`}
        >
          {t("notificationBell.all")}
        </button>
        <button
          onClick={() => setUnreadOnly(true)}
          className={`rounded-md border px-3 py-1.5 text-sm ${
            unreadOnly ? "border-chalk text-chalk" : "border-line text-text-muted"
          }`}
        >
          {t("notifications.unreadOnly")}
        </button>
        {unreadOnly && !isLoading && (
          <span className="text-xs text-text-muted">{notifications.length}{t("notifications.unreadCountSuffix")}</span>
        )}
        <Button variant="secondary" onClick={handleMarkAllRead} className="ml-auto">
          {t("notifications.markAllRead")}
        </Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : notifications.length === 0 ? (
        <EmptyState
          title={t("notifications.noNotificationsTitle")}
          description={t("notifications.noNotificationsDescription")}
        />
      ) : (
        <Card>
          <div className="divide-y divide-line">
            {notifications.map((n) => {
              const link = notificationLink(n);
              const isUrgent = URGENT_NOTIFICATION_TYPES.includes(n.type);
              const content = (
                <div
                  className={`flex items-start gap-3 px-4 py-3 text-sm ${!n.is_read ? "bg-surface-raised/40" : ""}`}
                >
                  <span className={`mt-0.5 text-lg ${NOTIFICATION_COLORS[n.type]}`}>
                    {NOTIFICATION_ICONS[n.type]}
                  </span>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      {isUrgent && (
                        <span className="rounded-full border border-status-injured/40 bg-status-injured/15 px-1.5 py-px text-[10px] font-semibold uppercase text-status-injured">
                          Urgent
                        </span>
                      )}
                      <p className={n.is_read ? "text-text-muted" : "text-text-primary font-medium"}>
                        {n.title}
                      </p>
                    </div>
                    {n.message && <p className="text-xs text-text-muted">{n.message}</p>}
                    <p className="mt-1 text-[11px] text-text-muted">
                      {new Date(n.created_at).toLocaleString("el-GR")}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {!n.is_read && <span className="h-2 w-2 rounded-full bg-chalk" />}
                    <button
                      onClick={(e) => handleDelete(n.id, e)}
                      className="text-xs text-status-injured hover:underline"
                    >
                      {t("common.delete")}
                    </button>
                  </div>
                </div>
              );
              return link ? (
                <Link key={n.id} to={link} onClick={() => handleMarkRead(n)} className="block hover:bg-surface-raised">
                  {content}
                </Link>
              ) : (
                <div key={n.id} onClick={() => handleMarkRead(n)} className="cursor-pointer hover:bg-surface-raised">
                  {content}
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </AppLayout>
  );
}
