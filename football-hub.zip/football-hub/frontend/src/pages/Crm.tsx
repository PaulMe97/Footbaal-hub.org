import { useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { extractErrorMessage, mediaUrl } from "../api/client";
import { createCrmTopic, getCrmStats, listCrmContacts, listCrmTeams, listCrmTopics } from "../api/crm";
import type { CrmContact, CrmStats, CrmTeamOption, CrmTopic } from "../api/crm";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";
import { normalizePhone, viberChatLink } from "../utils/academyMessages";
import { CrmTopicModal } from "./crm/CrmTopicModal";

const PIE_COLORS = ["#D8FF5C", "#3E7D52", "#E0A83E", "#C0392B", "#6B7280"];

function PriorityBadge({ priority, labels }: { priority: string; labels: Record<string, string> }) {
  const cls =
    priority === "urgent"
      ? "border-status-injured/40 bg-status-injured/10 text-status-injured"
      : priority === "low"
        ? "border-line text-text-muted"
        : "border-status-fit/40 bg-status-fit/10 text-status-fit";
  return <span className={`rounded-full border px-2 py-0.5 text-[11px] ${cls}`}>{labels[priority]}</span>;
}

function StatusBadge({ status, labels }: { status: string; labels: Record<string, string> }) {
  const cls =
    status === "resolved"
      ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
      : status === "in_progress"
        ? "border-status-doubtful/40 bg-status-doubtful/10 text-status-doubtful"
        : "border-line text-text-muted";
  return <span className={`rounded-full border px-2 py-0.5 text-[11px] ${cls}`}>{labels[status]}</span>;
}

export default function Crm() {
  const toast = useToast();
  const { t } = useLanguage();
  const CATEGORY_LABELS: Record<string, string> = {
    general: t("crm.categoryGeneral"),
    stadium: t("crm.categoryStadium"),
    parents: t("crm.categoryParents"),
    event: t("crm.categoryEvent"),
    other: t("crm.categoryOther"),
  };
  const PRIORITY_LABELS: Record<string, string> = {
    urgent: t("crm.priorityUrgent"),
    normal: t("crm.priorityNormal"),
    low: t("crm.priorityLow"),
  };
  const STATUS_LABELS: Record<string, string> = {
    open: t("crm.statusOpen"),
    in_progress: t("crm.statusInProgress"),
    resolved: t("crm.statusResolved"),
  };
  const ROLE_LABELS: Record<string, string> = {
    super_admin: t("crm.roleSuperAdmin"),
    admin: t("crm.roleAdmin"),
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
  };
  const [tab, setTab] = useState<"overview" | "contacts" | "topics">("overview");

  const [stats, setStats] = useState<CrmStats | null>(null);
  const [contacts, setContacts] = useState<CrmContact[]>([]);
  const [topics, setTopics] = useState<CrmTopic[]>([]);
  const [teams, setTeams] = useState<CrmTeamOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [filterTeam, setFilterTeam] = useState("");
  const [filterCategory, setFilterCategory] = useState("");
  const [filterPriority, setFilterPriority] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);

  const [showCreate, setShowCreate] = useState(false);
  const [newTeamId, setNewTeamId] = useState("");
  const [newTitle, setNewTitle] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newCategory, setNewCategory] = useState("general");
  const [newPriority, setNewPriority] = useState("normal");
  const [newExpiresAt, setNewExpiresAt] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  async function loadAll() {
    setIsLoading(true);
    try {
      const [s, c, topicsData, teamOptions] = await Promise.all([
        getCrmStats(),
        listCrmContacts(),
        listCrmTopics(),
        listCrmTeams(),
      ]);
      setStats(s);
      setContacts(c);
      setTopics(topicsData);
      setTeams(teamOptions);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadTopics() {
    try {
      const topicsData = await listCrmTopics({
        team_id: filterTeam || undefined,
        category: filterCategory || undefined,
        priority: filterPriority || undefined,
        status: filterStatus || undefined,
      });
      setTopics(topicsData);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  useEffect(() => {
    if (tab === "topics") loadTopics();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterTeam, filterCategory, filterPriority, filterStatus, tab]);

  async function handleCreateTopic() {
    if (!newTeamId || !newTitle) return;
    setIsCreating(true);
    try {
      await createCrmTopic({
        team_id: newTeamId,
        title: newTitle,
        description: newDescription || undefined,
        category: newCategory,
        priority: newPriority,
        expires_at: newExpiresAt || undefined,
      });
      toast.show(t("crm.topicCreated"), "success");
      setShowCreate(false);
      setNewTitle("");
      setNewDescription("");
      setNewCategory("general");
      setNewPriority("normal");
      setNewExpiresAt("");
      loadTopics();
      loadAll();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsCreating(false);
    }
  }

  const categoryChartData = useMemo(
    () =>
      Object.entries(stats?.by_category || {}).map(([key, value]) => ({
        name: CATEGORY_LABELS[key] || key,
        value,
      })),
    [stats]
  );
  const priorityChartData = useMemo(
    () =>
      Object.entries(stats?.by_priority || {}).map(([key, value]) => ({
        name: PRIORITY_LABELS[key] || key,
        value,
      })),
    [stats]
  );

  return (
    <AppLayout title="CRM">
      <p className="mb-4 text-sm text-text-muted">{t("crm.introText")}</p>

      <div className="mb-5 flex gap-2 border-b border-line">
        {(
          [
            { key: "overview", label: t("crm.tabOverview") },
            { key: "contacts", label: t("crm.tabContacts") },
            { key: "topics", label: t("crm.tabTopics") },
          ] as const
        ).map((tabDef) => (
          <button
            key={tabDef.key}
            onClick={() => setTab(tabDef.key)}
            className={`border-b-2 px-3 py-2 text-sm ${
              tab === tabDef.key ? "border-chalk text-chalk" : "border-transparent text-text-muted hover:text-text-primary"
            }`}
          >
            {tabDef.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <Spinner />
      ) : tab === "overview" ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Card className="p-4 text-center">
              <p className="font-display text-2xl text-text-primary">{stats?.total_topics ?? 0}</p>
              <p className="text-[11px] uppercase text-text-muted">{t("crm.totalTopics")}</p>
            </Card>
            <Card className="p-4 text-center">
              <p
                className={`font-display text-2xl ${
                  (stats?.urgent_open_count ?? 0) > 0 ? "text-status-injured" : "text-text-primary"
                }`}
              >
                {stats?.urgent_open_count ?? 0}
              </p>
              <p className="text-[11px] uppercase text-text-muted">{t("crm.urgentOpen")}</p>
            </Card>
            <Card className="p-4 text-center">
              <p
                className={`font-display text-2xl ${
                  (stats?.expired_count ?? 0) > 0 ? "text-status-doubtful" : "text-text-primary"
                }`}
              >
                {stats?.expired_count ?? 0}
              </p>
              <p className="text-[11px] uppercase text-text-muted">{t("crm.expired")}</p>
            </Card>
            <Card className="p-4 text-center">
              <p className="font-display text-2xl text-status-fit">{stats?.resolved_this_month ?? 0}</p>
              <p className="text-[11px] uppercase text-text-muted">{t("crm.resolvedThisMonth")}</p>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("crm.topicsByCategory")}
              </h3>
              {categoryChartData.length === 0 ? (
                <p className="text-sm text-text-muted">{t("crm.noTopicsYet")}</p>
              ) : (
                <div style={{ width: "100%", height: 220 }}>
                  <ResponsiveContainer>
                    <PieChart>
                      <Pie data={categoryChartData} dataKey="value" nameKey="name" outerRadius={80} label>
                        {categoryChartData.map((_, idx) => (
                          <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          background: "rgb(var(--color-surface-raised))",
                          border: "1px solid rgb(var(--color-line))",
                          borderRadius: 8,
                          fontSize: 12,
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("crm.topicsByPriority")}
              </h3>
              {priorityChartData.length === 0 ? (
                <p className="text-sm text-text-muted">{t("crm.noTopicsYet")}</p>
              ) : (
                <div style={{ width: "100%", height: 220 }}>
                  <ResponsiveContainer>
                    <BarChart data={priorityChartData} margin={{ top: 8, right: 8, left: -20, bottom: 8 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--color-line))" />
                      <XAxis dataKey="name" tick={{ fontSize: 11, fill: "rgb(var(--color-text-muted))" }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "rgb(var(--color-text-muted))" }} />
                      <Tooltip
                        contentStyle={{
                          background: "rgb(var(--color-surface-raised))",
                          border: "1px solid rgb(var(--color-line))",
                          borderRadius: 8,
                          fontSize: 12,
                        }}
                      />
                      <Bar dataKey="value" fill="rgb(var(--color-chalk))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
          </div>

          {topics.filter((topic) => topic.priority === "urgent" && topic.status !== "resolved").length > 0 && (
            <Card corners>
              <div className="border-b border-line px-4 py-3">
                <h3 className="font-display text-sm uppercase tracking-wide text-status-injured">
                  {t("crm.urgentTopicsHeading")}
                </h3>
              </div>
              <div className="divide-y divide-line">
                {topics
                  .filter((topic) => topic.priority === "urgent" && topic.status !== "resolved")
                  .map((topic) => (
                    <button
                      key={topic.id}
                      onClick={() => setSelectedTopicId(topic.id)}
                      className="flex w-full items-center justify-between px-4 py-3 text-left hover:bg-surface-raised"
                    >
                      <div>
                        <p className="text-sm text-text-primary">{topic.title}</p>
                        <p className="text-xs text-text-muted">{topic.team_name}</p>
                      </div>
                      <StatusBadge status={topic.status} labels={STATUS_LABELS} />
                    </button>
                  ))}
              </div>
            </Card>
          )}
        </div>
      ) : tab === "contacts" ? (
        contacts.length === 0 ? (
          <EmptyState title={t("crm.noContactsYet")} description={t("crm.staffWillShowHere")} />
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {contacts.map((c) => (
              <Card key={c.user_id} className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm text-text-muted">
                    {c.avatar_path ? (
                      <img src={mediaUrl(c.avatar_path)} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (c.full_name || c.username).charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm text-text-primary">{c.full_name || c.username}</p>
                    <p className="truncate text-xs text-text-muted">
                      {ROLE_LABELS[c.role] || c.role} · {c.teams.join(", ")}
                    </p>
                  </div>
                </div>
                <div className="mt-3 space-y-1.5 border-t border-line pt-3 text-xs">
                  <a href={`mailto:${c.email}`} className="block text-chalk hover:underline">
                    ✉ {c.email}
                  </a>
                  {c.phone && (
                    <div className="flex items-center justify-between">
                      <a href={`tel:${normalizePhone(c.phone)}`} className="text-chalk hover:underline">
                        📞 {normalizePhone(c.phone)}
                      </a>
                      <a href={viberChatLink(c.phone)} className="text-chalk hover:underline">
                        📱 Viber
                      </a>
                    </div>
                  )}
                  {!c.phone && <p className="text-text-muted">{t("crm.noPhoneOnFile")}</p>}
                </div>
              </Card>
            ))}
          </div>
        )
      ) : (
        <div>
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div className="flex flex-wrap gap-2">
              <Select value={filterTeam} onChange={(e) => setFilterTeam(e.target.value)}>
                <option value="">{t("crm.allTeams")}</option>
                {teams.map((teamOpt) => (
                  <option key={teamOpt.id} value={teamOpt.id}>
                    {teamOpt.name}
                  </option>
                ))}
              </Select>
              <Select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
                <option value="">{t("crm.allCategories")}</option>
                {Object.entries(CATEGORY_LABELS).map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </Select>
              <Select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)}>
                <option value="">{t("crm.everyPriority")}</option>
                {Object.entries(PRIORITY_LABELS).map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </Select>
              <Select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                <option value="">{t("crm.everyStatus")}</option>
                {Object.entries(STATUS_LABELS).map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </Select>
            </div>
            <Button onClick={() => setShowCreate(true)}>+ {t("crm.newTopic")}</Button>
          </div>

          {topics.length === 0 ? (
            <EmptyState
              title={t("crm.noTopics")}
              description={t("crm.noTopicsDescription")}
            />
          ) : (
            <Card corners>
              <div className="divide-y divide-line">
                {topics.map((topic) => (
                  <button
                    key={topic.id}
                    onClick={() => setSelectedTopicId(topic.id)}
                    className="flex w-full flex-wrap items-center justify-between gap-2 px-4 py-3 text-left hover:bg-surface-raised"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-text-primary">{topic.title}</p>
                      <p className="truncate text-xs text-text-muted">
                        {topic.team_name} · {CATEGORY_LABELS[topic.category] || topic.category} · {topic.created_by_name}
                        {topic.comment_count > 0 ? ` · 💬 ${topic.comment_count}` : ""}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      {topic.is_expired && (
                        <span className="rounded-full border border-status-injured/40 bg-status-injured/10 px-2 py-0.5 text-[11px] text-status-injured">
                          {t("crm.expiredBadge")}
                        </span>
                      )}
                      <PriorityBadge priority={topic.priority} labels={PRIORITY_LABELS} />
                      <StatusBadge status={topic.status} labels={STATUS_LABELS} />
                    </div>
                  </button>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}

      <CrmTopicModal
        topicId={selectedTopicId}
        onClose={() => setSelectedTopicId(null)}
        onChanged={() => {
          loadTopics();
          loadAll();
        }}
      />

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("crm.newTopic")}>
        <div className="space-y-4">
          <Select label={t("crm.team")} value={newTeamId} onChange={(e) => setNewTeamId(e.target.value)}>
            <option value="">{t("crm.selectTeam")}</option>
            {teams.map((teamOpt) => (
              <option key={teamOpt.id} value={teamOpt.id}>
                {teamOpt.name}
              </option>
            ))}
          </Select>
          <Input label={t("crm.titleLabel")} value={newTitle} onChange={(e) => setNewTitle(e.target.value)} />
          <Textarea
            label={t("crm.descriptionOptional")}
            value={newDescription}
            onChange={(e) => setNewDescription(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-3">
            <Select label={t("crm.category")} value={newCategory} onChange={(e) => setNewCategory(e.target.value)}>
              {Object.entries(CATEGORY_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
            <Select label={t("crm.priority")} value={newPriority} onChange={(e) => setNewPriority(e.target.value)}>
              {Object.entries(PRIORITY_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </div>
          <Input
            label={t("crm.expiresOnOptional")}
            type="datetime-local"
            value={newExpiresAt}
            onChange={(e) => setNewExpiresAt(e.target.value)}
          />
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              onClick={handleCreateTopic}
              isLoading={isCreating}
              disabled={!newTeamId || !newTitle}
            >
              {t("common.create")}
            </Button>
          </div>
        </div>
      </Modal>
    </AppLayout>
  );
}
