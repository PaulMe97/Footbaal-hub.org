import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";

import { extractErrorMessage, mediaUrl } from "../api/client";
import { getMessages, listConversations, sendMessage, startConversation } from "../api/messages";
import type { ConversationItem, MessageItem } from "../api/messages";
import {
  createGroupConversation,
  getGroupMessages,
  getOrCreateTeamGroupChat,
  listGroupConversations,
  sendGroupMessage,
} from "../api/groupMessages";
import type { GroupConversationItem, GroupMessageItem } from "../api/groupMessages";
import { listTeams } from "../api/teams";
import type { Team } from "../types";
import { AppLayout } from "../components/layout/AppLayout";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { NewConversationModal } from "./messages/NewConversationModal";

function timeAgo(iso?: string | null): string {
  if (!iso) return "";
  return new Date(iso).toLocaleString("el-GR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

type UnifiedItem =
  | { kind: "direct"; id: string; data: ConversationItem }
  | { kind: "group"; id: string; data: GroupConversationItem };

export default function Messages() {
  const toast = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();

  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [groupConversations, setGroupConversations] = useState<GroupConversationItem[]>([]);
  const [myTeams, setMyTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selected, setSelected] = useState<UnifiedItem | null>(null);
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [groupMessages, setGroupMessages] = useState<GroupMessageItem[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [draft, setDraft] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [showNewConversation, setShowNewConversation] = useState(false);
  const [showTeamPicker, setShowTeamPicker] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function openDirect(conv: ConversationItem) {
    setSelected({ kind: "direct", id: conv.id, data: conv });
    setIsLoadingMessages(true);
    try {
      const data = await getMessages(conv.id);
      setMessages(data);
      setConversations((prev) => prev.map((c) => (c.id === conv.id ? { ...c, unread_count: 0 } : c)));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingMessages(false);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  }

  async function openGroup(conv: GroupConversationItem) {
    setSelected({ kind: "group", id: conv.id, data: conv });
    setIsLoadingMessages(true);
    try {
      const data = await getGroupMessages(conv.id);
      setGroupMessages(data);
      setGroupConversations((prev) => prev.map((c) => (c.id === conv.id ? { ...c, unread_count: 0 } : c)));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingMessages(false);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  }

  async function load() {
    setIsLoading(true);
    try {
      const [directData, groupData, teamsData] = await Promise.all([
        listConversations(),
        listGroupConversations(),
        listTeams(),
      ]);
      setConversations(directData);
      setGroupConversations(groupData);
      setMyTeams(teamsData);

      const targetId = searchParams.get("conversation_id");
      if (targetId) {
        const matchDirect = directData.find((c) => c.id === targetId);
        const matchGroup = groupData.find((c) => c.id === targetId);
        if (matchDirect) openDirect(matchDirect);
        else if (matchGroup) openGroup(matchGroup);
        setSearchParams((prev) => {
          const next = new URLSearchParams(prev);
          next.delete("conversation_id");
          return next;
        });
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    if (!selected || !draft.trim()) return;
    setIsSending(true);
    try {
      if (selected.kind === "direct") {
        const message = await sendMessage(selected.id, draft.trim());
        setMessages((prev) => [...prev, message]);
        setConversations((prev) =>
          prev.map((c) =>
            c.id === selected.id
              ? { ...c, last_message: message.content, last_message_at: message.created_at }
              : c
          )
        );
      } else {
        const message = await sendGroupMessage(selected.id, draft.trim());
        setGroupMessages((prev) => [...prev, message]);
        setGroupConversations((prev) =>
          prev.map((c) =>
            c.id === selected.id
              ? {
                  ...c,
                  last_message: message.content,
                  last_message_at: message.created_at,
                  last_message_sender_name: message.sender_name,
                }
              : c
          )
        );
      }
      setDraft("");
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSending(false);
    }
  }

  async function handleStartDirect(userId: string) {
    const conv = await startConversation(userId);
    setConversations((prev) => {
      const exists = prev.some((c) => c.id === conv.id);
      return exists ? prev.map((c) => (c.id === conv.id ? conv : c)) : [conv, ...prev];
    });
    openDirect(conv);
  }

  async function handleCreateGroup(userIds: string[], name?: string) {
    const conv = await createGroupConversation(userIds, name);
    setGroupConversations((prev) => [conv, ...prev]);
    openGroup(conv);
  }

  async function handleOpenTeamChat(teamId: string) {
    setShowTeamPicker(false);
    try {
      const conv = await getOrCreateTeamGroupChat(teamId);
      setGroupConversations((prev) => {
        const exists = prev.some((c) => c.id === conv.id);
        return exists ? prev.map((c) => (c.id === conv.id ? conv : c)) : [conv, ...prev];
      });
      openGroup(conv);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  const unifiedList: UnifiedItem[] = useMemo(() => {
    const direct: UnifiedItem[] = conversations.map((c) => ({ kind: "direct" as const, id: c.id, data: c }));
    const group: UnifiedItem[] = groupConversations.map((c) => ({ kind: "group" as const, id: c.id, data: c }));
    return [...direct, ...group].sort((a, b) => {
      const aTime = a.data.last_message_at || a.data.created_at;
      const bTime = b.data.last_message_at || b.data.created_at;
      return new Date(bTime).getTime() - new Date(aTime).getTime();
    });
  }, [conversations, groupConversations]);

  const hasAnyConversation = unifiedList.length > 0;

  return (
    <AppLayout title={t("messages.title")}>
      <div className="mb-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setShowNewConversation(true)}
          className="rounded-md bg-chalk px-3 py-1.5 text-xs font-semibold text-void"
        >
          + {t("messages.newConversationButton")}
        </button>
        {myTeams.length > 0 && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowTeamPicker((v) => !v)}
              className="rounded-md border border-line px-3 py-1.5 text-xs text-text-primary hover:border-chalk"
            >
              👥 {t("messages.teamChatButton")}
            </button>
            {showTeamPicker && (
              <div className="absolute left-0 z-20 mt-1 w-56 rounded-md border border-line bg-surface py-1 shadow-2xl">
                {myTeams.map((tm) => (
                  <button
                    key={tm.id}
                    type="button"
                    onClick={() => handleOpenTeamChat(tm.id)}
                    className="block w-full px-3 py-1.5 text-left text-xs text-text-primary hover:bg-surface-raised"
                  >
                    {tm.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {isLoading ? (
        <Spinner />
      ) : !hasAnyConversation ? (
        <EmptyState
          title={t("messages.noConversationsYet")}
          description={t("messages.noConversationsDescription")}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3" style={{ height: "calc(100vh - 230px)" }}>
          <Card className="overflow-y-auto lg:col-span-1">
            <div className="divide-y divide-line">
              {unifiedList.map((item) => {
                if (item.kind === "direct") {
                  const c = item.data;
                  return (
                    <button
                      key={`d-${c.id}`}
                      onClick={() => openDirect(c)}
                      className={`flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-surface-raised ${
                        selected?.kind === "direct" && selected.id === c.id ? "bg-surface-raised" : ""
                      }`}
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface font-display text-xs text-text-muted">
                        {c.other_user_avatar ? (
                          <img src={mediaUrl(c.other_user_avatar)} alt="" className="h-full w-full object-cover" />
                        ) : (
                          (c.other_user_name || "?").charAt(0).toUpperCase()
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <p className="truncate text-sm text-text-primary">{c.other_user_name || "—"}</p>
                          {c.unread_count > 0 && (
                            <span className="ml-2 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-chalk px-1 text-[10px] font-semibold text-void">
                              {c.unread_count}
                            </span>
                          )}
                        </div>
                        {c.context_label && <p className="truncate text-xs text-chalk">{c.context_label}</p>}
                        {c.last_message && <p className="truncate text-xs text-text-muted">{c.last_message}</p>}
                      </div>
                    </button>
                  );
                }
                const c = item.data;
                return (
                  <button
                    key={`g-${c.id}`}
                    onClick={() => openGroup(c)}
                    className={`flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-surface-raised ${
                      selected?.kind === "group" && selected.id === c.id ? "bg-surface-raised" : ""
                    }`}
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-chalk/50 bg-surface font-display text-xs text-chalk">
                      👥
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <p className="truncate text-sm text-text-primary">{c.name || "—"}</p>
                        {c.unread_count > 0 && (
                          <span className="ml-2 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-chalk px-1 text-[10px] font-semibold text-void">
                            {c.unread_count}
                          </span>
                        )}
                      </div>
                      {c.last_message && (
                        <p className="truncate text-xs text-text-muted">
                          {c.last_message_sender_name ? `${c.last_message_sender_name}: ` : ""}
                          {c.last_message}
                        </p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="flex flex-col lg:col-span-2">
            {!selected ? (
              <div className="flex flex-1 items-center justify-center text-sm text-text-muted">
                {t("messages.selectConversation")}
              </div>
            ) : (
              <>
                <div className="border-b border-line px-4 py-3">
                  {selected.kind === "direct" ? (
                    <>
                      <p className="text-sm text-text-primary">{selected.data.other_user_name}</p>
                      {selected.data.context_label && (
                        <p className="text-xs text-text-muted">{selected.data.context_label}</p>
                      )}
                    </>
                  ) : (
                    <>
                      <p className="text-sm text-text-primary">{selected.data.name}</p>
                      <p className="text-xs text-text-muted">
                        {selected.data.participants.length} {t("messages.participantsSuffix")}
                      </p>
                    </>
                  )}
                </div>
                <div className="flex-1 space-y-2 overflow-y-auto p-4">
                  {isLoadingMessages ? (
                    <Spinner />
                  ) : selected.kind === "direct" ? (
                    messages.map((m) => (
                      <div key={m.id} className={`flex ${m.sender_id === user?.id ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${
                            m.sender_id === user?.id ? "bg-chalk text-void" : "bg-surface-raised text-text-primary"
                          }`}
                        >
                          <p>{m.content}</p>
                          <p
                            className={`mt-1 text-[10px] ${
                              m.sender_id === user?.id ? "text-void/60" : "text-text-muted"
                            }`}
                          >
                            {timeAgo(m.created_at)}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    groupMessages.map((m) => (
                      <div key={m.id} className={`flex ${m.sender_id === user?.id ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${
                            m.sender_id === user?.id ? "bg-chalk text-void" : "bg-surface-raised text-text-primary"
                          }`}
                        >
                          {m.sender_id !== user?.id && (
                            <p className="mb-0.5 text-[11px] font-semibold text-chalk">{m.sender_name}</p>
                          )}
                          <p>{m.content}</p>
                          <p
                            className={`mt-1 text-[10px] ${
                              m.sender_id === user?.id ? "text-void/60" : "text-text-muted"
                            }`}
                          >
                            {timeAgo(m.created_at)}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={bottomRef} />
                </div>
                <form onSubmit={handleSend} className="flex gap-2 border-t border-line p-3">
                  <input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder={t("messages.messagePlaceholder")}
                    className="flex-1 rounded-md border border-line bg-surface px-3 py-2 text-sm text-text-primary focus:border-chalk focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={isSending || !draft.trim()}
                    className="rounded-md bg-chalk px-4 py-2 text-sm font-medium text-void disabled:opacity-50"
                  >
                    {t("messages.send")}
                  </button>
                </form>
              </>
            )}
          </Card>
        </div>
      )}

      <NewConversationModal
        isOpen={showNewConversation}
        onClose={() => setShowNewConversation(false)}
        onStartDirect={handleStartDirect}
        onCreateGroup={handleCreateGroup}
      />
    </AppLayout>
  );
}
