import { FormEvent, useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

import { extractErrorMessage } from "../../api/client";
import { listMatches } from "../../api/matches";
import { createTacticalBoard, deleteTacticalBoard, listTacticalBoards } from "../../api/tactical";
import { listTeams } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { TeamPickerGrid } from "../../components/TeamPickerGrid";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import { FORMATIONS, SCENARIO_TYPES } from "../../types";
import type { Match, Team, TacticalBoard } from "../../types";

export default function TacticalBoardsList() {
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const teamIdFilter = searchParams.get("team_id") || "";
  const navigate = useNavigate();
  const toast = useToast();

  const [boards, setBoards] = useState<TacticalBoard[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<TacticalBoard | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const [name, setName] = useState("");
  const [teamId, setTeamId] = useState("");
  const [matchId, setMatchId] = useState("");
  const [formation, setFormation] = useState<string>("4-4-2");
  const [scenarioType, setScenarioType] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  useEffect(() => {
    if (!teamId) {
      setMatches([]);
      return;
    }
    listMatches({ team_id: teamId }).catch(() => []).then((m) => setMatches(m || []));
  }, [teamId]);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listTacticalBoards({ team_id: teamIdFilter || undefined });
      setBoards(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamIdFilter]);

  function openCreate() {
    setName("");
    setTeamId(teamIdFilter || "");
    setMatchId("");
    setFormation("4-4-2");
    setScenarioType("");
    setNotes("");
    setShowCreate(true);
  }

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const board = await createTacticalBoard({
        name,
        team_id: teamId || null,
        match_id: matchId || null,
        formation,
        scenario_type: scenarioType || null,
        notes: notes || null,
      });
      toast.show(t("tactical.created"), "success");
      setShowCreate(false);
      navigate(`/tactical-board/${board.id}`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteTacticalBoard(deleteTarget.id);
      toast.show(t("tactical.deleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  const selectedTeam = teams.find((t) => t.id === teamIdFilter);

  return (
    <AppLayout title={t("tactical.title")}>
      {teamIdFilter && (
        <button
          onClick={() => setSearchParams({})}
          className="mb-3 text-xs text-chalk hover:underline"
        >
          {t("matches.backToTeams")}
        </button>
      )}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {teamIdFilter && selectedTeam ? (
          <h2 className="font-display text-lg text-text-primary">{selectedTeam.name}</h2>
        ) : (
          <div />
        )}
        <Button onClick={openCreate}>{t("tactical.newBoard")}</Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : !teamIdFilter ? (
        teams.length === 0 ? (
          <EmptyState
            title={t("matches.noTeamsYet")}
            description={t("tactical.noTeamsDescription")}
            action={
              <Link to="/teams">
                <Button>{t("matches.goToTeams")}</Button>
              </Link>
            }
          />
        ) : (
          <TeamPickerGrid teams={teams} onSelect={(id) => setSearchParams({ team_id: id })} />
        )
      ) : boards.length === 0 ? (
        <EmptyState
          title={t("tactical.noBoardsYet")}
          description={t("tactical.noBoardsDescription")}
          action={<Button onClick={openCreate}>{t("tactical.newBoard")}</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {boards.map((b) => (
            <Card key={b.id} corners className="flex flex-col p-5">
              <Link to={`/tactical-board/${b.id}`} className="font-display text-base text-text-primary hover:text-chalk">
                {b.name}
              </Link>
              <p className="mt-1 text-xs text-text-muted">
                {[b.team_name, b.formation, b.scenario_type, b.training_label].filter(Boolean).join(" · ") || "—"}
              </p>
              <div className="mt-4 flex items-center justify-between border-t border-line pt-3 text-sm">
                <Badge>
                  {b.object_count} {t("tactical.objectsUnit")}
                </Badge>
                <div className="flex gap-2">
                  <Link to={`/tactical-board/${b.id}`} className="text-xs text-text-muted hover:text-chalk">
                    {t("tactical.openBoard")}
                  </Link>
                  <button
                    onClick={() => setDeleteTarget(b)}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("common.delete")}
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("tactical.newBoardModalTitle")} wide>
        <form onSubmit={handleCreate} className="space-y-4">
          <Input label={t("tactical.nameRequired")} required value={name} onChange={(e) => setName(e.target.value)} />
          <div className="grid grid-cols-2 gap-4">
            <Select label={t("players.teamRequired")} required value={teamId} onChange={(e) => setTeamId(e.target.value)}>
              <option value="">{t("players.selectTeam")}</option>
              {teams.map((t2) => (
                <option key={t2.id} value={t2.id}>
                  {t2.name}
                </option>
              ))}
            </Select>
            <Select
              label={t("tactical.matchOptional")}
              value={matchId}
              onChange={(e) => setMatchId(e.target.value)}
            >
              <option value="">{t("tactical.noMatch")}</option>
              {matches.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.home_team_name} vs {m.away_team_name} ({new Date(m.date).toLocaleDateString("el-GR")})
                </option>
              ))}
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Select label="Formation" value={formation} onChange={(e) => setFormation(e.target.value)}>
              {FORMATIONS.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </Select>
            <Select
              label={t("tactical.scenarioOptional")}
              value={scenarioType}
              onChange={(e) => setScenarioType(e.target.value)}
            >
              <option value="">—</option>
              {SCENARIO_TYPES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </div>
          <Textarea label={t("calendar.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isSubmitting}>
              {t("tactical.createAndOpen")}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("tactical.deleteBoardTitle")}
        message={`${t("tactical.deleteConfirmPrefix")}${deleteTarget?.name}${t("tactical.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}
