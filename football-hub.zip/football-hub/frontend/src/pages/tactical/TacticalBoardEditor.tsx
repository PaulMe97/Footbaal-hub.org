import { PointerEvent as ReactPointerEvent, MouseEvent as ReactMouseEvent, useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { extractErrorMessage } from "../../api/client";
import { listPlayers } from "../../api/players";
import {
  deleteTacticalBoard,
  downloadTacticalBoardPdf,
  getTacticalBoard,
  saveTacticalObjects,
  updateTacticalBoard,
} from "../../api/tactical";
import { AppLayout } from "../../components/layout/AppLayout";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useContextMenu } from "../../components/ui/ContextMenu";
import { Spinner } from "../../components/ui/EmptyState";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { ConfirmDialog } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import { FORMATIONS, FORMATION_PRESETS, SCENARIO_TYPES } from "../../types";
import type { Player, TacticalBoardDetail } from "../../types";

interface Point {
  x: number;
  y: number;
}

interface WorkingObject {
  clientId: string;
  object_type: "player" | "arrow" | "zone" | "text" | "cone";
  player_id: string | null;
  coordinates: Point[];
  color: string | null;
  label: string | null;
}

type Mode = "select" | "arrow" | "zone" | "text" | "cone";

let clientIdCounter = 0;
function newClientId() {
  clientIdCounter += 1;
  return `new-${Date.now()}-${clientIdCounter}`;
}

function fromDetail(detail: TacticalBoardDetail): WorkingObject[] {
  return detail.objects.map((o) => ({
    clientId: o.id,
    object_type: o.object_type,
    player_id: o.player_id ?? null,
    coordinates: (o.coordinates as unknown as Point[]) ?? [],
    color: o.color ?? null,
    label: o.label ?? null,
  }));
}

export default function TacticalBoardEditor() {
  const { boardId } = useParams<{ boardId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useLanguage();
  const svgRef = useRef<SVGSVGElement>(null);
  const menu = useContextMenu();

  const [board, setBoard] = useState<TacticalBoardDetail | null>(null);
  const [roster, setRoster] = useState<Player[]>([]);
  const [objects, setObjects] = useState<WorkingObject[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [showApplyFormation, setShowApplyFormation] = useState(false);

  const [name, setName] = useState("");
  const [formation, setFormation] = useState("4-4-2");
  const [scenarioType, setScenarioType] = useState("");
  const [notes, setNotes] = useState("");

  const [mode, setMode] = useState<Mode>("select");
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [arrowStart, setArrowStart] = useState<Point | null>(null);
  const [zoneDraft, setZoneDraft] = useState<{ start: Point; current: Point } | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  async function load() {
    if (!boardId) return;
    setIsLoading(true);
    try {
      const detail = await getTacticalBoard(boardId);
      setBoard(detail);
      setObjects(fromDetail(detail));
      setName(detail.name);
      setFormation(detail.formation || "4-4-2");
      setScenarioType(detail.scenario_type || "");
      setNotes(detail.notes || "");
      if (detail.team_id) {
        const players = await listPlayers({ team_id: detail.team_id });
        setRoster(players);
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boardId]);

  function getRelativeCoords(e: { clientX: number; clientY: number }): Point {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return { x: 50, y: 50 };
    const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100));
    return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
  }

  function addObject(obj: Omit<WorkingObject, "clientId">) {
    setObjects((prev) => [...prev, { ...obj, clientId: newClientId() }]);
  }

  function removeObject(clientId: string) {
    setObjects((prev) => prev.filter((o) => o.clientId !== clientId));
  }

  function updateObject(clientId: string, patch: Partial<WorkingObject>) {
    setObjects((prev) => prev.map((o) => (o.clientId === clientId ? { ...o, ...patch } : o)));
  }

  function handlePointerDownOnMarker(e: ReactPointerEvent, clientId: string) {
    if (mode !== "select") return;
    e.stopPropagation();
    setDraggingId(clientId);
    setSelectedId(clientId);
  }

  function handleMarkerContextMenu(
    e: ReactPointerEvent | ReactMouseEvent,
    obj: WorkingObject,
    assignedElsewhere: Set<string | null>
  ) {
    e.preventDefault();
    e.stopPropagation();
    setSelectedId(obj.clientId);
    const availableForThisSlot = roster.filter(
      (p) => p.id === obj.player_id || !assignedElsewhere.has(p.id)
    );
    menu.open(e as unknown as { preventDefault: () => void; clientX: number; clientY: number }, [
      {
        heading: t("tacticalEditor.assignPlayer"),
        items: [
          { label: t("tacticalEditor.emptySlot"), onClick: () => updateObject(obj.clientId, { player_id: null }) },
          ...availableForThisSlot.map((p) => ({
            label: `${p.first_name} ${p.last_name}${p.player_number != null ? ` (#${p.player_number})` : ""}`,
            onClick: () => updateObject(obj.clientId, { player_id: p.id }),
          })),
        ],
      },
      {
        items: [
          {
            label: t("tacticalEditor.changeNumber"),
            onClick: () => {
              const value = window.prompt(t("tacticalEditor.numberPrompt"), obj.label || "");
              if (value !== null) {
                updateObject(obj.clientId, { label: value.trim() || null });
              }
            },
          },
          { label: t("tacticalEditor.removeSlot"), onClick: () => removeObject(obj.clientId), danger: true },
        ],
      },
    ]);
  }

  function handleContainerPointerDown(e: ReactPointerEvent<SVGSVGElement>) {
    const coords = getRelativeCoords(e);
    if (mode === "select") {
      setSelectedId(null);
    } else if (mode === "zone") {
      setZoneDraft({ start: coords, current: coords });
    }
  }

  function handleContainerPointerMove(e: ReactPointerEvent<SVGSVGElement>) {
    const coords = getRelativeCoords(e);
    if (draggingId) {
      updateObject(draggingId, { coordinates: [coords] });
    } else if (zoneDraft) {
      setZoneDraft({ start: zoneDraft.start, current: coords });
    }
  }

  function handleContainerPointerUp() {
    if (draggingId) {
      setDraggingId(null);
    }
    if (zoneDraft) {
      const { start, current } = zoneDraft;
      const x1 = Math.min(start.x, current.x);
      const y1 = Math.min(start.y, current.y);
      const x2 = Math.max(start.x, current.x);
      const y2 = Math.max(start.y, current.y);
      if (x2 - x1 > 2 && y2 - y1 > 2) {
        addObject({
          object_type: "zone",
          player_id: null,
          coordinates: [
            { x: x1, y: y1 },
            { x: x2, y: y2 },
          ],
          color: "#D8FF5C",
          label: null,
        });
      }
      setZoneDraft(null);
    }
  }

  function handleContainerClick(e: ReactMouseEvent<SVGSVGElement>) {
    if (mode === "text") {
      const coords = getRelativeCoords(e);
      const text = window.prompt(t("tacticalEditor.textNotePrompt"));
      if (text && text.trim()) {
        addObject({ object_type: "text", player_id: null, coordinates: [coords], color: "#D8FF5C", label: text.trim() });
      }
    } else if (mode === "cone") {
      const coords = getRelativeCoords(e);
      addObject({ object_type: "cone", player_id: null, coordinates: [coords], color: "#E0A83E", label: null });
    } else if (mode === "arrow") {
      const coords = getRelativeCoords(e);
      if (!arrowStart) {
        setArrowStart(coords);
      } else {
        addObject({ object_type: "arrow", player_id: null, coordinates: [arrowStart, coords], color: "#D8FF5C", label: null });
        setArrowStart(null);
      }
    }
  }

  function applyFormation() {
    const preset = FORMATION_PRESETS[formation] || FORMATION_PRESETS["4-4-2"];
    const newPlayerObjects: WorkingObject[] = preset.map((p) => ({
      clientId: newClientId(),
      object_type: "player",
      player_id: null,
      coordinates: [{ x: p.x, y: p.y }],
      color: "#D8FF5C",
      label: null,
    }));
    setObjects((prev) => [...prev.filter((o) => o.object_type !== "player"), ...newPlayerObjects]);
    setShowApplyFormation(false);
    toast.show(t("tacticalEditor.formationApplied"), "success");
  }

  function addPlayerSlot() {
    addObject({
      object_type: "player",
      player_id: null,
      coordinates: [{ x: 50, y: 50 }],
      color: "#D8FF5C",
      label: null,
    });
  }

  async function handleSave() {
    if (!boardId) return;
    setIsSaving(true);
    try {
      const updated = await updateTacticalBoard(boardId, {
        name,
        formation,
        scenario_type: scenarioType || null,
        notes: notes || null,
      });
      const detail = await saveTacticalObjects(
        boardId,
        objects.map((o) => ({
          object_type: o.object_type,
          player_id: o.player_id,
          coordinates: o.coordinates,
          color: o.color,
          label: o.label,
        }))
      );
      setBoard({ ...detail, ...updated, objects: detail.objects });
      setObjects(fromDetail(detail));
      toast.show(t("tacticalEditor.boardSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSaving(false);
    }
  }

  async function handleExportPdf() {
    if (!boardId || !board) return;
    setIsExportingPdf(true);
    try {
      await handleSave();
      await downloadTacticalBoardPdf(boardId, `tactical-board-${board.name.replace(/\s+/g, "-")}.pdf`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExportingPdf(false);
    }
  }

  async function handleDelete() {
    if (!boardId) return;
    setIsDeleting(true);
    try {
      await deleteTacticalBoard(boardId);
      toast.show(t("tactical.deleted"), "success");
      navigate("/tactical-board");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
      setIsDeleting(false);
    }
  }

  if (isLoading || !board) {
    return (
      <AppLayout title={t("tactical.title")}>
        <Spinner />
      </AppLayout>
    );
  }

  const playerObjects = objects.filter((o) => o.object_type === "player");
  const drawingObjects = objects.filter((o) => o.object_type !== "player");
  const assignedPlayerIds = new Set(playerObjects.map((o) => o.player_id).filter(Boolean));

  return (
    <AppLayout title={board.name}>
      <Link to="/tactical-board" className="mb-4 inline-block text-sm text-text-muted hover:text-chalk">
        {t("tacticalEditor.allBoards")}
      </Link>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        {/* Pitch */}
        <div className="xl:col-span-2">
          <Card corners className="p-4">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              {(
                [
                  { key: "select", label: t("tacticalEditor.toolMove") },
                  { key: "arrow", label: t("tacticalEditor.toolArrow") },
                  { key: "zone", label: t("tacticalEditor.toolZone") },
                  { key: "cone", label: t("tacticalEditor.toolCone") },
                  { key: "text", label: t("tacticalEditor.toolText") },
                ] as { key: Mode; label: string }[]
              ).map((tool) => (
                <button
                  key={tool.key}
                  onClick={() => {
                    setMode(tool.key);
                    setArrowStart(null);
                  }}
                  className={`rounded-md border px-3 py-1.5 text-xs transition-colors ${
                    mode === tool.key
                      ? "border-chalk bg-chalk/15 text-chalk"
                      : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                  }`}
                >
                  {tool.label}
                </button>
              ))}
              <span className="ml-auto text-xs text-text-muted">
                {mode === "arrow" &&
                  (arrowStart ? t("tacticalEditor.hintArrowEnd") : t("tacticalEditor.hintArrowStart"))}
                {mode === "zone" && t("tacticalEditor.hintZone")}
                {mode === "cone" && t("tacticalEditor.hintCone")}
                {mode === "text" && t("tacticalEditor.hintText")}
                {mode === "select" && t("tacticalEditor.hintSelect")}
              </span>
            </div>

            <div className="relative mx-auto aspect-[68/105] w-full max-w-md overflow-hidden rounded-lg border-2 border-line bg-gradient-to-b from-pitch-dark to-void">
              <svg
                ref={svgRef}
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                className="absolute inset-0 h-full w-full touch-none select-none"
                style={{ cursor: mode === "select" ? "default" : "crosshair" }}
                onPointerDown={handleContainerPointerDown}
                onPointerMove={handleContainerPointerMove}
                onPointerUp={handleContainerPointerUp}
                onClick={handleContainerClick}
              >
                <PitchMarkings />

                {drawingObjects
                  .filter((o) => o.object_type === "zone")
                  .map((o) => (
                    <rect
                      key={o.clientId}
                      x={o.coordinates[0]?.x}
                      y={o.coordinates[0]?.y}
                      width={(o.coordinates[1]?.x ?? 0) - (o.coordinates[0]?.x ?? 0)}
                      height={(o.coordinates[1]?.y ?? 0) - (o.coordinates[0]?.y ?? 0)}
                      fill={o.color || "#D8FF5C"}
                      fillOpacity={0.15}
                      stroke={o.color || "#D8FF5C"}
                      strokeWidth={0.3}
                      strokeDasharray="1.2 1"
                    />
                  ))}

                {zoneDraft && (
                  <rect
                    x={Math.min(zoneDraft.start.x, zoneDraft.current.x)}
                    y={Math.min(zoneDraft.start.y, zoneDraft.current.y)}
                    width={Math.abs(zoneDraft.current.x - zoneDraft.start.x)}
                    height={Math.abs(zoneDraft.current.y - zoneDraft.start.y)}
                    fill="#D8FF5C"
                    fillOpacity={0.1}
                    stroke="#D8FF5C"
                    strokeWidth={0.3}
                    strokeDasharray="1.2 1"
                  />
                )}

                <defs>
                  <marker id="arrowhead" markerWidth="4" markerHeight="4" refX="3" refY="2" orient="auto">
                    <path d="M0,0 L4,2 L0,4 Z" fill="#D8FF5C" />
                  </marker>
                </defs>

                {drawingObjects
                  .filter((o) => o.object_type === "arrow")
                  .map((o) => (
                    <line
                      key={o.clientId}
                      x1={o.coordinates[0]?.x}
                      y1={o.coordinates[0]?.y}
                      x2={o.coordinates[1]?.x}
                      y2={o.coordinates[1]?.y}
                      stroke={o.color || "#D8FF5C"}
                      strokeWidth={0.7}
                      markerEnd="url(#arrowhead)"
                    />
                  ))}

                {arrowStart && <circle cx={arrowStart.x} cy={arrowStart.y} r={0.8} fill="#D8FF5C" />}

                {drawingObjects
                  .filter((o) => o.object_type === "cone")
                  .map((o) => (
                    <g
                      key={o.clientId}
                      transform={`translate(${o.coordinates[0]?.x ?? 50}, ${o.coordinates[0]?.y ?? 50})`}
                    >
                      <polygon points="0,-2.4 -2,1.6 2,1.6" fill="#E0A83E" stroke="#0A0F0D" strokeWidth={0.15} />
                      <line x1={-1} y1={0.5} x2={1} y2={0.5} stroke="#0A0F0D" strokeWidth={0.2} />
                    </g>
                  ))}

                {drawingObjects
                  .filter((o) => o.object_type === "text")
                  .map((o) => (
                    <g key={o.clientId} transform={`translate(${o.coordinates[0]?.x}, ${o.coordinates[0]?.y})`}>
                      <rect
                        x={-1}
                        y={-3}
                        width={Math.max(8, (o.label?.length || 1) * 1.7)}
                        height={4}
                        rx={0.8}
                        fill="#0A0F0D"
                        stroke="#D8FF5C"
                        strokeWidth={0.2}
                      />
                      <text x={0.5} y={0} fontSize={2.6} fill="#EDF2EE">
                        {o.label}
                      </text>
                    </g>
                  ))}

                {playerObjects.map((o) => {
                  const player = roster.find((p) => p.id === o.player_id);
                  return (
                    <g
                      key={o.clientId}
                      transform={`translate(${o.coordinates[0]?.x ?? 50}, ${o.coordinates[0]?.y ?? 50})`}
                      onPointerDown={(e) => handlePointerDownOnMarker(e, o.clientId)}
                      onContextMenu={(e) => handleMarkerContextMenu(e, o, assignedPlayerIds)}
                      style={{ cursor: mode === "select" ? "grab" : "default" }}
                    >
                      <circle
                        r={3.4}
                        fill={player ? "#D8FF5C" : "#243029"}
                        stroke={selectedId === o.clientId ? "#EDF2EE" : "#0A0F0D"}
                        strokeWidth={selectedId === o.clientId ? 0.6 : 0.4}
                      />
                      <text
                        y={1}
                        fontSize={2.6}
                        textAnchor="middle"
                        fill={player ? "#0A0F0D" : "#8FA098"}
                        fontFamily="IBM Plex Mono, monospace"
                      >
                        {o.label || player?.player_number || "?"}
                      </text>
                      <text y={6.5} fontSize={2.1} textAnchor="middle" fill="#EDF2EE">
                        {player ? player.last_name : ""}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </Card>
        </div>

        {/* Side panel */}
        <div className="space-y-6">
          <Card className="p-5">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("tacticalEditor.boardDetails")}
            </h3>
            <div className="space-y-3">
              <Input label={t("tacticalEditor.name")} value={name} onChange={(e) => setName(e.target.value)} />
              <div className="flex items-end gap-2">
                <Select
                  label="Formation"
                  value={formation}
                  onChange={(e) => setFormation(e.target.value)}
                  className="flex-1"
                >
                  {FORMATIONS.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </Select>
                <Button type="button" variant="secondary" onClick={() => setShowApplyFormation(true)}>
                  {t("tacticalEditor.apply")}
                </Button>
              </div>
              <Select label={t("tacticalEditor.scenario")} value={scenarioType} onChange={(e) => setScenarioType(e.target.value)}>
                <option value="">—</option>
                {SCENARIO_TYPES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </Select>
              <Textarea label={t("calendar.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <div className="mt-4 flex flex-wrap gap-2 border-t border-line pt-4">
              <Button onClick={handleSave} isLoading={isSaving} className="flex-1">
                {t("tacticalEditor.saveBoard")}
              </Button>
              <Button variant="secondary" onClick={handleExportPdf} isLoading={isExportingPdf}>
                📄 Export to PDF
              </Button>
              <Button variant="danger" onClick={() => setShowDelete(true)}>
                {t("common.delete")}
              </Button>
            </div>
          </Card>

          <Card className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("tacticalEditor.composition")} ({playerObjects.length})
              </h3>
              <button onClick={addPlayerSlot} className="text-xs text-chalk hover:underline">
                {t("tacticalEditor.addSlot")}
              </button>
            </div>
            <div className="max-h-72 space-y-2 overflow-y-auto pr-1">
              {playerObjects.map((o, i) => (
                <div key={o.clientId} className="flex items-center gap-2">
                  <span className="w-5 shrink-0 text-center text-xs text-text-muted">{i + 1}</span>
                  <select
                    value={o.player_id ?? ""}
                    onChange={(e) => updateObject(o.clientId, { player_id: e.target.value || null })}
                    className="flex-1 rounded-md border border-line bg-surface px-2 py-1.5 text-xs text-text-primary focus:border-chalk focus:outline-none"
                  >
                    <option value="">{t("tacticalEditor.emptySlot")}</option>
                    {roster
                      .filter((p) => p.id === o.player_id || !assignedPlayerIds.has(p.id))
                      .map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.first_name} {p.last_name}
                          {p.player_number != null ? ` (#${p.player_number})` : ""}
                        </option>
                      ))}
                  </select>
                  <button
                    onClick={() => removeObject(o.clientId)}
                    className="text-xs text-status-injured hover:underline"
                    title={t("tacticalEditor.removeSlot")}
                  >
                    ✕
                  </button>
                </div>
              ))}
              {playerObjects.length === 0 && (
                <p className="text-xs text-text-muted">{t("tacticalEditor.selectFormationHint")}</p>
              )}
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("tacticalEditor.drawings")} ({drawingObjects.length})
            </h3>
            {drawingObjects.length === 0 ? (
              <p className="text-xs text-text-muted">{t("tacticalEditor.useToolsHint")}</p>
            ) : (
              <div className="space-y-1.5">
                {drawingObjects.map((o) => (
                  <div key={o.clientId} className="flex items-center justify-between text-xs">
                    <span className="text-text-muted">
                      {o.object_type === "arrow" && t("tacticalEditor.arrowLabel")}
                      {o.object_type === "zone" && t("tacticalEditor.zoneLabel")}
                      {o.object_type === "cone" && t("tacticalEditor.coneLabel")}
                      {o.object_type === "text" && `✎ ${o.label}`}
                    </span>
                    <button onClick={() => removeObject(o.clientId)} className="text-status-injured hover:underline">
                      {t("common.delete")}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      <ConfirmDialog
        isOpen={showApplyFormation}
        onClose={() => setShowApplyFormation(false)}
        onConfirm={applyFormation}
        title={t("tacticalEditor.applyFormationTitle")}
        message={t("tacticalEditor.applyFormationMessage")}
        confirmLabel={t("tacticalEditor.apply")}
      />

      <ConfirmDialog
        isOpen={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title={t("tactical.deleteBoardTitle")}
        message={t("tacticalEditor.deleteBoardMessage")}
        isLoading={isDeleting}
      />

      {menu.render()}
    </AppLayout>
  );
}

function PitchMarkings() {
  const stroke = "rgba(237,242,238,0.35)";
  return (
    <g fill="none" stroke={stroke} strokeWidth={0.4}>
      <rect x={2} y={2} width={96} height={96} />
      <line x1={2} y1={50} x2={98} y2={50} />
      <ellipse cx={50} cy={50} rx={9} ry={14} />
      <circle cx={50} cy={50} r={0.6} fill={stroke} />
      {/* Own goal area (bottom) */}
      <rect x={25} y={84} width={50} height={16} />
      <rect x={38} y={94} width={24} height={6} />
      <circle cx={50} cy={88} r={0.6} fill={stroke} />
      {/* Opponent goal area (top) */}
      <rect x={25} y={0} width={50} height={16} />
      <rect x={38} y={0} width={24} height={6} />
      <circle cx={50} cy={12} r={0.6} fill={stroke} />
    </g>
  );
}
