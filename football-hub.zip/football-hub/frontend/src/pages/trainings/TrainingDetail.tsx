import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { extractErrorMessage } from "../../api/client";
import { listTeams } from "../../api/teams";
import { createTacticalBoard, deleteTacticalBoard, listTacticalBoards } from "../../api/tactical";
import {
  deleteTraining,
  getAttendance,
  getTraining,
  setAttendance,
  updateTraining,
} from "../../api/trainings";
import { AppLayout } from "../../components/layout/AppLayout";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { Spinner } from "../../components/ui/EmptyState";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import type {
  AttendanceStatus,
  TacticalBoard,
  Team,
  TrainingAttendanceEntry,
  TrainingSession,
} from "../../types";
import { ATTENDANCE_LABELS } from "../../types";
import { TrainingForm, trainingFormToPayload, type TrainingFormValues } from "./TrainingForm";
import { useLanguage } from "../../context/LanguageContext";

const STATUS_OPTIONS: AttendanceStatus[] = ["present", "absent", "late", "injured", "excused"];

const statusPillClass: Record<AttendanceStatus, string> = {
  present: "border-status-fit/40 bg-status-fit/15 text-status-fit",
  absent: "border-status-injured/40 bg-status-injured/15 text-status-injured",
  late: "border-status-doubtful/40 bg-status-doubtful/15 text-status-doubtful",
  injured: "border-status-injured/40 bg-status-injured/15 text-status-injured",
  excused: "border-status-suspended/40 bg-status-suspended/15 text-status-suspended",
};

export default function TrainingDetail() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useLanguage();

  const [session, setSession] = useState<TrainingSession | null>(null);
  const [attendance, setAttendanceRows] = useState<TrainingAttendanceEntry[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [diagrams, setDiagrams] = useState<TacticalBoard[]>([]);
  const [isCreatingDiagram, setIsCreatingDiagram] = useState(false);
  const [deleteDiagramTarget, setDeleteDiagramTarget] = useState<TacticalBoard | null>(null);
  const [isDeletingDiagram, setIsDeletingDiagram] = useState(false);

  async function load() {
    if (!sessionId) return;
    setIsLoading(true);
    try {
      const [s, a, teamsData, diags] = await Promise.all([
        getTraining(sessionId),
        getAttendance(sessionId),
        listTeams(),
        listTacticalBoards({ training_session_id: sessionId }),
      ]);
      setSession(s);
      setAttendanceRows(a);
      setTeams(teamsData);
      setDiagrams(diags);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  function updateLocalStatus(playerId: string, status: AttendanceStatus) {
    setAttendanceRows((rows) => rows.map((r) => (r.player_id === playerId ? { ...r, status } : r)));
  }

  async function handleSaveAttendance() {
    if (!sessionId) return;
    setIsSaving(true);
    try {
      const payload = attendance.map((a) => ({
        player_id: a.player_id,
        status: a.status,
        notes: a.notes,
      }));
      const updated = await setAttendance(sessionId, payload);
      setAttendanceRows(updated);
      const s = await getTraining(sessionId);
      setSession(s);
      toast.show(t("trainingDetail.attendanceSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSaving(false);
    }
  }

  async function handleUpdateSession(values: TrainingFormValues) {
    if (!sessionId) return;
    setIsSubmitting(true);
    try {
      const updated = await updateTraining(sessionId, trainingFormToPayload(values));
      setSession(updated);
      toast.show(t("dashboard.changesSaved"), "success");
      setShowEdit(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!sessionId) return;
    setIsDeleting(true);
    try {
      await deleteTraining(sessionId);
      toast.show(t("trainingDetail.sessionDeleted"), "success");
      navigate("/trainings");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
      setIsDeleting(false);
    }
  }

  async function handleCreateDiagram() {
    if (!sessionId || !session) return;
    setIsCreatingDiagram(true);
    try {
      const board = await createTacticalBoard({
        name: `${t("trainingDetail.diagramNamePrefix")}${session.date}`,
        team_id: session.team_id,
        training_session_id: sessionId,
        formation: null,
        scenario_type: null,
        notes: null,
      });
      navigate(`/tactical-board/${board.id}`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsCreatingDiagram(false);
    }
  }

  async function handleDeleteDiagram() {
    if (!deleteDiagramTarget) return;
    setIsDeletingDiagram(true);
    try {
      await deleteTacticalBoard(deleteDiagramTarget.id);
      toast.show(t("trainingDetail.diagramDeleted"), "success");
      setDeleteDiagramTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeletingDiagram(false);
    }
  }

  if (isLoading || !session) {
    return (
      <AppLayout title={t("trainingDetail.loadingTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  return (
    <AppLayout title={session.team_name || t("trainingDetail.loadingTitle")}>
      <Link to="/trainings" className="mb-4 inline-block text-sm text-text-muted hover:text-chalk">
        {t("trainingDetail.backToAll")}
      </Link>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card corners className="p-5 lg:col-span-1">
          <h2 className="font-display text-lg text-text-primary">
            {new Date(session.date).toLocaleDateString("el-GR", {
              weekday: "long",
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
            })}
          </h2>
          <dl className="mt-4 space-y-2 text-sm">
            <Row label={t("crm.team")} value={session.team_name} />
            <Row label={t("calendar.time")} value={session.time} />
            <Row
              label={t("trainingDetail.durationLabel")}
              value={session.duration_minutes ? `${session.duration_minutes}'` : undefined}
            />
            <Row label={t("trainingForm.location")} value={session.location} />
            <Row label={t("trainingDetail.typeLabel")} value={session.training_type} />
          </dl>
          {session.objectives && (
            <div className="mt-4 border-t border-line pt-3">
              <p className="text-xs uppercase text-text-muted">{t("trainingForm.objectives")}</p>
              <p className="mt-1 text-sm text-text-primary">{session.objectives}</p>
            </div>
          )}
          {session.exercises && (
            <div className="mt-3">
              <p className="text-xs uppercase text-text-muted">{t("trainingForm.exercises")}</p>
              <p className="mt-1 text-sm text-text-primary">{session.exercises}</p>
            </div>
          )}
          {session.coach_notes && (
            <div className="mt-3">
              <p className="text-xs uppercase text-text-muted">{t("matchReportForm.coachNotes")}</p>
              <p className="mt-1 text-sm text-text-primary">{session.coach_notes}</p>
            </div>
          )}

          <div className="mt-5 flex gap-2 border-t border-line pt-4">
            <Button variant="secondary" onClick={() => setShowEdit(true)} className="flex-1">
              {t("common.edit")}
            </Button>
            <Button variant="danger" onClick={() => setShowDelete(true)}>
              {t("common.delete")}
            </Button>
          </div>
        </Card>

        <div className="lg:col-span-2">
          <Card>
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("trainingDetail.attendancePrefix")}{attendance.length})
              </h3>
              <Button onClick={handleSaveAttendance} isLoading={isSaving}>
                {t("trainingDetail.saveAttendance")}
              </Button>
            </div>
            {attendance.length === 0 ? (
              <p className="p-6 text-center text-sm text-text-muted">
                {t("trainingDetail.noPlayersInTeamYet")}
              </p>
            ) : (
              <div className="divide-y divide-line">
                {attendance.map((a) => (
                  <div key={a.player_id} className="flex items-center justify-between px-4 py-3 text-sm">
                    <Link to={`/players/${a.player_id}`} className="text-text-primary hover:text-chalk">
                      {a.player_name}
                    </Link>
                    <div className="flex flex-wrap gap-1.5">
                      {STATUS_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => updateLocalStatus(a.player_id, opt)}
                          className={`rounded-full border px-2.5 py-1 text-xs transition-colors ${
                            a.status === opt
                              ? statusPillClass[opt]
                              : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                          }`}
                        >
                          {ATTENDANCE_LABELS[opt]}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="mt-6">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("trainingDetail.diagramPrefix")}{diagrams.length})
              </h3>
              <Button onClick={handleCreateDiagram} isLoading={isCreatingDiagram} variant="ghost">
                {t("trainingDetail.newDiagram")}
              </Button>
            </div>
            {diagrams.length === 0 ? (
              <p className="p-6 text-center text-sm text-text-muted">
                {t("trainingDetail.noDiagramYet")}
              </p>
            ) : (
              <div className="divide-y divide-line">
                {diagrams.map((d) => (
                  <div key={d.id} className="flex items-center justify-between px-4 py-3 text-sm">
                    <Link to={`/tactical-board/${d.id}`} className="text-text-primary hover:text-chalk">
                      {d.name}
                    </Link>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-text-muted">{d.object_count}{t("trainingDetail.objectsCountSuffix")}</span>
                      <button
                        onClick={() => setDeleteDiagramTarget(d)}
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      <Modal isOpen={showEdit} onClose={() => setShowEdit(false)} title={t("trainingDetail.editSessionModalTitle")} wide>
        <TrainingForm
          session={session}
          teams={teams}
          onSubmit={handleUpdateSession}
          onCancel={() => setShowEdit(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title={t("trainingDetail.deleteSessionTitle")}
        message={t("trainingDetail.deleteSessionMessage")}
        isLoading={isDeleting}
      />

      <ConfirmDialog
        isOpen={!!deleteDiagramTarget}
        onClose={() => setDeleteDiagramTarget(null)}
        onConfirm={handleDeleteDiagram}
        title={t("trainingDetail.deleteDiagramTitle")}
        message={`${t("trainingDetail.deleteDiagramConfirmPrefix")}${deleteDiagramTarget?.name}${t("trainingDetail.deleteDiagramConfirmSuffix")}`}
        isLoading={isDeletingDiagram}
      />
    </AppLayout>
  );
}

function Row({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-text-muted">{label}</dt>
      <dd className="text-right text-text-primary">{value || "—"}</dd>
    </div>
  );
}
