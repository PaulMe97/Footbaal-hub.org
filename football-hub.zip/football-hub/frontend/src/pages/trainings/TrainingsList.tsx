import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

import { listCalendarEvents } from "../../api/calendar";
import { extractErrorMessage } from "../../api/client";
import { createTraining, deleteTraining, listTrainings } from "../../api/trainings";
import { listTeams } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { TeamPickerGrid } from "../../components/TeamPickerGrid";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import type { Team, TrainingSession } from "../../types";
import { TrainingForm, trainingFormToPayload, type TrainingFormValues } from "./TrainingForm";

export default function TrainingsList() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const teamIdFilter = searchParams.get("team_id") || "";

  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<TrainingSession | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const toast = useToast();

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  useEffect(() => {
    if (searchParams.get("create") === "1") {
      setShowCreate(true);
      const next = new URLSearchParams(searchParams);
      next.delete("create");
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listTrainings(teamIdFilter || undefined);
      setSessions(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamIdFilter]);

  async function handleCreate(values: TrainingFormValues) {
    setIsSubmitting(true);
    try {
      const existing = await listCalendarEvents({
        team_id: values.team_id,
        start: values.date,
        end: values.date,
      });
      if (existing.length > 0) {
        const names = existing.map((e) => e.title).join(", ");
        const proceed = window.confirm(
          `${t("matches.conflictPrefix")}${names}${t("matches.conflictSuffix")}`
        );
        if (!proceed) {
          setIsSubmitting(false);
          return;
        }
      }
      await createTraining(trainingFormToPayload(values));
      toast.show(t("trainings.created"), "success");
      setShowCreate(false);
      navigate(`/calendar?date=${values.date}`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteTraining(deleteTarget.id);
      toast.show(t("trainings.deleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  const selectedTeam = teams.find((t) => t.id === teamIdFilter);

  return (
    <AppLayout title={t("trainings.title")}>
      {teamIdFilter && (
        <button
          onClick={() => setSearchParams({})}
          className="mb-3 text-xs text-chalk hover:underline"
        >
          {t("matches.backToTeams")}
        </button>
      )}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {teamIdFilter && selectedTeam ? (
          <h2 className="font-display text-lg text-text-primary">{selectedTeam.name}</h2>
        ) : (
          <div />
        )}
        <Button onClick={() => setShowCreate(true)}>{t("trainings.newTraining")}</Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : !teamIdFilter ? (
        teams.length === 0 ? (
          <EmptyState
            title={t("matches.noTeamsYet")}
            description={t("trainings.noTeamsDescription")}
            action={
              <Link to="/teams">
                <Button>{t("matches.goToTeams")}</Button>
              </Link>
            }
          />
        ) : (
          <TeamPickerGrid teams={teams} onSelect={(id) => setSearchParams({ team_id: id })} />
        )
      ) : sessions.length === 0 ? (
        <EmptyState
          title={t("trainings.noTrainingsYet")}
          description={t("trainings.noTrainingsDescription")}
          action={<Button onClick={() => setShowCreate(true)}>{t("trainings.newTraining")}</Button>}
        />
      ) : (
        <Card>
          <div className="divide-y divide-line">
            {sessions.map((s) => (
              <Link
                key={s.id}
                to={`/trainings/${s.id}`}
                className="flex items-center justify-between px-4 py-3 text-sm hover:bg-surface-raised"
              >
                <div>
                  <p className="text-text-primary">
                    {new Date(s.date).toLocaleDateString("el-GR", {
                      weekday: "short",
                      day: "2-digit",
                      month: "2-digit",
                      year: "numeric",
                    })}
                    {s.time ? ` · ${s.time}` : ""}
                  </p>
                  <p className="text-xs text-text-muted">
                    {[s.team_name, s.training_type, s.location].filter(Boolean).join(" · ") || "—"}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-xs text-text-muted">
                    {s.attendance_present}/{s.attendance_total} {t("trainings.presentUnit")}
                  </span>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setDeleteTarget(s);
                    }}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("common.delete")}
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("trainings.newTrainingModalTitle")} wide>
        <TrainingForm
          teams={teams}
          presetTeamId={teamIdFilter || undefined}
          onSubmit={handleCreate}
          onCancel={() => setShowCreate(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("trainings.deleteTrainingTitle")}
        message={t("trainings.deleteConfirmMessage")}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}
