import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { DateField } from "../../components/ui/DateField";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { QuickSuggestions, appendSuggestion } from "../../components/QuickSuggestions";
import { useQuickSuggestions } from "../../utils/quickSuggestions";
import type { Team, TrainingSession } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export interface TrainingFormValues {
  team_id: string;
  date: string;
  time: string;
  location: string;
  training_type: string;
  duration_minutes: string;
  objectives: string;
  exercises: string;
  coach_notes: string;
}

function toFormValues(session?: TrainingSession | null, presetTeamId?: string): TrainingFormValues {
  return {
    team_id: session?.team_id ?? presetTeamId ?? "",
    date: session?.date?.slice(0, 10) ?? new Date().toISOString().slice(0, 10),
    time: session?.time ?? "",
    location: session?.location ?? "",
    training_type: session?.training_type ?? "",
    duration_minutes: session?.duration_minutes != null ? String(session.duration_minutes) : "",
    objectives: session?.objectives ?? "",
    exercises: session?.exercises ?? "",
    coach_notes: session?.coach_notes ?? "",
  };
}

export function trainingFormToPayload(values: TrainingFormValues) {
  return {
    team_id: values.team_id,
    date: values.date,
    time: values.time || null,
    location: values.location || null,
    training_type: values.training_type || null,
    duration_minutes: values.duration_minutes ? Number(values.duration_minutes) : null,
    objectives: values.objectives || null,
    exercises: values.exercises || null,
    coach_notes: values.coach_notes || null,
  };
}

export function TrainingForm({
  session,
  teams,
  presetTeamId,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  session?: TrainingSession | null;
  teams: Team[];
  presetTeamId?: string;
  onSubmit: (values: TrainingFormValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const [values, setValues] = useState<TrainingFormValues>(toFormValues(session, presetTeamId));
  const { t } = useLanguage();

  function set<K extends keyof TrainingFormValues>(key: K, value: TrainingFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  const objectivesSuggestions = useQuickSuggestions("trainingObjectives");
  const exercisesSuggestions = useQuickSuggestions("trainingExercises");
  const coachNotesSuggestions = useQuickSuggestions("trainingCoachNotes");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Select
        label={t("trainingForm.teamRequired")}
        required
        value={values.team_id}
        onChange={(e) => set("team_id", e.target.value)}
      >
        <option value="">{t("crm.selectTeam")}</option>
        {teams.map((teamOpt) => (
          <option key={teamOpt.id} value={teamOpt.id}>
            {teamOpt.name}
          </option>
        ))}
      </Select>

      <div className="grid grid-cols-3 gap-4">
        <DateField
          label={t("matchForm.dateRequired")}
          required
          value={values.date}
          onChange={(iso) => set("date", iso)}
        />
        <Input label={t("calendar.time")} type="time" value={values.time} onChange={(e) => set("time", e.target.value)} />
        <Input
          label={t("trainingForm.durationMinutes")}
          type="number"
          value={values.duration_minutes}
          onChange={(e) => set("duration_minutes", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("trainingForm.location")}
          value={values.location}
          onChange={(e) => set("location", e.target.value)}
        />
        <Input
          label={t("trainingForm.trainingType")}
          placeholder={t("trainingForm.trainingTypePlaceholder")}
          value={values.training_type}
          onChange={(e) => set("training_type", e.target.value)}
        />
      </div>

      <Textarea
        label={t("trainingForm.objectives")}
        value={values.objectives}
        onChange={(e) => set("objectives", e.target.value)}
      />
      <QuickSuggestions
        suggestions={objectivesSuggestions}
        onSelect={(s) => set("objectives", appendSuggestion(values.objectives, s))}
      />
      <Textarea
        label={t("trainingForm.exercises")}
        value={values.exercises}
        onChange={(e) => set("exercises", e.target.value)}
      />
      <QuickSuggestions
        suggestions={exercisesSuggestions}
        onSelect={(s) => set("exercises", appendSuggestion(values.exercises, s))}
      />
      <Textarea
        label={t("matchReportForm.coachNotes")}
        value={values.coach_notes}
        onChange={(e) => set("coach_notes", e.target.value)}
      />
      <QuickSuggestions
        suggestions={coachNotesSuggestions}
        onSelect={(s) => set("coach_notes", appendSuggestion(values.coach_notes, s))}
      />

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {session ? t("common.save") : t("common.create")}
        </Button>
      </div>
    </form>
  );
}
