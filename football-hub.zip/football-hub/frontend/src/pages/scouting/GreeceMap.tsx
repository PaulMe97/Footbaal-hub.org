import type { Region } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

// Σχηματική τοποθέτηση (στήλη, γραμμή) των 13 Περιφερειών — προσεγγιστική
// γεωγραφία (βορράς πάνω, νησιά δεξιά/γύρω, Πελοπόννησος/Κρήτη κάτω).
// Χρησιμοποιεί "brick offset" ώστε να μοιάζει περισσότερο με χάρτη παρά με
// αυστηρό grid. ΠΡΟΣΟΧΗ: τα keys εδώ ΠΡΕΠΕΙ να παραμείνουν τα ελληνικά
// ονόματα όπως τα επιστρέφει το backend (region.name) — δεν μεταφράζονται.
const LAYOUT: Record<string, { col: number; row: number }> = {
  "Δυτική Μακεδονία": { col: 1, row: 0 },
  "Κεντρική Μακεδονία": { col: 2.5, row: 0 },
  "Ανατολική Μακεδονία και Θράκη": { col: 4, row: 0 },
  "Ήπειρος": { col: 0.5, row: 1 },
  "Θεσσαλία": { col: 2.5, row: 1 },
  "Βόρειο Αιγαίο": { col: 5, row: 1.2 },
  "Ιόνια Νησιά": { col: 0, row: 2.1 },
  "Στερεά Ελλάδα": { col: 2, row: 2.1 },
  "Δυτική Ελλάδα": { col: 1, row: 3 },
  "Αττική": { col: 3, row: 3 },
  "Νότιο Αιγαίο": { col: 4.5, row: 3.2 },
  "Πελοπόννησος": { col: 1.7, row: 4 },
  "Κρήτη": { col: 2.5, row: 5.1 },
};

// Χαρτογράφηση backend name -> μεταφρασμένο κλειδί, μόνο για την
// ΕΜΦΑΝΙΖΟΜΕΝΗ ετικέτα (το LAYOUT παραπάνω δεν επηρεάζεται).
const REGION_NAME_KEYS: Record<string, string> = {
  "Δυτική Μακεδονία": "regions.westMacedonia",
  "Κεντρική Μακεδονία": "regions.centralMacedonia",
  "Ανατολική Μακεδονία και Θράκη": "regions.eastMacedoniaThrace",
  "Ήπειρος": "regions.epirus",
  "Θεσσαλία": "regions.thessaly",
  "Βόρειο Αιγαίο": "regions.northAegean",
  "Ιόνια Νησιά": "regions.ionianIslands",
  "Στερεά Ελλάδα": "regions.centralGreece",
  "Δυτική Ελλάδα": "regions.westGreece",
  "Αττική": "regions.attica",
  "Νότιο Αιγαίο": "regions.southAegean",
  "Πελοπόννησος": "regions.peloponnese",
  "Κρήτη": "regions.crete",
};

const CELL_W = 92;
const CELL_H = 74;
const TILE_W = 82;
const TILE_H = 60;

export function GreeceMap({
  regions,
  selectedRegionId,
  onSelect,
}: {
  regions: Region[];
  selectedRegionId?: string;
  onSelect: (region: Region) => void;
}) {
  const { t } = useLanguage();
  const maxCol = Math.max(...Object.values(LAYOUT).map((p) => p.col)) + 1.5;
  const maxRow = Math.max(...Object.values(LAYOUT).map((p) => p.row)) + 1.3;
  const width = maxCol * CELL_W;
  const height = maxRow * CELL_H;

  return (
    <div className="overflow-x-auto">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="mx-auto"
        style={{ width: "100%", maxWidth: 620, height: "auto" }}
      >
        {regions.map((region) => {
          const pos = LAYOUT[region.name];
          if (!pos) return null;
          const x = pos.col * CELL_W;
          const y = pos.row * CELL_H;
          const isSelected = region.id === selectedRegionId;
          return (
            <g
              key={region.id}
              transform={`translate(${x}, ${y})`}
              onClick={() => onSelect(region)}
              className="cursor-pointer"
            >
              <rect
                width={TILE_W}
                height={TILE_H}
                rx={10}
                className={
                  isSelected
                    ? "fill-chalk stroke-chalk"
                    : "fill-surface-raised stroke-line hover:stroke-chalk"
                }
                strokeWidth={isSelected ? 2 : 1.2}
                style={{ transition: "all 0.15s ease" }}
              />
              <foreignObject width={TILE_W} height={TILE_H}>
                <div
                  className={`flex h-full w-full items-center justify-center px-1.5 text-center text-[10px] font-medium leading-tight ${
                    isSelected ? "text-void" : "text-text-primary"
                  }`}
                >
                  {t(REGION_NAME_KEYS[region.name] || "") || region.name}
                </div>
              </foreignObject>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
