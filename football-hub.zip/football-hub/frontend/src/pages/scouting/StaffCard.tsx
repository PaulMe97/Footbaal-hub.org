import { mediaUrl } from "../../api/client";
import { STAFF_AVAILABILITY_LABELS, VERIFICATION_LEVEL_INFO } from "../../types";
import type { ScoutingStaff } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export function StaffCard({ staff, onClick }: { staff: ScoutingStaff; onClick: () => void }) {
  const { t } = useLanguage();
  const ROLE_LABELS: Record<string, string> = {
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
  };
  const verification = VERIFICATION_LEVEL_INFO[staff.verification_level] || VERIFICATION_LEVEL_INFO[0];
  return (
    <button
      onClick={onClick}
      className="corner-card flex w-full items-center gap-3 rounded-lg border border-line bg-surface p-3 text-left hover:border-chalk"
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm text-text-muted">
        {staff.avatar_path ? (
          <img src={mediaUrl(staff.avatar_path)} alt="" className="h-full w-full object-cover" />
        ) : (
          (staff.full_name || "?").charAt(0).toUpperCase()
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span
            className={`h-2 w-2 shrink-0 rounded-full ${verification.dot}`}
            title={verification.label}
          />
          <p className="truncate text-sm text-text-primary">{staff.full_name || "—"}</p>
        </div>
        <p className="truncate text-xs text-text-muted">
          {ROLE_LABELS[staff.role] || staff.role}
          {staff.origin_federation_name ? ` · ${t("staff.fromPrefix")}${staff.origin_federation_name}` : ""}
        </p>
        <div className="mt-1 flex flex-wrap items-center gap-1">
          {staff.staff_availability !== "not_listed" && (
            <span
              className={`rounded-full border px-1.5 py-0.5 text-[10px] ${
                staff.staff_availability === "available"
                  ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                  : "border-status-doubtful/40 bg-status-doubtful/10 text-status-doubtful"
              }`}
            >
              {STAFF_AVAILABILITY_LABELS[staff.staff_availability]}
            </span>
          )}
          {staff.desired_staff_role && (
            <span className="rounded-full border border-chalk/30 bg-chalk/10 px-1.5 py-0.5 text-[10px] text-chalk">
              {t("staff.seekingPrefix")}{ROLE_LABELS[staff.desired_staff_role] || staff.desired_staff_role}
            </span>
          )}
          {staff.qualifications.slice(0, 2).map((q) => (
            <span
              key={q.id}
              className="rounded-full border border-chalk/30 bg-chalk/10 px-1.5 py-0.5 text-[10px] text-chalk"
            >
              {q.title}
            </span>
          ))}
        </div>
      </div>
    </button>
  );
}
