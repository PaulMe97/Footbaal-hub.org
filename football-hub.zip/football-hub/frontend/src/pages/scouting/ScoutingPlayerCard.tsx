import { mediaUrl } from "../../api/client";
import { TRANSFER_STATUS_COLORS, TRANSFER_STATUS_LABELS } from "../../types";
import type { ScoutingPlayer } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export function ScoutingPlayerCard({
  player,
  onClick,
  onToggleShortlist,
}: {
  player: ScoutingPlayer;
  onClick: () => void;
  onToggleShortlist: () => void;
}) {
  const { t } = useLanguage();
  return (
    <button
      onClick={onClick}
      className="corner-card flex w-full items-center gap-3 rounded-lg border border-line bg-surface p-3 text-left hover:border-chalk"
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm text-text-muted">
        {player.photo_path ? (
          <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
        ) : (
          `${player.first_name[0] ?? ""}${player.last_name[0] ?? ""}`
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm text-text-primary">
          {player.first_name} {player.last_name}
        </p>
        <p className="truncate text-xs text-text-muted">
          {[player.position, player.age ? `${player.age}${t("players.yearsOldSuffix")}` : null, player.team_name]
            .filter(Boolean)
            .join(" · ") || "—"}
        </p>
        <div className="mt-1 flex items-center gap-2">
          <span
            className={`rounded-full border px-1.5 py-0.5 text-[10px] ${TRANSFER_STATUS_COLORS[player.transfer_status]}`}
          >
            {TRANSFER_STATUS_LABELS[player.transfer_status]}
          </span>
          <span className="text-[10px] text-text-muted">
            ⚽ {player.season_stats.goals} · 🅰 {player.season_stats.assists} · {player.season_stats.matches_played}{t("scoutingPlayerCard.matchesAbbrev")}
          </span>
        </div>
      </div>
      <span
        role="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleShortlist();
        }}
        className={`shrink-0 text-lg ${player.is_shortlisted ? "text-chalk" : "text-text-muted hover:text-chalk"}`}
        title="Shortlist"
      >
        {player.is_shortlisted ? "★" : "☆"}
      </span>
    </button>
  );
}
