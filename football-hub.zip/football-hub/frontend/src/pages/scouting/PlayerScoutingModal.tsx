import { useState } from "react";
import { Link } from "react-router-dom";

import { mediaUrl } from "../../api/client";
import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { ATTRIBUTE_LABELS, TRANSFER_STATUS_COLORS, TRANSFER_STATUS_LABELS } from "../../types";
import type { PlayerAttributes, ScoutingPlayer, Team } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

function AttributeBar({ label, value }: { label: string; value: number | null | undefined }) {
  const pct = value != null ? (value / 10) * 100 : 0;
  return (
    <div>
      <div className="mb-0.5 flex justify-between text-xs">
        <span className="text-text-muted">{label}</span>
        <span className="font-mono text-text-primary">{value != null ? value.toFixed(1) : "—"}</span>
      </div>
      <div className="h-1.5 w-full rounded-full bg-surface-raised">
        <div className="h-1.5 rounded-full bg-chalk" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function PlayerScoutingModal({
  player,
  isOpen,
  onClose,
  onToggleShortlist,
  canClaim,
  isClaiming,
  onClaim,
  canOffer,
  myTeams,
  onSendOffer,
}: {
  player: ScoutingPlayer | null;
  isOpen: boolean;
  onClose: () => void;
  onToggleShortlist: () => void;
  canClaim?: boolean;
  isClaiming?: boolean;
  onClaim?: () => void;
  canOffer?: boolean;
  myTeams?: Team[];
  onSendOffer?: (teamId: string, years?: number, salary?: string, bonus?: string) => Promise<void>;
}) {
  const { t } = useLanguage();
  const [showOfferForm, setShowOfferForm] = useState(false);
  const [offerTeamId, setOfferTeamId] = useState("");
  const [offerYears, setOfferYears] = useState("");
  const [offerSalary, setOfferSalary] = useState("");
  const [offerBonus, setOfferBonus] = useState("");
  const [isSendingOffer, setIsSendingOffer] = useState(false);

  if (!player) return null;
  const attrs: PlayerAttributes = player.attributes || {};

  async function handleSendOffer() {
    if (!onSendOffer || !offerTeamId) return;
    setIsSendingOffer(true);
    try {
      await onSendOffer(
        offerTeamId,
        offerYears ? Number(offerYears) : undefined,
        offerSalary || undefined,
        offerBonus || undefined
      );
      setShowOfferForm(false);
      setOfferYears("");
      setOfferSalary("");
      setOfferBonus("");
    } finally {
      setIsSendingOffer(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t("playerScoutingModal.title")} wide>
      {canClaim && (
        <div className="mb-4 flex items-center justify-between rounded-md border border-chalk/40 bg-chalk/10 px-3 py-2">
          <p className="text-xs text-text-primary">{t("playerScoutingModal.isThisYou")}</p>
          <Button variant="secondary" onClick={onClaim} isLoading={isClaiming}>
            {t("playerScoutingModal.claimButton")}
          </Button>
        </div>
      )}
      <div className="flex flex-col items-center gap-3 text-center sm:flex-row sm:items-start sm:text-left">
        <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-2xl text-text-muted">
          {player.photo_path ? (
            <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
          ) : (
            `${player.first_name[0] ?? ""}${player.last_name[0] ?? ""}`
          )}
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
            <h3 className="font-display text-lg text-text-primary">
              {player.first_name} {player.last_name}
            </h3>
            <span
              className={`rounded-full border px-2 py-0.5 text-xs ${TRANSFER_STATUS_COLORS[player.transfer_status]}`}
            >
              {TRANSFER_STATUS_LABELS[player.transfer_status]}
            </span>
          </div>
          <p className="mt-1 text-sm text-text-muted">
            {[
              player.position,
              player.age ? `${player.age}${t("players.yearsOldSuffix")}` : null,
              player.nationality,
              player.team_name,
              player.height_cm ? `${player.height_cm}cm` : null,
            ]
              .filter(Boolean)
              .join(" · ") || "—"}
          </p>
          {player.transfer_notes && (
            <p className="mt-2 text-xs text-text-muted">💬 {player.transfer_notes}</p>
          )}
        </div>
        <button
          onClick={onToggleShortlist}
          className={`text-2xl ${player.is_shortlisted ? "text-chalk" : "text-text-muted hover:text-chalk"}`}
          title="Shortlist"
        >
          {player.is_shortlisted ? "★" : "☆"}
        </button>
      </div>

      <div className="mt-5 grid grid-cols-4 gap-2 border-t border-line pt-4 text-center">
        <div className="rounded-md border border-line bg-surface-raised py-2">
          <p className="font-display text-lg text-chalk">{player.season_stats.matches_played}</p>
          <p className="text-[10px] uppercase text-text-muted">{t("performance.matches")}</p>
        </div>
        <div className="rounded-md border border-line bg-surface-raised py-2">
          <p className="font-display text-lg text-chalk">{player.season_stats.goals}</p>
          <p className="text-[10px] uppercase text-text-muted">{t("performance.goals")}</p>
        </div>
        <div className="rounded-md border border-line bg-surface-raised py-2">
          <p className="font-display text-lg text-chalk">{player.season_stats.assists}</p>
          <p className="text-[10px] uppercase text-text-muted">{t("performance.assists")}</p>
        </div>
        <div className="rounded-md border border-line bg-surface-raised py-2">
          <p className="font-display text-lg text-chalk">
            {player.season_stats.avg_rating != null ? player.season_stats.avg_rating.toFixed(1) : "—"}
          </p>
          <p className="text-[10px] uppercase text-text-muted">{t("playerScoutingModal.avgRating")}</p>
        </div>
      </div>

      <div className="mt-5 border-t border-line pt-4">
        <h4 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
          {t("playerScoutingModal.attributesHeading")}
        </h4>
        {Object.values(attrs).every((v) => v == null) ? (
          <p className="text-xs text-text-muted">{t("playerScoutingModal.notRatedYet")}</p>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {(Object.keys(ATTRIBUTE_LABELS) as (keyof PlayerAttributes)[]).map((key) => (
              <AttributeBar key={key} label={ATTRIBUTE_LABELS[key]} value={attrs[key]} />
            ))}
          </div>
        )}
      </div>

      {canOffer && player.linked_user_id && (
        <div className="mt-5 border-t border-line pt-4">
          {!showOfferForm ? (
            <Button variant="secondary" onClick={() => setShowOfferForm(true)}>
              {t("playerScoutingModal.sendContractOffer")}
            </Button>
          ) : (
            <div className="space-y-3 rounded-md border border-line bg-surface-raised p-3">
              <h4 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerScoutingModal.contractOfferHeading")}
              </h4>
              <Select
                label={t("crm.team")}
                value={offerTeamId}
                onChange={(e) => setOfferTeamId(e.target.value)}
              >
                <option value="">{t("crm.selectTeam")}</option>
                {(myTeams || []).map((teamOpt) => (
                  <option key={teamOpt.id} value={teamOpt.id}>
                    {teamOpt.name}
                  </option>
                ))}
              </Select>
              <Input
                label={t("playerScoutingModal.contractYears")}
                type="number"
                value={offerYears}
                onChange={(e) => setOfferYears(e.target.value)}
              />
              <Textarea
                label={t("playerScoutingModal.financialTermsOptional")}
                placeholder={t("playerScoutingModal.financialTermsPlaceholder")}
                value={offerSalary}
                onChange={(e) => setOfferSalary(e.target.value)}
              />
              <Textarea
                label={t("playerScoutingModal.bonusPerksOptional")}
                placeholder={t("playerScoutingModal.bonusPlaceholder")}
                value={offerBonus}
                onChange={(e) => setOfferBonus(e.target.value)}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setShowOfferForm(false)}>
                  {t("common.cancel")}
                </Button>
                <Button
                  type="button"
                  onClick={handleSendOffer}
                  isLoading={isSendingOffer}
                  disabled={!offerTeamId}
                >
                  {t("playerScoutingModal.sendOffer")}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {player.team_id && (
        <div className="mt-5 flex justify-end border-t border-line pt-4">
          <Link to={`/teams/${player.team_id}`}>
            <Button variant="secondary">{t("playerScoutingModal.viewTeam")}</Button>
          </Link>
        </div>
      )}
    </Modal>
  );
}
