import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { mediaUrl, extractErrorMessage } from "../../api/client";
import { startConversationWithScoutingStaff } from "../../api/scouting";
import { Button } from "../../components/ui/Button";
import { Modal } from "../../components/ui/Modal";
import { StaffOfferModal } from "../../components/StaffOfferModal";
import { useToast } from "../../components/ui/Toast";
import { STAFF_AVAILABILITY_LABELS, VERIFICATION_LEVEL_INFO } from "../../types";
import type { ScoutingStaff, Team } from "../../types";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";

export function StaffScoutingModal({
  staff,
  isOpen,
  onClose,
  myTeams = [],
}: {
  staff: ScoutingStaff | null;
  isOpen: boolean;
  onClose: () => void;
  myTeams?: Team[];
}) {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [isStartingConversation, setIsStartingConversation] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [localOfferSent, setLocalOfferSent] = useState(false);

  useEffect(() => {
    setLocalOfferSent(false);
  }, [staff?.id]);
  // Οποιοσδήποτε πραγματικά διαχειρίζεται έστω μία ομάδα (owner ή με
  // πρόσβαση διαχείρισης) μπορεί να κάνει προσφορά — όχι μόνο
  // president/technical_director, ώστε π.χ. ένας head_coach με πρόσβαση
  // σε ομάδα να μπορεί επίσης να προτείνει έναν συνεργάτη.
  const canSendOffer = myTeams.length > 0;
  const ROLE_LABELS: Record<string, string> = {
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
  };
  if (!staff) return null;

  async function handleStartConversation() {
    if (!staff) return;
    setIsStartingConversation(true);
    try {
      const conversation = await startConversationWithScoutingStaff(staff.id);
      onClose();
      navigate(`/messages?conversation_id=${conversation.id}`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsStartingConversation(false);
    }
  }

  return (
    <>
    <Modal isOpen={isOpen} onClose={onClose} title={t("staff.profileTitle")} wide>
      <div className="flex flex-col items-center gap-3 text-center sm:flex-row sm:items-start sm:text-left">
        <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-2xl text-text-muted">
          {staff.avatar_path ? (
            <img src={mediaUrl(staff.avatar_path)} alt="" className="h-full w-full object-cover" />
          ) : (
            (staff.full_name || "?").charAt(0).toUpperCase()
          )}
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
            <h3 className="font-display text-lg text-text-primary">{staff.full_name || "—"}</h3>
            <span
              className={`flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] ${VERIFICATION_LEVEL_INFO[staff.verification_level]?.color || VERIFICATION_LEVEL_INFO[0].color}`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${VERIFICATION_LEVEL_INFO[staff.verification_level]?.dot || VERIFICATION_LEVEL_INFO[0].dot}`}
              />
              {VERIFICATION_LEVEL_INFO[staff.verification_level]?.label || VERIFICATION_LEVEL_INFO[0].label}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-chalk">{ROLE_LABELS[staff.role] || staff.role}</p>
            {staff.staff_availability !== "not_listed" && (
              <span
                className={`rounded-full border px-2 py-0.5 text-xs ${
                  staff.staff_availability === "available"
                    ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                    : "border-status-doubtful/40 bg-status-doubtful/10 text-status-doubtful"
                }`}
              >
                {STAFF_AVAILABILITY_LABELS[staff.staff_availability]}
              </span>
            )}
            {staff.desired_staff_role && (
              <span className="rounded-full border border-chalk/30 bg-chalk/10 px-2 py-0.5 text-xs text-chalk">
                {t("staff.seekingPrefix")}{ROLE_LABELS[staff.desired_staff_role] || staff.desired_staff_role}
              </span>
            )}
          </div>
          {staff.origin_federation_name && (
            <p className="mt-1 text-xs text-text-muted">
              {t("staff.fromPrefix")}{staff.origin_federation_name}
            </p>
          )}
          {staff.bio && <p className="mt-2 text-sm text-text-muted">{staff.bio}</p>}
          {staff.linkedin_url && (
            <a
              href={staff.linkedin_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-xs text-chalk hover:underline"
            >
              {t("staffScoutingModal.linkedinProfileLink")}
            </a>
          )}
          {user?.id !== staff.id && (
            <div className="mt-3 flex flex-wrap gap-2">
              <Button onClick={handleStartConversation} isLoading={isStartingConversation}>
                💬 {t("staffScoutingModal.contactButton")}
              </Button>
              {canSendOffer &&
                (staff.has_pending_offer_from_me || localOfferSent ? (
                  <span className="inline-flex items-center gap-1.5 rounded-md border border-line px-3 py-1.5 text-sm text-text-muted">
                    ✓ {t("staffScoutingModal.offerAlreadySent")}
                  </span>
                ) : (
                  <Button variant="secondary" onClick={() => setShowOfferModal(true)}>
                    📄 {t("staffScoutingModal.offerButton")}
                  </Button>
                ))}
            </div>
          )}
        </div>
      </div>

      {staff.desired_federation_names && staff.desired_federation_names.length > 0 && (
        <div className="mt-5 border-t border-line pt-4">
          <h4 className="mb-2 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("staff.interestedInHeading")}
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {staff.desired_federation_names.map((name, i) => (
              <span
                key={i}
                className="rounded-full border border-line px-2 py-0.5 text-xs text-text-primary"
              >
                {name}
              </span>
            ))}
          </div>
        </div>
      )}

      {staff.qualifications.length > 0 && (
        <div className="mt-5 border-t border-line pt-4">
          <h4 className="mb-2 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.qualificationsHeading")}
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {staff.qualifications.map((q) => (
              <span
                key={q.id}
                className="rounded-full border border-chalk/30 bg-chalk/10 px-2 py-0.5 text-xs text-chalk"
              >
                {q.title}
                {q.year ? ` (${q.year})` : ""}
              </span>
            ))}
          </div>
        </div>
      )}

      {staff.achievements.length > 0 && (
        <div className="mt-5 border-t border-line pt-4">
          <h4 className="mb-2 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.achievementsHeading")}
          </h4>
          <div className="space-y-1">
            {staff.achievements.map((a) => (
              <p key={a.id} className="text-sm text-text-primary">
                🏆 {a.title}
                {a.year ? ` (${a.year})` : ""}
              </p>
            ))}
          </div>
        </div>
      )}

      {staff.experience.length > 0 && (
        <div className="mt-5 border-t border-line pt-4">
          <h4 className="mb-2 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.experienceHeading")}
          </h4>
          <div className="space-y-1.5">
            {staff.experience.map((e) => (
              <div key={e.id} className="text-sm">
                <span className="text-text-primary">
                  {e.organization}
                  {e.role_title ? ` — ${e.role_title}` : ""}
                </span>
                <span className="ml-2 text-xs text-text-muted">
                  {e.start_year || "—"} - {e.end_year || t("profile.today")}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {staff.teams.length > 0 && (
        <div className="mt-5 border-t border-line pt-4">
          <h4 className="mb-2 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("teams.title")}
          </h4>
          <div className="flex flex-wrap gap-2">
            {staff.teams.map((staffTeam, i) => (
              <Link
                key={i}
                to={`/teams/${staffTeam.team_id}`}
                className="rounded-full border border-line px-2.5 py-1 text-xs text-text-primary hover:border-chalk"
              >
                {staffTeam.team_name}
                {staffTeam.role_title ? ` · ${staffTeam.role_title}` : ""}
              </Link>
            ))}
          </div>
        </div>
      )}
    </Modal>

    <StaffOfferModal
      target={showOfferModal && staff ? { user_id: staff.id, full_name: staff.full_name || "" } : null}
      myTeams={myTeams}
      onClose={() => setShowOfferModal(false)}
      onSent={() => setLocalOfferSent(true)}
    />
    </>
  );
}
