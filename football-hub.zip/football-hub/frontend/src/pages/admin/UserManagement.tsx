import { useEffect, useMemo, useState } from "react";

import type { AdminUserDocumentItem, AdminUserListItem } from "../../api/admin";
import { listAdminUsers } from "../../api/admin";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { listPlayers } from "../../api/players";
import { AppLayout } from "../../components/layout/AppLayout";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Input } from "../../components/ui/Input";
import { useToast } from "../../components/ui/Toast";
import type { Player } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import { DocumentPreviewModal } from "./DocumentPreviewModal";
import { CreateUserModal } from "./CreateUserModal";
import { UserDetailModal } from "./UserDetailModal";

const ROLE_LABEL_KEYS: Record<string, string> = {
  super_admin: "userManagement.roleSuperAdmin",
  admin: "userManagement.roleAdmin",
  president: "crm.rolePresident",
  technical_director: "crm.roleTechnicalDirector",
  head_coach: "crm.roleHeadCoach",
  assistant_coach: "crm.roleAssistantCoach",
  fitness_coach: "crm.roleFitnessCoach",
  analyst: "crm.roleAnalyst",
  scout: "userManagement.roleScout",
  player: "userManagement.rolePlayer",
};

export default function UserManagement() {
  const { t } = useLanguage();
  const toast = useToast();
  const [users, setUsers] = useState<AdminUserListItem[]>([]);
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<"all" | "needs_approval" | "pending_docs">("all");
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [previewDoc, setPreviewDoc] = useState<AdminUserDocumentItem | null>(null);
  const [showCreateUser, setShowCreateUser] = useState(false);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listAdminUsers();
      setUsers(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    listPlayers()
      .then(setAllPlayers)
      .catch(() => {
        /* σιωπηλή αποτυχία */
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredSortedUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    let filtered = q
      ? users.filter(
          (u) =>
            (u.full_name || "").toLowerCase().includes(q) ||
            u.username.toLowerCase().includes(q) ||
            u.email.toLowerCase().includes(q)
        )
      : users;
    if (activeFilter === "needs_approval") {
      filtered = filtered.filter((u) => u.needs_approval);
    } else if (activeFilter === "pending_docs") {
      filtered = filtered.filter((u) => u.documents.some((d) => d.status === "pending"));
    }
    return [...filtered].sort((a, b) => {
      if (a.needs_approval !== b.needs_approval) return a.needs_approval ? -1 : 1;
      const nameA = (a.full_name || a.username).toLowerCase();
      const nameB = (b.full_name || b.username).toLowerCase();
      return nameA.localeCompare(nameB, "el");
    });
  }, [users, searchQuery, activeFilter]);

  const stats = useMemo(() => {
    const needsApprovalCount = users.filter((u) => u.needs_approval).length;
    const pendingDocsCount = users.reduce(
      (sum, u) => sum + u.documents.filter((d) => d.status === "pending").length,
      0
    );
    return { total: users.length, needsApprovalCount, pendingDocsCount };
  }, [users]);

  const selectedUser = users.find((u) => u.id === selectedUserId) || null;

  return (
    <AppLayout title={t("userManagement.pageTitle")}>
      <div className="space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <p className="max-w-2xl text-sm text-text-muted">{t("userManagement.pageIntro")}</p>
          <button
            type="button"
            onClick={() => setShowCreateUser(true)}
            className="shrink-0 rounded-md bg-chalk px-4 py-2 text-sm font-semibold text-void hover:opacity-90"
          >
            + {t("createUserModal.openButton")}
          </button>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Card
            corners
            onClick={() => setActiveFilter("all")}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setActiveFilter("all");
            }}
            className={`cursor-pointer p-4 transition-colors hover:border-chalk ${
              activeFilter === "all" ? "border-chalk" : ""
            }`}
          >
            <p className="text-xs uppercase tracking-wide text-text-muted">{t("userManagement.statTotalUsers")}</p>
            <p className="mt-1 font-display text-2xl text-text-primary">{stats.total}</p>
          </Card>
          <Card
            corners
            onClick={() => setActiveFilter((prev) => (prev === "needs_approval" ? "all" : "needs_approval"))}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ")
                setActiveFilter((prev) => (prev === "needs_approval" ? "all" : "needs_approval"));
            }}
            className={`cursor-pointer p-4 transition-colors hover:border-chalk ${
              activeFilter === "needs_approval" ? "border-chalk" : ""
            }`}
          >
            <p className="text-xs uppercase tracking-wide text-text-muted">
              {t("userManagement.statNeedsApproval")}
            </p>
            <p
              className={`mt-1 font-display text-2xl ${stats.needsApprovalCount > 0 ? "text-status-injured" : "text-text-primary"}`}
            >
              {stats.needsApprovalCount}
            </p>
          </Card>
          <Card
            corners
            onClick={() => setActiveFilter((prev) => (prev === "pending_docs" ? "all" : "pending_docs"))}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ")
                setActiveFilter((prev) => (prev === "pending_docs" ? "all" : "pending_docs"));
            }}
            className={`cursor-pointer p-4 transition-colors hover:border-chalk ${
              activeFilter === "pending_docs" ? "border-chalk" : ""
            }`}
          >
            <p className="text-xs uppercase tracking-wide text-text-muted">
              {t("userManagement.statPendingDocuments")}
            </p>
            <p
              className={`mt-1 font-display text-2xl ${stats.pendingDocsCount > 0 ? "text-status-doubtful" : "text-text-primary"}`}
            >
              {stats.pendingDocsCount}
            </p>
          </Card>
        </div>

        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t("userManagement.searchPlaceholder")}
        />

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner />
          </div>
        ) : filteredSortedUsers.length === 0 ? (
          <EmptyState
            title={t("userManagement.noUsersFound")}
            description={
              searchQuery || activeFilter !== "all" ? t("userManagement.tryDifferentSearch") : undefined
            }
          />
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {filteredSortedUsers.map((u) => {
              const pendingDocsForUser = u.documents.filter((d) => d.status === "pending").length;
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setSelectedUserId(u.id)}
                  className={`flex items-start gap-3 rounded-lg border p-4 text-left transition-colors hover:border-chalk ${
                    u.needs_approval ? "border-status-injured/50 bg-status-injured/5" : "border-line bg-surface"
                  }`}
                >
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm text-text-muted">
                    {u.avatar_path ? (
                      <img src={mediaUrl(u.avatar_path)} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (u.full_name || u.username).charAt(0).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <p className="truncate text-sm font-semibold text-text-primary">
                        {u.full_name || u.username}
                      </p>
                      {!u.is_active && (
                        <span className="shrink-0 rounded-full bg-status-injured/15 px-1.5 py-px text-[9px] font-semibold uppercase text-status-injured">
                          {t("userManagement.statusInactive")}
                        </span>
                      )}
                    </div>
                    <p className="truncate text-xs text-text-muted">@{u.username}</p>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      <span className="rounded-full border border-line px-2 py-0.5 text-[10px] text-text-muted">
                        {t(ROLE_LABEL_KEYS[u.role] || u.role)}
                      </span>
                      {u.needs_approval && (
                        <span className="rounded-full border border-status-injured/40 bg-status-injured/15 px-2 py-0.5 text-[10px] font-semibold uppercase text-status-injured">
                          {t("userManagement.needsApprovalBadge")}
                        </span>
                      )}
                      {pendingDocsForUser > 0 && (
                        <span className="rounded-full border border-status-doubtful/40 bg-status-doubtful/15 px-2 py-0.5 text-[10px] font-semibold text-status-doubtful">
                          📄 {pendingDocsForUser}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <UserDetailModal
        user={selectedUser}
        allPlayers={allPlayers}
        onClose={() => setSelectedUserId(null)}
        onActionComplete={load}
        onPreviewDocument={setPreviewDoc}
      />
      <DocumentPreviewModal doc={previewDoc} onClose={() => setPreviewDoc(null)} />
      <CreateUserModal isOpen={showCreateUser} onClose={() => setShowCreateUser(false)} onCreated={load} />
    </AppLayout>
  );
}
