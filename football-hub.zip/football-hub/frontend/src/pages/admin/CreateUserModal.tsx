import { useState } from "react";

import type { AdminCreateUserPayload } from "../../api/admin";
import { adminCreateUser } from "../../api/admin";
import { extractErrorMessage } from "../../api/client";
import { Button } from "../../components/ui/Button";
import { DateField } from "../../components/ui/DateField";
import { Input, Select } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";

const ROLE_VALUES = [
  "super_admin",
  "admin",
  "president",
  "technical_director",
  "head_coach",
  "assistant_coach",
  "fitness_coach",
  "analyst",
  "scout",
  "player",
];

const LEADERSHIP_ROLES = new Set(["president", "technical_director"]);

const PASSWORD_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%";

function generatePassword(length = 12): string {
  let out = "";
  const array = new Uint32Array(length);
  crypto.getRandomValues(array);
  for (let i = 0; i < length; i++) {
    out += PASSWORD_CHARS[array[i] % PASSWORD_CHARS.length];
  }
  return out;
}

export function CreateUserModal({
  isOpen,
  onClose,
  onCreated,
}: {
  isOpen: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const { t } = useLanguage();
  const toast = useToast();

  const ROLE_LABELS: Record<string, string> = {
    super_admin: t("userManagement.roleSuperAdmin"),
    admin: t("userManagement.roleAdmin"),
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
    player: t("userManagement.rolePlayer"),
  };

  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState(() => generatePassword());
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState("player");
  const [taxId, setTaxId] = useState("");
  const [phone, setPhone] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdAccount, setCreatedAccount] = useState<{ username: string; password: string; role: string } | null>(
    null
  );

  function resetForm() {
    setEmail("");
    setUsername("");
    setPassword(generatePassword());
    setFullName("");
    setRole("player");
    setTaxId("");
    setPhone("");
    setDateOfBirth("");
    setCreatedAccount(null);
  }

  function handleClose() {
    resetForm();
    onClose();
  }

  async function handleCopy(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      toast.show(t("createUserModal.copiedToast").replace("{label}", label), "success");
    } catch {
      /* σιωπηλή αποτυχία — ο admin μπορεί πάντα να επιλέξει/αντιγράψει χειροκίνητα */
    }
  }

  async function handleSubmit() {
    if (!email.trim() || !username.trim() || password.length < 8) return;
    setIsSubmitting(true);
    try {
      const payload: AdminCreateUserPayload = {
        email: email.trim(),
        username: username.trim(),
        password,
        full_name: fullName.trim() || undefined,
        role,
        tax_id: LEADERSHIP_ROLES.has(role) && taxId.trim() ? taxId.trim() : undefined,
        phone: phone.trim() || undefined,
        date_of_birth: dateOfBirth || undefined,
      };
      await adminCreateUser(payload);
      setCreatedAccount({ username: payload.username, password, role });
      onCreated();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title={t("createUserModal.title")} wide>
      {createdAccount ? (
        <div className="space-y-4">
          <div className="rounded-lg border border-status-fit/40 bg-status-fit/10 p-4 text-center">
            <p className="text-3xl">✅</p>
            <p className="mt-2 font-display text-base text-text-primary">{t("createUserModal.successHeading")}</p>
            <p className="mt-1 text-xs text-text-muted">{t("createUserModal.successHint")}</p>
          </div>
          <div className="space-y-3 rounded-lg border border-line bg-surface-raised p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-wide text-text-muted">
                  {t("createUserModal.usernameLabel")}
                </p>
                <p className="font-mono text-lg text-text-primary">{createdAccount.username}</p>
              </div>
              <Button
                type="button"
                variant="secondary"
                onClick={() => handleCopy(createdAccount.username, t("createUserModal.usernameLabel"))}
              >
                📋 {t("createUserModal.copyButton")}
              </Button>
            </div>
            <div className="flex items-center justify-between gap-3 border-t border-line pt-3">
              <div>
                <p className="text-xs uppercase tracking-wide text-text-muted">
                  {t("createUserModal.passwordLabel")}
                </p>
                <p className="font-mono text-lg text-text-primary">{createdAccount.password}</p>
              </div>
              <Button
                type="button"
                variant="secondary"
                onClick={() => handleCopy(createdAccount.password, t("createUserModal.passwordLabel"))}
              >
                📋 {t("createUserModal.copyButton")}
              </Button>
            </div>
            <p className="border-t border-line pt-3 text-xs text-text-muted">
              {ROLE_LABELS[createdAccount.role] || createdAccount.role}
            </p>
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={resetForm}>
              {t("createUserModal.createAnotherButton")}
            </Button>
            <Button type="button" onClick={handleClose}>
              {t("createUserModal.doneButton")}
            </Button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-sm text-text-muted">{t("createUserModal.intro")}</p>
          <p className="rounded-md border border-status-doubtful/40 bg-status-doubtful/10 px-3 py-2 text-xs text-status-doubtful">
            ⚠️ {t("createUserModal.notSavedYetWarning")}
          </p>

          <Select label={t("userManagement.roleLabel")} value={role} onChange={(e) => setRole(e.target.value)}>
            {ROLE_VALUES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABELS[r]}
              </option>
            ))}
          </Select>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              label={t("createUserModal.fullNameLabel")}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
            <Input
              label={t("createUserModal.emailLabel")}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Input
              label={t("createUserModal.usernameLabel")}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <div>
              <span className="mb-1.5 block text-xs font-medium text-text-muted">
                {t("createUserModal.passwordLabel")}
              </span>
              <div className="flex gap-2">
                <input
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full flex-1 rounded-md border border-line bg-surface px-3 py-2 font-mono text-sm text-text-primary focus:border-chalk focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setPassword(generatePassword())}
                  className="shrink-0 rounded-md border border-line px-3 text-sm text-text-primary hover:border-chalk"
                  title={t("createUserModal.regenerateButton")}
                >
                  🎲
                </button>
              </div>
              <span className="mt-1 block text-xs text-text-muted">{t("createUserModal.passwordHint")}</span>
            </div>
          </div>

          {LEADERSHIP_ROLES.has(role) && (
            <Input
              label={t("createUserModal.taxIdLabel")}
              hint={t("createUserModal.taxIdHint")}
              value={taxId}
              onChange={(e) => setTaxId(e.target.value)}
              placeholder="123456789"
            />
          )}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Input
              label={t("profile.phoneLabel")}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="69XXXXXXXX"
            />
            <DateField label={t("profile.dateOfBirthLabel")} value={dateOfBirth} onChange={setDateOfBirth} />
          </div>

          <div className="flex justify-end gap-2 border-t border-line pt-4">
            <Button type="button" variant="secondary" onClick={handleClose}>
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              onClick={handleSubmit}
              isLoading={isSubmitting}
              disabled={!email.trim() || !username.trim() || password.length < 8}
            >
              {t("createUserModal.createButton")}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
