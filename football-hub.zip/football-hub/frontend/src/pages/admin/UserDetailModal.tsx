import { useEffect, useState } from "react";

import type { AdminUserDocumentItem, AdminUserListItem } from "../../api/admin";
import { updateUserActiveStatus } from "../../api/admin";
import { approveLeadership, updateUserRole } from "../../api/auth";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { linkUserToPlayer } from "../../api/scouting";
import { reviewDocument } from "../../api/verification";
import { Button } from "../../components/ui/Button";
import { Select } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import type { Player } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

const ROLE_VALUES = [
  "super_admin",
  "admin",
  "president",
  "technical_director",
  "head_coach",
  "assistant_coach",
  "fitness_coach",
  "analyst",
  "scout",
  "player",
];

const DOC_TYPE_KEYS: Record<string, string> = {
  id_document: "userManagement.docTypeId",
  coaching_license: "userManagement.docTypeCoachingLicense",
  reference_letter: "userManagement.docTypeReferenceLetter",
  club_registration: "userManagement.docTypeClubRegistration",
};

const STATUS_KEYS: Record<string, string> = {
  pending: "userManagement.docStatusPending",
  approved: "userManagement.docStatusApproved",
  rejected: "userManagement.docStatusRejected",
};

export function UserDetailModal({
  user,
  allPlayers,
  onClose,
  onActionComplete,
  onPreviewDocument,
}: {
  user: AdminUserListItem | null;
  allPlayers: Player[];
  onClose: () => void;
  onActionComplete: () => void;
  onPreviewDocument: (doc: AdminUserDocumentItem) => void;
}) {
  const { t } = useLanguage();
  const toast = useToast();
  const [role, setRole] = useState("player");
  const [isSavingRole, setIsSavingRole] = useState(false);
  const [isTogglingActive, setIsTogglingActive] = useState(false);
  const [isApprovingLeadership, setIsApprovingLeadership] = useState(false);
  const [reviewingDocId, setReviewingDocId] = useState<string | null>(null);
  const [linkSelection, setLinkSelection] = useState("");
  const [isLinking, setIsLinking] = useState(false);

  const ROLE_LABELS: Record<string, string> = {
    super_admin: t("userManagement.roleSuperAdmin"),
    admin: t("userManagement.roleAdmin"),
    president: t("crm.rolePresident"),
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
    player: t("userManagement.rolePlayer"),
  };

  useEffect(() => {
    if (user) {
      setRole(user.role);
      setLinkSelection(user.linked_player_id || "");
    }
  }, [user?.id, user?.role, user?.linked_player_id]);

  async function handleSaveRole() {
    if (!user) return;
    setIsSavingRole(true);
    try {
      await updateUserRole(user.id, role);
      toast.show(t("userManagement.roleSaved"), "success");
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingRole(false);
    }
  }

  async function handleToggleActive() {
    if (!user) return;
    setIsTogglingActive(true);
    try {
      await updateUserActiveStatus(user.id, !user.is_active);
      toast.show(
        !user.is_active ? t("userManagement.userActivated") : t("userManagement.userDeactivated"),
        "success"
      );
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsTogglingActive(false);
    }
  }

  async function handleApproveLeadership() {
    if (!user) return;
    setIsApprovingLeadership(true);
    try {
      await approveLeadership(user.id);
      toast.show(t("userManagement.leadershipApproved"), "success");
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsApprovingLeadership(false);
    }
  }

  async function handleLinkPlayer() {
    if (!user || !linkSelection) return;
    setIsLinking(true);
    try {
      await linkUserToPlayer(user.id, linkSelection);
      toast.show(t("userManagement.playerLinked"), "success");
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLinking(false);
    }
  }

  async function handleReviewDocument(docId: string, approve: boolean) {
    setReviewingDocId(docId);
    try {
      await reviewDocument(docId, approve);
      toast.show(approve ? t("userManagement.documentApproved") : t("userManagement.documentRejected"), "success");
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setReviewingDocId(null);
    }
  }

  return (
    <Modal isOpen={!!user} onClose={onClose} title={t("userManagement.detailModalTitle")} wide>
      {user && (
        <div className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xl text-text-muted">
              {user.avatar_path ? (
                <img src={mediaUrl(user.avatar_path)} alt="" className="h-full w-full object-cover" />
              ) : (
                (user.full_name || user.username).charAt(0).toUpperCase()
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-lg text-text-primary">
                {user.full_name || user.username}
              </p>
              <p className="truncate text-sm text-text-muted">@{user.username}</p>
              <p className="truncate text-sm text-text-muted">{user.email}</p>
            </div>
            <span
              className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                user.is_active
                  ? "bg-status-fit/15 text-status-fit"
                  : "bg-status-injured/15 text-status-injured"
              }`}
            >
              {user.is_active ? t("userManagement.statusActive") : t("userManagement.statusInactive")}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 rounded-md border border-line bg-surface-raised p-3 text-sm">
            <div>
              <p className="text-xs text-text-muted">{t("profile.phoneLabel")}</p>
              <p className="text-text-primary">{user.phone || "—"}</p>
            </div>
            <div>
              <p className="text-xs text-text-muted">{t("profile.dateOfBirthLabel")}</p>
              <p className="text-text-primary">
                {user.date_of_birth ? new Date(user.date_of_birth).toLocaleDateString("el-GR") : "—"}
              </p>
            </div>
            <div>
              <p className="text-xs text-text-muted">{t("userManagement.memberSince")}</p>
              <p className="text-text-primary">{new Date(user.created_at).toLocaleDateString("el-GR")}</p>
            </div>
            <div>
              <p className="text-xs text-text-muted">{t("userManagement.verificationLevelLabel")}</p>
              <p className="text-text-primary">{user.verification_level}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-end gap-2 border-t border-line pt-4">
            <Select
              label={t("userManagement.roleLabel")}
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="flex-1"
            >
              {ROLE_VALUES.map((r) => (
                <option key={r} value={r}>
                  {ROLE_LABELS[r]}
                </option>
              ))}
            </Select>
            <Button onClick={handleSaveRole} isLoading={isSavingRole} disabled={role === user.role}>
              {t("userManagement.saveRole")}
            </Button>
            <Button variant="secondary" onClick={handleToggleActive} isLoading={isTogglingActive}>
              {user.is_active ? t("userManagement.deactivate") : t("userManagement.activate")}
            </Button>
            {user.needs_approval && (
              <Button onClick={handleApproveLeadership} isLoading={isApprovingLeadership}>
                ✓ {t("userManagement.approveLeadershipButton")}
              </Button>
            )}
          </div>

          {user.role === "player" && (
            <div className="flex flex-wrap items-end gap-2 border-t border-line pt-4">
              <Select
                label={t("settings.linkWithPlayer")}
                value={linkSelection}
                onChange={(e) => setLinkSelection(e.target.value)}
                className="flex-1"
              >
                <option value="">{t("settings.selectPlayerOption")}</option>
                {allPlayers.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.first_name} {p.last_name}
                    {p.team_name ? ` (${p.team_name})` : ""}
                  </option>
                ))}
              </Select>
              <Button
                variant="secondary"
                onClick={handleLinkPlayer}
                isLoading={isLinking}
                disabled={!linkSelection || linkSelection === user.linked_player_id}
              >
                {t("settings.link")}
              </Button>
              {user.linked_player_id && (
                <span className="text-xs text-status-fit">{t("settings.linked")}</span>
              )}
            </div>
          )}

          <div className="border-t border-line pt-4">
            <h3 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("userManagement.documentsHeading")} ({user.documents.length})
            </h3>
            {user.documents.length === 0 ? (
              <p className="text-sm text-text-muted">{t("userManagement.noDocuments")}</p>
            ) : (
              <div className="space-y-2">
                {user.documents.map((d) => (
                  <div
                    key={d.id}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-line px-3 py-2 text-sm"
                  >
                    <button
                      type="button"
                      onClick={() => onPreviewDocument(d)}
                      className="flex-1 text-left text-text-primary hover:text-chalk hover:underline"
                    >
                      📄 {t(DOC_TYPE_KEYS[d.document_type] || d.document_type)}
                    </button>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                        d.status === "approved"
                          ? "bg-status-fit/15 text-status-fit"
                          : d.status === "rejected"
                            ? "bg-status-injured/15 text-status-injured"
                            : "bg-status-doubtful/15 text-status-doubtful"
                      }`}
                    >
                      {t(STATUS_KEYS[d.status] || d.status)}
                    </span>
                    {d.status === "pending" && (
                      <div className="flex gap-1.5">
                        <button
                          type="button"
                          disabled={reviewingDocId === d.id}
                          onClick={() => handleReviewDocument(d.id, true)}
                          className="rounded border border-status-fit/40 px-2 py-1 text-xs text-status-fit hover:bg-status-fit/10 disabled:opacity-50"
                        >
                          ✓ {t("userManagement.approve")}
                        </button>
                        <button
                          type="button"
                          disabled={reviewingDocId === d.id}
                          onClick={() => handleReviewDocument(d.id, false)}
                          className="rounded border border-status-injured/40 px-2 py-1 text-xs text-status-injured hover:bg-status-injured/10 disabled:opacity-50"
                        >
                          ✕ {t("userManagement.reject")}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}
