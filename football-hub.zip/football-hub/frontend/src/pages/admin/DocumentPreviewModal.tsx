import { useEffect, useState } from "react";

import { fetchDocumentBlob } from "../../api/admin";
import type { AdminUserDocumentItem } from "../../api/admin";
import { extractErrorMessage } from "../../api/client";
import { Spinner } from "../../components/ui/EmptyState";
import { Modal } from "../../components/ui/Modal";
import { useLanguage } from "../../context/LanguageContext";

export function DocumentPreviewModal({
  doc,
  onClose,
}: {
  doc: AdminUserDocumentItem | null;
  onClose: () => void;
}) {
  const { t } = useLanguage();
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let currentUrl: string | null = null;
    let cancelled = false;
    setObjectUrl(null);
    setError(null);
    if (!doc) return;

    setIsLoading(true);
    fetchDocumentBlob(doc.id)
      .then((blob) => {
        if (cancelled) return;
        currentUrl = URL.createObjectURL(blob);
        setObjectUrl(currentUrl);
      })
      .catch((err) => {
        if (!cancelled) setError(extractErrorMessage(err));
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
      if (currentUrl) URL.revokeObjectURL(currentUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc?.id]);

  const isPdf = doc?.content_type === "application/pdf";

  return (
    <Modal isOpen={!!doc} onClose={onClose} title={t("userManagement.documentPreviewTitle")} wide>
      {isLoading && (
        <div className="flex justify-center py-16">
          <Spinner />
        </div>
      )}
      {error && <p className="py-8 text-center text-sm text-status-injured">{error}</p>}
      {!isLoading && !error && objectUrl && (
        <>
          {isPdf ? (
            <iframe
              src={objectUrl}
              title="document-preview"
              className="h-[70vh] w-full rounded-md border border-line bg-surface"
            />
          ) : (
            <img
              src={objectUrl}
              alt="document-preview"
              className="mx-auto max-h-[70vh] rounded-md border border-line"
            />
          )}
        </>
      )}
    </Modal>
  );
}
