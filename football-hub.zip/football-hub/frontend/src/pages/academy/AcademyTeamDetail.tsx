import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

import {
  applyKitTemplate,
  createAnnouncement,
  deleteAnnouncement,
  exportAcademyExcel,
  exportAcademyPdf,
  getFeeSettings,
  listAcademyPlayers,
  listAnnouncements,
  updateFeeSettings,
} from "../../api/academy";
import type { AcademyAnnouncement, AcademyFeeSettings, AcademyPlayerSummary } from "../../api/academy";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { getTeam } from "../../api/teams";
import type { Team } from "../../types";
import { AppLayout } from "../../components/layout/AppLayout";
import { ExportMenu } from "../../components/ExportMenu";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Input, Textarea } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import { buildAnnouncementMessage, viberForwardLink, whatsappShareLink } from "../../utils/academyMessages";
import { AcademyPlayerModal } from "./AcademyPlayerModal";

export default function AcademyTeamDetail() {
  const { teamId } = useParams<{ teamId: string }>();
  const toast = useToast();
  const { t } = useLanguage();

  const [team, setTeam] = useState<Team | null>(null);
  const [players, setPlayers] = useState<AcademyPlayerSummary[]>([]);
  const [settings, setSettings] = useState<AcademyFeeSettings | null>(null);
  const [announcements, setAnnouncements] = useState<AcademyAnnouncement[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);

  const [showSettings, setShowSettings] = useState(false);
  const [monthlyFee, setMonthlyFee] = useState("");
  const [annualFee, setAnnualFee] = useState("");
  const [registrationFee, setRegistrationFee] = useState("");
  const [dueDay, setDueDay] = useState("10");
  const [kitTemplate, setKitTemplate] = useState<string[]>([]);
  const [newKitTemplateItem, setNewKitTemplateItem] = useState("");
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [isApplyingTemplate, setIsApplyingTemplate] = useState(false);

  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [annTitle, setAnnTitle] = useState("");
  const [annDescription, setAnnDescription] = useState("");
  const [annDate, setAnnDate] = useState("");
  const [annTime, setAnnTime] = useState("");
  const [annLocation, setAnnLocation] = useState("");
  const [annMapsUrl, setAnnMapsUrl] = useState("");
  const [isSavingAnnouncement, setIsSavingAnnouncement] = useState(false);
  const [deleteAnnTarget, setDeleteAnnTarget] = useState<AcademyAnnouncement | null>(null);

  async function load() {
    if (!teamId) return;
    setIsLoading(true);
    try {
      const [teamData, p, s, a] = await Promise.all([
        getTeam(teamId),
        listAcademyPlayers(teamId),
        getFeeSettings(teamId),
        listAnnouncements(teamId),
      ]);
      setTeam(teamData);
      setPlayers(p);
      setSettings(s);
      setAnnouncements(a);
      setMonthlyFee(s.monthly_fee != null ? String(s.monthly_fee) : "");
      setAnnualFee(s.annual_fee != null ? String(s.annual_fee) : "");
      setRegistrationFee(s.registration_fee != null ? String(s.registration_fee) : "");
      setDueDay(String(s.payment_due_day));
      setKitTemplate(s.kit_template);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamId]);

  async function handleSaveSettings() {
    if (!teamId) return;
    setIsSavingSettings(true);
    try {
      const updated = await updateFeeSettings(teamId, {
        monthly_fee: monthlyFee ? Number(monthlyFee) : undefined,
        annual_fee: annualFee ? Number(annualFee) : undefined,
        registration_fee: registrationFee ? Number(registrationFee) : undefined,
        payment_due_day: Number(dueDay) || 10,
        kit_template: kitTemplate,
      });
      setSettings(updated);
      toast.show(t("academyDetail.settingsSaved"), "success");
      setShowSettings(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingSettings(false);
    }
  }

  function addKitTemplateItem() {
    const trimmed = newKitTemplateItem.trim();
    if (trimmed && !kitTemplate.includes(trimmed)) {
      setKitTemplate((prev) => [...prev, trimmed]);
    }
    setNewKitTemplateItem("");
  }

  async function handleApplyTemplate() {
    if (!teamId) return;
    setIsApplyingTemplate(true);
    try {
      const updatedPlayers = await applyKitTemplate(teamId);
      setPlayers(updatedPlayers);
      toast.show(t("academyDetail.kitTemplateApplied"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsApplyingTemplate(false);
    }
  }

  async function handleCreateAnnouncement() {
    if (!teamId || !annTitle) return;
    setIsSavingAnnouncement(true);
    try {
      await createAnnouncement(teamId, {
        title: annTitle,
        description: annDescription || undefined,
        event_date: annDate || undefined,
        event_time: annTime || undefined,
        location_name: annLocation || undefined,
        location_maps_url: annMapsUrl || undefined,
      });
      toast.show(t("academyDetail.announcementPublished"), "success");
      setShowAnnouncementForm(false);
      setAnnTitle("");
      setAnnDescription("");
      setAnnDate("");
      setAnnTime("");
      setAnnLocation("");
      setAnnMapsUrl("");
      const a = await listAnnouncements(teamId);
      setAnnouncements(a);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingAnnouncement(false);
    }
  }

  async function handleDeleteAnnouncement() {
    if (!deleteAnnTarget || !teamId) return;
    try {
      await deleteAnnouncement(deleteAnnTarget.id);
      setAnnouncements((prev) => prev.filter((a) => a.id !== deleteAnnTarget.id));
      toast.show(t("academyDetail.announcementDeleted"), "success");
      setDeleteAnnTarget(null);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  if (isLoading || !team) {
    return (
      <AppLayout title={t("academyDetail.loadingTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  return (
    <AppLayout title={team.name}>
      <Link to="/academy" className="mb-4 inline-block text-sm text-text-muted hover:text-chalk">
        {t("academyDetail.backToAll")}
      </Link>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Roster */}
        <div className="lg:col-span-2">
          <Card corners>
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("academyDetail.rosterPrefix")}{players.length})
              </h3>
              <div className="flex items-center gap-3">
                <ExportMenu
                  onExportExcel={() => exportAcademyExcel(team.id, team.name)}
                  onExportPdf={() => exportAcademyPdf(team.id, team.name)}
                  label={t("academyDetail.exportDebts")}
                />
                {settings && settings.kit_template.length > 0 && (
                  <button
                    onClick={handleApplyTemplate}
                    disabled={isApplyingTemplate}
                    className="text-xs text-chalk hover:underline disabled:opacity-50"
                    title={`${t("academyDetail.templatePrefix")}${settings.kit_template.join(", ")}`}
                  >
                    {isApplyingTemplate ? "..." : t("academyDetail.applyTemplateToAll")}
                  </button>
                )}
                <button onClick={() => setShowSettings(true)} className="text-xs text-chalk hover:underline">
                  {t("academyDetail.subscriptionSettings")}
                </button>
              </div>
            </div>
            {players.length === 0 ? (
              <EmptyState
                title={t("academyDetail.noPlayersOnTeam")}
                description={t("academyDetail.addPlayersFromPlayersPage")}
              />
            ) : (
              <div className="divide-y divide-line">
                {players.map((p) => (
                  <button
                    key={p.player_id}
                    onClick={() => setSelectedPlayerId(p.player_id)}
                    className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left hover:bg-surface-raised"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xs text-text-muted">
                        {p.photo_path ? (
                          <img src={mediaUrl(p.photo_path)} alt="" className="h-full w-full object-cover" />
                        ) : (
                          p.player_name.charAt(0)
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm text-text-primary">{p.player_name}</p>
                        <p className="truncate text-xs text-text-muted">
                          {p.plan_type === "annual" ? t("academyDetail.annual") : t("academyDetail.monthly")}
                          {p.parent_phone ? ` · ${p.parent_phone}` : t("academyDetail.noParentPhoneSuffix")}
                        </p>
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center justify-end gap-1.5">
                      {!p.has_account && (
                        <span className="rounded-full border border-line px-2 py-0.5 text-[11px] text-text-muted">
                          {t("academyDetail.noAccountDetails")}
                        </span>
                      )}
                      {!p.registration_paid && (
                        <span className="rounded-full border border-status-doubtful/40 bg-status-doubtful/10 px-2 py-0.5 text-[11px] text-status-doubtful">
                          {t("academyDetail.registrationPending")}
                        </span>
                      )}
                      {p.kit_items.some((k) => !k.received) && (
                        <span className="rounded-full border border-status-doubtful/40 bg-status-doubtful/10 px-2 py-0.5 text-[11px] text-status-doubtful">
                          {t("academyDetail.kitPending")}
                        </span>
                      )}
                      {p.is_overdue && (
                        <span className="rounded-full border border-status-injured/40 bg-status-injured/10 px-2 py-0.5 text-[11px] text-status-injured">
                          {t("academyDetail.overdue")}
                        </span>
                      )}
                      <span
                        className={`font-display text-sm ${
                          p.total_owed + p.kit_owed > 0 ? "text-status-injured" : "text-status-fit"
                        }`}
                      >
                        {p.total_owed + p.kit_owed > 0 ? `€${(p.total_owed + p.kit_owed).toFixed(2)}` : "✓"}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Announcements */}
        <div>
          <Card corners>
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">{t("academyDetail.announcements")}</h3>
              <button
                onClick={() => setShowAnnouncementForm((s) => !s)}
                className="text-xs text-chalk hover:underline"
              >
                {showAnnouncementForm ? t("common.close") : t("academyDetail.newAnnouncement")}
              </button>
            </div>

            {showAnnouncementForm && (
              <div className="space-y-2 border-b border-line p-4">
                <Input label={t("crm.titleLabel")} value={annTitle} onChange={(e) => setAnnTitle(e.target.value)} />
                <Textarea
                  label={t("crm.descriptionOptional")}
                  value={annDescription}
                  onChange={(e) => setAnnDescription(e.target.value)}
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input label={t("academyDetail.dateLabel")} type="date" value={annDate} onChange={(e) => setAnnDate(e.target.value)} />
                  <Input label={t("calendar.time")} type="time" value={annTime} onChange={(e) => setAnnTime(e.target.value)} />
                </div>
                <Input
                  label={t("academyDetail.locationLabel")}
                  placeholder={t("academyDetail.locationPlaceholder")}
                  value={annLocation}
                  onChange={(e) => setAnnLocation(e.target.value)}
                />
                <Input
                  label={t("academyDetail.googleMapsLinkOptional")}
                  placeholder="https://maps.google.com/..."
                  value={annMapsUrl}
                  onChange={(e) => setAnnMapsUrl(e.target.value)}
                />
                <Button
                  type="button"
                  onClick={handleCreateAnnouncement}
                  isLoading={isSavingAnnouncement}
                  disabled={!annTitle}
                >
                  {t("academyDetail.publish")}
                </Button>
              </div>
            )}

            {announcements.length === 0 ? (
              <p className="p-4 text-xs text-text-muted">{t("academyDetail.noAnnouncementsYet")}</p>
            ) : (
              <div className="divide-y divide-line">
                {announcements.map((a) => (
                  <div key={a.id} className="px-4 py-3 text-sm">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-text-primary">{a.title}</p>
                      <button
                        onClick={() => setDeleteAnnTarget(a)}
                        className="shrink-0 text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    </div>
                    {a.description && <p className="mt-0.5 text-xs text-text-muted">{a.description}</p>}
                    <p className="mt-1 text-xs text-text-muted">
                      {a.event_date && new Date(a.event_date).toLocaleDateString("el-GR")}
                      {a.event_time ? ` · ${a.event_time}` : ""}
                      {a.location_name ? ` · ${a.location_name}` : ""}
                    </p>
                    {a.location_maps_url && (
                      <a
                        href={a.location_maps_url}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-1 inline-block text-xs text-chalk hover:underline"
                      >
                        {t("academyDetail.openInGoogleMaps")}
                      </a>
                    )}
                    <div className="mt-2 flex items-center gap-3">
                      <a href={viberForwardLink(buildAnnouncementMessage(a))} className="text-xs text-chalk hover:underline">
                        {t("academyDetail.shareViber")}
                      </a>
                      <a href={whatsappShareLink(buildAnnouncementMessage(a))} className="text-xs text-chalk hover:underline">
                        {t("academyDetail.shareWhatsapp")}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      <AcademyPlayerModal
        playerId={selectedPlayerId}
        feeSettings={settings}
        onClose={() => setSelectedPlayerId(null)}
        onChanged={load}
      />

      <Modal isOpen={showSettings} onClose={() => setShowSettings(false)} title={t("academyDetail.subscriptionSettingsModalTitle")}>
        <div className="space-y-4">
          <p className="text-xs text-text-muted">{t("academyDetail.settingsIntro")}</p>
          <Input
            label={t("academyDetail.monthlyFee")}
            type="number"
            value={monthlyFee}
            onChange={(e) => setMonthlyFee(e.target.value)}
          />
          <Input
            label={t("academyDetail.annualFee")}
            type="number"
            value={annualFee}
            onChange={(e) => setAnnualFee(e.target.value)}
          />
          <Input
            label={t("academyDetail.registrationCost")}
            type="number"
            value={registrationFee}
            onChange={(e) => setRegistrationFee(e.target.value)}
          />
          <Input
            label={t("academyDetail.paymentDueDay")}
            type="number"
            min={1}
            max={28}
            value={dueDay}
            onChange={(e) => setDueDay(e.target.value)}
          />

          <div>
            <p className="mb-1.5 text-xs font-medium text-text-muted">
              {t("academyDetail.kitTemplateLabel")}
            </p>
            {kitTemplate.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-1.5">
                {kitTemplate.map((item) => (
                  <span
                    key={item}
                    className="flex items-center gap-1 rounded-full border border-line bg-surface-raised px-2.5 py-1 text-xs text-text-primary"
                  >
                    {item}
                    <button
                      onClick={() => setKitTemplate((prev) => prev.filter((i) => i !== item))}
                      className="text-text-muted hover:text-status-injured"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <input
                value={newKitTemplateItem}
                onChange={(e) => setNewKitTemplateItem(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addKitTemplateItem();
                  }
                }}
                placeholder={t("academyDetail.kitItemPlaceholder")}
                className="flex-1 rounded-md border border-line bg-surface px-3 py-2 text-sm text-text-primary focus:border-chalk focus:outline-none"
              />
              <button
                type="button"
                onClick={addKitTemplateItem}
                className="rounded-md border border-line px-3 py-2 text-xs text-text-primary hover:border-chalk"
              >
                {t("scouting.addButton")}
              </button>
            </div>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {[
                t("academyDetail.kitJersey"),
                t("academyDetail.kitShorts"),
                t("academyDetail.kitSocks"),
                t("academyDetail.kitTracksuit"),
                t("academyDetail.kitBag"),
                t("academyDetail.kitShoes"),
              ]
                .filter((s) => !kitTemplate.includes(s))
                .map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setKitTemplate((prev) => [...prev, s])}
                    className="rounded-full border border-dashed border-line px-2.5 py-1 text-[11px] text-text-muted hover:border-chalk hover:text-chalk"
                  >
                    + {s}
                  </button>
                ))}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => setShowSettings(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="button" onClick={handleSaveSettings} isLoading={isSavingSettings}>
              {t("common.save")}
            </Button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteAnnTarget}
        onClose={() => setDeleteAnnTarget(null)}
        onConfirm={handleDeleteAnnouncement}
        title={t("academyDetail.deleteAnnouncementTitle")}
        message={deleteAnnTarget ? `${t("academyDetail.deleteAnnouncementConfirmPrefix")}${deleteAnnTarget.title}${t("academyDetail.deleteAnnouncementConfirmSuffix")}` : ""}
      />
    </AppLayout>
  );
}
