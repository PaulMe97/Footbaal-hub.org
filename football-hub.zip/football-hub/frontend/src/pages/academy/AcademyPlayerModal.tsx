import { useEffect, useState } from "react";

import {
  addKitItem,
  addPayment,
  deleteKitItem,
  deletePayment,
  getAcademyPlayer,
  updateAcademyAccount,
  updateKitItem,
} from "../../api/academy";
import type { AcademyFeeSettings, AcademyPlayerDetail } from "../../api/academy";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { ContactParentPanel } from "../../components/academy/ContactParentPanel";
import { Button } from "../../components/ui/Button";
import { Spinner } from "../../components/ui/EmptyState";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import { monthLabel } from "../../utils/academyMessages";

export function AcademyPlayerModal({
  playerId,
  feeSettings,
  onClose,
  onChanged,
}: {
  playerId: string | null;
  feeSettings: AcademyFeeSettings | null;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const { t } = useLanguage();
  const PAYMENT_TYPE_LABELS: Record<string, string> = {
    monthly: t("academyPlayer.paymentTypeMonthly"),
    annual: t("academyPlayer.paymentTypeAnnual"),
    registration: t("academyPlayer.paymentTypeRegistration"),
  };
  const [player, setPlayer] = useState<AcademyPlayerDetail | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const [planType, setPlanType] = useState("monthly");
  const [parentName, setParentName] = useState("");
  const [parentPhone, setParentPhone] = useState("");
  const [enrollmentDate, setEnrollmentDate] = useState("");
  const [notes, setNotes] = useState("");
  const [isSavingAccount, setIsSavingAccount] = useState(false);

  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentType, setPaymentType] = useState("monthly");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentYear, setPaymentYear] = useState(String(new Date().getFullYear()));
  const [paymentMonth, setPaymentMonth] = useState(String(new Date().getMonth() + 1));
  const [paymentNotes, setPaymentNotes] = useState("");
  const [isSavingPayment, setIsSavingPayment] = useState(false);
  const [isMarkingRegistration, setIsMarkingRegistration] = useState(false);

  const [newKitName, setNewKitName] = useState("");
  const [newKitPrice, setNewKitPrice] = useState("");
  const [isAddingKit, setIsAddingKit] = useState(false);

  async function load() {
    if (!playerId) return;
    setIsLoading(true);
    try {
      const data = await getAcademyPlayer(playerId);
      setPlayer(data);
      setPlanType(data.plan_type);
      setParentName(data.parent_name || "");
      setParentPhone(data.parent_phone || "");
      setEnrollmentDate(data.enrollment_date || "");
      setNotes(data.notes || "");
      if (feeSettings?.monthly_fee) setPaymentAmount(String(feeSettings.monthly_fee));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playerId]);

  async function handleSaveAccount() {
    if (!playerId) return;
    setIsSavingAccount(true);
    try {
      const updated = await updateAcademyAccount(playerId, {
        plan_type: planType,
        parent_name: parentName || undefined,
        parent_phone: parentPhone || undefined,
        enrollment_date: enrollmentDate || undefined,
        notes: notes || undefined,
      });
      setPlayer(updated);
      toast.show(t("academyPlayer.detailsSaved"), "success");
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingAccount(false);
    }
  }

  async function handleMarkRegistrationPaid() {
    if (!playerId) return;
    setIsMarkingRegistration(true);
    try {
      const updated = await addPayment(playerId, {
        payment_type: "registration",
        amount: feeSettings?.registration_fee || 0,
      });
      setPlayer(updated);
      toast.show(t("academyPlayer.registrationMarkedPaid"), "success");
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsMarkingRegistration(false);
    }
  }

  async function handleAddPayment() {
    if (!playerId || !paymentAmount) return;
    setIsSavingPayment(true);
    try {
      const updated = await addPayment(playerId, {
        payment_type: paymentType,
        period_year: paymentType === "monthly" ? Number(paymentYear) : undefined,
        period_month: paymentType === "monthly" ? Number(paymentMonth) : undefined,
        amount: Number(paymentAmount),
        notes: paymentNotes || undefined,
      });
      setPlayer(updated);
      setShowPaymentForm(false);
      setPaymentNotes("");
      toast.show(t("academyPlayer.paymentLogged"), "success");
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingPayment(false);
    }
  }

  async function handleDeletePayment(paymentId: string) {
    try {
      await deletePayment(paymentId);
      if (playerId) setPlayer(await getAcademyPlayer(playerId));
      toast.show(t("academyPlayer.paymentDeleted"), "success");
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAddKit() {
    if (!playerId || !newKitName) return;
    setIsAddingKit(true);
    try {
      const updated = await addKitItem(playerId, {
        item_name: newKitName,
        price: newKitPrice ? Number(newKitPrice) : undefined,
      });
      setPlayer(updated);
      setNewKitName("");
      setNewKitPrice("");
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAddingKit(false);
    }
  }

  async function handleQuickAddKit(name: string) {
    if (!playerId) return;
    try {
      const updated = await addKitItem(playerId, { item_name: name });
      setPlayer(updated);
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleToggleKit(itemId: string, field: "received" | "paid", value: boolean) {
    try {
      const updated = await updateKitItem(itemId, { [field]: value });
      setPlayer(updated);
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleDeleteKit(itemId: string) {
    try {
      if (playerId) {
        await deleteKitItem(itemId);
        setPlayer(await getAcademyPlayer(playerId));
        onChanged();
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  return (
    <Modal isOpen={!!playerId} onClose={onClose} title={player ? player.player_name : t("academyPlayer.playerFallback")} wide>
      {isLoading || !player ? (
        <Spinner />
      ) : (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm text-text-muted">
              {player.photo_path ? (
                <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
              ) : (
                player.player_name.charAt(0)
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              <span
                className={`rounded-full border px-2.5 py-1 text-xs ${
                  player.total_owed > 0
                    ? "border-status-injured/40 bg-status-injured/10 text-status-injured"
                    : "border-status-fit/40 bg-status-fit/10 text-status-fit"
                }`}
              >
                {player.total_owed > 0 ? `${t("academyPlayer.owesPrefix")}${player.total_owed.toFixed(2)}` : t("academyPlayer.noDebt")}
              </span>
              {player.is_overdue && (
                <span className="rounded-full border border-status-injured/40 bg-status-injured/10 px-2.5 py-1 text-xs text-status-injured">
                  {t("academyDetail.overdue")}
                </span>
              )}
              <span
                className={`rounded-full border px-2.5 py-1 text-xs ${
                  player.registration_paid
                    ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                    : "border-status-doubtful/40 bg-status-doubtful/10 text-status-doubtful"
                }`}
              >
                {player.registration_paid ? t("academyPlayer.registrationPaidBadge") : t("academyDetail.registrationPending")}
              </span>
              {player.plan_type === "annual" && (
                <span
                  className={`rounded-full border px-2.5 py-1 text-xs ${
                    player.annual_paid_in_full
                      ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                      : "border-status-doubtful/40 bg-status-doubtful/10 text-status-doubtful"
                  }`}
                >
                  {player.annual_paid_in_full ? t("academyPlayer.annualPaidBadge") : t("academyPlayer.annualPending")}
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-display text-xs uppercase tracking-wide text-text-muted">
                {t("academyPlayer.accountDetails")}
              </h4>

              <div className="flex items-center justify-between rounded-md border border-line bg-surface-raised p-3">
                <span className="text-xs font-medium text-text-muted">
                  {t("academyPlayer.paymentTypeRegistration")} {feeSettings?.registration_fee ? `(€${feeSettings.registration_fee})` : ""}
                </span>
                {player.registration_paid ? (
                  <span className="rounded-full border border-status-fit/40 bg-status-fit/15 px-2.5 py-1 text-xs font-medium text-status-fit">
                    {t("academyPlayer.ok")}
                  </span>
                ) : (
                  <Button
                    type="button"
                    onClick={handleMarkRegistrationPaid}
                    isLoading={isMarkingRegistration}
                  >
                    {t("academyPlayer.markAsPaid")}
                  </Button>
                )}
              </div>

              <Select label={t("academyPlayer.subscriptionType")} value={planType} onChange={(e) => setPlanType(e.target.value)}>
                <option value="monthly">{t("academyDetail.monthly")}</option>
                <option value="annual">{t("academyPlayer.annualFullPackage")}</option>
              </Select>
              <Input
                label={t("academyPlayer.parentFullName")}
                value={parentName}
                onChange={(e) => setParentName(e.target.value)}
              />
              <Input
                label={t("academyPlayer.parentPhoneLabel")}
                placeholder="+30 69XXXXXXXX"
                value={parentPhone}
                onChange={(e) => setParentPhone(e.target.value)}
              />
              <Input
                label={t("academyPlayer.enrollmentDate")}
                type="date"
                value={enrollmentDate}
                onChange={(e) => setEnrollmentDate(e.target.value)}
              />
              <Textarea label={t("calendar.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
              <Button type="button" onClick={handleSaveAccount} isLoading={isSavingAccount}>
                {t("academyPlayer.saveDetails")}
              </Button>
            </div>

            <div>
              <h4 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("academyPlayer.contactWithParent")}
              </h4>
              <ContactParentPanel player={player} dueDay={feeSettings?.payment_due_day || 10} />
            </div>
          </div>

          {player.unpaid_months.length > 0 && (
            <div>
              <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("academyPlayer.unpaidMonths")}
              </h4>
              <div className="flex flex-wrap gap-2">
                {player.unpaid_months.map((m) => (
                  <span
                    key={`${m.year}-${m.month}`}
                    className="rounded-full border border-status-injured/40 bg-status-injured/10 px-2.5 py-1 text-xs text-status-injured"
                  >
                    {monthLabel(m.month)} {m.year} — €{m.amount}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="mb-2 flex items-center justify-between">
              <h4 className="font-display text-xs uppercase tracking-wide text-text-muted">
                {t("academyPlayer.paymentHistory")}
              </h4>
              <button
                onClick={() => setShowPaymentForm((s) => !s)}
                className="text-xs text-chalk hover:underline"
              >
                {showPaymentForm ? t("common.close") : t("academyPlayer.logPayment")}
              </button>
            </div>

            {showPaymentForm && (
              <div className="mb-3 space-y-2 rounded-md border border-line bg-surface-raised p-3">
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  <Select label={t("academyPlayer.typeLabel")} value={paymentType} onChange={(e) => setPaymentType(e.target.value)}>
                    <option value="monthly">{t("academyPlayer.paymentTypeMonthly")}</option>
                    <option value="annual">{t("academyPlayer.paymentTypeAnnual")}</option>
                    <option value="registration">{t("academyPlayer.paymentTypeRegistration")}</option>
                  </Select>
                  {paymentType === "monthly" && (
                    <>
                      <Select
                        label={t("academyPlayer.monthLabel")}
                        value={paymentMonth}
                        onChange={(e) => setPaymentMonth(e.target.value)}
                      >
                        {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                          <option key={m} value={m}>
                            {monthLabel(m)}
                          </option>
                        ))}
                      </Select>
                      <Input
                        label={t("academyPlayer.yearLabel")}
                        type="number"
                        value={paymentYear}
                        onChange={(e) => setPaymentYear(e.target.value)}
                      />
                    </>
                  )}
                  <Input
                    label={t("academyPlayer.amountLabel")}
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                  />
                </div>
                <Input
                  label={t("academyPlayer.notesOptional")}
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                />
                <Button type="button" onClick={handleAddPayment} isLoading={isSavingPayment}>
                  {t("staff.submit")}
                </Button>
              </div>
            )}

            {player.payments.length === 0 ? (
              <p className="text-xs text-text-muted">{t("academyPlayer.noPaymentsYet")}</p>
            ) : (
              <div className="space-y-1.5">
                {player.payments.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-1.5 text-sm"
                  >
                    <div>
                      <span className="text-text-primary">{PAYMENT_TYPE_LABELS[p.payment_type]}</span>
                      {p.period_month && (
                        <span className="text-text-muted">
                          {" "}
                          · {monthLabel(p.period_month)} {p.period_year}
                        </span>
                      )}
                      <span className="ml-2 text-status-fit">€{p.amount}</span>
                      <p className="text-[11px] text-text-muted">
                        {new Date(p.paid_date).toLocaleDateString("el-GR")}
                        {p.recorded_by_name ? ` · ${p.recorded_by_name}` : ""}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeletePayment(p.id)}
                      className="text-xs text-status-injured hover:underline"
                    >
                      {t("common.delete")}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("academyPlayer.kit")}{" "}
              {player.kit_owed > 0 && (
                <span className="text-status-injured">({t("academyPlayer.debtPrefix")}{player.kit_owed.toFixed(2)})</span>
              )}
            </h4>
            {player.kit_items.length > 0 && (
              <div className="mb-2 flex flex-wrap gap-2">
                {player.kit_items.map((k) => (
                  <div
                    key={k.id}
                    className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs ${
                      k.received
                        ? "border-status-fit/40 bg-status-fit/10 text-status-fit"
                        : "border-status-injured/40 bg-status-injured/10 text-status-injured"
                    }`}
                  >
                    <button onClick={() => handleToggleKit(k.id, "received", !k.received)}>
                      {k.received ? "✓" : "○"} {k.item_name}
                    </button>
                    {k.price ? (
                      <button
                        onClick={() => handleToggleKit(k.id, "paid", !k.paid)}
                        className={k.paid ? "text-status-fit" : "text-status-injured underline"}
                      >
                        {k.paid ? t("academyPlayer.paid") : `€${k.price}`}
                      </button>
                    ) : null}
                    <button
                      onClick={() => handleDeleteKit(k.id)}
                      className="text-text-muted hover:text-status-injured"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="mb-2 flex flex-wrap gap-1.5">
              {[
                t("academyDetail.kitJersey"),
                t("academyDetail.kitShorts"),
                t("academyDetail.kitSocks"),
                t("academyDetail.kitTracksuit"),
                t("academyDetail.kitBag"),
                t("academyDetail.kitShoes"),
              ]
                .filter((s) => !player.kit_items.some((k) => k.item_name === s))
                .map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => handleQuickAddKit(s)}
                    className="rounded-full border border-dashed border-line px-2.5 py-1 text-[11px] text-text-muted hover:border-chalk hover:text-chalk"
                  >
                    + {s}
                  </button>
                ))}
            </div>
            <div className="flex flex-wrap items-end gap-2">
              <Input
                label={t("academyPlayer.newItemOther")}
                placeholder={t("academyPlayer.newItemPlaceholder")}
                value={newKitName}
                onChange={(e) => setNewKitName(e.target.value)}
              />
              <Input
                label={t("academyPlayer.priceOptional")}
                type="number"
                value={newKitPrice}
                onChange={(e) => setNewKitPrice(e.target.value)}
              />
              <Button type="button" variant="secondary" onClick={handleAddKit} isLoading={isAddingKit}>
                {t("scouting.addButton")}
              </Button>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}
