import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { extractErrorMessage, mediaUrl } from "../../api/client";
import { listMatches } from "../../api/matches";
import { listPlayers } from "../../api/players";
import { searchUsers } from "../../api/profile";
import {
  listTeamAccessGrants,
  listTeamJoinRequests,
  listTeamPlayerRequests,
  listUnlinkedPlayers,
  respondToPlayerRequest,
  respondToTeamRequest,
  revokeTeamAccessGrant,
} from "../../api/requests";
import type {
  PlayerJoinRequestItem,
  TeamAccessGrantItem,
  TeamJoinRequestItem,
  UnlinkedPlayerItem,
} from "../../api/requests";
import {
  addTeamStaff,
  deleteTeam,
  exportRosterExcel,
  exportRosterPdf,
  getTeam,
  importPlayersCsv,
  listTeams,
  listTeamStaff,
  publishTeam,
  removeTeamStaff,
  updateTeam,
  uploadTeamLogo,
} from "../../api/teams";
import type { CSVImportResult } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { CsvTemplateModal } from "../../components/CsvTemplateModal";
import { ExportMenu } from "../../components/ExportMenu";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { StatusBadge } from "../../components/ui/Badge";
import { Input } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useAuth } from "../../context/AuthContext";
import type { LeagueTier, Match, Player, PlayerPosition, Team, TeamStaffMember, UserSearchResult } from "../../types";
import { LEAGUE_TIER_LABELS } from "../../types";
import { TeamForm, type TeamFormValues } from "./TeamForm";
import { TeamListings } from "./TeamListings";
import { TeamRenewals } from "./TeamRenewals";
import { TeamAccessGrantModal } from "./TeamAccessGrantModal";
import { TeamStaffMemberModal } from "./TeamStaffMemberModal";
import { useLanguage } from "../../context/LanguageContext";

function getMatchResult(match: Match, teamId?: string): "W" | "D" | "L" {
  if (match.home_score == null || match.away_score == null) return "D";
  const isHome = match.home_team_id === teamId;
  const teamScore = isHome ? match.home_score : match.away_score;
  const oppScore = isHome ? match.away_score : match.home_score;
  if (teamScore > oppScore) return "W";
  if (teamScore < oppScore) return "L";
  return "D";
}

function groupPlayersByCategory(
  players: Player[],
  positionCategories: { label: string; positions: PlayerPosition[] }[],
  noPositionLabel: string
) {
  const groups = positionCategories.map((c) => ({ label: c.label, players: [] as Player[] }));
  const other: Player[] = [];
  for (const p of players) {
    const group = groups.find((g) =>
      positionCategories.find((c) => c.label === g.label)!.positions.includes(
        p.position as PlayerPosition
      )
    );
    if (group) {
      group.players.push(p);
    } else {
      other.push(p);
    }
  }
  if (other.length > 0) {
    groups.push({ label: noPositionLabel, players: other });
  }
  return groups.filter((g) => g.players.length > 0);
}

export default function TeamDetail() {
  const { teamId } = useParams<{ teamId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const isPlayer = user?.role === "player";

  const POSITION_CATEGORIES: { label: string; positions: PlayerPosition[] }[] = [
    { label: t("teamDetail.positionGoalkeepers"), positions: ["GK"] },
    { label: t("teamDetail.positionDefense"), positions: ["CB", "LB", "RB", "LWB", "RWB"] },
    { label: t("teamDetail.positionMidfield"), positions: ["DM", "CM", "AM"] },
    { label: t("teamDetail.positionAttack"), positions: ["LW", "RW", "ST"] },
  ];

  const [team, setTeam] = useState<Team | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [statusModal, setStatusModal] = useState<{ key: string; label: string } | null>(null);
  const [recentMatches, setRecentMatches] = useState<Match[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showEdit, setShowEdit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [isImportingCsv, setIsImportingCsv] = useState(false);
  const [showCsvTemplate, setShowCsvTemplate] = useState(false);
  const [csvResult, setCsvResult] = useState<CSVImportResult | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);
  const [staff, setStaff] = useState<TeamStaffMember[]>([]);
  const [showAddStaff, setShowAddStaff] = useState(false);
  const [staffSearchQuery, setStaffSearchQuery] = useState("");
  const [staffSearchResults, setStaffSearchResults] = useState<UserSearchResult[]>([]);
  const [selectedStaffUser, setSelectedStaffUser] = useState<UserSearchResult | null>(null);
  const [staffRoleTitle, setStaffRoleTitle] = useState("");
  const [isAddingStaff, setIsAddingStaff] = useState(false);
  const [teamRequests, setTeamRequests] = useState<TeamJoinRequestItem[]>([]);
  const [playerRequests, setPlayerRequests] = useState<PlayerJoinRequestItem[]>([]);
  const [accessGrants, setAccessGrants] = useState<TeamAccessGrantItem[]>([]);
  const [unlinkedPlayers, setUnlinkedPlayers] = useState<UnlinkedPlayerItem[]>([]);
  const [linkSelections, setLinkSelections] = useState<Record<string, string>>({});
  const [respondingId, setRespondingId] = useState<string | null>(null);
  const [acceptRoleTitle, setAcceptRoleTitle] = useState("");
  const [acceptingRequest, setAcceptingRequest] = useState<TeamJoinRequestItem | null>(null);
  const [additionalTeamIds, setAdditionalTeamIds] = useState<string[]>([]);
  const [allMyTeams, setAllMyTeams] = useState<Team[]>([]);
  const [myTeamsForOffer, setMyTeamsForOffer] = useState<Team[]>([]);
  const [selectedStaffMember, setSelectedStaffMember] = useState<TeamStaffMember | null>(null);
  const [selectedAccessGrant, setSelectedAccessGrant] = useState<TeamAccessGrantItem | null>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function load() {
    if (!teamId) return;
    setIsLoading(true);
    try {
      const [teamData, p, m, s] = await Promise.all([
        getTeam(teamId),
        listPlayers({ team_id: teamId }),
        listMatches({ team_id: teamId, status: "finished" }),
        listTeamStaff(teamId),
      ]);
      setTeam(teamData);
      setPlayers(p);
      setRecentMatches(
        [...m].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 5)
      );
      setStaff(s);

      if (!isPlayer) {
        const [tr, pr, grants, myTeams, unlinked] = await Promise.all([
          listTeamJoinRequests(teamId),
          listTeamPlayerRequests(teamId),
          listTeamAccessGrants(teamId),
          listTeams(),
          listUnlinkedPlayers(teamId),
        ]);
        setTeamRequests(tr.filter((r) => r.status === "pending"));
        setPlayerRequests(pr.filter((r) => r.status === "pending"));
        setAccessGrants(grants);
        setAllMyTeams(myTeams.filter((mt) => mt.id !== teamId));
        setMyTeamsForOffer(myTeams);
        setUnlinkedPlayers(unlinked);
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamId]);

  async function handleUpdate(values: TeamFormValues) {
    if (!teamId) return;
    setIsSubmitting(true);
    try {
      const updated = await updateTeam(teamId, values);
      setTeam(updated);
      toast.show(t("dashboard.changesSaved"), "success");
      setShowEdit(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!teamId) return;
    setIsDeleting(true);
    try {
      await deleteTeam(teamId);
      toast.show(t("scouting.teamDeleted"), "success");
      navigate("/teams");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
      setIsDeleting(false);
    }
  }

  async function handleLogoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !teamId) return;
    setIsUploadingLogo(true);
    try {
      const updated = await uploadTeamLogo(teamId, file);
      setTeam(updated);
      toast.show(t("teamDetail.logoUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUploadingLogo(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleCsvChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !teamId) return;
    setIsImportingCsv(true);
    try {
      const result = await importPlayersCsv(teamId, file);
      setCsvResult(result);
      toast.show(`${t("players.importedPrefix")}${result.created}${t("players.importedSuffix")}`, "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsImportingCsv(false);
      if (csvInputRef.current) csvInputRef.current.value = "";
    }
  }

  async function handlePublishToggle(nextValue: boolean) {
    if (!teamId) return;
    setIsPublishing(true);
    try {
      const updated = await publishTeam(teamId, { is_publicly_shared: nextValue });
      setTeam(updated);
      toast.show(nextValue ? t("teamDetail.pagePublished") : t("teamDetail.pageUnpublished"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsPublishing(false);
    }
  }

  async function handleRosterVisibilityToggle(nextValue: boolean) {
    if (!teamId || !team) return;
    setIsPublishing(true);
    try {
      const updated = await publishTeam(teamId, {
        is_publicly_shared: team.is_publicly_shared ?? false,
        public_show_roster: nextValue,
      });
      setTeam(updated);
      toast.show(t("teamDetail.settingUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsPublishing(false);
    }
  }

  function handleCopyPublicLink() {
    if (!team?.public_slug) return;
    const url = `${window.location.origin}/club/${team.public_slug}`;
    navigator.clipboard.writeText(url);
    toast.show(t("teamDetail.linkCopied"), "success");
  }

  async function handleRejectTeamRequest(requestId: string) {
    if (!teamId) return;
    setRespondingId(requestId);
    try {
      await respondToTeamRequest(teamId, requestId, false);
      setTeamRequests((prev) => prev.filter((r) => r.id !== requestId));
      toast.show(t("teamDetail.requestRejected"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingId(null);
    }
  }

  function openAcceptTeamRequest(request: TeamJoinRequestItem) {
    setAcceptingRequest(request);
    setAcceptRoleTitle("");
    setAdditionalTeamIds([]);
  }

  async function handleConfirmAcceptTeamRequest() {
    if (!teamId || !acceptingRequest) return;
    setRespondingId(acceptingRequest.id);
    try {
      await respondToTeamRequest(teamId, acceptingRequest.id, true, acceptRoleTitle || undefined, additionalTeamIds);
      setTeamRequests((prev) => prev.filter((r) => r.id !== acceptingRequest.id));
      toast.show(t("teamDetail.requestAccepted"), "success");
      setAcceptingRequest(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingId(null);
    }
  }

  async function handleRespondPlayerRequest(requestId: string, accept: boolean, linkToPlayerId?: string) {
    if (!teamId) return;
    setRespondingId(requestId);
    try {
      await respondToPlayerRequest(teamId, requestId, accept, linkToPlayerId);
      setPlayerRequests((prev) => prev.filter((r) => r.id !== requestId));
      toast.show(accept ? t("teamDetail.requestAccepted") : t("teamDetail.requestRejected"), "success");
      if (accept) load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingId(null);
    }
  }

  async function handleRevokeGrant(grantId: string) {
    if (!teamId) return;
    try {
      await revokeTeamAccessGrant(teamId, grantId);
      setAccessGrants((prev) => prev.filter((g) => g.id !== grantId));
      toast.show(t("teamDetail.accessRemoved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }


  function openAddStaff() {
    setStaffSearchQuery("");
    setStaffSearchResults([]);
    setSelectedStaffUser(null);
    setStaffRoleTitle("");
    setShowAddStaff(true);
  }

  async function handleStaffSearchChange(query: string) {
    setStaffSearchQuery(query);
    setSelectedStaffUser(null);
    if (query.trim().length < 2) {
      setStaffSearchResults([]);
      return;
    }
    try {
      const results = await searchUsers(query.trim());
      setStaffSearchResults(results);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAddStaff() {
    if (!teamId || !selectedStaffUser) return;
    setIsAddingStaff(true);
    try {
      const member = await addTeamStaff(teamId, selectedStaffUser.id, staffRoleTitle || undefined);
      setStaff((prev) => [...prev, member]);
      toast.show(t("teamDetail.addedToStaff"), "success");
      setShowAddStaff(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAddingStaff(false);
    }
  }

  async function handleRemoveStaff(staffId: string) {
    if (!teamId) return;
    try {
      await removeTeamStaff(teamId, staffId);
      setStaff((prev) => prev.filter((s) => s.id !== staffId));
      toast.show(t("teamDetail.removedFromStaff"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  if (isLoading || !team) {
    return (
      <AppLayout title={t("teamDetail.loadingTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  return (
    <AppLayout title={team.name}>
      <Link to="/teams" className="mb-4 inline-block text-sm text-text-muted hover:text-chalk">
        {t("matches.backToTeams")}
      </Link>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card corners className="p-5 lg:col-span-1">
          <div className="flex flex-col items-center text-center">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="group relative flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised font-display text-2xl text-text-muted hover:border-chalk"
              title={t("teamDetail.changeLogo")}
            >
              {team.logo_path ? (
                <img src={mediaUrl(team.logo_path)} alt="" className="h-full w-full object-cover" />
              ) : (
                team.name.slice(0, 2).toUpperCase()
              )}
              <span className="absolute inset-0 hidden items-center justify-center bg-void/70 text-xs text-chalk group-hover:flex">
                {isUploadingLogo ? "..." : t("profile.change")}
              </span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleLogoChange}
            />
            <h2 className="mt-4 font-display text-xl text-text-primary">{team.name}</h2>
            <p className="text-sm text-text-muted">
              {[team.category, team.division].filter(Boolean).join(" · ") || "—"}
            </p>
            {recentMatches.length > 0 && (
              <div className="mt-3 flex items-center justify-center gap-1.5">
                {recentMatches
                  .slice()
                  .reverse()
                  .map((m) => {
                    const result = getMatchResult(m, teamId);
                    return (
                      <span
                        key={m.id}
                        title={`${m.home_team_name} ${m.home_score}-${m.away_score} ${m.away_team_name} (${m.date})`}
                        className={`flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold ${
                          result === "W"
                            ? "bg-status-fit/20 text-status-fit"
                            : result === "L"
                            ? "bg-status-injured/20 text-status-injured"
                            : "bg-status-doubtful/20 text-status-doubtful"
                        }`}
                      >
                        {result === "W" ? t("teamDetail.resultWin") : result === "L" ? t("teamDetail.resultLoss") : t("teamDetail.resultDraw")}
                      </span>
                    );
                  })}
              </div>
            )}
          </div>

          <dl className="mt-5 space-y-2 border-t border-line pt-4 text-sm">
            <Row
              label={t("crm.category")}
              value={team.league_tier ? LEAGUE_TIER_LABELS[team.league_tier as LeagueTier] || team.league_tier : undefined}
            />
            {team.federation_name && <Row label={t("teamDetail.federationLabel")} value={team.federation_name} />}
            {team.region_name && <Row label={t("teamForm.regionLabel")} value={team.region_name} />}
            {team.league_level_name && <Row label={t("scouting.level")} value={team.league_level_name} />}
            {team.league_group_name && <Row label={t("scouting.group")} value={team.league_group_name} />}
            <Row label="Season" value={team.season} />
            <Row label={t("teamDetail.stadiumLabel")} value={team.home_stadium} />
            {team.president_name && <Row label={t("crm.rolePresident")} value={team.president_name} />}
            <Row label={t("crm.roleHeadCoach")} value={team.coach_name} />
            <Row label={t("teamDetail.playersLabel")} value={String(team.player_count)} />
          </dl>

          <div className="mt-3 flex items-center justify-between border-t border-line pt-3 text-xs">
            <span className={team.is_public_scouting === false ? "text-text-muted" : "text-status-fit"}>
              {team.is_public_scouting === false ? t("teamDetail.privateTeam") : t("teamDetail.visibleInScouting")}
            </span>
            <Link to="/scouting" className="text-chalk hover:underline">
              {t("teamDetail.openScoutingHub")}
            </Link>
          </div>

          <div className="mt-3 border-t border-line pt-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wide text-text-muted">
                {t("teamDetail.publicTeamPage")}
              </span>
              <button
                onClick={() => handlePublishToggle(!team.is_publicly_shared)}
                disabled={isPublishing}
                className={`rounded-full border px-2.5 py-1 text-[11px] disabled:opacity-50 ${
                  team.is_publicly_shared
                    ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                    : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                }`}
              >
                {team.is_publicly_shared ? t("teamDetail.published") : t("academyDetail.publish")}
              </button>
            </div>

            {team.is_publicly_shared && team.public_slug && (
              <div className="mt-2 space-y-2">
                <div className="flex items-center gap-2 rounded-md border border-line bg-surface-raised px-2 py-1.5">
                  <span className="flex-1 truncate text-[11px] text-text-muted">
                    {window.location.origin}/club/{team.public_slug}
                  </span>
                  <button onClick={handleCopyPublicLink} className="text-[11px] text-chalk hover:underline">
                    {t("teamDetail.copy")}
                  </button>
                  <a
                    href={`/club/${team.public_slug}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[11px] text-chalk hover:underline"
                  >
                    {t("teamDetail.preview")}
                  </a>
                </div>
                <label className="flex items-center gap-2 text-xs text-text-primary">
                  <input
                    type="checkbox"
                    checked={team.public_show_roster ?? true}
                    onChange={(e) => handleRosterVisibilityToggle(e.target.checked)}
                    disabled={isPublishing}
                    className="h-3.5 w-3.5 accent-chalk"
                  />
                  {t("teamDetail.showRosterOnPublicPage")}
                </label>
              </div>
            )}
          </div>

          {team.description && (
            <p className="mt-4 border-t border-line pt-4 text-sm text-text-muted">
              {team.description}
            </p>
          )}

          {!isPlayer && (
            <div className="mt-5 flex gap-2 border-t border-line pt-4">
              <Button variant="secondary" onClick={() => setShowEdit(true)} className="flex-1">
                {t("common.edit")}
              </Button>
              <Button variant="danger" onClick={() => setShowDelete(true)}>
                {t("common.delete")}
              </Button>
            </div>
          )}
        </Card>

        <div className="lg:col-span-2">
          <Card className="mb-6 p-4">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("teamDetail.rosterReadiness")}
            </h3>
            <div className="grid grid-cols-5 gap-2 text-center">
              {(
                [
                  { key: "fit", label: t("teamDetail.statusFit"), color: "text-status-fit" },
                  { key: "injured", label: t("teamDetail.statusInjured"), color: "text-status-injured" },
                  { key: "doubtful", label: t("teamDetail.statusDoubtful"), color: "text-status-doubtful" },
                  { key: "suspended", label: t("teamDetail.statusSuspended"), color: "text-status-suspended" },
                  { key: "unavailable", label: t("teamDetail.statusUnavailable"), color: "text-status-unavailable" },
                ] as const
              ).map((s) => (
                <button
                  key={s.key}
                  onClick={() => setStatusModal({ key: s.key, label: s.label })}
                  className="rounded-md border border-line bg-surface-raised py-2 transition-colors hover:border-chalk"
                >
                  <p className={`font-display text-xl ${s.color}`}>
                    {players.filter((p) => (p.status || "fit") === s.key).length}
                  </p>
                  <p className="text-[10px] uppercase text-text-muted">{s.label}</p>
                </button>
              ))}
            </div>
          </Card>

          <Card className="mb-6">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("teamDetail.technicalStaffPrefix")}{staff.length})
              </h3>
              {!isPlayer && (
                <button onClick={openAddStaff} className="text-xs text-chalk hover:underline">
                  {t("scouting.addButton")}
                </button>
              )}
            </div>
            {staff.length === 0 ? (
              <p className="p-4 text-sm text-text-muted">
                {t("teamDetail.noStaffAddedYet")}
              </p>
            ) : (
              <div className="divide-y divide-line">
                {staff.map((s) => (
                  <div key={s.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                    <button
                      type="button"
                      onClick={() => setSelectedStaffMember(s)}
                      className="text-left hover:text-chalk"
                    >
                      <p className="text-text-primary hover:underline">{s.full_name || s.username}</p>
                      {s.role_title && <p className="text-xs text-text-muted">{s.role_title}</p>}
                    </button>
                    <button
                      onClick={() => handleRemoveStaff(s.id)}
                      className="text-xs text-status-injured hover:underline"
                    >
                      {t("teamDetail.remove")}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </Card>

          {teamId && !isPlayer && <TeamRenewals teamId={teamId} />}

          {teamId && !isPlayer && (
            <TeamListings
              teamId={teamId}
              canPost={user?.role === "president" || user?.role === "technical_director" || user?.role === "super_admin" || user?.role === "admin"}
            />
          )}

          {!isPlayer && (teamRequests.length > 0 || playerRequests.length > 0) && (
            <Card corners className="mb-6">
              <div className="border-b border-line px-4 py-3">
                <h3 className="font-display text-sm uppercase tracking-wide text-chalk">
                  {t("teamDetail.pendingRequestsPrefix")}{teamRequests.length + playerRequests.length})
                </h3>
              </div>
              <div className="divide-y divide-line">
                {teamRequests.map((r) => (
                  <div key={r.id} className="flex items-center justify-between px-4 py-3 text-sm">
                    <div>
                      <p className="text-text-primary">
                        {r.applicant_name || "—"}{" "}
                        <span className="text-xs text-text-muted">{t("teamDetail.wantsToTakeTeam")}</span>
                      </p>
                      <p className="text-xs text-text-muted">
                        {t("teamDetail.expiresPrefix")}{new Date(r.expires_at).toLocaleDateString("el-GR")}
                        {r.message ? ` · "${r.message}"` : ""}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {r.can_respond ? (
                        <>
                          <Button
                            variant="secondary"
                            onClick={() => openAcceptTeamRequest(r)}
                            isLoading={respondingId === r.id}
                          >
                            {t("teamDetail.accept")}
                          </Button>
                          <button
                            onClick={() => handleRejectTeamRequest(r.id)}
                            className="text-xs text-status-injured hover:underline"
                          >
                            {t("teamDetail.reject")}
                          </button>
                        </>
                      ) : (
                        <span className="text-xs text-text-muted">
                          {t("teamDetail.noPermissionToRespond")}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
                {playerRequests.map((r) => (
                  <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                    <div>
                      <p className="text-text-primary">
                        {r.applicant_name || "—"}{" "}
                        <span className="text-xs text-text-muted">{t("teamDetail.wantsToJoinAsPlayer")}</span>
                      </p>
                      <p className="text-xs text-text-muted">
                        {t("teamDetail.expiresPrefix")}{new Date(r.expires_at).toLocaleDateString("el-GR")}
                        {r.message ? ` · "${r.message}"` : ""}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      {r.can_respond ? (
                        <>
                          {unlinkedPlayers.length > 0 && (
                            <select
                              value={linkSelections[r.id] || ""}
                              onChange={(e) =>
                                setLinkSelections((prev) => ({ ...prev, [r.id]: e.target.value }))
                              }
                              className="rounded-md border border-line bg-surface px-2 py-1.5 text-xs text-text-primary"
                              title={t("teamDetail.linkExistingPlayerOptional")}
                            >
                              <option value="">{t("teamDetail.newPlayerRegistration")}</option>
                              {unlinkedPlayers.map((p) => (
                                <option key={p.id} value={p.id}>
                                  🔗 {p.first_name} {p.last_name}
                                </option>
                              ))}
                            </select>
                          )}
                          <Button
                            variant="secondary"
                            onClick={() => handleRespondPlayerRequest(r.id, true, linkSelections[r.id] || undefined)}
                            isLoading={respondingId === r.id}
                          >
                            {t("teamDetail.accept")}
                          </Button>
                          <button
                            onClick={() => handleRespondPlayerRequest(r.id, false)}
                            className="text-xs text-status-injured hover:underline"
                          >
                            {t("teamDetail.reject")}
                          </button>
                        </>
                      ) : (
                        <span className="text-xs text-text-muted">
                          {t("teamDetail.noPermissionToRespond")}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {!isPlayer && accessGrants.length > 0 && (
            <Card className="mb-6">
              <div className="border-b border-line px-4 py-3">
                <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                  {t("teamDetail.managementAccessPrefix")}{accessGrants.length})
                </h3>
              </div>
              <div className="divide-y divide-line">
                {accessGrants.map((g) => (
                  <div key={g.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                    <button
                      type="button"
                      onClick={() => setSelectedAccessGrant(g)}
                      className="text-left hover:text-chalk"
                    >
                      <p className="text-text-primary hover:underline">{g.full_name || g.username}</p>
                      {g.role_title && <p className="text-xs text-text-muted">{g.role_title}</p>}
                    </button>
                    <button
                      onClick={() => handleRevokeGrant(g.id)}
                      className="text-xs text-status-injured hover:underline"
                    >
                      {t("teamDetail.removeAccess")}
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card>
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                Roster ({players.length})
              </h3>
              {!isPlayer && (
                <div className="flex items-center gap-3">
                  <ExportMenu
                    onExportExcel={() => exportRosterExcel(team.id, team.name)}
                    onExportPdf={() => exportRosterPdf(team.id, team.name)}
                    label={t("teamDetail.exportRoster")}
                  />
                  <button
                    onClick={() => setShowCsvTemplate(true)}
                    className="text-xs text-text-muted hover:text-chalk"
                  >
                    {t("csvTemplate.viewButton")}
                  </button>
                  <input
                    ref={csvInputRef}
                    type="file"
                    accept=".csv,.xlsx"
                    className="hidden"
                    onChange={handleCsvChange}
                  />
                  <button
                    onClick={() => csvInputRef.current?.click()}
                    disabled={isImportingCsv}
                    className="text-xs text-text-muted hover:text-chalk disabled:opacity-50"
                    title={t("players.csvColumnsHelp")}
                  >
                    {isImportingCsv ? t("teamDetail.importing") : t("teamDetail.importCsvExcel")}
                  </button>
                  <Link to={`/players?team_id=${team.id}`} className="text-xs text-chalk hover:underline">
                    {t("teamDetail.addPlayer")}
                  </Link>
                </div>
              )}
            </div>
            {players.length === 0 ? (
              <div className="p-6">
                <EmptyState
                  title={t("teamDetail.noPlayersYet")}
                  description={t("teamDetail.addPlayersFromPlayersPage")}
                  action={
                    <Link to={`/players?team_id=${team.id}`}>
                      <Button>{t("teamDetail.addPlayer")}</Button>
                    </Link>
                  }
                />
              </div>
            ) : (
              <div>
                {groupPlayersByCategory(players, POSITION_CATEGORIES, t("teamDetail.noPosition")).map((group) => (
                  <div key={group.label}>
                    <div className="border-b border-t border-line bg-surface-raised/40 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-text-muted first:border-t-0">
                      {group.label} ({group.players.length})
                    </div>
                    <div className="divide-y divide-line">
                      {group.players.map((p) => (
                        <Link
                          key={p.id}
                          to={`/players/${p.id}`}
                          className="flex items-center justify-between px-4 py-3 text-sm hover:bg-surface-raised"
                        >
                          <div className="flex items-center gap-3">
                            <span className="flex h-8 w-8 items-center justify-center rounded-full border border-line bg-void font-mono text-xs text-text-muted">
                              {p.player_number ?? "-"}
                            </span>
                            <span className="text-text-primary">
                              {p.first_name} {p.last_name}
                            </span>
                            <span className="text-xs text-text-muted">{p.position}</span>
                          </div>
                          <StatusBadge status={p.status} />
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      <Modal
        isOpen={!!statusModal}
        onClose={() => setStatusModal(null)}
        title={statusModal ? `${statusModal.label} (${players.filter((p) => (p.status || "fit") === statusModal.key).length})` : ""}
      >
        {statusModal && (
          <div className="space-y-2">
            {players.filter((p) => (p.status || "fit") === statusModal.key).length === 0 ? (
              <p className="text-sm text-text-muted">{t("teamDetail.noPlayersInStatus")}</p>
            ) : (
              players
                .filter((p) => (p.status || "fit") === statusModal.key)
                .map((p) => (
                  <Link
                    key={p.id}
                    to={`/players/${p.id}`}
                    className="block rounded-md border border-line bg-surface-raised px-3 py-2 hover:border-chalk"
                  >
                    <p className="text-sm text-text-primary">
                      {p.first_name} {p.last_name}
                      {p.position ? <span className="text-text-muted"> · {p.position}</span> : null}
                    </p>
                    {statusModal.key === "injured" && (p.injury_type || p.expected_return) && (
                      <p className="mt-0.5 text-xs text-status-injured">
                        {p.injury_type || t("teamDetail.injuryDefault")}
                        {p.expected_return
                          ? ` · ${t("teamDetail.returnPrefix")}${new Date(p.expected_return).toLocaleDateString("el-GR")}`
                          : ""}
                      </p>
                    )}
                    {statusModal.key !== "injured" && statusModal.key !== "fit" && p.availability_notes && (
                      <p className="mt-0.5 text-xs text-text-muted">{p.availability_notes}</p>
                    )}
                  </Link>
                ))
            )}
          </div>
        )}
      </Modal>

      <Modal isOpen={showEdit} onClose={() => setShowEdit(false)} title={t("teamDetail.editTeamModalTitle")} wide>
        <TeamForm
          team={team}
          onSubmit={handleUpdate}
          onCancel={() => setShowEdit(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title={t("scouting.deleteTeam")}
        message={`${t("teamDetail.deleteConfirmPrefix")}${team.name}${t("teamDetail.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />

      <Modal isOpen={!!csvResult} onClose={() => setCsvResult(null)} title={t("players.importResultTitle")}>
        {csvResult && (
          <div className="space-y-3 text-sm">
            <p className="text-status-fit">
              {t("players.createdPrefix")}
              {csvResult.created}
              {t("players.createdSuffix")}
            </p>
            {csvResult.errors.length > 0 && (
              <div>
                <p className="mb-1 text-status-injured">
                  {t("players.rowsSkippedPrefix")}
                  {csvResult.errors.length}
                  {t("players.rowsSkippedSuffix")}
                </p>
                <div className="max-h-48 space-y-1 overflow-y-auto rounded-md border border-line bg-surface-raised p-2">
                  {csvResult.errors.map((e, i) => (
                    <p key={i} className="text-xs text-text-muted">
                      {t("players.rowLabel")}
                      {e.row}: {e.message}
                    </p>
                  ))}
                </div>
              </div>
            )}
            <div className="flex justify-end">
              <Button onClick={() => setCsvResult(null)}>{t("common.close")}</Button>
            </div>
          </div>
        )}
      </Modal>

      <Modal isOpen={showAddStaff} onClose={() => setShowAddStaff(false)} title={t("teamDetail.addToStaffModalTitle")}>
        <div className="space-y-4">
          <div>
            <Input
              label={t("teamDetail.searchUserPlaceholder")}
              value={staffSearchQuery}
              onChange={(e) => handleStaffSearchChange(e.target.value)}
              autoFocus
            />
            {staffSearchResults.length > 0 && !selectedStaffUser && (
              <div className="mt-1.5 max-h-40 overflow-y-auto rounded-md border border-line bg-surface-raised">
                {staffSearchResults.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      setSelectedStaffUser(u);
                      setStaffSearchQuery(u.full_name || u.username);
                      setStaffSearchResults([]);
                    }}
                    className="block w-full px-3 py-2 text-left text-sm text-text-primary hover:bg-void"
                  >
                    {u.full_name || u.username} <span className="text-xs text-text-muted">@{u.username}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <Input
            label={t("teamDetail.roleInTeamOptional")}
            placeholder={t("teamDetail.roleInTeamPlaceholder")}
            value={staffRoleTitle}
            onChange={(e) => setStaffRoleTitle(e.target.value)}
          />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowAddStaff(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              onClick={handleAddStaff}
              isLoading={isAddingStaff}
              disabled={!selectedStaffUser}
            >
              {t("teamDetail.addStaffButton")}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal
        isOpen={!!acceptingRequest}
        onClose={() => setAcceptingRequest(null)}
        title={t("teamDetail.acceptRequestTitle")}
      >
        {acceptingRequest && (
          <div className="space-y-4">
            <p className="text-sm text-text-muted">
              {t("teamDetail.acceptingPrefix")}<span className="text-text-primary">{acceptingRequest.applicant_name}</span>{" "}
              {t("teamDetail.acceptingMiddle")}<span className="text-text-primary">{team.name}</span>{t("teamDetail.acceptingSuffix")}
            </p>
            <Input
              label={t("teamDetail.roleOptional")}
              placeholder={t("teamDetail.rolePlaceholder")}
              value={acceptRoleTitle}
              onChange={(e) => setAcceptRoleTitle(e.target.value)}
            />
            {allMyTeams.length > 0 && (
              <div>
                <p className="mb-1.5 text-xs font-medium text-text-muted">
                  {t("teamDetail.assignAdditionalTeams")}
                </p>
                <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-line p-2">
                  {allMyTeams.map((teamOpt) => (
                    <label key={teamOpt.id} className="flex items-center gap-2 text-sm text-text-primary">
                      <input
                        type="checkbox"
                        checked={additionalTeamIds.includes(teamOpt.id)}
                        disabled={!additionalTeamIds.includes(teamOpt.id) && additionalTeamIds.length >= 2}
                        onChange={(e) =>
                          setAdditionalTeamIds((prev) =>
                            e.target.checked ? [...prev, teamOpt.id] : prev.filter((id) => id !== teamOpt.id)
                          )
                        }
                        className="h-3.5 w-3.5 accent-chalk"
                      />
                      {teamOpt.name}
                    </label>
                  ))}
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="secondary" onClick={() => setAcceptingRequest(null)}>
                {t("common.cancel")}
              </Button>
              <Button
                type="button"
                onClick={handleConfirmAcceptTeamRequest}
                isLoading={respondingId === acceptingRequest.id}
              >
                {t("teamDetail.confirmAccept")}
              </Button>
            </div>
          </div>
        )}
      </Modal>

      <CsvTemplateModal isOpen={showCsvTemplate} onClose={() => setShowCsvTemplate(false)} />

      {teamId && (
        <TeamStaffMemberModal
          member={selectedStaffMember}
          teamId={teamId}
          myTeams={myTeamsForOffer}
          canManage={!isPlayer}
          onClose={() => setSelectedStaffMember(null)}
          onActionComplete={load}
        />
      )}
      {teamId && (
        <TeamAccessGrantModal
          grant={selectedAccessGrant}
          teamId={teamId}
          myTeams={myTeamsForOffer}
          canManage={!isPlayer}
          onClose={() => setSelectedAccessGrant(null)}
          onActionComplete={load}
        />
      )}
    </AppLayout>
  );
}

function Row({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-text-muted">{label}</dt>
      <dd className="text-right text-text-primary">{value || "—"}</dd>
    </div>
  );
}
