import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { extractErrorMessage } from "../../api/client";
import { startConversation } from "../../api/messages";
import { addStaffEvaluation, fireStaffMember, listStaffEvaluations, updateStaffRoleTitle } from "../../api/staff";
import type { StaffEvaluationItem } from "../../api/staff";
import type { TeamAccessGrantItem } from "../../api/requests";
import { StaffOfferModal } from "../../components/StaffOfferModal";
import { Button } from "../../components/ui/Button";
import { Input, Textarea } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import type { Team } from "../../types";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";

function Stars({ value }: { value: number }) {
  return (
    <span className="text-chalk">
      {"★".repeat(Math.round(value))}
      <span className="text-line">{"★".repeat(5 - Math.round(value))}</span>
    </span>
  );
}

export function TeamAccessGrantModal({
  grant,
  teamId,
  myTeams,
  canManage,
  onClose,
  onActionComplete,
}: {
  grant: TeamAccessGrantItem | null;
  teamId: string;
  myTeams: Team[];
  canManage: boolean;
  onClose: () => void;
  onActionComplete: () => void;
}) {
  const { t } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [roleTitle, setRoleTitle] = useState("");
  const [isSavingRole, setIsSavingRole] = useState(false);
  const [isStartingConversation, setIsStartingConversation] = useState(false);
  const [showOfferModal, setShowOfferModal] = useState(false);

  const [evaluations, setEvaluations] = useState<StaffEvaluationItem[]>([]);
  const [isLoadingEvals, setIsLoadingEvals] = useState(false);
  const [evalRating, setEvalRating] = useState(5);
  const [evalComment, setEvalComment] = useState("");
  const [isSubmittingEval, setIsSubmittingEval] = useState(false);

  const [showFireConfirm, setShowFireConfirm] = useState(false);
  const [isFiring, setIsFiring] = useState(false);

  useEffect(() => {
    setRoleTitle(grant?.role_title || "");
    setEvaluations([]);
    setEvalRating(5);
    setEvalComment("");
    if (!grant) return;
    setIsLoadingEvals(true);
    listStaffEvaluations(teamId, grant.user_id)
      .then(setEvaluations)
      .catch(() => {
        /* σιωπηλή αποτυχία */
      })
      .finally(() => setIsLoadingEvals(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [grant?.id, teamId]);

  async function handleSaveRole() {
    if (!grant) return;
    setIsSavingRole(true);
    try {
      await updateStaffRoleTitle(teamId, grant.user_id, roleTitle);
      toast.show(t("teamStaffProfile.roleSaved"), "success");
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingRole(false);
    }
  }

  async function handleStartConversation() {
    if (!grant) return;
    setIsStartingConversation(true);
    try {
      const conversation = await startConversation(grant.user_id);
      onClose();
      navigate(`/messages?conversation_id=${conversation.id}`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsStartingConversation(false);
    }
  }

  async function handleSubmitEval() {
    if (!grant) return;
    setIsSubmittingEval(true);
    try {
      const newEval = await addStaffEvaluation(teamId, grant.user_id, evalRating, evalComment || undefined);
      setEvaluations((prev) => [newEval, ...prev]);
      setEvalComment("");
      toast.show(t("teamStaffProfile.evaluationAdded"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmittingEval(false);
    }
  }

  async function handleFire() {
    if (!grant) return;
    setIsFiring(true);
    try {
      await fireStaffMember(teamId, grant.user_id);
      toast.show(t("teamStaffProfile.memberRemoved"), "success");
      setShowFireConfirm(false);
      onClose();
      onActionComplete();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsFiring(false);
    }
  }

  const overallRating =
    evaluations.length > 0 ? evaluations.reduce((sum, e) => sum + e.rating, 0) / evaluations.length : null;

  return (
    <>
      <Modal isOpen={!!grant} onClose={onClose} title={t("teamStaffProfile.title")} wide>
        {grant && (
          <div className="space-y-5">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-line bg-surface-raised font-display text-lg text-text-muted">
                {(grant.full_name || grant.username || "?").charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-lg text-text-primary">
                  {grant.full_name || grant.username}
                </p>
                {grant.username && <p className="truncate text-sm text-text-muted">@{grant.username}</p>}
              </div>
              {overallRating != null && (
                <div className="text-right">
                  <Stars value={overallRating} />
                  <p className="text-xs text-text-muted">
                    {overallRating.toFixed(1)} ({evaluations.length})
                  </p>
                </div>
              )}
            </div>

            {canManage && (
              <div className="flex flex-wrap items-end gap-2 border-t border-line pt-4">
                <Input
                  label={t("teamStaffProfile.responsibilityLabel")}
                  value={roleTitle}
                  onChange={(e) => setRoleTitle(e.target.value)}
                  placeholder={t("teamStaffProfile.responsibilityPlaceholder")}
                  className="flex-1"
                />
                <Button
                  onClick={handleSaveRole}
                  isLoading={isSavingRole}
                  disabled={roleTitle === (grant.role_title || "")}
                >
                  {t("teamStaffProfile.saveResponsibility")}
                </Button>
              </div>
            )}

            <div className="flex flex-wrap gap-2 border-t border-line pt-4">
              {grant.user_id !== user?.id && (
                <Button onClick={handleStartConversation} isLoading={isStartingConversation}>
                  💬 {t("staffScoutingModal.contactButton")}
                </Button>
              )}
              {canManage && grant.user_id !== user?.id && (
                <Button variant="secondary" onClick={() => setShowOfferModal(true)}>
                  📄 {t("staffScoutingModal.offerButton")}
                </Button>
              )}
              {canManage && grant.user_id !== user?.id && (
                <Button variant="secondary" onClick={() => setShowFireConfirm(true)}>
                  🗑 {t("teamStaffProfile.removeButton")}
                </Button>
              )}
            </div>

            <div className="border-t border-line pt-4">
              <h3 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
                {t("teamStaffProfile.evaluationsHeading")}
              </h3>
              {canManage && (
                <div className="mb-4 space-y-2 rounded-md border border-line bg-surface-raised p-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-text-muted">{t("teamStaffProfile.ratingLabel")}</span>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((n) => (
                        <button
                          key={n}
                          type="button"
                          onClick={() => setEvalRating(n)}
                          className={`text-lg ${n <= evalRating ? "text-chalk" : "text-line"}`}
                        >
                          ★
                        </button>
                      ))}
                    </div>
                  </div>
                  <Textarea
                    value={evalComment}
                    onChange={(e) => setEvalComment(e.target.value)}
                    placeholder={t("teamStaffProfile.observationPlaceholder")}
                    className="min-h-[70px]"
                  />
                  <div className="flex justify-end">
                    <Button onClick={handleSubmitEval} isLoading={isSubmittingEval}>
                      {t("teamStaffProfile.addEvaluation")}
                    </Button>
                  </div>
                </div>
              )}
              {isLoadingEvals ? (
                <p className="text-sm text-text-muted">{t("settings.loading")}</p>
              ) : evaluations.length === 0 ? (
                <p className="text-sm text-text-muted">{t("teamStaffProfile.noEvaluations")}</p>
              ) : (
                <div className="space-y-2">
                  {evaluations.map((e) => (
                    <div key={e.id} className="rounded-md border border-line px-3 py-2 text-sm">
                      <div className="flex items-center justify-between">
                        <Stars value={e.rating} />
                        <span className="text-xs text-text-muted">
                          {e.evaluator_name} · {new Date(e.created_at).toLocaleDateString("el-GR")}
                        </span>
                      </div>
                      {e.comment && <p className="mt-1 text-text-muted">{e.comment}</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      <StaffOfferModal
        target={
          showOfferModal && grant ? { user_id: grant.user_id, full_name: grant.full_name || grant.username || "" } : null
        }
        myTeams={myTeams}
        onClose={() => setShowOfferModal(false)}
      />

      <ConfirmDialog
        isOpen={showFireConfirm}
        title={t("teamStaffProfile.confirmRemoveTitle")}
        message={t("teamStaffProfile.confirmRemoveMessage")}
        confirmLabel={t("teamStaffProfile.removeButton")}
        onConfirm={handleFire}
        onClose={() => setShowFireConfirm(false)}
        isLoading={isFiring}
      />
    </>
  );
}
