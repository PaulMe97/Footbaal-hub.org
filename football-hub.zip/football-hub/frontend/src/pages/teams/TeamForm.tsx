import { FormEvent, useEffect, useState } from "react";

import { listCountries, listFederations, listLeagueGroups, listLeagueLevels, listRegions } from "../../api/scouting";
import type { LeagueGroupItem, LeagueLevelItem } from "../../api/scouting";
import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { GREECE_LEAGUE_TIERS, LEAGUE_TIER_LABELS, ACADEMY_AGE_GROUPS } from "../../types";
import type { Country, Federation, LeagueTier, Region, Team } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export interface TeamFormValues {
  name: string;
  category: string;
  season: string;
  home_stadium: string;
  coach_name: string;
  primary_color: string;
  secondary_color: string;
  description: string;
  notes: string;
  country_id: string;
  league_tier: LeagueTier;
  academy_age_group: string;
  federation_id: string;
  league_level_id: string;
  league_group_id: string;
  is_public_scouting: boolean;
}

function toFormValues(team?: Team | null): TeamFormValues {
  return {
    name: team?.name ?? "",
    category: team?.category ?? "",
    season: team?.season ?? "",
    home_stadium: team?.home_stadium ?? "",
    coach_name: team?.coach_name ?? "",
    primary_color: team?.primary_color ?? "#3E7D52",
    secondary_color: team?.secondary_color ?? "#0A0F0D",
    description: team?.description ?? "",
    notes: team?.notes ?? "",
    country_id: team?.country_id ?? "",
    league_tier: (team?.league_tier as LeagueTier) ?? "regional",
    academy_age_group: team?.academy_age_group ?? "",
    federation_id: team?.federation_id ?? "",
    league_level_id: team?.league_level_id ?? "",
    league_group_id: team?.league_group_id ?? "",
    is_public_scouting: team?.is_public_scouting ?? true,
  };
}

export function TeamForm({
  team,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  team?: Team | null;
  onSubmit: (values: TeamFormValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const [values, setValues] = useState<TeamFormValues>(toFormValues(team));
  const { t } = useLanguage();
  const [countries, setCountries] = useState<Country[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [selectedRegionId, setSelectedRegionId] = useState("");
  const [federations, setFederations] = useState<Federation[]>([]);
  const [levels, setLevels] = useState<LeagueLevelItem[]>([]);
  const [groups, setGroups] = useState<LeagueGroupItem[]>([]);

  function set<K extends keyof TeamFormValues>(key: K, value: TeamFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  // Φόρτωσε χώρες, προεπίλεξε Ελλάδα αν δεν υπάρχει ήδη τιμή
  useEffect(() => {
    listCountries().then((data) => {
      setCountries(data);
      if (!values.country_id) {
        const greece = data.find((c) => c.name === "Ελλάδα");
        if (greece) set("country_id", greece.id);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!values.country_id) return;
    listRegions(values.country_id).then(setRegions);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.country_id]);

  const hasGeoNav = values.league_tier === "regional" || values.league_tier === "academy";
  const isNationalTier =
    values.league_tier === "top_division" ||
    values.league_tier === "second_division" ||
    values.league_tier === "third_division";

  // Φόρτωσε ΕΠΣ όταν επιλεγεί περιφέρεια (μόνο για εμφάνιση επιλογών — το
  // πεδίο που στέλνεται τελικά είναι federation_id)
  useEffect(() => {
    if (!selectedRegionId) {
      setFederations([]);
      return;
    }
    listFederations(selectedRegionId).then(setFederations);
  }, [selectedRegionId]);

  // Φόρτωσε Επίπεδα (Α1/Α'/Β'/Γ' ή Κ8-Κ17) όταν επιλεγεί ΕΠΣ
  useEffect(() => {
    if (!values.federation_id || !hasGeoNav) {
      setLevels([]);
      return;
    }
    listLeagueLevels(values.federation_id, values.league_tier).then(setLevels);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.federation_id, values.league_tier]);

  // Φόρτωσε Ομίλους όταν επιλεγεί Επίπεδο
  useEffect(() => {
    if (!values.league_level_id) {
      setGroups([]);
      return;
    }
    listLeagueGroups(values.league_level_id).then(setGroups);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values.league_level_id]);

  const isGreece = countries.find((c) => c.id === values.country_id)?.name === "Ελλάδα";
  const availableTiers: LeagueTier[] = isGreece
    ? GREECE_LEAGUE_TIERS
    : (["top_division", "academy"] as LeagueTier[]);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input
        label={t("teamForm.nameRequired")}
        required
        value={values.name}
        onChange={(e) => set("name", e.target.value)}
      />
      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("crm.category")}
          placeholder={t("teamForm.categoryPlaceholder")}
          value={values.category}
          onChange={(e) => set("category", e.target.value)}
        />
        <Input
          label="Season"
          placeholder="2025-2026"
          value={values.season}
          onChange={(e) => set("season", e.target.value)}
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("teamForm.homeStadium")}
          value={values.home_stadium}
          onChange={(e) => set("home_stadium", e.target.value)}
        />
        <Input
          label={t("crm.roleHeadCoach")}
          value={values.coach_name}
          onChange={(e) => set("coach_name", e.target.value)}
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("teamForm.primaryColor")}
          type="color"
          value={values.primary_color}
          onChange={(e) => set("primary_color", e.target.value)}
          className="h-10 cursor-pointer"
        />
        <Input
          label={t("teamForm.secondaryColor")}
          type="color"
          value={values.secondary_color}
          onChange={(e) => set("secondary_color", e.target.value)}
          className="h-10 cursor-pointer"
        />
      </div>

      <div className="rounded-md border border-line bg-surface-raised p-3">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-text-muted">
          Scouting Hub
        </p>
        <div className="grid grid-cols-2 gap-4">
          <Select label={t("teamForm.country")} value={values.country_id} onChange={(e) => set("country_id", e.target.value)}>
            {countries.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
          <Select
            label={t("teamForm.leagueTierCategory")}
            value={values.league_tier}
            onChange={(e) => {
              set("league_tier", e.target.value as LeagueTier);
              set("league_level_id", "");
              set("league_group_id", "");
            }}
          >
            {availableTiers.map((tier) => (
              <option key={tier} value={tier}>
                {LEAGUE_TIER_LABELS[tier]}
              </option>
            ))}
          </Select>
        </div>

        {isNationalTier && (
          <div className="mt-4">
            <p className="mb-1.5 text-xs text-text-muted">{t("teamType.label")}</p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => set("academy_age_group", "")}
                className={`rounded-md border px-3 py-1.5 text-xs ${
                  !values.academy_age_group
                    ? "border-chalk/60 bg-chalk/10 text-chalk"
                    : "border-line text-text-muted hover:border-chalk"
                }`}
              >
                {t("teamType.senior")}
              </button>
              <button
                type="button"
                onClick={() => set("academy_age_group", values.academy_age_group || "K19")}
                className={`rounded-md border px-3 py-1.5 text-xs ${
                  values.academy_age_group
                    ? "border-chalk/60 bg-chalk/10 text-chalk"
                    : "border-line text-text-muted hover:border-chalk"
                }`}
              >
                {t("teamType.academy")}
              </button>
            </div>
            {values.academy_age_group && (
              <Select
                label={t("teamForm.academyAgeGroupLabel")}
                value={values.academy_age_group}
                onChange={(e) => set("academy_age_group", e.target.value)}
                className="mt-3"
              >
                {ACADEMY_AGE_GROUPS.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </Select>
            )}
          </div>
        )}

        {hasGeoNav && (
          <>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <Select
                label={t("teamForm.regionLabel")}
                value={selectedRegionId}
                onChange={(e) => {
                  setSelectedRegionId(e.target.value);
                  set("federation_id", "");
                  set("league_level_id", "");
                  set("league_group_id", "");
                }}
              >
                <option value="">{t("teamForm.selectRegion")}</option>
                {regions.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </Select>
              <Select
                label="ΕΠΣ"
                value={values.federation_id}
                onChange={(e) => {
                  set("federation_id", e.target.value);
                  set("league_level_id", "");
                  set("league_group_id", "");
                }}
                disabled={!selectedRegionId}
              >
                <option value="">{t("teamForm.selectFederationEPS")}</option>
                {federations.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </Select>
            </div>

            {values.federation_id && (
              <div className="mt-4 grid grid-cols-2 gap-4">
                <Select
                  label={values.league_tier === "academy" ? t("scouting.ageCategory") : t("scouting.level")}
                  value={values.league_level_id}
                  onChange={(e) => {
                    set("league_level_id", e.target.value);
                    set("league_group_id", "");
                  }}
                >
                  <option value="">
                    {levels.length === 0 ? t("teamForm.noneDefinedYet") : t("scouting.selectLevel")}
                  </option>
                  {levels.map((lvl) => (
                    <option key={lvl.id} value={lvl.id}>
                      {lvl.name}
                    </option>
                  ))}
                </Select>
                <Select
                  label={t("scouting.group")}
                  value={values.league_group_id}
                  onChange={(e) => set("league_group_id", e.target.value)}
                  disabled={!values.league_level_id || groups.length === 0}
                >
                  <option value="">
                    {!values.league_level_id
                      ? t("teamForm.selectLevelFirst")
                      : groups.length === 0
                        ? t("teamForm.noGroupsYet")
                        : t("teamForm.selectGroup")}
                  </option>
                  {groups.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name}
                    </option>
                  ))}
                </Select>
              </div>
            )}
          </>
        )}

        <label className="mt-4 flex items-center gap-2 text-sm text-text-primary">
          <input
            type="checkbox"
            checked={values.is_public_scouting}
            onChange={(e) => set("is_public_scouting", e.target.checked)}
            className="h-4 w-4 accent-chalk"
          />
          {t("teamForm.visibleInScoutingPublic")}
        </label>
      </div>

      <Textarea
        label={t("teamForm.description")}
        value={values.description}
        onChange={(e) => set("description", e.target.value)}
      />
      <Textarea label={t("calendar.notes")} value={values.notes} onChange={(e) => set("notes", e.target.value)} />

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {team ? t("common.save") : t("common.create")}
        </Button>
      </div>
    </form>
  );
}
