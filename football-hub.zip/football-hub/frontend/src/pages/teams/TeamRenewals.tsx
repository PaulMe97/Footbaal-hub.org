import { useEffect, useState } from "react";

import { extractErrorMessage } from "../../api/client";
import { listTeamRenewals, resolveTeamRenewal } from "../../api/renewals";
import type { RenewalRequestItem } from "../../api/renewals";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";

export function TeamRenewals({ teamId }: { teamId: string }) {
  const toast = useToast();
  const { t } = useLanguage();
  const [renewals, setRenewals] = useState<RenewalRequestItem[]>([]);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  async function load() {
    try {
      const data = await listTeamRenewals(teamId);
      setRenewals(data.filter((r) => r.status === "on_hold"));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamId]);

  async function handleResolve(renewalId: string, action: "confirm" | "release") {
    setResolvingId(renewalId);
    try {
      await resolveTeamRenewal(teamId, renewalId, action);
      setRenewals((prev) => prev.filter((r) => r.id !== renewalId));
      toast.show(
        action === "confirm" ? t("teamRenewals.continuationConfirmed") : t("teamRenewals.partnerFreed"),
        "success"
      );
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setResolvingId(null);
    }
  }

  if (renewals.length === 0) return null;

  return (
    <Card corners className="mb-6">
      <div className="border-b border-line px-4 py-3">
        <h3 className="font-display text-sm uppercase tracking-wide text-chalk">
          {t("teamRenewals.pendingRenewalsPrefix")}{renewals.length})
        </h3>
      </div>
      <div className="divide-y divide-line">
        {renewals.map((r) => (
          <div key={r.id} className="px-4 py-3">
            <p className="text-sm text-text-primary">
              {r.user_name} · {r.current_season} → {r.next_season}
            </p>
            {r.hold_reason && <p className="mt-1 text-xs text-text-muted">"{r.hold_reason}"</p>}
            {r.hold_deadline && (
              <p className="mt-1 text-xs text-text-muted">
                {t("teamRenewals.deadlinePrefix")}{new Date(r.hold_deadline).toLocaleDateString("el-GR")}{t("teamRenewals.deadlineSuffix")}
              </p>
            )}
            <div className="mt-2 flex gap-2">
              <Button
                variant="secondary"
                onClick={() => handleResolve(r.id, "confirm")}
                isLoading={resolvingId === r.id}
              >
                {t("teamRenewals.confirmContinuation")}
              </Button>
              <Button
                variant="danger"
                onClick={() => handleResolve(r.id, "release")}
                isLoading={resolvingId === r.id}
              >
                {t("teamRenewals.release")}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
