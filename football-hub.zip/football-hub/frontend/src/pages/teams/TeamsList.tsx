import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { createTeam, deleteTeam, listTeams } from "../../api/teams";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { AppLayout } from "../../components/layout/AppLayout";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Input } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import type { LeagueTier, Team } from "../../types";
import { LEAGUE_TIER_LABELS } from "../../types";
import { TeamForm, type TeamFormValues } from "./TeamForm";

export default function TeamsList() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Team | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const toast = useToast();

  async function load() {
    setIsLoading(true);
    try {
      const data = await listTeams({ search: search || undefined });
      setTeams(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  async function handleCreate(values: TeamFormValues) {
    setIsSubmitting(true);
    try {
      await createTeam(values);
      toast.show(t("teams.created"), "success");
      setShowCreate(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteTeam(deleteTarget.id);
      toast.show(t("teams.deleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  return (
    <AppLayout title={t("teams.title")}>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Input
          placeholder={t("teams.searchPlaceholder")}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="sm:w-72"
        />
        <Button onClick={() => setShowCreate(true)}>{t("teams.newTeam")}</Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : teams.length === 0 ? (
        <EmptyState
          title={t("teams.noTeamsYet")}
          description={t("teams.noTeamsDescription")}
          action={<Button onClick={() => setShowCreate(true)}>{t("teams.newTeam")}</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((team) => (
            <Card
              key={team.id}
              corners
              className="flex cursor-pointer flex-col p-5 transition-colors hover:border-chalk"
              onClick={() => navigate(`/teams/${team.id}`)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") navigate(`/teams/${team.id}`);
              }}
            >
              <div className="flex items-start gap-3">
                <div
                  className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm"
                  style={{ borderColor: team.primary_color || undefined }}
                >
                  {team.logo_path ? (
                    <img src={mediaUrl(team.logo_path)} alt="" className="h-full w-full object-cover" />
                  ) : (
                    team.name.slice(0, 2).toUpperCase()
                  )}
                </div>
                <div className="min-w-0">
                  <p className="font-display text-base text-text-primary">{team.name}</p>
                  <p className="truncate text-xs text-text-muted">
                    {[team.category, team.league_level_name, team.season].filter(Boolean).join(" · ") || "—"}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    {team.league_tier && (
                      <span className="rounded-full border border-chalk/40 bg-chalk/10 px-2 py-0.5 text-[10px] text-chalk">
                        {LEAGUE_TIER_LABELS[team.league_tier as LeagueTier] || team.league_tier}
                      </span>
                    )}
                    {team.federation_name && (
                      <span className="truncate text-[10px] text-text-muted">{team.federation_name}</span>
                    )}
                    {team.is_public_scouting === false && (
                      <span className="rounded-full border border-line px-2 py-0.5 text-[10px] text-text-muted">
                        {t("teams.private")}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-line pt-3 text-sm">
                <span className="text-text-muted">
                  <span className="font-mono text-text-primary">{team.player_count}</span> {t("teams.playersUnit")}
                </span>
                <div className="flex gap-2">
                  <span className="text-xs text-chalk">{t("common.view")} →</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteTarget(team);
                    }}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("common.delete")}
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("teams.newTeamModalTitle")} wide>
        <TeamForm onSubmit={handleCreate} onCancel={() => setShowCreate(false)} isSubmitting={isSubmitting} />
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("teams.deleteTeamTitle")}
        message={`${t("teams.deleteConfirmPrefix")}${deleteTarget?.name}${t("teams.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}
