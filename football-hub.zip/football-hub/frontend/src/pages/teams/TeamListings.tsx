import { useEffect, useState } from "react";

import { extractErrorMessage } from "../../api/client";
import {
  closeListing,
  createListing,
  listListingApplications,
  listTeamListings,
  respondToListingApplication,
} from "../../api/listings";
import type { ListingApplicationItem, TeamListingItem } from "../../api/listings";
import { listFederations } from "../../api/scouting";
import { ListingDetailModal } from "../../components/ListingDetailModal";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { POSITIONS } from "../../types";
import type { Federation } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

function ApplicantRow({
  app,
  onRespond,
  isResponding,
}: {
  app: ListingApplicationItem;
  onRespond: (accept: boolean) => void;
  isResponding: boolean;
}) {
  const { t } = useLanguage();
  return (
    <div className="border-b border-line px-4 py-3 last:border-0">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm text-text-primary">{app.applicant_name || "—"}</p>
          {app.message && <p className="mt-0.5 text-xs text-text-muted">"{app.message}"</p>}
          {app.applicant_player && (
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-text-muted">
              <span>
                {app.applicant_player.position} ·{" "}
                {app.applicant_player.age ? `${app.applicant_player.age}${t("players.yearsOldSuffix")}` : "—"}
              </span>
              <span>
                ⚽ {app.applicant_player.season_stats.goals} · 🅰{" "}
                {app.applicant_player.season_stats.assists} ·{" "}
                {app.applicant_player.season_stats.matches_played}{t("scoutingPlayerCard.matchesAbbrev")}
              </span>
              {app.applicant_player.team_name && <span>{t("teamListings.formerTeamPrefix")}{app.applicant_player.team_name}</span>}
            </div>
          )}
        </div>
        {app.status === "pending" ? (
          app.can_respond ? (
            <div className="flex shrink-0 items-center gap-2">
              <Button variant="secondary" onClick={() => onRespond(true)} isLoading={isResponding}>
                {t("profile.accept")}
              </Button>
              <button
                onClick={() => onRespond(false)}
                className="text-xs text-status-injured hover:underline"
              >
                {t("profile.reject")}
              </button>
            </div>
          ) : (
            <span className="shrink-0 text-xs text-text-muted">{t("teamListings.noPermissionToRespond")}</span>
          )
        ) : (
          <span
            className={`shrink-0 rounded-full border px-2 py-0.5 text-xs ${
              app.status === "accepted"
                ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                : "border-status-injured/40 bg-status-injured/15 text-status-injured"
            }`}
          >
            {app.status === "accepted" ? t("profile.accepted") : t("profile.rejected")}
          </span>
        )}
      </div>
    </div>
  );
}

export function TeamListings({ teamId, canPost }: { teamId: string; canPost: boolean }) {
  const toast = useToast();
  const { t } = useLanguage();
  const STAFF_ROLE_OPTIONS = [
    { value: "technical_director", label: t("crm.roleTechnicalDirector") },
    { value: "head_coach", label: t("crm.roleHeadCoach") },
    { value: "assistant_coach", label: t("crm.roleAssistantCoach") },
    { value: "fitness_coach", label: t("crm.roleFitnessCoach") },
    { value: "analyst", label: t("crm.roleAnalyst") },
    { value: "scout", label: "Scout" },
  ];
  const [listings, setListings] = useState<TeamListingItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedListing, setSelectedListing] = useState<TeamListingItem | null>(null);

  const [listingType, setListingType] = useState<"staff" | "player">("player");
  const [roleNeeded, setRoleNeeded] = useState<string[]>(["head_coach"]);
  const [season, setSeason] = useState("");
  const [employmentType, setEmploymentType] = useState("paid");
  const [positionNeeded, setPositionNeeded] = useState<string[]>([]);
  const [minAge, setMinAge] = useState("");
  const [maxAge, setMaxAge] = useState("");
  const [description, setDescription] = useState("");
  const [federations, setFederations] = useState<Federation[]>([]);
  const [targetFederationIds, setTargetFederationIds] = useState<string[]>([]);

  const [viewingListing, setViewingListing] = useState<TeamListingItem | null>(null);
  const [applications, setApplications] = useState<ListingApplicationItem[]>([]);
  const [isLoadingApps, setIsLoadingApps] = useState(false);
  const [respondingId, setRespondingId] = useState<string | null>(null);

  async function load() {
    setIsLoading(true);
    try {
      const [data, feds] = await Promise.all([listTeamListings(teamId), listFederations()]);
      setListings(data);
      setFederations(feds);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamId]);

  function toggleTargetFederation(id: string) {
    setTargetFederationIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length >= 10 ? prev : [...prev, id]
    );
  }

  async function handleCreate() {
    if (listingType === "staff" && roleNeeded.length === 0) {
      toast.show(t("teamListings.selectAtLeastOneRole"), "error");
      return;
    }
    setIsCreating(true);
    try {
      await createListing(teamId, {
        listing_type: listingType,
        role_needed: listingType === "staff" ? roleNeeded : undefined,
        season: listingType === "staff" ? season || undefined : undefined,
        employment_type: listingType === "staff" ? employmentType : undefined,
        position_needed: listingType === "player" ? positionNeeded : undefined,
        min_age: listingType === "player" && minAge ? Number(minAge) : undefined,
        max_age: listingType === "player" && maxAge ? Number(maxAge) : undefined,
        target_federation_ids: targetFederationIds.length > 0 ? targetFederationIds : undefined,
        description: description || undefined,
      });
      toast.show(t("teamListings.listingPublished"), "success");
      setShowCreate(false);
      setSeason("");
      setPositionNeeded([]);
      setMinAge("");
      setMaxAge("");
      setDescription("");
      setTargetFederationIds([]);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsCreating(false);
    }
  }

  async function handleClose(listingId: string) {
    try {
      await closeListing(teamId, listingId);
      toast.show(t("teamListings.listingClosed"), "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function openApplicants(listing: TeamListingItem) {
    setViewingListing(listing);
    setIsLoadingApps(true);
    try {
      const data = await listListingApplications(listing.id);
      setApplications(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingApps(false);
    }
  }

  async function handleRespond(applicationId: string, accept: boolean) {
    if (!viewingListing) return;
    setRespondingId(applicationId);
    try {
      const updated = await respondToListingApplication(viewingListing.id, applicationId, accept);
      setApplications((prev) => prev.map((a) => (a.id === applicationId ? updated : a)));
      toast.show(accept ? t("teamDetail.requestAccepted") : t("teamDetail.requestRejected"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingId(null);
    }
  }

  if (!canPost && listings.length === 0 && !isLoading) return null;

  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between border-b border-line px-4 py-3">
        <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
          {t("teamListings.listingsPrefix")}{listings.length})
        </h3>
        {canPost && (
          <button onClick={() => setShowCreate(true)} className="text-xs text-chalk hover:underline">
            {t("teamListings.newListing")}
          </button>
        )}
      </div>
      {listings.length === 0 ? (
        <p className="p-4 text-sm text-text-muted">
          {t("teamListings.noListingsYet")}
        </p>
      ) : (
        <div className="divide-y divide-line">
          {listings.map((l) => (
            <div
              key={l.id}
              className="flex cursor-pointer items-center justify-between px-4 py-2.5 text-sm transition-colors hover:bg-surface-raised"
              onClick={() => setSelectedListing(l)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") setSelectedListing(l);
              }}
            >
              <div>
                <p className="text-text-primary">
                  {l.listing_type === "staff"
                    ? l.role_needed
                        .map((r) => STAFF_ROLE_OPTIONS.find((o) => o.value === r)?.label || r)
                        .join(", ") || "Staff"
                    : `${t("teamListings.playerPrefix")}${l.position_needed.join(", ") || t("teamListings.anyPosition")}`}
                  {l.status === "closed" && <span className="ml-2 text-xs text-text-muted">{t("teamListings.closedSuffix")}</span>}
                  {l.status === "expired" && <span className="ml-2 text-xs text-status-injured">{t("teamListings.expiredSuffix")}</span>}
                </p>
                <p className="text-xs text-text-muted">
                  {l.application_count}{t("teamListings.applicationsCountSuffix")}
                  {l.season ? ` · ${l.season}` : ""}
                  {l.employment_type ? ` · ${l.employment_type === "paid" ? t("scouting.employed") : t("scouting.practice")}` : ""}
                  {l.status === "open" && l.expires_at
                    ? ` · ${t("teamListings.expiresPrefixShort")}${new Date(l.expires_at).toLocaleDateString("el-GR")}`
                    : ""}
                </p>
                {l.target_federation_names.length > 0 && (
                  <p className="text-xs text-text-muted">
                    {t("teamListings.targetRegionsPrefix")}{l.target_federation_names.join(", ")}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    openApplicants(l);
                  }}
                  className="text-xs text-chalk hover:underline"
                >
                  {t("teamListings.viewApplications")}
                </button>
                {canPost && l.status === "open" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleClose(l.id);
                    }}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("common.close")}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("teamListings.newListingModalTitle")} wide>
        <div className="space-y-4">
          <div className="flex gap-2">
            <button
              onClick={() => setListingType("player")}
              className={`flex-1 rounded-md border px-3 py-2 text-sm ${
                listingType === "player" ? "border-chalk bg-chalk/10 text-chalk" : "border-line text-text-muted"
              }`}
            >
              {t("teamListings.lookingForPlayerButton")}
            </button>
            <button
              onClick={() => setListingType("staff")}
              className={`flex-1 rounded-md border px-3 py-2 text-sm ${
                listingType === "staff" ? "border-chalk bg-chalk/10 text-chalk" : "border-line text-text-muted"
              }`}
            >
              {t("teamListings.lookingForStaffButton")}
            </button>
          </div>

          {listingType === "staff" ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <p className="mb-1.5 text-xs font-medium text-text-muted">{t("teamListings.rolesUpTo5")}</p>
                <div className="flex flex-wrap gap-2">
                  {STAFF_ROLE_OPTIONS.map((o) => {
                    const checked = roleNeeded.includes(o.value);
                    return (
                      <button
                        key={o.value}
                        type="button"
                        onClick={() =>
                          setRoleNeeded((prev) =>
                            checked
                              ? prev.filter((v) => v !== o.value)
                              : prev.length >= 5
                              ? prev
                              : [...prev, o.value]
                          )
                        }
                        className={`rounded-full border px-3 py-1 text-xs ${
                          checked
                            ? "border-chalk bg-chalk/15 text-chalk"
                            : "border-line text-text-muted hover:border-chalk"
                        }`}
                      >
                        {o.label}
                      </button>
                    );
                  })}
                </div>
              </div>
              <Input
                label={t("teamListings.season")}
                placeholder="2025-2026"
                value={season}
                onChange={(e) => setSeason(e.target.value)}
              />
              <Select
                label={t("teamListings.employmentType")}
                value={employmentType}
                onChange={(e) => setEmploymentType(e.target.value)}
              >
                <option value="paid">{t("scouting.employed")}</option>
                <option value="unpaid">{t("scouting.practice")}</option>
              </Select>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-3">
                <p className="mb-1.5 text-xs font-medium text-text-muted">{t("teamListings.positionsUpTo5")}</p>
                <div className="flex flex-wrap gap-2">
                  {POSITIONS.map((p) => {
                    const checked = positionNeeded.includes(p);
                    return (
                      <button
                        key={p}
                        type="button"
                        onClick={() =>
                          setPositionNeeded((prev) =>
                            checked
                              ? prev.filter((v) => v !== p)
                              : prev.length >= 5
                              ? prev
                              : [...prev, p]
                          )
                        }
                        className={`rounded-full border px-3 py-1 text-xs ${
                          checked
                            ? "border-chalk bg-chalk/15 text-chalk"
                            : "border-line text-text-muted hover:border-chalk"
                        }`}
                      >
                        {p}
                      </button>
                    );
                  })}
                </div>
              </div>
              <Input
                label={t("scouting.minAge")}
                type="number"
                value={minAge}
                onChange={(e) => setMinAge(e.target.value)}
              />
              <Input
                label={t("scouting.maxAge")}
                type="number"
                placeholder={t("teamListings.noLimit")}
                value={maxAge}
                onChange={(e) => setMaxAge(e.target.value)}
              />
            </div>
          )}

          <div>
            <p className="mb-1.5 text-xs font-medium text-text-muted">
              {t("teamListings.targetRegionsLabel")}
            </p>
            <p className="mb-1.5 text-[11px] text-text-muted">{t("teamListings.targetRegionsHint")}</p>
            <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-line p-2">
              {federations.map((f) => (
                <label key={f.id} className="flex items-center gap-2 text-sm text-text-primary">
                  <input
                    type="checkbox"
                    checked={targetFederationIds.includes(f.id)}
                    disabled={!targetFederationIds.includes(f.id) && targetFederationIds.length >= 10}
                    onChange={() => toggleTargetFederation(f.id)}
                    className="h-3.5 w-3.5 accent-chalk"
                  />
                  {f.name}
                </label>
              ))}
            </div>
          </div>

          <Textarea
            label={t("crm.descriptionOptional")}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="button" onClick={handleCreate} isLoading={isCreating}>
              {t("academyDetail.publish")}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal isOpen={!!viewingListing} onClose={() => setViewingListing(null)} title={t("teamListings.applicationsModalTitle")} wide>
        {isLoadingApps ? (
          <p className="text-sm text-text-muted">{t("settings.loading")}</p>
        ) : applications.length === 0 ? (
          <p className="text-sm text-text-muted">{t("teamListings.noApplicationsYet")}</p>
        ) : (
          <div className="-mx-6 divide-y divide-line">
            {applications.map((a) => (
              <ApplicantRow
                key={a.id}
                app={a}
                onRespond={(accept) => handleRespond(a.id, accept)}
                isResponding={respondingId === a.id}
              />
            ))}
          </div>
        )}
      </Modal>

      <ListingDetailModal listing={selectedListing} onClose={() => setSelectedListing(null)} />
    </Card>
  );
}
