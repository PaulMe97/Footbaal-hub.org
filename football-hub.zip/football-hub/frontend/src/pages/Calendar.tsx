import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

import {
  createCalendarEvent,
  deleteCalendarEvent,
  listCalendarEvents,
  updateCalendarEvent,
} from "../api/calendar";
import { extractErrorMessage } from "../api/client";
import { listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Spinner } from "../components/ui/EmptyState";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog, Modal } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";
import type { CalendarEvent, Team } from "../types";

function toISO(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function buildGrid(monthDate: Date): Date[] {
  const firstOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
  const mondayIndex = (firstOfMonth.getDay() + 6) % 7;
  const gridStart = new Date(firstOfMonth);
  gridStart.setDate(firstOfMonth.getDate() - mondayIndex);
  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(gridStart);
    d.setDate(gridStart.getDate() + i);
    return d;
  });
}

const typeColor: Record<string, string> = {
  match: "bg-chalk",
  training: "bg-pitch",
  other: "bg-status-suspended",
  injury: "bg-status-injured",
  video_analysis: "bg-blue-400",
};

function rawId(compositeId: string): string {
  return compositeId.replace(/^event-/, "");
}

export default function CalendarPage() {
  const toast = useToast();
  const { t } = useLanguage();
  const WEEKDAYS = t("calendar.weekdaysCSV").split(",");
  const MONTH_NAMES = t("calendar.monthsCSV").split(",");
  const typeLabel: Record<string, string> = {
    match: t("calendar.typeMatch"),
    training: t("calendar.typeTraining"),
    other: t("calendar.typeOther"),
    injury: t("calendar.typeInjury"),
  };
  const today = useMemo(() => new Date(), []);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const deepLinkDate = searchParams.get("date");
  const initialDate = deepLinkDate ? new Date(deepLinkDate) : today;
  const [monthDate, setMonthDate] = useState(new Date(initialDate.getFullYear(), initialDate.getMonth(), 1));
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [teamFilter, setTeamFilter] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<string>(deepLinkDate || toISO(today));

  const [showCreate, setShowCreate] = useState(false);
  const [showTypeSelector, setShowTypeSelector] = useState(false);
  const [pendingEventDate, setPendingEventDate] = useState<string | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CalendarEvent | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const [title, setTitle] = useState("");
  const [eventDate, setEventDate] = useState(toISO(today));
  const [eventTime, setEventTime] = useState("");
  const [eventTeamId, setEventTeamId] = useState("");
  const [notes, setNotes] = useState("");
  const [eventType, setEventType] = useState("other");

  const grid = useMemo(() => buildGrid(monthDate), [monthDate]);

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  async function load() {
    setIsLoading(true);
    try {
      const start = toISO(grid[0]);
      const end = toISO(grid[grid.length - 1]);
      const data = await listCalendarEvents({ start, end, team_id: teamFilter || undefined });
      setEvents(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [monthDate, teamFilter]);

  const eventsByDate = useMemo(() => {
    const map: Record<string, CalendarEvent[]> = {};
    for (const e of events) {
      const key = e.date.slice(0, 10);
      if (!map[key]) map[key] = [];
      map[key].push(e);
    }
    return map;
  }, [events]);

  function openCreate(date?: string) {
    setPendingEventDate(date || selectedDate);
    setShowTypeSelector(true);
  }

  function openGenericEventForm(type: string, presetTitle = "") {
    setTitle(presetTitle);
    setEventType(type);
    setEventDate(pendingEventDate || selectedDate);
    setEventTime("");
    setEventTeamId(teamFilter || "");
    setNotes("");
    setShowTypeSelector(false);
    setShowCreate(true);
  }

  function goToCreateMatch() {
    setShowTypeSelector(false);
    navigate("/matches?create=1");
  }

  function goToCreateTraining() {
    setShowTypeSelector(false);
    navigate("/trainings?create=1");
  }

  function openEdit(event: CalendarEvent) {
    setEditingEvent(event);
    setTitle(event.title);
    setEventDate(event.date.slice(0, 10));
    setEventTime(event.time || "");
    setEventTeamId(event.team_id || "");
    setNotes(event.notes || "");
  }

  async function handleCreateSubmit(e: FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await createCalendarEvent({
        title,
        event_type: eventType,
        date: eventDate,
        time: eventTime || null,
        team_id: eventTeamId || null,
        notes: notes || null,
      });
      toast.show(t("calendar.created"), "success");
      setShowCreate(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleEditSubmit(e: FormEvent) {
    e.preventDefault();
    if (!editingEvent) return;
    setIsSubmitting(true);
    try {
      await updateCalendarEvent(rawId(editingEvent.id), {
        title,
        date: eventDate,
        time: eventTime || null,
        team_id: eventTeamId || null,
        notes: notes || null,
      });
      toast.show(t("calendar.updated"), "success");
      setEditingEvent(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteCalendarEvent(rawId(deleteTarget.id));
      toast.show(t("calendar.deleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  function eventLink(event: CalendarEvent): string | null {
    if (event.event_type === "match" && event.related_entity_id) return `/matches/${event.related_entity_id}`;
    if (event.event_type === "training" && event.related_entity_id) return `/trainings/${event.related_entity_id}`;
    return null;
  }

  const selectedEvents = eventsByDate[selectedDate] || [];

  return (
    <AppLayout title={t("calendar.title")}>
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMonthDate(new Date(monthDate.getFullYear(), monthDate.getMonth() - 1, 1))}
            className="rounded-md border border-line px-2.5 py-1.5 text-sm text-text-muted hover:border-chalk hover:text-text-primary"
          >
            ←
          </button>
          <h2 className="font-display text-lg text-text-primary">
            {MONTH_NAMES[monthDate.getMonth()]} {monthDate.getFullYear()}
          </h2>
          <button
            onClick={() => setMonthDate(new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 1))}
            className="rounded-md border border-line px-2.5 py-1.5 text-sm text-text-muted hover:border-chalk hover:text-text-primary"
          >
            →
          </button>
          <button
            onClick={() => setMonthDate(new Date(today.getFullYear(), today.getMonth(), 1))}
            className="ml-1 rounded-md border border-line px-2.5 py-1.5 text-xs text-text-muted hover:border-chalk hover:text-text-primary"
          >
            {t("dashboard.today")}
          </button>
        </div>
        <Select value={teamFilter} onChange={(e) => setTeamFilter(e.target.value)} className="w-48">
          <option value="">{t("players.allTeams")}</option>
          {teams.map((t2) => (
            <option key={t2.id} value={t2.id}>
              {t2.name}
            </option>
          ))}
        </Select>
        <Button onClick={() => openCreate()} className="ml-auto">
          {t("calendar.newEvent")}
        </Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-4">
          <Card className="overflow-hidden xl:col-span-3">
            <div className="grid grid-cols-7 border-b border-line text-center text-xs text-text-muted">
              {WEEKDAYS.map((d) => (
                <div key={d} className="py-2">
                  {d}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {grid.map((d) => {
                const iso = toISO(d);
                const inMonth = d.getMonth() === monthDate.getMonth();
                const isToday = iso === toISO(today);
                const isSelected = iso === selectedDate;
                const dayEvents = eventsByDate[iso] || [];
                return (
                  <button
                    key={iso}
                    onClick={() => setSelectedDate(iso)}
                    className={`flex min-h-[84px] flex-col items-start border-b border-r border-line p-2 text-left transition-colors hover:bg-surface-raised ${
                      inMonth ? "" : "opacity-40"
                    } ${isSelected ? "bg-surface-raised" : ""}`}
                  >
                    <span
                      className={`flex h-6 w-6 items-center justify-center rounded-full text-xs ${
                        isToday ? "bg-chalk text-void font-semibold" : "text-text-muted"
                      }`}
                    >
                      {d.getDate()}
                    </span>
                    <div className="mt-1 flex w-full flex-col gap-0.5">
                      {dayEvents.slice(0, 3).map((e) => (
                        <span key={e.id} className="flex items-center gap-1 truncate text-[10px] text-text-muted">
                          <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${typeColor[e.event_type]}`} />
                          <span className="truncate">{e.title}</span>
                        </span>
                      ))}
                      {dayEvents.length > 3 && (
                        <span className="text-[10px] text-text-muted">
                          +{dayEvents.length - 3}
                          {t("calendar.moreSuffix")}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </Card>

          <Card className="p-4">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-sm text-text-primary">
                {new Date(selectedDate).toLocaleDateString("el-GR", {
                  weekday: "long",
                  day: "2-digit",
                  month: "2-digit",
                })}
              </h3>
              <button onClick={() => openCreate(selectedDate)} className="text-xs text-chalk hover:underline">
                {t("calendar.addEvent")}
              </button>
            </div>
            {selectedEvents.length === 0 ? (
              <p className="text-sm text-text-muted">{t("calendar.noEntriesThisDay")}</p>
            ) : (
              <div className="space-y-3">
                {selectedEvents.map((e) => {
                  const link = eventLink(e);
                  return (
                    <div key={e.id} className="rounded-md border border-line p-3 text-sm">
                      <div className="mb-1 flex items-center gap-2">
                        <span className={`h-2 w-2 rounded-full ${typeColor[e.event_type]}`} />
                        <span className="text-xs uppercase text-text-muted">{typeLabel[e.event_type]}</span>
                        {e.time && <span className="ml-auto font-mono text-xs text-text-muted">{e.time}</span>}
                      </div>
                      {link ? (
                        <Link to={link} className="font-medium text-text-primary hover:text-chalk">
                          {e.title}
                        </Link>
                      ) : (
                        <p className="font-medium text-text-primary">{e.title}</p>
                      )}
                      {e.team_name && <p className="text-xs text-text-muted">{e.team_name}</p>}
                      {e.notes && <p className="mt-1 text-xs text-text-muted">{e.notes}</p>}
                      {e.editable && (
                        <div className="mt-2 flex gap-3 border-t border-line pt-2">
                          <button onClick={() => openEdit(e)} className="text-xs text-text-muted hover:text-chalk">
                            {t("common.edit")}
                          </button>
                          <button
                            onClick={() => setDeleteTarget(e)}
                            className="text-xs text-status-injured hover:underline"
                          >
                            {t("common.delete")}
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
      )}

      <Modal isOpen={showTypeSelector} onClose={() => setShowTypeSelector(false)} title={t("calendar.typeSelectorTitle")}>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <button
            onClick={goToCreateMatch}
            className="rounded-md border border-line p-4 text-left transition-colors hover:border-chalk hover:bg-surface-raised"
          >
            <p className="font-display text-sm text-text-primary">{t("calendar.typeSelectorMatch")}</p>
            <p className="mt-1 text-xs text-text-muted">{t("calendar.typeMatchDesc")}</p>
          </button>
          <button
            onClick={goToCreateTraining}
            className="rounded-md border border-line p-4 text-left transition-colors hover:border-chalk hover:bg-surface-raised"
          >
            <p className="font-display text-sm text-text-primary">{t("calendar.typeSelectorTraining")}</p>
            <p className="mt-1 text-xs text-text-muted">{t("calendar.typeTrainingDesc")}</p>
          </button>
          <button
            onClick={() => openGenericEventForm("video_analysis", t("calendar.videoAnalysisPresetTitle"))}
            className="rounded-md border border-line p-4 text-left transition-colors hover:border-chalk hover:bg-surface-raised"
          >
            <p className="font-display text-sm text-text-primary">{t("calendar.typeVideoAnalysis")}</p>
            <p className="mt-1 text-xs text-text-muted">{t("calendar.typeVideoAnalysisDesc")}</p>
          </button>
          <button
            onClick={() => openGenericEventForm("other")}
            className="rounded-md border border-line p-4 text-left transition-colors hover:border-chalk hover:bg-surface-raised"
          >
            <p className="font-display text-sm text-text-primary">{t("calendar.typeGeneral")}</p>
            <p className="mt-1 text-xs text-text-muted">{t("calendar.typeGeneralDesc")}</p>
          </button>
        </div>
      </Modal>

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("calendar.newEventModalTitle")}>
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          <Input label={t("calendar.titleRequired")} required value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label={t("calendar.dateRequired")}
              type="date"
              required
              value={eventDate}
              onChange={(e) => setEventDate(e.target.value)}
            />
            <Input label={t("calendar.time")} type="time" value={eventTime} onChange={(e) => setEventTime(e.target.value)} />
          </div>
          <Select label={t("calendar.teamOptional")} value={eventTeamId} onChange={(e) => setEventTeamId(e.target.value)}>
            <option value="">{t("calendar.noTeam")}</option>
            {teams.map((t2) => (
              <option key={t2.id} value={t2.id}>
                {t2.name}
              </option>
            ))}
          </Select>
          <Textarea label={t("calendar.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isSubmitting}>
              {t("common.create")}
            </Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={!!editingEvent} onClose={() => setEditingEvent(null)} title={t("calendar.editEventModalTitle")}>
        <form onSubmit={handleEditSubmit} className="space-y-4">
          <Input label={t("calendar.titleRequired")} required value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label={t("calendar.dateRequired")}
              type="date"
              required
              value={eventDate}
              onChange={(e) => setEventDate(e.target.value)}
            />
            <Input label={t("calendar.time")} type="time" value={eventTime} onChange={(e) => setEventTime(e.target.value)} />
          </div>
          <Select label={t("calendar.teamOptional")} value={eventTeamId} onChange={(e) => setEventTeamId(e.target.value)}>
            <option value="">{t("calendar.noTeam")}</option>
            {teams.map((t2) => (
              <option key={t2.id} value={t2.id}>
                {t2.name}
              </option>
            ))}
          </Select>
          <Textarea label={t("calendar.notes")} value={notes} onChange={(e) => setNotes(e.target.value)} />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setEditingEvent(null)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" isLoading={isSubmitting}>
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("calendar.deleteEventTitle")}
        message={`${t("calendar.deleteConfirmPrefix")}${deleteTarget?.title}${t("calendar.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}
