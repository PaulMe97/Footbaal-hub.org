import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { extractErrorMessage, mediaUrl } from "../../api/client";
import {
  deletePlayer,
  deletePlayerInjury,
  deletePlayerPhoto,
  getPlayer,
  getPlayerLinkedUser,
  getPlayerMatchHistory,
  getPlayerStatistics,
  incrementPlayerStatistic,
  listPlayerInjuries,
  listPlayers,
  updatePlayer,
  updatePlayerStatistics,
  uploadPlayerPhoto,
} from "../../api/players";
import type { MatchHistoryEntry } from "../../api/players";
import {
  getPlayerAttributes,
  updateOwnTransferStatus,
  updatePlayerAttributes,
  updatePlayerTransferStatus,
} from "../../api/scouting";
import { sendStaffAssignmentOffer } from "../../api/staffOffers";
import { listTeams } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { PlayerHistoryModal } from "../../components/PlayerHistoryModal";
import { StatusBadge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useContextMenu } from "../../components/ui/ContextMenu";
import { Spinner } from "../../components/ui/EmptyState";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useAuth } from "../../context/AuthContext";
import type { Injury, Player, PlayerAttributes as PlayerAttrs, PlayerStatistics, PlayerStatus, Team } from "../../types";
import {
  ATTRIBUTE_LABELS,
  INJURY_STATUS_LABELS,
  STATUS_LABELS,
  TRANSFER_STATUS_COLORS,
  TRANSFER_STATUS_LABELS,
} from "../../types";
import { MedicalInfoModal } from "./MedicalInfoModal";
import { PlayerAttributesForm } from "./PlayerAttributesForm";
import { PlayerForm, playerFormToPayload, type PlayerFormValues } from "./PlayerForm";
import { PlayerStatsForm } from "./PlayerStatsForm";
import { useLanguage } from "../../context/LanguageContext";

export default function PlayerDetail() {
  const { playerId } = useParams<{ playerId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const isPlayer = user?.role === "player";

  const [player, setPlayer] = useState<Player | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const [allPlayersOrder, setAllPlayersOrder] = useState<Player[]>([]);
  const [stats, setStats] = useState<PlayerStatistics | null>(null);
  const [injuries, setInjuries] = useState<Injury[]>([]);
  const [matchHistory, setMatchHistory] = useState<MatchHistoryEntry[]>([]);
  const [attributes, setAttributes] = useState<PlayerAttrs | null>(null);
  const [showAttributesEdit, setShowAttributesEdit] = useState(false);
  const [showMedicalEdit, setShowMedicalEdit] = useState(false);
  const [isAttributesSubmitting, setIsAttributesSubmitting] = useState(false);
  const [isChangingTransferStatus, setIsChangingTransferStatus] = useState(false);
  const [transferNotes, setTransferNotes] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [showEdit, setShowEdit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [showStatsEdit, setShowStatsEdit] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [isStatsSubmitting, setIsStatsSubmitting] = useState(false);
  const canOfferStaffRole = user?.role === "president" || user?.role === "technical_director";
  const [linkedUserId, setLinkedUserId] = useState<string | null>(null);
  const [showStaffOfferForm, setShowStaffOfferForm] = useState(false);
  const [offerTeamId, setOfferTeamId] = useState("");
  const [offerNewRole, setOfferNewRole] = useState("assistant_coach");
  const [offerIncentive, setOfferIncentive] = useState("");
  const [offerMessage, setOfferMessage] = useState("");
  const [isSendingStaffOffer, setIsSendingStaffOffer] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const menu = useContextMenu();

  async function load() {
    if (!playerId) return;
    setIsLoading(true);
    try {
      const [p, teamsData, s, inj, history, attrs] = await Promise.all([
        getPlayer(playerId),
        listTeams(),
        getPlayerStatistics(playerId),
        listPlayerInjuries(playerId),
        getPlayerMatchHistory(playerId),
        getPlayerAttributes(playerId),
      ]);
      setPlayer(p);
      setTeams(teamsData);
      setStats(s);
      setInjuries(inj);
      setMatchHistory(history);
      setAttributes(attrs);
      setTransferNotes(p.transfer_notes || "");
      if (canOfferStaffRole) {
        try {
          const uid = await getPlayerLinkedUser(playerId);
          setLinkedUserId(uid);
        } catch {
          /* μη κρίσιμο */
        }
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playerId]);

  useEffect(() => {
    listPlayers()
      .then(setAllPlayersOrder)
      .catch(() => {
        /* σιωπηλή αποτυχία — τα κουμπιά πάνω/κάτω απλά δεν θα εμφανιστούν */
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSendStaffOffer() {
    if (!linkedUserId || !offerTeamId) return;
    setIsSendingStaffOffer(true);
    try {
      await sendStaffAssignmentOffer(offerTeamId, {
        recipient_user_id: linkedUserId,
        new_role: offerNewRole,
        incentive_details: offerIncentive || undefined,
        message: offerMessage || undefined,
      });
      toast.show(t("playerDetail.staffOfferSent"), "success");
      setShowStaffOfferForm(false);
      setOfferTeamId("");
      setOfferIncentive("");
      setOfferMessage("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSendingStaffOffer(false);
    }
  }

  async function handleUpdate(values: PlayerFormValues) {
    if (!playerId) return;
    setIsSubmitting(true);
    try {
      const updated = await updatePlayer(playerId, playerFormToPayload(values));
      setPlayer(updated);
      toast.show(t("dashboard.changesSaved"), "success");
      setShowEdit(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!playerId) return;
    setIsDeleting(true);
    try {
      await deletePlayer(playerId);
      toast.show(t("playerDetail.playerDeleted"), "success");
      navigate("/players");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
      setIsDeleting(false);
    }
  }

  async function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !playerId) return;
    setIsUploadingPhoto(true);
    try {
      const updated = await uploadPlayerPhoto(playerId, file);
      setPlayer(updated);
      toast.show(t("playerDetail.photoUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handlePhotoDelete() {
    if (!playerId) return;
    try {
      const updated = await deletePlayerPhoto(playerId);
      setPlayer(updated);
      toast.show(t("playerDetail.photoRemoved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleQuickStat(field: "matches_played" | "goals" | "yellow_cards" | "red_cards") {
    if (!playerId) return;
    try {
      const updated = await incrementPlayerStatistic(playerId, field, 1);
      setStats(updated);
      toast.show(t("playerDetail.statUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleStatsSubmit(values: {
    matches_played: number;
    goals: number;
    assists: number;
    yellow_cards: number;
    red_cards: number;
  }) {
    if (!playerId) return;
    setIsStatsSubmitting(true);
    try {
      const updated = await updatePlayerStatistics(playerId, values);
      setStats(updated);
      toast.show(t("playerDetail.statsUpdated"), "success");
      setShowStatsEdit(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsStatsSubmitting(false);
    }
  }

  async function handleQuickStatus(status: PlayerStatus) {
    if (!playerId) return;
    try {
      const updated = await updatePlayer(playerId, { status });
      setPlayer(updated);
      toast.show(`${t("playerDetail.statusChangedPrefix")}${STATUS_LABELS[status]}${t("playerDetail.statusChangedSuffix")}`, "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleDeleteInjury(injuryId: string) {
    if (!playerId) return;
    try {
      await deletePlayerInjury(playerId, injuryId);
      setInjuries((prev) => prev.filter((i) => i.id !== injuryId));
      toast.show(t("playerDetail.injuryDeleted"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAttributesSubmit(values: PlayerAttrs) {
    if (!playerId) return;
    setIsAttributesSubmitting(true);
    try {
      const updated = await updatePlayerAttributes(playerId, values);
      setAttributes(updated);
      toast.show(t("playerDetail.attributesSaved"), "success");
      setShowAttributesEdit(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAttributesSubmitting(false);
    }
  }

  async function handleCoachTransferStatusChange(status: string) {
    if (!playerId) return;
    setIsChangingTransferStatus(true);
    try {
      await updatePlayerTransferStatus(playerId, status, transferNotes);
      setPlayer((prev) => (prev ? { ...prev, transfer_status: status, transfer_notes: transferNotes } : prev));
      toast.show(t("playerDetail.transferStatusUpdatedCoach"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsChangingTransferStatus(false);
    }
  }

  async function handleSelfTransferStatusChange(status: string) {
    setIsChangingTransferStatus(true);
    try {
      await updateOwnTransferStatus(status);
      setPlayer((prev) => (prev ? { ...prev, transfer_status: status } : prev));
      toast.show(t("playerDetail.transferStatusUpdatedSelf"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsChangingTransferStatus(false);
    }
  }

  function openStatsContextMenu(e: { preventDefault: () => void; clientX: number; clientY: number }) {
    if (isPlayer) return;
    menu.open(e, [
      {
        heading: t("playerDetail.quickLog"),
        items: [
          { label: t("playerDetail.goalPlus1"), onClick: () => handleQuickStat("goals") },
          { label: t("playerDetail.matchPlus1"), onClick: () => handleQuickStat("matches_played") },
          { label: t("playerDetail.yellowPlus1"), onClick: () => handleQuickStat("yellow_cards") },
          { label: t("playerDetail.redPlus1"), onClick: () => handleQuickStat("red_cards") },
        ],
      },
      {
        heading: t("players.status"),
        items: [
          { label: t("playerDetail.statusFitOption"), onClick: () => handleQuickStatus("fit"), disabled: player?.status === "fit" },
          { label: t("playerDetail.statusInjuredOption"), onClick: () => handleQuickStatus("injured"), disabled: player?.status === "injured" },
          {
            label: t("playerDetail.returnedFromInjury"),
            onClick: () => handleQuickStatus("fit"),
            disabled: player?.status !== "injured",
          },
          { label: t("playerDetail.statusUnavailableOption"), onClick: () => handleQuickStatus("unavailable"), disabled: player?.status === "unavailable" },
          { label: t("playerDetail.statusSuspendedOption"), onClick: () => handleQuickStatus("suspended"), disabled: player?.status === "suspended" },
        ],
      },
      { items: [{ label: t("playerDetail.editStatsEllipsis"), onClick: () => setShowStatsEdit(true) }] },
    ]);
  }

  if (isLoading || !player) {
    return (
      <AppLayout title={t("playerDetail.loadingTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  const currentPlayerIndex = allPlayersOrder.findIndex((p) => p.id === player.id);
  const prevPlayer = currentPlayerIndex > 0 ? allPlayersOrder[currentPlayerIndex - 1] : null;
  const nextPlayer =
    currentPlayerIndex >= 0 && currentPlayerIndex < allPlayersOrder.length - 1
      ? allPlayersOrder[currentPlayerIndex + 1]
      : null;

  return (
    <AppLayout title={`${player.first_name} ${player.last_name}`}>
      <div className="mb-4 flex items-center justify-between">
        <Link to="/players" className="inline-block text-sm text-text-muted hover:text-chalk">
          {t("playerDetail.backToAll")}
        </Link>
        <div className="flex gap-2">
          <button
            onClick={() => prevPlayer && navigate(`/players/${prevPlayer.id}`)}
            disabled={!prevPlayer}
            className="rounded-md border border-chalk/50 bg-chalk/10 px-3 py-1.5 text-xs font-semibold text-chalk hover:bg-chalk/20 disabled:cursor-not-allowed disabled:opacity-30"
          >
            {t("playerDetail.previousPlayer")}
          </button>
          <button
            onClick={() => nextPlayer && navigate(`/players/${nextPlayer.id}`)}
            disabled={!nextPlayer}
            className="rounded-md border border-chalk/50 bg-chalk/10 px-3 py-1.5 text-xs font-semibold text-chalk hover:bg-chalk/20 disabled:cursor-not-allowed disabled:opacity-30"
          >
            {t("playerDetail.nextPlayer")}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card corners className="p-5 lg:col-span-1" onContextMenu={openStatsContextMenu}>
          <div className="flex flex-col items-center text-center">
            {!isPlayer ? (
              <>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="group relative flex h-28 w-28 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised font-display text-3xl text-text-muted hover:border-chalk"
                  title={t("playerDetail.changePhoto")}
                >
                  {player.photo_path ? (
                    <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
                  ) : (
                    `${player.first_name[0] ?? ""}${player.last_name[0] ?? ""}`
                  )}
                  <span className="absolute inset-0 hidden items-center justify-center bg-void/70 text-xs text-chalk group-hover:flex">
                    {isUploadingPhoto ? "..." : t("profile.change")}
                  </span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={handlePhotoChange}
                />
                {player.photo_path && (
                  <button onClick={handlePhotoDelete} className="mt-1 text-xs text-status-injured hover:underline">
                    {t("playerDetail.removePhoto")}
                  </button>
                )}
              </>
            ) : (
              <div className="flex h-28 w-28 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised font-display text-3xl text-text-muted">
                {player.photo_path ? (
                  <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
                ) : (
                  `${player.first_name[0] ?? ""}${player.last_name[0] ?? ""}`
                )}
              </div>
            )}

            <h2 className="mt-4 font-display text-xl text-text-primary">
              {player.first_name} {player.last_name}
            </h2>
            <p className="text-sm text-text-muted">
              {[player.position, player.team_name].filter(Boolean).join(" · ") || "—"}
            </p>
            <div className="mt-2">
              <StatusBadge status={player.status} />
            </div>
          </div>

          <dl className="mt-5 space-y-2 border-t border-line pt-4 text-sm">
            <Row label={t("playerForm.number")} value={player.player_number != null ? String(player.player_number) : undefined} />
            <Row label={t("playerCompare.age")} value={player.age != null ? `${player.age}${t("players.yearsOldSuffix")}` : undefined} />
            <Row label={t("playerForm.nationality")} value={player.nationality} />
            <Row label={t("playerForm.preferredFoot")} value={feetLabel(player.preferred_foot, t)} />
            <Row label={t("playerDetail.heightLabel")} value={player.height_cm ? `${player.height_cm} cm` : undefined} />
            <Row label={t("playerDetail.weightLabel")} value={player.weight_kg ? `${player.weight_kg} kg` : undefined} />
            <Row label={t("playerForm.phone")} value={player.phone} />
            <Row label="Email" value={player.email} />
          </dl>

          <div className="mt-5 border-t border-line pt-4">
            <Button variant="secondary" onClick={() => setShowHistory(true)} className="w-full">
              {t("absences.viewHistoryButton")}
            </Button>
          </div>

          {!isPlayer && (
            <div className="mt-3 flex gap-2">
              <Button variant="secondary" onClick={() => setShowEdit(true)} className="flex-1">
                {t("common.edit")}
              </Button>
              <Button variant="danger" onClick={() => setShowDelete(true)}>
                {t("common.delete")}
              </Button>
            </div>
          )}

          {canOfferStaffRole && linkedUserId && (
            <div className="mt-3 border-t border-line pt-3">
              <Button variant="secondary" onClick={() => setShowStaffOfferForm(true)} className="w-full">
                {t("playerDetail.staffOfferButton")}
              </Button>
            </div>
          )}
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card
            onClick={() => setShowMedicalEdit(true)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setShowMedicalEdit(true);
            }}
            className={`cursor-pointer p-5 transition-colors hover:border-chalk ${
              player.status === "injured" ? "border-status-injured/30" : ""
            }`}
          >
            <h3
              className={`mb-3 font-display text-sm uppercase tracking-wide ${
                player.status === "injured" ? "text-status-injured" : "text-text-muted"
              }`}
            >
              {t("playerDetail.medicalInfo")}
            </h3>
            {player.status === "injured" ? (
              <>
                <dl className="space-y-2 text-sm">
                  <Row label={t("playerForm.injuryType")} value={player.injury_type} />
                  <Row label={t("playerForm.injuryDate")} value={player.injury_date} />
                  <Row label={t("playerForm.expectedReturn")} value={player.expected_return} />
                </dl>
                {player.medical_notes && (
                  <p className="mt-3 border-t border-line pt-3 text-sm text-text-muted">
                    {player.medical_notes}
                  </p>
                )}
              </>
            ) : (
              <p className="text-sm text-text-muted">{t("medicalInfoModal.noIssuesReported")}</p>
            )}
          </Card>

          {injuries.length > 0 && (
            <Card className="p-5">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerDetail.injuryHistoryPrefix")}{injuries.length})
              </h3>
              <div className="space-y-3">
                {injuries.map((inj) => (
                  <div key={inj.id} className="flex items-start justify-between border-b border-line pb-3 last:border-0 last:pb-0">
                    <div className="text-sm">
                      <p className="text-text-primary">{inj.injury_type || t("teamDetail.injuryDefault")}</p>
                      <p className="text-xs text-text-muted">
                        {inj.injury_date}
                        {inj.actual_return ? `${t("playerDetail.returnedArrow")}${inj.actual_return}` : ""}
                        {!inj.actual_return && inj.expected_return
                          ? `${t("playerDetail.expectedReturnMid")}${inj.expected_return}`
                          : ""}
                      </p>
                      {inj.notes && <p className="mt-1 text-xs text-text-muted">{inj.notes}</p>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`rounded-full border px-2 py-0.5 text-[11px] ${
                          inj.status === "active"
                            ? "border-status-injured/40 bg-status-injured/15 text-status-injured"
                            : "border-status-fit/40 bg-status-fit/15 text-status-fit"
                        }`}
                      >
                        {INJURY_STATUS_LABELS[inj.status]}
                      </span>
                      {!isPlayer && (
                        <button
                          onClick={() => handleDeleteInjury(inj.id)}
                          className="text-xs text-status-injured hover:underline"
                        >
                          {t("common.delete")}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card
            onClick={() => setShowAttributesEdit(true)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setShowAttributesEdit(true);
            }}
            className="cursor-pointer p-5 transition-colors hover:border-chalk"
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerScoutingModal.attributesHeading")}
              </h3>
              {!isPlayer && <span className="text-xs text-chalk">{t("common.edit")}</span>}
            </div>
            {!attributes || Object.values(attributes).every((v) => v == null) ? (
              <p className="text-sm text-text-muted">{t("playerDetail.notRatedYet")}</p>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {(Object.keys(ATTRIBUTE_LABELS) as (keyof PlayerAttrs)[]).map((key) => {
                  const value = attributes[key];
                  const pct = value != null ? (value / 10) * 100 : 0;
                  return (
                    <div key={key}>
                      <div className="mb-0.5 flex justify-between text-xs">
                        <span className="text-text-muted">{ATTRIBUTE_LABELS[key]}</span>
                        <span className="font-mono text-text-primary">
                          {value != null ? value.toFixed(1) : "—"}
                        </span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-surface-raised">
                        <div className="h-1.5 rounded-full bg-chalk" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card className="p-5">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("playerDetail.transferStatusHeading")}
            </h3>
            <div className="mb-3">
              <span
                className={`rounded-full border px-2.5 py-1 text-xs ${TRANSFER_STATUS_COLORS[(player.transfer_status as keyof typeof TRANSFER_STATUS_COLORS) || "not_listed"]}`}
              >
                {TRANSFER_STATUS_LABELS[(player.transfer_status as keyof typeof TRANSFER_STATUS_LABELS) || "not_listed"]}
              </span>
            </div>

            {user?.linked_player_id === player.id ? (
              <>
                <p className="mb-2 text-xs text-text-muted">
                  {t("playerDetail.selfEditHint")}
                </p>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(TRANSFER_STATUS_LABELS).map(([value, label]) => (
                    <button
                      key={value}
                      disabled={isChangingTransferStatus || player.transfer_status === value}
                      onClick={() => handleSelfTransferStatusChange(value)}
                      className="rounded-md border border-line px-2.5 py-1.5 text-xs text-text-primary hover:border-chalk disabled:opacity-40"
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </>
            ) : isPlayer ? (
              <p className="text-xs text-text-muted">{t("playerDetail.viewOnly")}</p>
            ) : (
              <>
                <Textarea
                  label={t("playerDetail.noteExample")}
                  value={transferNotes}
                  onChange={(e) => setTransferNotes(e.target.value)}
                />
                <div className="mt-2 flex flex-wrap gap-2">
                  {Object.entries(TRANSFER_STATUS_LABELS).map(([value, label]) => (
                    <button
                      key={value}
                      disabled={isChangingTransferStatus}
                      onClick={() => handleCoachTransferStatusChange(value)}
                      className={`rounded-md border px-2.5 py-1.5 text-xs disabled:opacity-40 ${
                        player.transfer_status === value
                          ? "border-chalk bg-chalk/15 text-chalk"
                          : "border-line text-text-primary hover:border-chalk"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </>
            )}
          </Card>

          <Card
            onClick={() => setShowEdit(true)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setShowEdit(true);
            }}
            className="cursor-pointer p-5 transition-colors hover:border-chalk"
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerDetail.footballInfoHeading")}
              </h3>
              {!isPlayer && <span className="text-xs text-chalk">{t("common.edit")}</span>}
            </div>
            <dl className="space-y-2 text-sm">
              <Row label={t("playerDetail.currentTeam")} value={player.team_name} />
              <Row label={t("playerForm.secondaryPosition")} value={player.secondary_position} />
            </dl>
            {player.contract_notes && (
              <p className="mt-3 border-t border-line pt-3 text-sm text-text-muted">
                {player.contract_notes}
              </p>
            )}
            {player.availability_notes && (
              <p className="mt-2 text-sm text-text-muted">{player.availability_notes}</p>
            )}
          </Card>

          <Card
            onClick={() => setShowStatsEdit(true)}
            onContextMenu={openStatsContextMenu}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") setShowStatsEdit(true);
            }}
            className="cursor-pointer p-5 transition-colors hover:border-chalk"
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerDetail.statisticsHeading")}
              </h3>
              {!isPlayer && <span className="text-xs text-chalk">{t("common.edit")}</span>}
            </div>
            {stats && (
              <div className="grid grid-cols-4 gap-3 text-center">
                <StatBox label={t("performance.matches")} value={stats.matches_played} />
                <StatBox label={t("performance.goals")} value={stats.goals} />
                <StatBox label={t("playerStatsForm.yellowCards")} value={stats.yellow_cards} />
                <StatBox label={t("playerStatsForm.redCards")} value={stats.red_cards} />
              </div>
            )}
            <p className="mt-3 text-xs text-text-muted">
              {t("playerDetail.rightClickHint")}
            </p>
          </Card>

          {matchHistory.length > 1 && (
            <Card className="p-5">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("playerDetail.performanceTrend")}
              </h3>
              <div style={{ width: "100%", height: 220 }}>
                <ResponsiveContainer>
                  <LineChart
                    data={matchHistory.map((h) => ({
                      date: new Date(h.date).toLocaleDateString("el-GR", { day: "2-digit", month: "2-digit" }),
                      rating: h.rating,
                      goals: h.goals,
                    }))}
                    margin={{ top: 5, right: 10, left: -20, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--color-line))" />
                    <XAxis dataKey="date" stroke="rgb(var(--color-text-muted))" fontSize={11} />
                    <YAxis stroke="rgb(var(--color-text-muted))" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        background: "rgb(var(--color-surface-raised))",
                        border: "1px solid rgb(var(--color-line))",
                        borderRadius: 6,
                        fontSize: 12,
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="rating"
                      name="Rating"
                      stroke="rgb(var(--color-chalk))"
                      strokeWidth={2}
                      dot={{ r: 3 }}
                      connectNulls
                    />
                    <Line
                      type="monotone"
                      dataKey="goals"
                      name={t("performance.goals")}
                      stroke="rgb(var(--color-pitch-light))"
                      strokeWidth={2}
                      dot={{ r: 3 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          )}
        </div>
      </div>

      <Modal isOpen={showEdit} onClose={() => setShowEdit(false)} title={t("playerDetail.editPlayerModalTitle")} wide>
        <PlayerForm
          player={player}
          teams={teams}
          onSubmit={handleUpdate}
          onCancel={() => setShowEdit(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title={t("playerDetail.deletePlayerTitle")}
        message={`${t("playerDetail.deleteConfirmPrefix")}${player.first_name} ${player.last_name}${t("playerDetail.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />

      <Modal isOpen={showStatsEdit} onClose={() => setShowStatsEdit(false)} title={t("playerDetail.editStatsModalTitle")}>
        {stats && (
          <PlayerStatsForm
            stats={stats}
            onSubmit={handleStatsSubmit}
            onCancel={() => setShowStatsEdit(false)}
            isSubmitting={isStatsSubmitting}
          />
        )}
      </Modal>

      <MedicalInfoModal
        player={player}
        isOpen={showMedicalEdit}
        onClose={() => setShowMedicalEdit(false)}
        onUpdated={setPlayer}
      />

      <Modal
        isOpen={showAttributesEdit}
        onClose={() => setShowAttributesEdit(false)}
        title={t("playerDetail.editAttributesModalTitle")}
        wide
      >
        <PlayerAttributesForm
          attributes={attributes || {}}
          onSubmit={handleAttributesSubmit}
          onCancel={() => setShowAttributesEdit(false)}
          isSubmitting={isAttributesSubmitting}
        />
      </Modal>

      <Modal
        isOpen={showStaffOfferForm}
        onClose={() => setShowStaffOfferForm(false)}
        title={t("playerDetail.staffOfferModalTitle")}
      >
        <div className="space-y-4">
          <p className="text-sm text-text-muted">
            {t("playerDetail.offerToPrefix")}<span className="text-text-primary">{player.first_name} {player.last_name}</span>{" "}
            {t("playerDetail.offerToSuffix")}
          </p>
          <Select label={t("crm.team")} value={offerTeamId} onChange={(e) => setOfferTeamId(e.target.value)}>
            <option value="">{t("crm.selectTeam")}</option>
            {teams.map((teamOpt) => (
              <option key={teamOpt.id} value={teamOpt.id}>
                {teamOpt.name}
              </option>
            ))}
          </Select>
          <Select label={t("playerDetail.newRole")} value={offerNewRole} onChange={(e) => setOfferNewRole(e.target.value)}>
            <option value="assistant_coach">{t("crm.roleAssistantCoach")}</option>
            <option value="head_coach">{t("crm.roleHeadCoach")}</option>
            <option value="technical_director">{t("crm.roleTechnicalDirector")}</option>
            <option value="fitness_coach">{t("crm.roleFitnessCoach")}</option>
            <option value="analyst">{t("crm.roleAnalyst")}</option>
            <option value="scout">Scout</option>
          </Select>
          <Textarea
            label={t("staff.incentiveOptional")}
            value={offerIncentive}
            onChange={(e) => setOfferIncentive(e.target.value)}
          />
          <Textarea
            label={t("staff.messageOptional")}
            value={offerMessage}
            onChange={(e) => setOfferMessage(e.target.value)}
          />
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={() => setShowStaffOfferForm(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              onClick={handleSendStaffOffer}
              isLoading={isSendingStaffOffer}
              disabled={!offerTeamId}
            >
              {t("staff.sendOffer")}
            </Button>
          </div>
        </div>
      </Modal>

      {menu.render()}

      <PlayerHistoryModal
        playerId={player.id}
        playerName={`${player.first_name} ${player.last_name}`}
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
      />
    </AppLayout>
  );
}

function feetLabel(foot: string | null | undefined, t: (key: string) => string) {
  if (foot === "left") return t("playerForm.footLeft");
  if (foot === "right") return t("playerForm.footRight");
  if (foot === "both") return t("playerForm.footBoth");
  return undefined;
}

function Row({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-text-muted">{label}</dt>
      <dd className="text-right text-text-primary">{value || "—"}</dd>
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border border-line bg-surface-raised py-2">
      <p className="font-display text-xl text-chalk">{value}</p>
      <p className="text-[10px] uppercase text-text-muted">{label}</p>
    </div>
  );
}
