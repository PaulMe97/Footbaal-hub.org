import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { extractErrorMessage, mediaUrl } from "../../api/client";
import { getPlayerStatistics, listPlayers } from "../../api/players";
import { getPlayerAttributes } from "../../api/scouting";
import { AppLayout } from "../../components/layout/AppLayout";
import { Card } from "../../components/ui/Card";
import { Select } from "../../components/ui/Input";
import { useToast } from "../../components/ui/Toast";
import { ATTRIBUTE_LABELS } from "../../types";
import type { Player, PlayerAttributes, PlayerStatistics } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

interface Side {
  player: Player | null;
  stats: PlayerStatistics | null;
  attrs: PlayerAttributes | null;
}

function ageOf(player?: Player | null): number | null {
  return player?.age ?? null;
}

function StatRow({
  label,
  a,
  b,
  higherIsBetter = true,
}: {
  label: string;
  a: number | null;
  b: number | null;
  higherIsBetter?: boolean;
}) {
  const aWins = a != null && b != null && a !== b && (higherIsBetter ? a > b : a < b);
  const bWins = a != null && b != null && a !== b && (higherIsBetter ? b > a : b < a);
  return (
    <div className="grid grid-cols-3 items-center gap-2 border-b border-line py-2 text-sm last:border-0">
      <span className={`text-center font-mono text-lg ${aWins ? "text-chalk" : "text-text-primary"}`}>
        {a ?? "—"}
      </span>
      <span className="text-center text-xs uppercase text-text-muted">{label}</span>
      <span className={`text-center font-mono text-lg ${bWins ? "text-chalk" : "text-text-primary"}`}>
        {b ?? "—"}
      </span>
    </div>
  );
}

function PlayerHeader({ player }: { player: Player | null }) {
  const { t } = useLanguage();
  if (!player) {
    return <div className="flex h-32 items-center justify-center text-sm text-text-muted">—</div>;
  }
  return (
    <div className="flex flex-col items-center gap-2 text-center">
      <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xl text-text-muted">
        {player.photo_path ? (
          <img src={mediaUrl(player.photo_path)} alt="" className="h-full w-full object-cover" />
        ) : (
          `${player.first_name[0] ?? ""}${player.last_name[0] ?? ""}`
        )}
      </div>
      <div>
        <Link to={`/players/${player.id}`} className="font-display text-base text-text-primary hover:text-chalk">
          {player.first_name} {player.last_name}
        </Link>
        <p className="text-xs text-text-muted">
          {[player.position, player.team_name, ageOf(player) ? `${ageOf(player)}${t("players.yearsOldSuffix")}` : null]
            .filter(Boolean)
            .join(" · ") || "—"}
        </p>
      </div>
    </div>
  );
}

export default function PlayerCompare() {
  const toast = useToast();
  const { t } = useLanguage();
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [sideA, setSideA] = useState<Side>({ player: null, stats: null, attrs: null });
  const [sideB, setSideB] = useState<Side>({ player: null, stats: null, attrs: null });

  useEffect(() => {
    listPlayers()
      .then(setAllPlayers)
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function selectPlayer(side: "a" | "b", playerId: string) {
    if (!playerId) {
      if (side === "a") setSideA({ player: null, stats: null, attrs: null });
      else setSideB({ player: null, stats: null, attrs: null });
      return;
    }
    const player = allPlayers.find((p) => p.id === playerId) || null;
    try {
      const [stats, attrs] = player
        ? await Promise.all([getPlayerStatistics(player.id), getPlayerAttributes(player.id)])
        : [null, null];
      if (side === "a") setSideA({ player, stats, attrs });
      else setSideB({ player, stats, attrs });
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  return (
    <AppLayout title={t("playerCompare.title")}>
      <div className="mb-6 grid grid-cols-2 gap-4">
        <Select value={sideA.player?.id || ""} onChange={(e) => selectPlayer("a", e.target.value)}>
          <option value="">{t("playerCompare.selectPlayerA")}</option>
          {allPlayers.map((p) => (
            <option key={p.id} value={p.id}>
              {p.first_name} {p.last_name} {p.team_name ? `(${p.team_name})` : ""}
            </option>
          ))}
        </Select>
        <Select value={sideB.player?.id || ""} onChange={(e) => selectPlayer("b", e.target.value)}>
          <option value="">{t("playerCompare.selectPlayerB")}</option>
          {allPlayers.map((p) => (
            <option key={p.id} value={p.id}>
              {p.first_name} {p.last_name} {p.team_name ? `(${p.team_name})` : ""}
            </option>
          ))}
        </Select>
      </div>

      <Card corners className="p-6">
        <div className="grid grid-cols-2 gap-4 border-b border-line pb-6">
          <PlayerHeader player={sideA.player} />
          <PlayerHeader player={sideB.player} />
        </div>

        {sideA.player && sideB.player ? (
          <div className="mt-4">
            <StatRow label={t("performance.matches")} a={sideA.stats?.matches_played ?? 0} b={sideB.stats?.matches_played ?? 0} />
            <StatRow label={t("performance.goals")} a={sideA.stats?.goals ?? 0} b={sideB.stats?.goals ?? 0} />
            <StatRow label={t("performance.assists")} a={sideA.stats?.assists ?? 0} b={sideB.stats?.assists ?? 0} />
            <StatRow
              label={t("playerScoutingModal.avgRating")}
              a={sideA.stats?.avg_rating ?? null}
              b={sideB.stats?.avg_rating ?? null}
            />
            <StatRow
              label={t("playerStatsForm.yellowCards")}
              a={sideA.stats?.yellow_cards ?? 0}
              b={sideB.stats?.yellow_cards ?? 0}
              higherIsBetter={false}
            />
            <StatRow
              label={t("playerStatsForm.redCards")}
              a={sideA.stats?.red_cards ?? 0}
              b={sideB.stats?.red_cards ?? 0}
              higherIsBetter={false}
            />
            <StatRow label={t("playerCompare.heightCm")} a={sideA.player.height_cm ?? null} b={sideB.player.height_cm ?? null} />
            <StatRow label={t("playerCompare.age")} a={ageOf(sideA.player)} b={ageOf(sideB.player)} higherIsBetter={false} />

            <p className="mb-1 mt-4 text-center text-[11px] uppercase tracking-wide text-text-muted">
              {t("playerScoutingModal.attributesHeading")}
            </p>
            {(Object.keys(ATTRIBUTE_LABELS) as (keyof PlayerAttributes)[]).map((key) => (
              <StatRow
                key={key}
                label={ATTRIBUTE_LABELS[key]}
                a={sideA.attrs?.[key] ?? null}
                b={sideB.attrs?.[key] ?? null}
              />
            ))}
          </div>
        ) : (
          <p className="mt-6 text-center text-sm text-text-muted">
            {t("playerCompare.selectTwoPlayers")}
          </p>
        )}
      </Card>
    </AppLayout>
  );
}
