import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import type { PlayerStatistics } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export function PlayerStatsForm({
  stats,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  stats: PlayerStatistics;
  onSubmit: (values: {
    matches_played: number;
    goals: number;
    assists: number;
    yellow_cards: number;
    red_cards: number;
  }) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const { t } = useLanguage();
  const [matches, setMatches] = useState(String(stats.matches_played));
  const [goals, setGoals] = useState(String(stats.goals));
  const [assists, setAssists] = useState(String(stats.assists));
  const [yellows, setYellows] = useState(String(stats.yellow_cards));
  const [reds, setReds] = useState(String(stats.red_cards));

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit({
      matches_played: Number(matches || 0),
      goals: Number(goals || 0),
      assists: Number(assists || 0),
      yellow_cards: Number(yellows || 0),
      red_cards: Number(reds || 0),
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input label={t("performance.matches")} type="number" min={0} value={matches} onChange={(e) => setMatches(e.target.value)} />
        <Input label={t("performance.goals")} type="number" min={0} value={goals} onChange={(e) => setGoals(e.target.value)} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <Input label={t("performance.assists")} type="number" min={0} value={assists} onChange={(e) => setAssists(e.target.value)} />
        <Input
          label={t("playerStatsForm.yellowCards")}
          type="number"
          min={0}
          value={yellows}
          onChange={(e) => setYellows(e.target.value)}
        />
        <Input label={t("playerStatsForm.redCards")} type="number" min={0} value={reds} onChange={(e) => setReds(e.target.value)} />
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {t("common.save")}
        </Button>
      </div>
    </form>
  );
}
