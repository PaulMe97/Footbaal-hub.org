import { useEffect, useState } from "react";

import { extractErrorMessage } from "../../api/client";
import { updatePlayer } from "../../api/players";
import { QuickSuggestions } from "../../components/QuickSuggestions";
import { Button } from "../../components/ui/Button";
import { DateField } from "../../components/ui/DateField";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { STATUS_LABELS } from "../../types";
import type { Player, PlayerStatus } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import { useQuickSuggestions } from "../../utils/quickSuggestions";

export function MedicalInfoModal({
  player,
  isOpen,
  onClose,
  onUpdated,
}: {
  player: Player | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (updated: Player) => void;
}) {
  const { t } = useLanguage();
  const toast = useToast();
  const injurySuggestions = useQuickSuggestions("injuryType");

  const [status, setStatus] = useState<PlayerStatus>("fit");
  const [injuryType, setInjuryType] = useState("");
  const [injuryDate, setInjuryDate] = useState("");
  const [expectedReturn, setExpectedReturn] = useState("");
  const [medicalNotes, setMedicalNotes] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!isOpen || !player) return;
    setStatus(player.status || "fit");
    setInjuryType(player.injury_type || "");
    setInjuryDate(player.injury_date || "");
    setExpectedReturn(player.expected_return || "");
    setMedicalNotes(player.medical_notes || "");
  }, [player?.id, isOpen]);

  async function handleSave() {
    if (!player) return;
    setIsSaving(true);
    try {
      const updated = await updatePlayer(player.id, {
        status,
        injury_type: status === "injured" ? injuryType || undefined : undefined,
        injury_date: status === "injured" ? injuryDate || undefined : undefined,
        expected_return: status === "injured" ? expectedReturn || undefined : undefined,
        medical_notes: medicalNotes || undefined,
      });
      onUpdated(updated);
      toast.show(t("medicalInfoModal.saved"), "success");
      onClose();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t("medicalInfoModal.title")}>
      <div className="space-y-4">
        <Select
          label={t("players.status")}
          value={status}
          onChange={(e) => setStatus(e.target.value as PlayerStatus)}
        >
          {Object.entries(STATUS_LABELS).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>

        {status === "injured" && (
          <>
            <Input
              label={t("playerForm.injuryType")}
              value={injuryType}
              onChange={(e) => setInjuryType(e.target.value)}
              placeholder={t("medicalInfoModal.injuryTypePlaceholder")}
            />
            <QuickSuggestions suggestions={injurySuggestions} onSelect={setInjuryType} />
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <DateField label={t("playerForm.injuryDate")} value={injuryDate} onChange={setInjuryDate} />
              <DateField
                label={t("playerForm.expectedReturn")}
                value={expectedReturn}
                onChange={setExpectedReturn}
              />
            </div>
          </>
        )}

        <Textarea
          label={t("medicalInfoModal.notesLabel")}
          value={medicalNotes}
          onChange={(e) => setMedicalNotes(e.target.value)}
          placeholder={t("medicalInfoModal.notesPlaceholder")}
        />

        <div className="flex justify-end gap-2 border-t border-line pt-4">
          <Button type="button" variant="secondary" onClick={onClose}>
            {t("common.cancel")}
          </Button>
          <Button type="button" onClick={handleSave} isLoading={isSaving}>
            {t("common.save")}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
