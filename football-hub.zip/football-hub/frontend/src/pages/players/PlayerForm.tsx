import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { POSITIONS } from "../../types";
import type { Player, PlayerPosition, PlayerStatus, PreferredFoot, Team } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export interface PlayerFormValues {
  first_name: string;
  last_name: string;
  date_of_birth: string;
  nationality: string;
  phone: string;
  email: string;
  player_number: string;
  preferred_foot: PreferredFoot | "";
  height_cm: string;
  weight_kg: string;
  position: PlayerPosition | "";
  secondary_position: PlayerPosition | "";
  current_team_id: string;
  status: PlayerStatus;
  contract_notes: string;
  availability_notes: string;
  injury_type: string;
  injury_date: string;
  expected_return: string;
  medical_notes: string;
}

function toFormValues(player?: Player | null, presetTeamId?: string): PlayerFormValues {
  return {
    first_name: player?.first_name ?? "",
    last_name: player?.last_name ?? "",
    date_of_birth: player?.date_of_birth?.slice(0, 10) ?? "",
    nationality: player?.nationality ?? "",
    phone: player?.phone ?? "",
    email: player?.email ?? "",
    player_number: player?.player_number != null ? String(player.player_number) : "",
    preferred_foot: player?.preferred_foot ?? "",
    height_cm: player?.height_cm != null ? String(player.height_cm) : "",
    weight_kg: player?.weight_kg != null ? String(player.weight_kg) : "",
    position: player?.position ?? "",
    secondary_position: player?.secondary_position ?? "",
    current_team_id: player?.current_team_id ?? presetTeamId ?? "",
    status: player?.status ?? "fit",
    contract_notes: player?.contract_notes ?? "",
    availability_notes: player?.availability_notes ?? "",
    injury_type: player?.injury_type ?? "",
    injury_date: player?.injury_date?.slice(0, 10) ?? "",
    expected_return: player?.expected_return?.slice(0, 10) ?? "",
    medical_notes: player?.medical_notes ?? "",
  };
}

export function playerFormToPayload(values: PlayerFormValues) {
  return {
    first_name: values.first_name,
    last_name: values.last_name,
    date_of_birth: values.date_of_birth || null,
    nationality: values.nationality || null,
    phone: values.phone || null,
    email: values.email || null,
    player_number: values.player_number ? Number(values.player_number) : null,
    preferred_foot: values.preferred_foot || null,
    height_cm: values.height_cm ? Number(values.height_cm) : null,
    weight_kg: values.weight_kg ? Number(values.weight_kg) : null,
    position: values.position || null,
    secondary_position: values.secondary_position || null,
    current_team_id: values.current_team_id || null,
    status: values.status,
    contract_notes: values.contract_notes || null,
    availability_notes: values.availability_notes || null,
    injury_type: values.injury_type || null,
    injury_date: values.injury_date || null,
    expected_return: values.expected_return || null,
    medical_notes: values.medical_notes || null,
  };
}

export function PlayerForm({
  player,
  teams,
  presetTeamId,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  player?: Player | null;
  teams: Team[];
  presetTeamId?: string;
  onSubmit: (values: PlayerFormValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const [values, setValues] = useState<PlayerFormValues>(toFormValues(player, presetTeamId));
  const { t } = useLanguage();

  function set<K extends keyof PlayerFormValues>(key: K, value: PlayerFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("playerForm.firstNameRequired")}
          required
          value={values.first_name}
          onChange={(e) => set("first_name", e.target.value)}
        />
        <Input
          label={t("playerForm.lastNameRequired")}
          required
          value={values.last_name}
          onChange={(e) => set("last_name", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Input
          label={t("playerForm.dob")}
          type="date"
          value={values.date_of_birth}
          onChange={(e) => set("date_of_birth", e.target.value)}
        />
        <Input
          label={t("playerForm.nationality")}
          value={values.nationality}
          onChange={(e) => set("nationality", e.target.value)}
        />
        <Input
          label={t("playerForm.number")}
          type="number"
          value={values.player_number}
          onChange={(e) => set("player_number", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input label={t("playerForm.phone")} value={values.phone} onChange={(e) => set("phone", e.target.value)} />
        <Input
          label="Email"
          type="email"
          value={values.email}
          onChange={(e) => set("email", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Select
          label={t("scouting.position")}
          value={values.position}
          onChange={(e) => set("position", e.target.value as PlayerPosition | "")}
        >
          <option value="">—</option>
          {POSITIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </Select>
        <Select
          label={t("playerForm.secondaryPosition")}
          value={values.secondary_position}
          onChange={(e) => set("secondary_position", e.target.value as PlayerPosition | "")}
        >
          <option value="">—</option>
          {POSITIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </Select>
        <Select
          label={t("playerForm.preferredFoot")}
          value={values.preferred_foot}
          onChange={(e) => set("preferred_foot", e.target.value as PreferredFoot | "")}
        >
          <option value="">—</option>
          <option value="left">{t("playerForm.footLeft")}</option>
          <option value="right">{t("playerForm.footRight")}</option>
          <option value="both">{t("playerForm.footBoth")}</option>
        </Select>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Input
          label={t("playerCompare.heightCm")}
          type="number"
          value={values.height_cm}
          onChange={(e) => set("height_cm", e.target.value)}
        />
        <Input
          label={t("playerForm.weightKg")}
          type="number"
          value={values.weight_kg}
          onChange={(e) => set("weight_kg", e.target.value)}
        />
        <Select
          label={t("dashboard.team")}
          value={values.current_team_id}
          onChange={(e) => set("current_team_id", e.target.value)}
        >
          <option value="">{t("players.noTeam")}</option>
          {teams.map((teamOpt) => (
            <option key={teamOpt.id} value={teamOpt.id}>
              {teamOpt.name}
            </option>
          ))}
        </Select>
      </div>

      <Select
        label={t("players.status")}
        value={values.status}
        onChange={(e) => set("status", e.target.value as PlayerStatus)}
      >
        <option value="fit">{t("playerForm.statusFitSingular")}</option>
        <option value="injured">{t("playerForm.statusInjuredSingular")}</option>
        <option value="suspended">{t("playerForm.statusSuspendedSingular")}</option>
        <option value="doubtful">{t("playerForm.statusDoubtfulSingular")}</option>
        <option value="unavailable">{t("playerForm.statusUnavailableSingular")}</option>
      </Select>

      {values.status === "injured" && (
        <div className="grid grid-cols-2 gap-4 rounded-md border border-status-injured/30 bg-status-injured/5 p-3">
          <Input
            label={t("playerForm.injuryType")}
            value={values.injury_type}
            onChange={(e) => set("injury_type", e.target.value)}
          />
          <Input
            label={t("playerForm.expectedReturn")}
            type="date"
            value={values.expected_return}
            onChange={(e) => set("expected_return", e.target.value)}
          />
          <Input
            label={t("playerForm.injuryDate")}
            type="date"
            value={values.injury_date}
            onChange={(e) => set("injury_date", e.target.value)}
          />
          <Textarea
            label={t("playerForm.medicalNotes")}
            value={values.medical_notes}
            onChange={(e) => set("medical_notes", e.target.value)}
          />
        </div>
      )}

      <Textarea
        label={t("playerForm.contractNotes")}
        value={values.contract_notes}
        onChange={(e) => set("contract_notes", e.target.value)}
      />
      <Textarea
        label={t("playerForm.availabilityNotes")}
        value={values.availability_notes}
        onChange={(e) => set("availability_notes", e.target.value)}
      />

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {player ? t("common.save") : t("common.create")}
        </Button>
      </div>
    </form>
  );
}
