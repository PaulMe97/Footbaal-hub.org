import { useEffect, useState, type MouseEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

import { extractErrorMessage, mediaUrl } from "../../api/client";
import { listAbsences } from "../../api/absences";
import type { PlayerAbsenceItem } from "../../api/absences";
import {
  createPlayer,
  deletePlayer,
  getPlayerStatistics,
  incrementPlayerStatistic,
  listPlayers,
  updatePlayer,
  updatePlayerStatistics,
} from "../../api/players";
import { importPlayersCsv, listTeams } from "../../api/teams";
import type { CSVImportResult } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { CsvTemplateModal } from "../../components/CsvTemplateModal";
import { PlayerHistoryModal } from "../../components/PlayerHistoryModal";
import { StatusBadge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { useContextMenu } from "../../components/ui/ContextMenu";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Input, Select } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { ABSENCE_REASON_INFO, POSITIONS, STATUS_LABELS } from "../../types";
import type { Player, PlayerStatistics, PlayerStatus, Team } from "../../types";
import { PlayerForm, playerFormToPayload, type PlayerFormValues } from "./PlayerForm";
import { PlayerStatsForm } from "./PlayerStatsForm";

function groupPlayersByTeam(players: Player[], unknownTeamLabel: string, noTeamLabel: string) {
  const map = new Map<string, { teamId: string; teamName: string; players: Player[] }>();
  const noTeam: Player[] = [];
  for (const p of players) {
    if (!p.current_team_id) {
      noTeam.push(p);
      continue;
    }
    if (!map.has(p.current_team_id)) {
      map.set(p.current_team_id, { teamId: p.current_team_id, teamName: p.team_name || unknownTeamLabel, players: [] });
    }
    map.get(p.current_team_id)!.players.push(p);
  }
  const groups: { teamId: string | null; teamName: string; players: Player[] }[] = Array.from(
    map.values()
  ).sort((a, b) => a.teamName.localeCompare(b.teamName, "el"));
  if (noTeam.length > 0) {
    groups.push({ teamId: null, teamName: noTeamLabel, players: noTeam });
  }
  return groups;
}

export default function PlayersList() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const isPlayer = user?.role === "player";
  const [searchParams, setSearchParams] = useSearchParams();
  const teamIdFilter = searchParams.get("team_id") || "";

  const [players, setPlayers] = useState<Player[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showAllTeams, setShowAllTeams] = useState(false);
  const [position, setPosition] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Player | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [statsPlayer, setStatsPlayer] = useState<Player | null>(null);
  const [stats, setStats] = useState<PlayerStatistics | null>(null);
  const [isStatsSubmitting, setIsStatsSubmitting] = useState(false);
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [showCsvTemplate, setShowCsvTemplate] = useState(false);
  const [csvTeamId, setCsvTeamId] = useState("");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [isImportingCsv, setIsImportingCsv] = useState(false);
  const [csvResult, setCsvResult] = useState<CSVImportResult | null>(null);
  const [activeAbsencesByPlayer, setActiveAbsencesByPlayer] = useState<Map<string, PlayerAbsenceItem>>(new Map());
  const [historyPlayerId, setHistoryPlayerId] = useState<string | null>(null);
  const [historyPlayerName, setHistoryPlayerName] = useState("");
  const toast = useToast();
  const menu = useContextMenu();

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  useEffect(() => {
    listAbsences({ active_only: true })
      .then((list) => {
        const map = new Map<string, PlayerAbsenceItem>();
        for (const a of list) map.set(a.player_id, a);
        setActiveAbsencesByPlayer(map);
      })
      .catch(() => {
        /* σιωπηλή αποτυχία — τα badges απλά δεν θα εμφανιστούν */
      });
  }, []);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listPlayers({
        search: search || undefined,
        team_id: teamIdFilter || undefined,
        position: position || undefined,
      });
      setPlayers(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, teamIdFilter, position]);

  async function handleCreate(values: PlayerFormValues) {
    setIsSubmitting(true);
    try {
      await createPlayer(playerFormToPayload(values));
      toast.show(t("players.playerAdded"), "success");
      setShowCreate(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deletePlayer(deleteTarget.id);
      toast.show(t("players.playerDeleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  async function handleQuickStat(player: Player, field: "matches_played" | "goals" | "yellow_cards" | "red_cards") {
    try {
      await incrementPlayerStatistic(player.id, field, 1);
      toast.show(t("players.statUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleQuickStatus(player: Player, status: PlayerStatus) {
    try {
      await updatePlayer(player.id, { status });
      toast.show(`${t("players.statusChangedPrefix")}${STATUS_LABELS[status]}${t("players.statusChangedSuffix")}`, "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function openStatsEditor(player: Player) {
    try {
      const s = await getPlayerStatistics(player.id);
      setStats(s);
      setStatsPlayer(player);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleStatsSubmit(values: {
    matches_played: number;
    goals: number;
    assists: number;
    yellow_cards: number;
    red_cards: number;
  }) {
    if (!statsPlayer) return;
    setIsStatsSubmitting(true);
    try {
      await updatePlayerStatistics(statsPlayer.id, values);
      toast.show(t("players.statsSaved"), "success");
      setStatsPlayer(null);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsStatsSubmitting(false);
    }
  }

  function openPlayerContextMenu(e: MouseEvent, player: Player) {
    if (isPlayer) return;
    menu.open(e, [
      {
        heading: `${player.first_name} ${player.last_name}`,
        items: [
          { label: t("players.actionGoal"), onClick: () => handleQuickStat(player, "goals") },
          { label: t("players.actionMatch"), onClick: () => handleQuickStat(player, "matches_played") },
          { label: t("players.actionYellowCard"), onClick: () => handleQuickStat(player, "yellow_cards") },
          { label: t("players.actionRedCard"), onClick: () => handleQuickStat(player, "red_cards") },
        ],
      },
      {
        heading: t("players.status"),
        items: [
          { label: t("players.statusAvailable"), onClick: () => handleQuickStatus(player, "fit"), disabled: player.status === "fit" },
          { label: t("players.statusInjured"), onClick: () => handleQuickStatus(player, "injured"), disabled: player.status === "injured" },
          { label: t("players.statusReturned"), onClick: () => handleQuickStatus(player, "fit"), disabled: player.status !== "injured" },
          { label: t("players.statusUnavailable"), onClick: () => handleQuickStatus(player, "unavailable"), disabled: player.status === "unavailable" },
          { label: t("players.statusSuspended"), onClick: () => handleQuickStatus(player, "suspended"), disabled: player.status === "suspended" },
        ],
      },
      {
        items: [
          { label: t("players.editStats"), onClick: () => openStatsEditor(player) },
          { label: t("players.deletePlayer"), onClick: () => setDeleteTarget(player), danger: true },
        ],
      },
    ]);
  }

  function openCsvImport() {
    setCsvTeamId(teamIdFilter || "");
    setCsvFile(null);
    setShowCsvImport(true);
  }

  async function handleCsvSubmit() {
    if (!csvTeamId || !csvFile) return;
    setIsImportingCsv(true);
    try {
      const result = await importPlayersCsv(csvTeamId, csvFile);
      setCsvResult(result);
      setShowCsvImport(false);
      toast.show(`${t("players.importedPrefix")}${result.created}${t("players.importedSuffix")}`, "success");
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsImportingCsv(false);
    }
  }

  const activeTeam = teams.find((t) => t.id === teamIdFilter);

  return (
    <AppLayout title={t("players.title")}>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row">
          <Input
            placeholder={t("players.searchPlaceholder")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="sm:w-64"
          />
          <Select value={position} onChange={(e) => setPosition(e.target.value)} className="sm:w-40">
            <option value="">{t("players.allPositions")}</option>
            {POSITIONS.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </Select>
          <Select
            value={teamIdFilter}
            onChange={(e) => {
              const v = e.target.value;
              setSearchParams(v ? { team_id: v } : {});
            }}
            className="sm:w-48"
          >
            <option value="">{t("players.allTeams")}</option>
            {teams.map((t2) => (
              <option key={t2.id} value={t2.id}>
                {t2.name}
              </option>
            ))}
          </Select>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            to="/players/compare"
            className="flex items-center rounded-md border border-line px-4 py-2 text-sm text-text-muted hover:border-chalk hover:text-text-primary"
          >
            {t("players.compare")}
          </Link>
          {!isPlayer && (
            <>
              <Button variant="secondary" onClick={openCsvImport}>
                {t("players.importCsv")}
              </Button>
              <Button onClick={() => setShowCreate(true)}>{t("players.newPlayer")}</Button>
            </>
          )}
        </div>
      </div>

      {activeTeam && (
        <p className="mb-3 text-sm text-text-muted">
          {t("players.filteringFor")} <span className="text-chalk">{activeTeam.name}</span>{" "}
          <button onClick={() => setSearchParams({})} className="ml-1 underline">
            {t("players.clearFilter")}
          </button>
        </p>
      )}

      {(teamIdFilter || search.trim() || position || showAllTeams) && (
        <p className="mb-2 text-xs text-text-muted">{t("players.contextMenuHint")}</p>
      )}

      {isLoading ? (
        <Spinner />
      ) : !teamIdFilter && !search.trim() && !position && !showAllTeams ? (
        teams.length === 0 ? (
          <EmptyState
            title={t("teams.noTeamsYet")}
            action={<Button onClick={() => setShowCreate(true)}>{t("players.newPlayer")}</Button>}
          />
        ) : (
          <>
            <p className="mb-4 text-sm text-text-muted">{t("players.pickTeamIntro")}</p>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {teams.map((team) => (
                <Card
                  key={team.id}
                  corners
                  className="flex cursor-pointer flex-col p-5 transition-colors hover:border-chalk"
                  onClick={() => setSearchParams({ team_id: team.id })}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") setSearchParams({ team_id: team.id });
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm">
                      {team.logo_path ? (
                        <img src={mediaUrl(team.logo_path)} alt="" className="h-full w-full object-cover" />
                      ) : (
                        team.name.slice(0, 2).toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-display text-base text-text-primary">{team.name}</p>
                      <p className="truncate text-xs text-text-muted">
                        {[team.category, team.season].filter(Boolean).join(" · ") || "—"}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 border-t border-line pt-3 text-sm text-text-muted">
                    <span className="font-mono text-text-primary">{team.player_count}</span> {t("teams.playersUnit")}
                  </div>
                </Card>
              ))}
            </div>
            <button
              onClick={() => setShowAllTeams(true)}
              className="mt-4 text-xs text-chalk hover:underline"
            >
              {t("players.pickTeamSearchAll")}
            </button>
          </>
        )
      ) : players.length === 0 ? (
        <EmptyState
          title={t("players.noPlayersFound")}
          description={t("players.noPlayersDescription")}
          action={<Button onClick={() => setShowCreate(true)}>{t("players.newPlayer")}</Button>}
        />
      ) : teamIdFilter ? (
        <Card>
          <div className="divide-y divide-line">
            {players.map((p) => (
              <PlayerRow
                key={p.id}
                player={p}
                absence={activeAbsencesByPlayer.get(p.id)}
                onContextMenu={(e) => openPlayerContextMenu(e, p)}
                onDelete={() => setDeleteTarget(p)}
                onOpenHistory={() => {
                  setHistoryPlayerId(p.id);
                  setHistoryPlayerName(`${p.first_name} ${p.last_name}`);
                }}
              />
            ))}
          </div>
        </Card>
      ) : (
        <div className="space-y-6">
          {groupPlayersByTeam(players, t("players.unknownTeam"), t("players.noTeam")).map((group) => (
            <Card key={group.teamId ?? group.teamName}>
              <div className="border-b border-line px-4 py-2.5">
                {group.teamId ? (
                  <Link to={`/teams/${group.teamId}`} className="font-display text-sm text-text-primary hover:text-chalk">
                    {group.teamName} <span className="text-xs text-text-muted">({group.players.length})</span>
                  </Link>
                ) : (
                  <h3 className="font-display text-sm text-text-primary">
                    {group.teamName} <span className="text-xs text-text-muted">({group.players.length})</span>
                  </h3>
                )}
              </div>
              <div className="divide-y divide-line">
                {group.players.map((p) => (
                  <PlayerRow
                    key={p.id}
                    player={p}
                    absence={activeAbsencesByPlayer.get(p.id)}
                    onContextMenu={(e) => openPlayerContextMenu(e, p)}
                    onDelete={() => setDeleteTarget(p)}
                    onOpenHistory={() => {
                      setHistoryPlayerId(p.id);
                      setHistoryPlayerName(`${p.first_name} ${p.last_name}`);
                    }}
                  />
                ))}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("players.newPlayerModalTitle")} wide>
        <PlayerForm
          teams={teams}
          presetTeamId={teamIdFilter || undefined}
          onSubmit={handleCreate}
          onCancel={() => setShowCreate(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("players.deletePlayerTitle")}
        message={`${t("players.deleteConfirmPrefix")}${deleteTarget?.first_name} ${deleteTarget?.last_name}${t("players.deleteConfirmSuffix")}`}
        isLoading={isDeleting}
      />

      <Modal
        isOpen={!!statsPlayer}
        onClose={() => setStatsPlayer(null)}
        title={`${t("players.statsModalTitlePrefix")}${statsPlayer?.first_name} ${statsPlayer?.last_name}`}
      >
        {stats && (
          <PlayerStatsForm
            stats={stats}
            onSubmit={handleStatsSubmit}
            onCancel={() => setStatsPlayer(null)}
            isSubmitting={isStatsSubmitting}
          />
        )}
      </Modal>

      {menu.render()}

      <Modal isOpen={showCsvImport} onClose={() => setShowCsvImport(false)} title={t("players.importFromCsvExcel")}>
        <div className="space-y-4">
          <Select label={t("players.teamRequired")} value={csvTeamId} onChange={(e) => setCsvTeamId(e.target.value)}>
            <option value="">{t("players.selectTeam")}</option>
            {teams.map((t2) => (
              <option key={t2.id} value={t2.id}>
                {t2.name}
              </option>
            ))}
          </Select>
          <div>
            <span className="mb-1.5 block text-xs font-medium text-text-muted">{t("players.fileCsvExcel")}</span>
            <input
              type="file"
              accept=".csv,.xlsx"
              onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
              className="w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-text-primary file:mr-3 file:rounded-md file:border-0 file:bg-surface-raised file:px-3 file:py-1.5 file:text-xs file:text-text-primary"
            />
            <p className="mt-1.5 text-xs text-text-muted">{t("players.csvColumnsHelp")}</p>
            <button
              type="button"
              onClick={() => setShowCsvTemplate(true)}
              className="mt-1.5 text-xs text-chalk hover:underline"
            >
              {t("csvTemplate.viewButton")}
            </button>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="secondary" onClick={() => setShowCsvImport(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              onClick={handleCsvSubmit}
              isLoading={isImportingCsv}
              disabled={!csvTeamId || !csvFile}
            >
              {t("players.import")}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal isOpen={!!csvResult} onClose={() => setCsvResult(null)} title={t("players.importResultTitle")}>
        {csvResult && (
          <div className="space-y-3 text-sm">
            <p className="text-status-fit">
              {t("players.createdPrefix")}
              {csvResult.created}
              {t("players.createdSuffix")}
            </p>
            {csvResult.errors.length > 0 && (
              <div>
                <p className="mb-1 text-status-injured">
                  {t("players.rowsSkippedPrefix")}
                  {csvResult.errors.length}
                  {t("players.rowsSkippedSuffix")}
                </p>
                <div className="max-h-48 space-y-1 overflow-y-auto rounded-md border border-line bg-surface-raised p-2">
                  {csvResult.errors.map((e, i) => (
                    <p key={i} className="text-xs text-text-muted">
                      {t("players.rowLabel")}
                      {e.row}: {e.message}
                    </p>
                  ))}
                </div>
              </div>
            )}
            <div className="flex justify-end">
              <Button onClick={() => setCsvResult(null)}>{t("common.close")}</Button>
            </div>
          </div>
        )}
      </Modal>

      <PlayerHistoryModal
        playerId={historyPlayerId}
        playerName={historyPlayerName}
        isOpen={!!historyPlayerId}
        onClose={() => setHistoryPlayerId(null)}
      />

      <CsvTemplateModal isOpen={showCsvTemplate} onClose={() => setShowCsvTemplate(false)} />
    </AppLayout>
  );
}

function PlayerRow({
  player: p,
  absence,
  onContextMenu,
  onDelete,
  onOpenHistory,
}: {
  player: Player;
  absence?: PlayerAbsenceItem;
  onContextMenu: (e: MouseEvent) => void;
  onDelete: () => void;
  onOpenHistory: () => void;
}) {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const absenceInfo = absence ? ABSENCE_REASON_INFO[absence.reason] : null;
  return (
    <div
      onClick={() => navigate(`/players/${p.id}`)}
      onContextMenu={onContextMenu}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") navigate(`/players/${p.id}`);
      }}
      className="flex cursor-pointer items-center justify-between px-4 py-3 hover:bg-surface-raised"
    >
      <div className="flex flex-1 items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface font-mono text-xs text-text-muted">
          {p.photo_path ? (
            <img src={mediaUrl(p.photo_path)} alt="" className="h-full w-full object-cover" />
          ) : (
            p.player_number ?? "-"
          )}
        </div>
        <div>
          <p className="text-sm text-text-primary">
            {p.first_name} {p.last_name}
          </p>
          <p className="text-xs text-text-muted">
            {[p.position, p.team_name, p.age ? `${p.age}${t("players.yearsOldSuffix")}` : null]
              .filter(Boolean)
              .join(" · ") || "—"}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="hidden items-center gap-3 font-mono text-xs text-text-muted sm:flex">
          <span title={t("players.matchesTitle")}>🏟 {p.matches_played}</span>
          <span title={t("players.goalsTitle")}>⚽ {p.goals}</span>
        </span>
        {absenceInfo && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenHistory();
            }}
            className={`hidden shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] sm:flex ${absenceInfo.color}`}
            title={absenceInfo.label}
          >
            {absenceInfo.icon} {absenceInfo.label}
          </button>
        )}
        <StatusBadge status={p.status} />
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenHistory();
          }}
          aria-label={t("playerHistory.viewHistoryAriaLabel")}
          className="text-xs text-text-muted hover:text-chalk"
        >
          📋
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="text-xs text-status-injured hover:underline"
        >
          {t("common.delete")}
        </button>
      </div>
    </div>
  );
}
