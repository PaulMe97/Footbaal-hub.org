import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import { ATTRIBUTE_LABELS } from "../../types";
import type { PlayerAttributes } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export function PlayerAttributesForm({
  attributes,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  attributes: PlayerAttributes;
  onSubmit: (values: PlayerAttributes) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const { t } = useLanguage();
  const [values, setValues] = useState<Record<string, string>>({
    potential: attributes.potential != null ? String(attributes.potential) : "",
    passing: attributes.passing != null ? String(attributes.passing) : "",
    shooting: attributes.shooting != null ? String(attributes.shooting) : "",
    dribbling: attributes.dribbling != null ? String(attributes.dribbling) : "",
    defending: attributes.defending != null ? String(attributes.defending) : "",
    attacking: attributes.attacking != null ? String(attributes.attacking) : "",
    physical: attributes.physical != null ? String(attributes.physical) : "",
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const payload: PlayerAttributes = {};
    for (const key of Object.keys(values) as (keyof PlayerAttributes)[]) {
      payload[key] = values[key] === "" ? null : Number(values[key]);
    }
    onSubmit(payload);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <p className="text-xs text-text-muted">{t("playerAttributesForm.scaleHint")}</p>
      <div className="grid grid-cols-2 gap-4">
        {(Object.keys(ATTRIBUTE_LABELS) as (keyof PlayerAttributes)[]).map((key) => (
          <Input
            key={key}
            label={ATTRIBUTE_LABELS[key]}
            type="number"
            min={1}
            max={10}
            step={0.1}
            value={values[key]}
            onChange={(e) => setValues((v) => ({ ...v, [key]: e.target.value }))}
          />
        ))}
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {t("common.save")}
        </Button>
      </div>
    </form>
  );
}
