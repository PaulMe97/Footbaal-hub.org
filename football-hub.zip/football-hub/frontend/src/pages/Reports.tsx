import { AppLayout } from "../components/layout/AppLayout";
import { useLanguage } from "../context/LanguageContext";

export default function Reports() {
  const { t } = useLanguage();
  return (
    <AppLayout title={t("nav.reports")}>
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-line py-24 text-center">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-line bg-surface-raised text-3xl">
          🔒
        </div>
        <h2 className="font-display text-xl text-text-primary">Coming Soon</h2>
        <p className="mt-2 max-w-sm text-sm text-text-muted">
          {t("reports.underConstruction")}
        </p>
      </div>
    </AppLayout>
  );
}
