import { useEffect, useMemo, useState } from "react";

import {
  addToShortlist,
  createLeagueGroup,
  createLeagueLevel,
  deleteLeagueGroup,
  deleteLeagueLevel,
  getShortlist,
  listCountries,
  listFederations,
  listLeagueGroups,
  listLeagueLevels,
  listRegions,
  listScoutingStaff,
  listScoutingTeams,
  listTeamScoutingPlayers,
  removeFromShortlist,
  searchScoutingPlayers,
} from "../api/scouting";
import type { LeagueGroupItem, LeagueLevelItem } from "../api/scouting";
import { extractErrorMessage, mediaUrl } from "../api/client";
import { sendContractOffer } from "../api/contracts";
import { applyToListing, browseListings } from "../api/listings";
import type { TeamListingItem } from "../api/listings";
import { applyAsPlayer, applyToTeam, claimPlayer } from "../api/requests";
import { deleteTeam, listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { ListingDetailModal } from "../components/ListingDetailModal";
import { useContextMenu } from "../components/ui/ContextMenu";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Input, Select } from "../components/ui/Input";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { GreeceMap } from "./scouting/GreeceMap";
import { PlayerScoutingModal } from "./scouting/PlayerScoutingModal";
import { ScoutingPlayerCard } from "./scouting/ScoutingPlayerCard";
import { StaffCard } from "./scouting/StaffCard";
import { StaffScoutingModal } from "./scouting/StaffScoutingModal";
import {
  ACADEMY_AGE_GROUPS,
  DEFAULT_LEAGUE_TIERS,
  GREECE_LEAGUE_TIERS,
  LEAGUE_TIER_LABELS,
  POSITIONS,
  STAFF_AVAILABILITY_LABELS,
  TRANSFER_STATUS_LABELS,
} from "../types";
import type {
  Country,
  Federation,
  LeagueTier,
  PlayerPosition,
  Region,
  ScoutingPlayer,
  ScoutingStaff,
  ScoutingTeam,
  Team,
} from "../types";

type ViewMode = "browse-teams" | "team-roster" | "search-results" | "shortlist" | "staff" | "listings";

function groupScoutingPlayersByPosition(
  players: ScoutingPlayer[],
  positionCategories: { label: string; positions: PlayerPosition[] }[],
  noPositionLabel: string
) {
  const groups = positionCategories.map((c) => ({ label: c.label, players: [] as ScoutingPlayer[] }));
  const other: ScoutingPlayer[] = [];
  for (const p of players) {
    const group = groups.find((g) =>
      positionCategories.find((c) => c.label === g.label)!.positions.includes(
        p.position as PlayerPosition
      )
    );
    if (group) {
      group.players.push(p);
    } else {
      other.push(p);
    }
  }
  if (other.length > 0) {
    groups.push({ label: noPositionLabel, players: other });
  }
  return groups.filter((g) => g.players.length > 0);
}

function groupStaffByRegion(staffList: ScoutingStaff[], noRegionLabel: string) {
  const byRegion = new Map<string, ScoutingStaff[]>();
  const noRegion: ScoutingStaff[] = [];
  for (const s of staffList) {
    if (s.origin_federation_name) {
      const list = byRegion.get(s.origin_federation_name) || [];
      list.push(s);
      byRegion.set(s.origin_federation_name, list);
    } else {
      noRegion.push(s);
    }
  }
  const groups = Array.from(byRegion.entries())
    .sort((a, b) => a[0].localeCompare(b[0], "el"))
    .map(([label, members]) => ({ label, staff: members }));
  if (noRegion.length > 0) {
    groups.push({ label: noRegionLabel, staff: noRegion });
  }
  return groups;
}

export default function Scouting() {
  const toast = useToast();
  const { user } = useAuth();
  const { t } = useLanguage();
  const LISTING_ROLE_LABELS: Record<string, string> = {
    technical_director: t("scouting.roleTechnicalDirector"),
    head_coach: t("scouting.roleHeadCoach"),
    assistant_coach: t("scouting.roleAssistantCoach"),
    fitness_coach: t("scouting.roleFitnessCoach"),
    analyst: t("scouting.roleAnalyst"),
    scout: "Scout",
  };
  const POSITION_CATEGORIES: { label: string; positions: PlayerPosition[] }[] = [
    { label: t("teamDetail.positionGoalkeepers"), positions: ["GK"] },
    { label: t("teamDetail.positionDefense"), positions: ["CB", "LB", "RB", "LWB", "RWB"] },
    { label: t("teamDetail.positionMidfield"), positions: ["DM", "CM", "AM"] },
    { label: t("teamDetail.positionAttack"), positions: ["LW", "RW", "ST"] },
  ];

  const [isApplying, setIsApplying] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);
  const [myTeams, setMyTeams] = useState<Team[]>([]);

  const [countries, setCountries] = useState<Country[]>([]);
  const [countryId, setCountryId] = useState("");
  const [tier, setTier] = useState<LeagueTier>("regional");
  const [academyOnly, setAcademyOnly] = useState(false);
  const [ageGroupFilter, setAgeGroupFilter] = useState("");

  const [regions, setRegions] = useState<Region[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);
  const [federations, setFederations] = useState<Federation[]>([]);
  const [selectedFederationId, setSelectedFederationId] = useState("");

  const [levels, setLevels] = useState<LeagueLevelItem[]>([]);
  const [selectedLevelId, setSelectedLevelId] = useState("");
  const [groups, setGroups] = useState<LeagueGroupItem[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [showLevelManager, setShowLevelManager] = useState(false);
  const [newLevelName, setNewLevelName] = useState("");
  const [newGroupName, setNewGroupName] = useState("");
  const [isSavingLevel, setIsSavingLevel] = useState(false);
  const [isSavingGroup, setIsSavingGroup] = useState(false);

  const [teams, setTeams] = useState<ScoutingTeam[]>([]);
  const [isLoadingTeams, setIsLoadingTeams] = useState(false);

  const [viewMode, setViewMode] = useState<ViewMode>("browse-teams");
  const [selectedTeam, setSelectedTeam] = useState<ScoutingTeam | null>(null);
  const [players, setPlayers] = useState<ScoutingPlayer[]>([]);
  const [isLoadingPlayers, setIsLoadingPlayers] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [teamSearchQuery, setTeamSearchQuery] = useState("");
  const [positionFilter, setPositionFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [minAge, setMinAge] = useState("");
  const [maxAge, setMaxAge] = useState("");
  const [staffRoleFilter, setStaffRoleFilter] = useState("");
  const [staffAvailabilityFilter, setStaffAvailabilityFilter] = useState("");
  const [listingTypeFilter, setListingTypeFilter] = useState("");

  const [selectedPlayer, setSelectedPlayer] = useState<ScoutingPlayer | null>(null);
  const [staffList, setStaffList] = useState<ScoutingStaff[]>([]);
  const [isLoadingStaff, setIsLoadingStaff] = useState(false);
  const [listings, setListings] = useState<TeamListingItem[]>([]);
  const [isLoadingListings, setIsLoadingListings] = useState(false);
  const [applyingListingId, setApplyingListingId] = useState<string | null>(null);
  const [appliedListingIds, setAppliedListingIds] = useState<string[]>([]);
  const [selectedListing, setSelectedListing] = useState<TeamListingItem | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<ScoutingStaff | null>(null);

  const isGreece = useMemo(
    () => countries.find((c) => c.id === countryId)?.name === "Ελλάδα",
    [countries, countryId]
  );
  const availableTiers = isGreece ? GREECE_LEAGUE_TIERS : DEFAULT_LEAGUE_TIERS;
  const isNationalTier = tier === "top_division" || tier === "second_division" || tier === "third_division";

  // --- Initial load: countries -----------------------------------------------
  useEffect(() => {
    listCountries()
      .then((data) => {
        setCountries(data);
        const greece = data.find((c) => c.name === "Ελλάδα");
        setCountryId(greece?.id || data[0]?.id || "");
      })
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- My teams (για την αποστολή προσφορών συμβολαίου/επιτελείου) ----------
  // Φορτώνεται για ΚΑΘΕ συνδεδεμένο χρήστη — όχι μόνο για president/technical_director
  // — ώστε το κουμπί "Προσφορά" να είναι διαθέσιμο σε οποιονδήποτε πραγματικά
  // διαχειρίζεται έστω μία ομάδα (owner ή με πρόσβαση διαχείρισης), ανεξαρτήτως
  // system role.
  const canOffer = myTeams.length > 0;
  const isAdmin = user?.role === "super_admin" || user?.role === "admin";
  const menu = useContextMenu();

  async function handleAdminDeleteTeam(teamId: string) {
    try {
      await deleteTeam(teamId);
      toast.show(t("scouting.teamDeleted"), "success");
      loadTeams();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAdminDeleteLevel(levelId: string) {
    try {
      await deleteLeagueLevel(levelId);
      const updated = await listLeagueLevels(selectedFederationId, tier);
      setLevels(updated);
      if (selectedLevelId === levelId) setSelectedLevelId("");
      toast.show(t("scouting.levelDeleted"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAdminDeleteGroup(groupId: string) {
    try {
      await deleteLeagueGroup(groupId);
      const updated = await listLeagueGroups(selectedLevelId);
      setGroups(updated);
      if (selectedGroupId === groupId) setSelectedGroupId("");
      toast.show(t("scouting.groupDeleted"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }
  useEffect(() => {
    listTeams()
      .then(setMyTeams)
      .catch(() => {
        /* σιωπηλή αποτυχία */
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- Regions when country changes ------------------------------------------
  useEffect(() => {
    if (!countryId) return;
    listRegions(countryId)
      .then(setRegions)
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    setSelectedRegion(null);
    setSelectedFederationId("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countryId]);

  // Reset tier to a valid option when country changes
  useEffect(() => {
    if (!availableTiers.includes(tier)) {
      setTier(availableTiers[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGreece]);

  // --- Federations when region selected --------------------------------------
  useEffect(() => {
    if (!selectedRegion) {
      setFederations([]);
      return;
    }
    listFederations(selectedRegion.id)
      .then(setFederations)
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    setSelectedFederationId("");
    setLevels([]);
    setSelectedLevelId("");
    setGroups([]);
    setSelectedGroupId("");
  }, [selectedRegion]);

  // --- League levels (π.χ. Α1/Α'/Β'/Γ' ή Κ8-Κ19) όταν επιλεγεί ΕΠΣ ------------
  useEffect(() => {
    if (!selectedFederationId || (tier !== "regional" && tier !== "academy")) {
      setLevels([]);
      setSelectedLevelId("");
      return;
    }
    listLeagueLevels(selectedFederationId, tier)
      .then(setLevels)
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    setSelectedLevelId("");
    setGroups([]);
    setSelectedGroupId("");
  }, [selectedFederationId, tier]);

  // --- Όμιλοι όταν επιλεγεί επίπεδο -------------------------------------------
  useEffect(() => {
    if (!selectedLevelId) {
      setGroups([]);
      setSelectedGroupId("");
      return;
    }
    listLeagueGroups(selectedLevelId)
      .then(setGroups)
      .catch((err) => toast.show(extractErrorMessage(err), "error"));
    setSelectedGroupId("");
  }, [selectedLevelId]);

  // --- Teams: load whenever tier/region/federation/country changes, in browse mode
  async function loadTeams() {
    setIsLoadingTeams(true);
    try {
      const hasGeoNav = tier === "regional" || tier === "academy";
      const data = await listScoutingTeams({
        search: teamSearchQuery.trim() || undefined,
        country_id: countryId || undefined,
        league_tier: tier,
        federation_id: hasGeoNav ? selectedFederationId || undefined : undefined,
        region_id: hasGeoNav && !selectedFederationId ? selectedRegion?.id : undefined,
        league_level_id: hasGeoNav ? selectedLevelId || undefined : undefined,
        league_group_id: hasGeoNav ? selectedGroupId || undefined : undefined,
        academy_only: isNationalTier ? academyOnly : undefined,
        academy_age_group: isNationalTier && academyOnly ? ageGroupFilter || undefined : undefined,
      });
      setTeams(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingTeams(false);
    }
  }

  useEffect(() => {
    if (viewMode !== "browse-teams") return;
    const hasGeoNav = tier === "regional" || tier === "academy";
    if (hasGeoNav && !teamSearchQuery.trim() && (!selectedRegion || !selectedFederationId || !selectedLevelId)) {
      setTeams([]);
      return;
    }
    loadTeams();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    viewMode,
    tier,
    selectedRegion,
    selectedFederationId,
    selectedLevelId,
    selectedGroupId,
    teamSearchQuery,
    countryId,
    academyOnly,
    ageGroupFilter,
  ]);

  // --- Search (debounced) -----------------------------------------------------
  useEffect(() => {
    if (!searchQuery.trim()) {
      if (viewMode === "search-results") setViewMode("browse-teams");
      return;
    }
    const t = setTimeout(async () => {
      setViewMode("search-results");
      setIsLoadingPlayers(true);
      try {
        const data = await searchScoutingPlayers({
          search: searchQuery,
          country_id: countryId || undefined,
          position: positionFilter || undefined,
          transfer_status: statusFilter || undefined,
          min_age: minAge ? Number(minAge) : undefined,
          max_age: maxAge ? Number(maxAge) : undefined,
        });
        setPlayers(data);
      } catch (err) {
        toast.show(extractErrorMessage(err), "error");
      } finally {
        setIsLoadingPlayers(false);
      }
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchQuery, positionFilter, statusFilter, minAge, maxAge]);

  async function openTeam(team: ScoutingTeam) {
    setSelectedTeam(team);
    setViewMode("team-roster");
    setIsLoadingPlayers(true);
    try {
      const data = await listTeamScoutingPlayers(team.id);
      setPlayers(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingPlayers(false);
    }
  }

  async function handleApplyToTeam() {
    if (!selectedTeam || !user) return;
    setIsApplying(true);
    try {
      if (user.role === "player") {
        await applyAsPlayer(selectedTeam.id);
      } else {
        await applyToTeam(selectedTeam.id);
      }
      toast.show(t("scouting.applicationSentValid3Days"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsApplying(false);
    }
  }

  async function openShortlist() {
    setViewMode("shortlist");
    setIsLoadingPlayers(true);
    try {
      const data = await getShortlist();
      setPlayers(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingPlayers(false);
    }
  }

  async function openStaff() {
    setViewMode("staff");
    setIsLoadingStaff(true);
    try {
      const data = await listScoutingStaff();
      setStaffList(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingStaff(false);
    }
  }

  async function openListings() {
    setViewMode("listings");
    setIsLoadingListings(true);
    try {
      const data = await browseListings(
        user?.role === "player" ? { listing_type: "player" } : {}
      );
      setListings(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoadingListings(false);
    }
  }

  async function handleApplyToListing(listingId: string) {
    setApplyingListingId(listingId);
    try {
      await applyToListing(listingId);
      setAppliedListingIds((prev) => [...prev, listingId]);
      toast.show(t("scouting.applicationSent"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setApplyingListingId(null);
    }
  }

  async function handleToggleShortlist(player: ScoutingPlayer) {
    try {
      if (player.is_shortlisted) {
        await removeFromShortlist(player.id);
      } else {
        await addToShortlist(player.id);
      }
      setPlayers((prev) =>
        prev.map((p) => (p.id === player.id ? { ...p, is_shortlisted: !p.is_shortlisted } : p))
      );
      if (selectedPlayer?.id === player.id) {
        setSelectedPlayer({ ...selectedPlayer, is_shortlisted: !selectedPlayer.is_shortlisted });
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleClaimPlayer() {
    if (!selectedPlayer) return;
    setIsClaiming(true);
    try {
      await claimPlayer(selectedPlayer.id);
      toast.show(t("scouting.accountLinkedToPlayer"), "success");
      setSelectedPlayer(null);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsClaiming(false);
    }
  }

  async function handleSendOffer(teamId: string, years?: number, salary?: string, bonus?: string) {
    if (!selectedPlayer?.linked_user_id) return;
    try {
      await sendContractOffer(teamId, {
        player_user_id: selectedPlayer.linked_user_id,
        years,
        salary_details: salary,
        bonus_details: bonus,
      });
      toast.show(t("scouting.offerSent"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  function backToBrowse() {
    setViewMode("browse-teams");
    setSelectedTeam(null);
    setSearchQuery("");
  }

  const filteredPlayers = useMemo(() => {
    return players.filter((p) => {
      if (positionFilter && p.position !== positionFilter) return false;
      if (statusFilter && p.transfer_status !== statusFilter) return false;
      if (minAge && (p.age == null || p.age < Number(minAge))) return false;
      if (maxAge && (p.age == null || p.age > Number(maxAge))) return false;
      return true;
    });
  }, [players, positionFilter, statusFilter, minAge, maxAge]);

  const filteredStaffList = useMemo(() => {
    return staffList.filter((s) => {
      if (staffRoleFilter && s.desired_staff_role !== staffRoleFilter) return false;
      if (staffAvailabilityFilter && s.staff_availability !== staffAvailabilityFilter) return false;
      return true;
    });
  }, [staffList, staffRoleFilter, staffAvailabilityFilter]);

  const filteredListings = useMemo(() => {
    return listings.filter((l) => {
      if (listingTypeFilter && l.listing_type !== listingTypeFilter) return false;
      return true;
    });
  }, [listings, listingTypeFilter]);

  return (
    <AppLayout title="Scouting Hub">
      <p className="mb-4 text-sm text-text-muted">{t("scouting.introText")}</p>

      {/* Top controls */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Select value={countryId} onChange={(e) => setCountryId(e.target.value)} className="w-40">
          {countries.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </Select>

        <div className="flex flex-wrap gap-1.5">
          {availableTiers.map((tierValue) => (
            <button
              key={tierValue}
              onClick={() => {
                setTier(tierValue);
                setViewMode("browse-teams");
                setSelectedRegion(null);
                setSelectedFederationId("");
              }}
              className={`rounded-md border px-3 py-1.5 text-xs ${
                tier === tierValue && viewMode !== "search-results" && viewMode !== "shortlist"
                  ? "border-chalk bg-chalk/15 text-chalk"
                  : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
              }`}
            >
              {LEAGUE_TIER_LABELS[tierValue]}
            </button>
          ))}
        </div>

        <button
          onClick={openShortlist}
          className={`rounded-md border px-3 py-1.5 text-xs ${
            viewMode === "shortlist"
              ? "border-chalk bg-chalk/15 text-chalk"
              : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
          }`}
        >
          {t("scouting.shortlistTab")}
        </button>

        <button
          onClick={openStaff}
          className={`rounded-md border px-3 py-1.5 text-xs ${
            viewMode === "staff"
              ? "border-chalk bg-chalk/15 text-chalk"
              : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
          }`}
        >
          {t("scouting.staffTab")}
        </button>

        <button
          onClick={openListings}
          className={`rounded-md border px-3 py-1.5 text-xs ${
            viewMode === "listings"
              ? "border-chalk bg-chalk/15 text-chalk"
              : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
          }`}
        >
          {t("scouting.listingsTab")}
        </button>

        <Input
          placeholder={t("scouting.searchPlayerPlaceholder")}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="ml-auto w-56"
        />
      </div>

      {isNationalTier && viewMode === "browse-teams" && (
        <div className="mb-5 flex flex-wrap items-center gap-3">
          <div className="flex gap-1.5">
            <button
              onClick={() => {
                setAcademyOnly(false);
                setAgeGroupFilter("");
              }}
              className={`rounded-md border px-3 py-1.5 text-xs ${
                !academyOnly
                  ? "border-chalk bg-chalk/15 text-chalk"
                  : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
              }`}
            >
              {t("teamType.senior")}
            </button>
            <button
              onClick={() => setAcademyOnly(true)}
              className={`rounded-md border px-3 py-1.5 text-xs ${
                academyOnly
                  ? "border-chalk bg-chalk/15 text-chalk"
                  : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
              }`}
            >
              {t("scouting.academiesLabel")}
            </button>
          </div>
          {academyOnly && (
            <Select value={ageGroupFilter} onChange={(e) => setAgeGroupFilter(e.target.value)} className="w-44">
              <option value="">{t("scouting.allAgeGroups")}</option>
              {ACADEMY_AGE_GROUPS.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </Select>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        {/* Filters sidebar */}
        <div className="space-y-6 lg:col-span-1">
          {viewMode === "browse-teams" && (
            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("scouting.searchTeam")}
              </h3>
              <Input
                placeholder={t("scouting.teamNamePlaceholder")}
                value={teamSearchQuery}
                onChange={(e) => setTeamSearchQuery(e.target.value)}
              />
              {teamSearchQuery.trim() && (
                <p className="mt-2 text-[11px] text-text-muted">{t("scouting.searchScopeHint")}</p>
              )}
            </Card>
          )}

          {(viewMode === "browse-teams" ||
            viewMode === "team-roster" ||
            viewMode === "search-results" ||
            viewMode === "shortlist") && (
            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("scouting.filters")}
              </h3>
              <div className="space-y-3">
                <Select label={t("scouting.position")} value={positionFilter} onChange={(e) => setPositionFilter(e.target.value)}>
                  <option value="">{t("scouting.all")}</option>
                  {POSITIONS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </Select>
                <Select
                  label={t("scouting.transferStatus")}
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="">{t("scouting.all")}</option>
                  {Object.entries(TRANSFER_STATUS_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </Select>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    label={t("scouting.minAge")}
                    type="number"
                    value={minAge}
                    onChange={(e) => setMinAge(e.target.value)}
                  />
                  <Input
                    label={t("scouting.maxAge")}
                    type="number"
                    value={maxAge}
                    onChange={(e) => setMaxAge(e.target.value)}
                  />
                </div>
              </div>
            </Card>
          )}

          {viewMode === "staff" && (
            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("scouting.filters")}
              </h3>
              <div className="space-y-3">
                <Select
                  label={t("scouting.staffRoleFilterLabel")}
                  value={staffRoleFilter}
                  onChange={(e) => setStaffRoleFilter(e.target.value)}
                >
                  <option value="">{t("scouting.all")}</option>
                  {Object.entries(LISTING_ROLE_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </Select>
                <Select
                  label={t("scouting.staffAvailabilityFilterLabel")}
                  value={staffAvailabilityFilter}
                  onChange={(e) => setStaffAvailabilityFilter(e.target.value)}
                >
                  <option value="">{t("scouting.all")}</option>
                  <option value="open_to_offers">{STAFF_AVAILABILITY_LABELS.open_to_offers}</option>
                  <option value="available">{STAFF_AVAILABILITY_LABELS.available}</option>
                </Select>
              </div>
            </Card>
          )}

          {viewMode === "listings" && (
            <Card className="p-4">
              <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
                {t("scouting.filters")}
              </h3>
              <div className="space-y-3">
                <Select
                  label={t("scouting.listingTypeFilterLabel")}
                  value={listingTypeFilter}
                  onChange={(e) => setListingTypeFilter(e.target.value)}
                >
                  <option value="">{t("scouting.all")}</option>
                  <option value="player">{t("scouting.lookingForPlayer")}</option>
                  <option value="staff">{t("scouting.lookingForStaff")}</option>
                </Select>
              </div>
            </Card>
          )}
        </div>

        {/* Main content */}
        <div className="lg:col-span-3">
          {viewMode === "browse-teams" && (
            <>
              {(tier === "regional" || tier === "academy") && (
                <Card corners className="mb-6 p-4">
                  <h3 className="mb-3 text-center font-display text-sm uppercase tracking-wide text-text-muted">
                    {t("scouting.selectRegionHeading")}
                  </h3>
                  <GreeceMap
                    regions={regions}
                    selectedRegionId={selectedRegion?.id}
                    onSelect={setSelectedRegion}
                  />
                </Card>
              )}

              {(tier === "regional" || tier === "academy") && selectedRegion && (
                <div className="mb-4 flex flex-wrap gap-2">
                  {federations.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setSelectedFederationId(f.id === selectedFederationId ? "" : f.id)}
                      className={`rounded-full border px-3 py-1 text-xs ${
                        selectedFederationId === f.id
                          ? "border-chalk bg-chalk/15 text-chalk"
                          : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                      }`}
                    >
                      {f.name}
                    </button>
                  ))}
                </div>
              )}

              {(tier === "regional" || tier === "academy") && selectedFederationId && (
                <div className="mb-4">
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="text-xs uppercase tracking-wide text-text-muted">
                      {tier === "academy" ? t("scouting.ageCategory") : t("scouting.level")}
                    </span>
                    {isAdmin && (
                      <button
                        onClick={() => setShowLevelManager((s) => !s)}
                        className="text-[11px] text-chalk hover:underline"
                      >
                        {t("scouting.management")}
                      </button>
                    )}
                  </div>
                  {levels.length === 0 && !showLevelManager ? (
                    <p className="text-xs text-text-muted">{t("scouting.noLevelsForFederation")}</p>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {levels.map((lvl) => (
                        <button
                          key={lvl.id}
                          onClick={() => setSelectedLevelId(lvl.id === selectedLevelId ? "" : lvl.id)}
                          onContextMenu={(e) => {
                            if (!isAdmin) return;
                            menu.open(e, [
                              {
                                items: [
                                  {
                                    label: t("scouting.deleteLevel"),
                                    onClick: () => handleAdminDeleteLevel(lvl.id),
                                    danger: true,
                                  },
                                ],
                              },
                            ]);
                          }}
                          className={`rounded-full border px-3 py-1 text-xs ${
                            selectedLevelId === lvl.id
                              ? "border-chalk bg-chalk/15 text-chalk"
                              : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                          }`}
                        >
                          {lvl.name}
                          {lvl.group_count > 1 ? ` (${lvl.group_count}${t("scouting.groupsSuffix")})` : ""}
                        </button>
                      ))}
                    </div>
                  )}

                  {showLevelManager && (
                    <div className="mt-2 flex flex-wrap items-end gap-2 rounded-md border border-dashed border-line p-2.5">
                      <Input
                        label={t("scouting.newLevel")}
                        placeholder={tier === "academy" ? t("scouting.newLevelPlaceholderAcademy") : t("scouting.newLevelPlaceholderRegional")}
                        value={newLevelName}
                        onChange={(e) => setNewLevelName(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="secondary"
                        isLoading={isSavingLevel}
                        onClick={async () => {
                          if (!newLevelName.trim()) return;
                          setIsSavingLevel(true);
                          try {
                            await createLeagueLevel({
                              federation_id: selectedFederationId,
                              name: newLevelName.trim(),
                              order_index: levels.length,
                              applies_to: tier,
                            });
                            setNewLevelName("");
                            const updated = await listLeagueLevels(selectedFederationId, tier);
                            setLevels(updated);
                          } catch (err) {
                            toast.show(extractErrorMessage(err), "error");
                          } finally {
                            setIsSavingLevel(false);
                          }
                        }}
                      >
                        {t("scouting.addButton")}
                      </Button>
                      {selectedLevelId && (
                        <button
                          onClick={async () => {
                            try {
                              await deleteLeagueLevel(selectedLevelId);
                              const updated = await listLeagueLevels(selectedFederationId, tier);
                              setLevels(updated);
                              setSelectedLevelId("");
                            } catch (err) {
                              toast.show(extractErrorMessage(err), "error");
                            }
                          }}
                          className="text-xs text-status-injured hover:underline"
                        >
                          {t("scouting.deleteSelectedLevel")}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {(tier === "regional" || tier === "academy") && selectedLevelId && (
                <div className="mb-4">
                  <span className="mb-1.5 block text-xs uppercase tracking-wide text-text-muted">{t("scouting.group")}</span>
                  <div className="flex flex-wrap gap-2">
                    {groups.map((g) => (
                      <button
                        key={g.id}
                        onClick={() => setSelectedGroupId(g.id === selectedGroupId ? "" : g.id)}
                        onContextMenu={(e) => {
                          if (!isAdmin) return;
                          menu.open(e, [
                            {
                              items: [
                                {
                                  label: t("scouting.deleteGroup"),
                                  onClick: () => handleAdminDeleteGroup(g.id),
                                  danger: true,
                                },
                              ],
                            },
                          ]);
                        }}
                        className={`rounded-full border px-3 py-1 text-xs ${
                          selectedGroupId === g.id
                            ? "border-chalk bg-chalk/15 text-chalk"
                            : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                        }`}
                      >
                        {g.name}
                      </button>
                    ))}
                  </div>
                  {showLevelManager && (
                    <div className="mt-2 flex flex-wrap items-end gap-2 rounded-md border border-dashed border-line p-2.5">
                      <Input
                        label={t("scouting.newGroup")}
                        placeholder={t("scouting.newGroupPlaceholder")}
                        value={newGroupName}
                        onChange={(e) => setNewGroupName(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="secondary"
                        isLoading={isSavingGroup}
                        onClick={async () => {
                          if (!newGroupName.trim()) return;
                          setIsSavingGroup(true);
                          try {
                            await createLeagueGroup({
                              league_level_id: selectedLevelId,
                              name: newGroupName.trim(),
                            });
                            setNewGroupName("");
                            const updated = await listLeagueGroups(selectedLevelId);
                            setGroups(updated);
                          } catch (err) {
                            toast.show(extractErrorMessage(err), "error");
                          } finally {
                            setIsSavingGroup(false);
                          }
                        }}
                      >
                        {t("scouting.addButton")}
                      </Button>
                      {selectedGroupId && (
                        <button
                          onClick={async () => {
                            try {
                              await deleteLeagueGroup(selectedGroupId);
                              const updated = await listLeagueGroups(selectedLevelId);
                              setGroups(updated);
                              setSelectedGroupId("");
                            } catch (err) {
                              toast.show(extractErrorMessage(err), "error");
                            }
                          }}
                          className="text-xs text-status-injured hover:underline"
                        >
                          {t("scouting.deleteSelectedGroup")}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {(tier === "regional" || tier === "academy") && !teamSearchQuery.trim() && !selectedRegion ? (
                <EmptyState
                  title={t("scouting.selectRegionOnMap")}
                  description={t("scouting.regionWillShowFederations")}
                />
              ) : (tier === "regional" || tier === "academy") &&
                !teamSearchQuery.trim() &&
                selectedRegion &&
                !selectedFederationId ? (
                <EmptyState
                  title={t("scouting.selectFederation")}
                  description={t("scouting.federationWillShowLevels")}
                />
              ) : (tier === "regional" || tier === "academy") &&
                !teamSearchQuery.trim() &&
                selectedFederationId &&
                !selectedLevelId ? (
                <EmptyState
                  title={tier === "academy" ? t("scouting.selectAgeCategory") : t("scouting.selectLevel")}
                  description={t("scouting.levelWillShowTeams")}
                />
              ) : isLoadingTeams ? (
                <Spinner />
              ) : teams.length === 0 ? (
                <EmptyState
                  title={t("scouting.noTeamsFound")}
                  description={t("scouting.noTeamsFoundDescription")}
                />
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {teams.map((team) => (
                    <button
                      key={team.id}
                      onClick={() => openTeam(team)}
                      onContextMenu={(e) => {
                        if (!isAdmin) return;
                        menu.open(e, [
                          {
                            items: [
                              { label: t("scouting.deleteTeam"), onClick: () => handleAdminDeleteTeam(team.id), danger: true },
                            ],
                          },
                        ]);
                      }}
                      className="corner-card flex items-center gap-3 rounded-lg border border-line bg-surface p-3 text-left hover:border-chalk"
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xs">
                        {team.logo_path ? (
                          <img src={mediaUrl(team.logo_path)} alt="" className="h-full w-full object-cover" />
                        ) : (
                          team.name.slice(0, 2).toUpperCase()
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm text-text-primary">{team.name}</p>
                        <p className="truncate text-xs text-text-muted">
                          {[team.federation_name, team.league_level_name, team.league_group_name, `${team.player_count} ${t("teams.playersUnit")}`]
                            .filter(Boolean)
                            .join(" · ")}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}

          {(viewMode === "team-roster" || viewMode === "search-results" || viewMode === "shortlist") && (
            <>
              <div className="mb-3 flex items-center justify-between">
                <button onClick={backToBrowse} className="text-sm text-text-muted hover:text-chalk">
                  {t("scouting.back")}
                </button>
                {viewMode === "team-roster" && selectedTeam && (
                  <h3 className="font-display text-sm text-text-primary">{selectedTeam.name}</h3>
                )}
                {viewMode === "search-results" && (
                  <h3 className="font-display text-sm text-text-primary">{t("scouting.searchResults")}</h3>
                )}
                {viewMode === "shortlist" && (
                  <h3 className="font-display text-sm text-text-primary">{t("scouting.myShortlist")}</h3>
                )}
                {viewMode === "team-roster" && selectedTeam ? (
                  <button
                    onClick={handleApplyToTeam}
                    disabled={isApplying}
                    className="rounded-md border border-chalk px-3 py-1.5 text-xs text-chalk hover:bg-chalk/10 disabled:opacity-50"
                  >
                    {isApplying
                      ? "..."
                      : user?.role === "player"
                      ? t("scouting.applyToJoin")
                      : t("scouting.makeApplication")}
                  </button>
                ) : (
                  <span />
                )}
              </div>

              {isLoadingPlayers ? (
                <Spinner />
              ) : filteredPlayers.length === 0 ? (
                <EmptyState title={t("scouting.noPlayersFound")} />
              ) : viewMode === "team-roster" ? (
                <div className="space-y-5">
                  {groupScoutingPlayersByPosition(filteredPlayers, POSITION_CATEGORIES, t("teamDetail.noPosition")).map(
                    (group) => (
                      <div key={group.label}>
                        <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                          {group.label} ({group.players.length})
                        </h4>
                        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                          {group.players.map((p) => (
                            <ScoutingPlayerCard
                              key={p.id}
                              player={p}
                              onClick={() => setSelectedPlayer(p)}
                              onToggleShortlist={() => handleToggleShortlist(p)}
                            />
                          ))}
                        </div>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {filteredPlayers.map((p) => (
                    <ScoutingPlayerCard
                      key={p.id}
                      player={p}
                      onClick={() => setSelectedPlayer(p)}
                      onToggleShortlist={() => handleToggleShortlist(p)}
                    />
                  ))}
                </div>
              )}
            </>
          )}

          {viewMode === "staff" && (
            <>
              <div className="mb-3 flex items-center justify-between">
                <button onClick={backToBrowse} className="text-sm text-text-muted hover:text-chalk">
                  {t("scouting.back")}
                </button>
                <h3 className="font-display text-sm text-text-primary">{t("scouting.technicalStaff")}</h3>
                <span />
              </div>

              {isLoadingStaff ? (
                <Spinner />
              ) : filteredStaffList.length === 0 ? (
                <EmptyState
                  title={t("scouting.noStaffFound")}
                  description={t("scouting.noStaffFoundDescription")}
                />
              ) : (
                <div className="space-y-5">
                  {groupStaffByRegion(filteredStaffList, t("scouting.noRegionDeclared")).map((group) => (
                    <div key={group.label}>
                      <h4 className="mb-2 font-display text-xs uppercase tracking-wide text-text-muted">
                        {group.label} ({group.staff.length})
                      </h4>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        {group.staff.map((s) => (
                          <StaffCard key={s.id} staff={s} onClick={() => setSelectedStaff(s)} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {viewMode === "listings" && (
            <>
              <div className="mb-3 flex items-center justify-between">
                <button onClick={backToBrowse} className="text-sm text-text-muted hover:text-chalk">
                  {t("scouting.back")}
                </button>
                <h3 className="font-display text-sm text-text-primary">{t("scouting.listingsTab").replace("📋 ", "")}</h3>
                <span />
              </div>

              {isLoadingListings ? (
                <Spinner />
              ) : filteredListings.length === 0 ? (
                <EmptyState
                  title={t("scouting.noOpenListings")}
                  description={t("scouting.tryAgainLater")}
                />
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {filteredListings.map((l) => (
                    <Card
                      key={l.id}
                      corners
                      className="cursor-pointer p-4 transition-colors hover:border-chalk"
                      onClick={() => setSelectedListing(l)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") setSelectedListing(l);
                      }}
                    >
                      <p className="text-xs uppercase tracking-wide text-chalk">
                        {l.listing_type === "staff" ? t("scouting.lookingForStaff") : t("scouting.lookingForPlayer")}
                      </p>
                      <p className="mt-1 text-sm text-text-primary">
                        {l.listing_type === "staff"
                          ? l.role_needed.map((r) => LISTING_ROLE_LABELS[r] || r).join(", ") || t("scouting.staffFallback")
                          : `${t("scouting.positionPrefix")}${l.position_needed.join(", ") || t("scouting.anyOption")}`}
                      </p>
                      <p className="mt-1 text-xs text-text-muted">
                        {l.team_name}
                        {l.listing_type === "staff" && l.season ? ` · ${l.season}` : ""}
                        {l.listing_type === "staff" && l.employment_type
                          ? ` · ${l.employment_type === "paid" ? t("scouting.employed") : t("scouting.practice")}`
                          : ""}
                        {l.listing_type === "player" && (l.min_age || l.max_age)
                          ? `${t("scouting.agePrefix")}${l.min_age || "0"}-${l.max_age || "+"}`
                          : ""}
                      </p>
                      {l.description && (
                        <p className="mt-2 text-xs text-text-muted line-clamp-2">{l.description}</p>
                      )}
                      <div className="mt-3 flex justify-end">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApplyToListing(l.id);
                          }}
                          disabled={applyingListingId === l.id || appliedListingIds.includes(l.id)}
                          className="rounded-md border border-chalk px-3 py-1.5 text-xs text-chalk hover:bg-chalk/10 disabled:opacity-50"
                        >
                          {appliedListingIds.includes(l.id)
                            ? t("scouting.applicationSentBadge")
                            : applyingListingId === l.id
                            ? "..."
                            : t("scouting.applyButton")}
                        </button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <PlayerScoutingModal
        player={selectedPlayer}
        isOpen={!!selectedPlayer}
        onClose={() => setSelectedPlayer(null)}
        onToggleShortlist={() => selectedPlayer && handleToggleShortlist(selectedPlayer)}
        canClaim={user?.role === "player" && !user.linked_player_id}
        isClaiming={isClaiming}
        onClaim={handleClaimPlayer}
        canOffer={canOffer}
        myTeams={myTeams}
        onSendOffer={handleSendOffer}
      />

      <StaffScoutingModal
        staff={selectedStaff}
        isOpen={!!selectedStaff}
        onClose={() => setSelectedStaff(null)}
        myTeams={myTeams}
      />

      <ListingDetailModal
        listing={selectedListing}
        onClose={() => setSelectedListing(null)}
        onApply={selectedListing ? () => handleApplyToListing(selectedListing.id) : undefined}
        isApplying={!!selectedListing && applyingListingId === selectedListing.id}
        hasApplied={!!selectedListing && appliedListingIds.includes(selectedListing.id)}
      />

      {menu.render()}
    </AppLayout>
  );
}
