import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { extractErrorMessage } from "../api/client";
import { getMonthlyPerformance } from "../api/performance";
import { listTeams } from "../api/teams";
import { AppLayout } from "../components/layout/AppLayout";
import { Card } from "../components/ui/Card";
import { EmptyState, Spinner } from "../components/ui/EmptyState";
import { Select } from "../components/ui/Input";
import { useToast } from "../components/ui/Toast";
import { useLanguage } from "../context/LanguageContext";
import type { PlayerMonthlyPerformance, Team } from "../types";

function currentYearMonth(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export default function Performance() {
  const toast = useToast();
  const { t } = useLanguage();
  const [yearMonth, setYearMonth] = useState(currentYearMonth());
  const [teams, setTeams] = useState<Team[]>([]);
  const [teamId, setTeamId] = useState("");
  const [rows, setRows] = useState<PlayerMonthlyPerformance[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [year, month] = useMemo(() => yearMonth.split("-").map(Number), [yearMonth]);

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  async function load() {
    setIsLoading(true);
    try {
      const data = await getMonthlyPerformance(year, month, teamId || undefined);
      setRows(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [yearMonth, teamId]);

  const monthLabel = new Date(year, month - 1, 1).toLocaleDateString("el-GR", {
    month: "long",
    year: "numeric",
  });

  return (
    <AppLayout title={t("performance.title")}>
      <p className="mb-4 text-sm text-text-muted">
        {t("performance.introPrefix")}{" "}
        <Link to="/matches" className="text-chalk hover:underline">
          Match Rating
        </Link>
        .
      </p>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <input
          type="month"
          value={yearMonth}
          onChange={(e) => setYearMonth(e.target.value)}
          className="rounded-md border border-line bg-surface px-3 py-2 text-sm text-text-primary focus:border-chalk focus:outline-none"
        />
        <Select value={teamId} onChange={(e) => setTeamId(e.target.value)} className="w-56">
          <option value="">{t("players.allTeams")}</option>
          {teams.map((teamOpt) => (
            <option key={teamOpt.id} value={teamOpt.id}>
              {teamOpt.name}
            </option>
          ))}
        </Select>
        <span className="text-sm capitalize text-text-muted">{monthLabel}</span>
      </div>

      {isLoading ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <EmptyState
          title={t("performance.noPerformanceThisMonth")}
          description={t("performance.noPerformanceDescription")}
        />
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase text-text-muted">
                <th className="px-4 py-3">{t("dashboard.player")}</th>
                <th className="px-4 py-3">{t("dashboard.team")}</th>
                <th className="px-4 py-3 text-center">{t("performance.matches")}</th>
                <th className="px-4 py-3 text-center">{t("performance.avgRating")}</th>
                <th className="px-4 py-3 text-center">{t("performance.goals")}</th>
                <th className="px-4 py-3 text-center">{t("performance.assists")}</th>
                <th className="px-4 py-3 text-center">🟨</th>
                <th className="px-4 py-3 text-center">🟥</th>
                <th className="px-4 py-3 text-center">★ MVP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((r) => (
                <tr key={r.player_id} className="hover:bg-surface-raised">
                  <td className="px-4 py-3">
                    <Link to={`/players/${r.player_id}`} className="text-text-primary hover:text-chalk">
                      {r.player_name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-text-muted">{r.team_name || "—"}</td>
                  <td className="px-4 py-3 text-center font-mono">{r.matches_played}</td>
                  <td className="px-4 py-3 text-center font-mono text-chalk">
                    {r.avg_rating != null ? r.avg_rating.toFixed(1) : "—"}
                  </td>
                  <td className="px-4 py-3 text-center font-mono">{r.goals}</td>
                  <td className="px-4 py-3 text-center font-mono">{r.assists}</td>
                  <td className="px-4 py-3 text-center font-mono">{r.yellow_cards}</td>
                  <td className="px-4 py-3 text-center font-mono">{r.red_cards}</td>
                  <td className="px-4 py-3 text-center font-mono">{r.mvp_count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </AppLayout>
  );
}
