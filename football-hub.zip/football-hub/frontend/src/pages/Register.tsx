import { FormEvent, useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";

import { register } from "../api/auth";
import { extractErrorMessage } from "../api/client";
import { getPublicCaptchaConfig } from "../api/security";
import { HCaptchaWidget } from "../components/HCaptchaWidget";
import { Button } from "../components/ui/Button";
import { Input, Select } from "../components/ui/Input";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";

// Ρόλοι που χρειάζονται ΑΦΜ ομάδας στην εγγραφή — ίδιο σύνολο με το
// backend CLUB_LEADERSHIP_ROLES (βλ. routers/auth.py).
const CLUB_LEADERSHIP_SPECIALTIES = ["president", "technical_director"];

// Ίδιος αλγόριθμος checksum με το backend (services/greek_validators.py) —
// άμεσο feedback στον χρήστη χωρίς round-trip στον server.
function isValidAfm(afm: string): boolean {
  if (!/^\d{9}$/.test(afm)) return false;
  const digits = afm.split("").map(Number);
  const weightedSum = digits.slice(0, 8).reduce((sum, d, i) => sum + d * Math.pow(2, 8 - i), 0);
  const checkDigit = (weightedSum % 11) % 10;
  return checkDigit === digits[8];
}

export default function Register() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useLanguage();

  const SPECIALTY_OPTIONS: { value: string; label: string }[] = [
    { value: "president", label: t("crm.rolePresident") },
    { value: "technical_director", label: t("crm.roleTechnicalDirector") },
    { value: "head_coach", label: t("crm.roleHeadCoach") },
    { value: "assistant_coach", label: t("crm.roleAssistantCoach") },
    { value: "fitness_coach", label: t("crm.roleFitnessCoach") },
    { value: "scout", label: "Scout" },
    { value: "analyst", label: t("crm.roleAnalyst") },
    { value: "player", label: t("settings.rolePlayerLabel") },
  ];

  const [fullName, setFullName] = useState("");
  const [specialty, setSpecialty] = useState("head_coach");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [taxId, setTaxId] = useState("");
  const [gdprConsent, setGdprConsent] = useState(false);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [honeypot, setHoneypot] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaSiteKey, setCaptchaSiteKey] = useState<string | null>(null);

  useEffect(() => {
    getPublicCaptchaConfig()
      .then((cfg) => setCaptchaSiteKey(cfg.enabled ? cfg.site_key || null : null))
      .catch(() => {
        /* σιωπηλή αποτυχία — η φόρμα δουλεύει κανονικά χωρίς CAPTCHA */
      });
  }, []);

  if (user) return <Navigate to="/" replace />;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirmPassword) {
      setError(t("auth.passwordsDontMatch"));
      return;
    }
    if (password.length < 8) {
      setError(t("register.passwordTooShort"));
      return;
    }
    if (!gdprConsent) {
      setError(t("register.mustAcceptGdpr"));
      return;
    }
    if (CLUB_LEADERSHIP_SPECIALTIES.includes(specialty) && !isValidAfm(taxId)) {
      setError(t("register.taxIdInvalid"));
      return;
    }
    if (captchaSiteKey && !captchaToken) {
      setError(t("register.captchaRequired"));
      return;
    }
    setIsLoading(true);
    try {
      const res = await register(
        email,
        username,
        password,
        fullName || undefined,
        specialty,
        specialty === "player" ? dateOfBirth || undefined : undefined,
        CLUB_LEADERSHIP_SPECIALTIES.includes(specialty) ? taxId || undefined : undefined,
        gdprConsent,
        honeypot || undefined,
        captchaToken || undefined
      );
      localStorage.setItem("fh_token", res.access_token);
      localStorage.setItem("fh_user", JSON.stringify(res.user));
      updateUser(res.user);
      toast.show(t("register.accountCreated"), "success");
      navigate("/");
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-void px-4 py-8">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-chalk">
            <span className="font-display text-xl text-chalk">FH</span>
          </div>
          <h1 className="font-display text-2xl tracking-wide text-text-primary">{t("register.title")}</h1>
          <p className="text-sm text-text-muted">Football Hub &amp; Analysis Platform</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="corner-card space-y-4 rounded-lg border border-line bg-surface p-6"
        >
          <Input
            label={t("settings.fullName")}
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            autoFocus
          />
          <Select
            label={t("register.specialty")}
            value={specialty}
            onChange={(e) => setSpecialty(e.target.value)}
          >
            {SPECIALTY_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </Select>
          {CLUB_LEADERSHIP_SPECIALTIES.includes(specialty) && (
            <>
              <Input
                label={t("register.teamTaxId")}
                value={taxId}
                onChange={(e) => setTaxId(e.target.value)}
                required
                maxLength={9}
              />
              <p className="text-xs text-text-muted">
                {t("register.taxIdPrivateNote")} {t("register.taxIdRequiredHint")}
              </p>
            </>
          )}
          {specialty === "player" && (
            <>
              <Input
                label={t("register.dateOfBirth")}
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
              />
              <p className="text-xs text-text-muted">
                {t("register.dobHint")}
              </p>
            </>
          )}
          <Input
            label="Email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            label="Username"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <Input
            label={t("auth.password")}
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            hint={t("settings.atLeast8Chars")}
          />
          <Input
            label={t("auth.confirmNewPassword")}
            type="password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
          {error && <p className="text-sm text-status-injured">{error}</p>}
          <label className="flex items-start gap-2 text-xs text-text-muted">
            <input
              type="checkbox"
              checked={gdprConsent}
              onChange={(e) => setGdprConsent(e.target.checked)}
              className="mt-0.5 h-3.5 w-3.5 accent-chalk"
              required
            />
            <span>
              {t("register.gdprConsentText")}
            </span>
          </label>
          {/* Honeypot — αόρατο σε πραγματικούς χρήστες, παγιδεύει bots που γεμίζουν όλα τα πεδία */}
          <input
            type="text"
            name="website"
            value={honeypot}
            onChange={(e) => setHoneypot(e.target.value)}
            tabIndex={-1}
            autoComplete="off"
            aria-hidden="true"
            className="pointer-events-none absolute left-[-9999px] h-0 w-0 opacity-0"
          />
          {captchaSiteKey && (
            <div className="flex justify-center">
              <HCaptchaWidget siteKey={captchaSiteKey} onVerify={setCaptchaToken} />
            </div>
          )}
          <Button type="submit" isLoading={isLoading} className="w-full">
            {t("register.createAccountButton")}
          </Button>
        </form>

        <p className="mt-4 text-center text-sm text-text-muted">
          {t("register.alreadyHaveAccount")}{" "}
          <Link to="/login" className="text-chalk hover:underline">
            {t("auth.login")}
          </Link>
        </p>
      </div>
    </div>
  );
}
