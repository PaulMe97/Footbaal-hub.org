import { FormEvent, useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";

import { changePassword, fetchMe, updateMe } from "../api/auth";
import { extractErrorMessage, mediaUrl } from "../api/client";
import {
  addAchievement,
  addExperience,
  addQualification,
  deleteAchievement,
  deleteExperience,
  deleteQualification,
  leaveTeam,
  listMyAchievements,
  listMyExperience,
  listMyQualifications,
  listMyTeamMemberships,
  updateStaffAvailability,
  updateStaffScoutingPrefs,
  updateStaffVisibility,
  uploadAvatar,
} from "../api/profile";
import type { MyTeamMembership } from "../api/profile";
import { listFederations } from "../api/scouting";
import {
  listMyPlayerRequests,
  listMyTeamRequests,
} from "../api/requests";
import { listMyContractOffers, respondToContractOffer } from "../api/contracts";
import { listMyStaffOffers, respondToStaffAssignmentOffer } from "../api/staffOffers";
import type { StaffAssignmentOfferItem } from "../api/staffOffers";
import type { ContractOfferItem } from "../api/contracts";
import type { PlayerJoinRequestItem, TeamJoinRequestItem } from "../api/requests";
import { AppLayout } from "../components/layout/AppLayout";
import { ProfileTrustSection } from "../components/ProfileTrustSection";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Spinner } from "../components/ui/EmptyState";
import { DateField } from "../components/ui/DateField";
import { Input, Select, Textarea } from "../components/ui/Input";
import { ConfirmDialog } from "../components/ui/Modal";
import { useToast } from "../components/ui/Toast";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { STAFF_AVAILABILITY_LABELS } from "../types";
import type { Achievement, Federation, Qualification, WorkExperience } from "../types";

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const { t } = useLanguage();
  const location = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const STAFF_OFFER_ROLE_LABELS: Record<string, string> = {
    technical_director: t("crm.roleTechnicalDirector"),
    head_coach: t("crm.roleHeadCoach"),
    assistant_coach: t("crm.roleAssistantCoach"),
    fitness_coach: t("crm.roleFitnessCoach"),
    analyst: t("crm.roleAnalyst"),
    scout: "Scout",
  };

  const [isLoading, setIsLoading] = useState(true);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [bio, setBio] = useState(user?.bio || "");
  const [isSavingBio, setIsSavingBio] = useState(false);
  const [phone, setPhone] = useState(user?.phone || "");
  const [dateOfBirth, setDateOfBirth] = useState(user?.date_of_birth || "");
  const [isSavingContactInfo, setIsSavingContactInfo] = useState(false);
  const [isTogglingVisibility, setIsTogglingVisibility] = useState(false);
  const [isSavingAvailability, setIsSavingAvailability] = useState(false);

  const [federations, setFederations] = useState<Federation[]>([]);
  const [desiredStaffRole, setDesiredStaffRole] = useState(user?.desired_staff_role || "");
  const [originFederationId, setOriginFederationId] = useState(user?.origin_federation_id || "");
  const [desiredFederationIds, setDesiredFederationIds] = useState<string[]>(
    user?.desired_federation_ids || []
  );
  const [isSavingScoutingPrefs, setIsSavingScoutingPrefs] = useState(false);

  const [qualifications, setQualifications] = useState<Qualification[]>([]);
  const [qualTitle, setQualTitle] = useState("");
  const [qualYear, setQualYear] = useState("");
  const [isAddingQual, setIsAddingQual] = useState(false);

  const [experience, setExperience] = useState<WorkExperience[]>([]);
  const [expOrg, setExpOrg] = useState("");
  const [expRole, setExpRole] = useState("");
  const [expStart, setExpStart] = useState("");
  const [expEnd, setExpEnd] = useState("");
  const [isAddingExp, setIsAddingExp] = useState(false);

  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [achTitle, setAchTitle] = useState("");
  const [achYear, setAchYear] = useState("");
  const [isAddingAch, setIsAddingAch] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSavingPassword, setIsSavingPassword] = useState(false);

  const [myTeamRequests, setMyTeamRequests] = useState<TeamJoinRequestItem[]>([]);
  const [myPlayerRequests, setMyPlayerRequests] = useState<PlayerJoinRequestItem[]>([]);
  const [myOffers, setMyOffers] = useState<ContractOfferItem[]>([]);
  const [respondingOfferId, setRespondingOfferId] = useState<string | null>(null);
  const [myStaffOffers, setMyStaffOffers] = useState<StaffAssignmentOfferItem[]>([]);
  const [respondingStaffOfferId, setRespondingStaffOfferId] = useState<string | null>(null);
  const [myTeamMemberships, setMyTeamMemberships] = useState<MyTeamMembership[]>([]);
  const [leaveTarget, setLeaveTarget] = useState<MyTeamMembership | null>(null);
  const [isLeavingTeam, setIsLeavingTeam] = useState(false);

  async function load() {
    setIsLoading(true);
    try {
      const [q, e, a, tr, pr] = await Promise.all([
        listMyQualifications(),
        listMyExperience(),
        listMyAchievements(),
        listMyTeamRequests(),
        listMyPlayerRequests(),
      ]);
      setQualifications(q);
      setExperience(e);
      setAchievements(a);
      setMyTeamRequests(tr);
      setMyPlayerRequests(pr);
      if (user?.role === "player") {
        const offers = await listMyContractOffers();
        setMyOffers(offers);
      } else {
        const memberships = await listMyTeamMemberships();
        setMyTeamMemberships(memberships);
        const feds = await listFederations();
        setFederations(feds);
      }
      // Οι προσφορές ανάθεσης/αλλαγής ρόλου μπορεί πλέον να αφορούν και
      // παίκτες (π.χ. πρόταση να γίνει Βοηθός Προπονητή) — φορτώνονται για
      // όλους, ανεξαρτήτως τρέχοντος ρόλου.
      const staffOffers = await listMyStaffOffers();
      setMyStaffOffers(staffOffers);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    setBio(user?.bio || "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Αν ήρθαμε εδώ από ειδοποίηση με στόχο ένα συγκεκριμένο section (π.χ.
  // προσφορά ανάθεσης ομάδας), κάνουμε scroll ακριβώς εκεί και το
  // επισημαίνουμε προσωρινά — μόνο αφού έχουν φορτωθεί τα δεδομένα, ώστε
  // το section να υπάρχει ήδη στο DOM. Το location.hash (αντί για
  // window.location.hash) πιάνει σωστά και την περίπτωση όπου ο χρήστης
  // ήταν ήδη στη σελίδα Προφίλ και απλά άλλαξε το hash.
  useEffect(() => {
    if (isLoading) return;
    const hash = location.hash.replace("#", "");
    if (!hash) return;
    const el = document.getElementById(hash);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.add("ring-2", "ring-chalk");
    const timer = setTimeout(() => {
      el.classList.remove("ring-2", "ring-chalk");
    }, 2500);
    return () => clearTimeout(timer);
  }, [isLoading, location.hash]);

  async function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingAvatar(true);
    try {
      const updated = await uploadAvatar(file);
      updateUser(updated);
      toast.show(t("profile.avatarUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUploadingAvatar(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleSaveBio(e: FormEvent) {
    e.preventDefault();
    setIsSavingBio(true);
    try {
      const updated = await updateMe({ bio });
      updateUser(updated);
      toast.show(t("profile.bioSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingBio(false);
    }
  }

  async function handleSaveContactInfo(e: FormEvent) {
    e.preventDefault();
    setIsSavingContactInfo(true);
    try {
      const updated = await updateMe({ phone, date_of_birth: dateOfBirth || undefined });
      updateUser(updated);
      toast.show(t("profile.contactInfoSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingContactInfo(false);
    }
  }

  async function handleToggleVisibility() {
    if (!user) return;
    setIsTogglingVisibility(true);
    try {
      const updated = await updateStaffVisibility(!user.is_staff_visible);
      updateUser(updated);
      toast.show(
        updated.is_staff_visible ? t("profile.visibleInScouting") : t("profile.hiddenFromScouting"),
        "success"
      );
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsTogglingVisibility(false);
    }
  }

  async function handleAvailabilityChange(value: string) {
    if (!user) return;
    setIsSavingAvailability(true);
    try {
      const updated = await updateStaffAvailability(value);
      updateUser(updated);
      toast.show(t("profile.statusUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingAvailability(false);
    }
  }

  function toggleDesiredFederation(id: string) {
    setDesiredFederationIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length >= 10 ? prev : [...prev, id]
    );
  }

  async function handleSaveScoutingPrefs() {
    setIsSavingScoutingPrefs(true);
    try {
      const updated = await updateStaffScoutingPrefs({
        desired_staff_role: desiredStaffRole || null,
        origin_federation_id: originFederationId || null,
        desired_federation_ids: desiredFederationIds,
      });
      updateUser(updated);
      toast.show(t("dashboard.changesSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingScoutingPrefs(false);
    }
  }

  async function handleAddQualification(e: FormEvent) {
    e.preventDefault();
    if (!qualTitle.trim()) return;
    setIsAddingQual(true);
    try {
      const q = await addQualification(qualTitle.trim(), qualYear ? Number(qualYear) : undefined);
      setQualifications((prev) => [...prev, q]);
      setQualTitle("");
      setQualYear("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAddingQual(false);
    }
  }

  async function handleDeleteQualification(id: string) {
    try {
      await deleteQualification(id);
      setQualifications((prev) => prev.filter((q) => q.id !== id));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAddExperience(e: FormEvent) {
    e.preventDefault();
    if (!expOrg.trim()) return;
    setIsAddingExp(true);
    try {
      const exp = await addExperience({
        organization: expOrg.trim(),
        role_title: expRole || undefined,
        start_year: expStart ? Number(expStart) : undefined,
        end_year: expEnd ? Number(expEnd) : undefined,
      });
      setExperience((prev) => [exp, ...prev]);
      setExpOrg("");
      setExpRole("");
      setExpStart("");
      setExpEnd("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAddingExp(false);
    }
  }

  async function handleDeleteExperience(id: string) {
    try {
      await deleteExperience(id);
      setExperience((prev) => prev.filter((e) => e.id !== id));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleAddAchievement(e: FormEvent) {
    e.preventDefault();
    if (!achTitle.trim()) return;
    setIsAddingAch(true);
    try {
      const a = await addAchievement(achTitle.trim(), achYear ? Number(achYear) : undefined);
      setAchievements((prev) => [a, ...prev]);
      setAchTitle("");
      setAchYear("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsAddingAch(false);
    }
  }

  async function handleDeleteAchievement(id: string) {
    try {
      await deleteAchievement(id);
      setAchievements((prev) => prev.filter((a) => a.id !== id));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function handleRespondOffer(offerId: string, accept: boolean) {
    setRespondingOfferId(offerId);
    try {
      const updated = await respondToContractOffer(offerId, accept);
      setMyOffers((prev) => prev.map((o) => (o.id === offerId ? updated : o)));
      toast.show(accept ? t("profile.offerAccepted") : t("profile.offerRejected"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingOfferId(null);
    }
  }

  async function handleRespondStaffOffer(offerId: string, accept: boolean) {
    setRespondingStaffOfferId(offerId);
    try {
      const updated = await respondToStaffAssignmentOffer(offerId, accept);
      setMyStaffOffers((prev) => prev.map((o) => (o.id === offerId ? updated : o)));
      if (accept) {
        // Η αποδοχή μπορεί να άλλαξε τον ρόλο του λογαριασμού (π.χ. Player
        // -> Assistant Coach) — φέρνουμε φρέσκα στοιχεία χρήστη.
        try {
          const freshUser = await fetchMe();
          updateUser(freshUser);
        } catch {
          /* μη κρίσιμο — θα ενημερωθεί στο επόμενο login */
        }
      }
      toast.show(accept ? t("profile.newTeamTaken") : t("profile.staffOfferRejected"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setRespondingStaffOfferId(null);
    }
  }

  async function handleLeaveTeam() {
    if (!leaveTarget) return;
    setIsLeavingTeam(true);
    try {
      await leaveTeam(leaveTarget.team_id);
      setMyTeamMemberships((prev) => prev.filter((m) => m.team_id !== leaveTarget.team_id));
      toast.show(`${t("profile.leftTeamPrefix")}${leaveTarget.team_name}${t("profile.leftTeamSuffix")}`, "success");
      setLeaveTarget(null);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLeavingTeam(false);
    }
  }

  async function handlePasswordSubmit(e: FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.show(t("profile.passwordsDontMatch"), "error");
      return;
    }
    if (newPassword.length < 8) {
      toast.show(t("profile.passwordTooShort"), "error");
      return;
    }
    setIsSavingPassword(true);
    try {
      await changePassword(currentPassword, newPassword);
      toast.show(t("profile.passwordChangedSuccess"), "success");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingPassword(false);
    }
  }

  if (!user) return null;

  return (
    <AppLayout title={t("profile.myProfileTitle")}>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Photo + bio + visibility */}
        <Card corners className="p-5 lg:col-span-2">
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
            <div className="flex flex-col items-center gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="group relative flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 border-line bg-surface-raised font-display text-2xl text-text-muted hover:border-chalk"
              >
                {user.avatar_path ? (
                  <img src={mediaUrl(user.avatar_path)} alt="" className="h-full w-full object-cover" />
                ) : (
                  (user.full_name || user.username).charAt(0).toUpperCase()
                )}
                <span className="absolute inset-0 hidden items-center justify-center bg-void/70 text-xs text-chalk group-hover:flex">
                  {isUploadingAvatar ? "..." : t("profile.change")}
                </span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={handleAvatarChange}
              />
            </div>

            <div className="flex-1 text-center sm:text-left">
              <h2 className="font-display text-xl text-text-primary">
                {user.full_name || user.username}
              </h2>
              <p className="text-sm text-text-muted">@{user.username}</p>
              {user.role !== "player" && (
                <div className="mt-3 flex flex-col items-center gap-2 sm:flex-row">
                  <button
                    onClick={handleToggleVisibility}
                    disabled={isTogglingVisibility}
                    className={`rounded-full border px-3 py-1.5 text-xs disabled:opacity-50 ${
                      user.is_staff_visible
                        ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                        : "border-line text-text-muted hover:border-chalk hover:text-text-primary"
                    }`}
                  >
                    {user.is_staff_visible ? t("profile.visiblePublic") : t("profile.notVisiblePublic")}
                  </button>
                </div>
              )}
              {user.role !== "player" && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {Object.entries(STAFF_AVAILABILITY_LABELS).map(([value, label]) => (
                    <button
                      key={value}
                      onClick={() => handleAvailabilityChange(value)}
                      disabled={isSavingAvailability}
                      className={`rounded-full border px-3 py-1 text-xs disabled:opacity-50 ${
                        user.staff_availability === value
                          ? "border-chalk bg-chalk/15 text-chalk"
                          : "border-line text-text-muted hover:border-chalk"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
              {user.role === "president" && (
                <p className="mt-2 text-xs text-text-muted">
                  {t("profile.teamTaxIdPrefix")}<span className="text-text-primary">{user.team_tax_id || "—"}</span>{" "}
                  <span className="text-text-muted">{t("profile.privateNote")}</span>
                </p>
              )}
            </div>
          </div>

          <form onSubmit={handleSaveBio} className="mt-5 border-t border-line pt-4">
            <Textarea
              label={t("profile.bio")}
              placeholder={t("profile.bioPlaceholder")}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="min-h-[100px]"
            />
            <div className="mt-2 flex justify-end">
              <Button type="submit" isLoading={isSavingBio}>
                {t("profile.saveBio")}
              </Button>
            </div>
          </form>

          <form onSubmit={handleSaveContactInfo} className="mt-5 border-t border-line pt-4">
            <h3 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("profile.contactInfoHeading")}
            </h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Input
                label={t("profile.phoneLabel")}
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="69XXXXXXXX"
              />
              <DateField
                label={t("profile.dateOfBirthLabel")}
                value={dateOfBirth}
                onChange={(iso) => setDateOfBirth(iso)}
              />
            </div>
            <div className="mt-2 flex justify-end">
              <Button type="submit" isLoading={isSavingContactInfo}>
                {t("profile.saveContactInfo")}
              </Button>
            </div>
          </form>
        </Card>

        {user.role !== "player" && (
          <Card className="p-5">
            <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profile.scoutingPrefsHeading")}
            </h3>
            <p className="mb-3 text-xs text-text-muted">{t("profile.scoutingPrefsIntro")}</p>
            <div className="space-y-3">
              <Select
                label={t("profile.desiredRoleLabel")}
                value={desiredStaffRole}
                onChange={(e) => setDesiredStaffRole(e.target.value)}
              >
                <option value="">{t("profile.noRolePreference")}</option>
                <option value="technical_director">{t("crm.roleTechnicalDirector")}</option>
                <option value="head_coach">{t("crm.roleHeadCoach")}</option>
                <option value="assistant_coach">{t("crm.roleAssistantCoach")}</option>
                <option value="fitness_coach">{t("crm.roleFitnessCoach")}</option>
                <option value="analyst">{t("crm.roleAnalyst")}</option>
                <option value="scout">Scout</option>
              </Select>
              <Select
                label={t("profile.originFederationLabel")}
                value={originFederationId}
                onChange={(e) => setOriginFederationId(e.target.value)}
              >
                <option value="">{t("scouting.selectFederation")}</option>
                {federations.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </Select>
              <div>
                <p className="mb-1.5 text-xs font-medium text-text-muted">
                  {t("profile.desiredRegionsLabel")}
                </p>
                <p className="mb-1.5 text-[11px] text-text-muted">{t("profile.desiredRegionsHint")}</p>
                <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-line p-2">
                  {federations.map((f) => (
                    <label key={f.id} className="flex items-center gap-2 text-sm text-text-primary">
                      <input
                        type="checkbox"
                        checked={desiredFederationIds.includes(f.id)}
                        disabled={!desiredFederationIds.includes(f.id) && desiredFederationIds.length >= 10}
                        onChange={() => toggleDesiredFederation(f.id)}
                        className="h-3.5 w-3.5 accent-chalk"
                      />
                      {f.name}
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button onClick={handleSaveScoutingPrefs} isLoading={isSavingScoutingPrefs}>
                {t("profile.savePreferences")}
              </Button>
            </div>
          </Card>
        )}

        <ProfileTrustSection />

        {/* Qualifications */}
        <Card className="p-5">
          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.qualificationsHeading")}
          </h3>
          {isLoading ? (
            <Spinner />
          ) : (
            <>
              {qualifications.length === 0 ? (
                <p className="mb-3 text-sm text-text-muted">{t("profile.noQualificationsYet")}</p>
              ) : (
                <div className="mb-3 space-y-1.5">
                  {qualifications.map((q) => (
                    <div
                      key={q.id}
                      className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-1.5 text-sm"
                    >
                      <span className="text-text-primary">
                        {q.title}
                        {q.year ? ` (${q.year})` : ""}
                      </span>
                      <button
                        onClick={() => handleDeleteQualification(q.id)}
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <form onSubmit={handleAddQualification} className="flex gap-2">
                <Input
                  placeholder={t("profile.qualificationPlaceholder")}
                  value={qualTitle}
                  onChange={(e) => setQualTitle(e.target.value)}
                  className="flex-1"
                />
                <Input
                  placeholder={t("profile.yearPlaceholder")}
                  type="number"
                  value={qualYear}
                  onChange={(e) => setQualYear(e.target.value)}
                  className="w-24"
                />
                <Button type="submit" isLoading={isAddingQual}>
                  +
                </Button>
              </form>
            </>
          )}
        </Card>

        {/* Achievements */}
        <Card className="p-5">
          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.achievementsHeading")}
          </h3>
          {isLoading ? (
            <Spinner />
          ) : (
            <>
              {achievements.length === 0 ? (
                <p className="mb-3 text-sm text-text-muted">{t("profile.noAchievementsYet")}</p>
              ) : (
                <div className="mb-3 space-y-1.5">
                  {achievements.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-1.5 text-sm"
                    >
                      <span className="text-text-primary">
                        🏆 {a.title}
                        {a.year ? ` (${a.year})` : ""}
                      </span>
                      <button
                        onClick={() => handleDeleteAchievement(a.id)}
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <form onSubmit={handleAddAchievement} className="flex gap-2">
                <Input
                  placeholder={t("profile.achievementPlaceholder")}
                  value={achTitle}
                  onChange={(e) => setAchTitle(e.target.value)}
                  className="flex-1"
                />
                <Input
                  placeholder={t("profile.yearPlaceholder")}
                  type="number"
                  value={achYear}
                  onChange={(e) => setAchYear(e.target.value)}
                  className="w-24"
                />
                <Button type="submit" isLoading={isAddingAch}>
                  +
                </Button>
              </form>
            </>
          )}
        </Card>

        {/* Work experience */}
        <Card className="p-5 lg:col-span-2">
          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.experienceHeading")}
          </h3>
          {isLoading ? (
            <Spinner />
          ) : (
            <>
              {experience.length === 0 ? (
                <p className="mb-3 text-sm text-text-muted">{t("profile.noExperienceYet")}</p>
              ) : (
                <div className="mb-3 space-y-2">
                  {experience.map((e) => (
                    <div
                      key={e.id}
                      className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2 text-sm"
                    >
                      <div>
                        <p className="text-text-primary">
                          {e.organization}
                          {e.role_title ? ` — ${e.role_title}` : ""}
                        </p>
                        <p className="text-xs text-text-muted">
                          {e.start_year || "—"} - {e.end_year || t("profile.today")}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDeleteExperience(e.id)}
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <form onSubmit={handleAddExperience} className="grid grid-cols-1 gap-2 sm:grid-cols-5">
                <Input
                  placeholder={t("profile.organizationPlaceholder")}
                  value={expOrg}
                  onChange={(e) => setExpOrg(e.target.value)}
                  className="sm:col-span-2"
                />
                <Input placeholder={t("profile.rolePlaceholder")} value={expRole} onChange={(e) => setExpRole(e.target.value)} />
                <Input
                  placeholder={t("profile.fromYearPlaceholder")}
                  type="number"
                  value={expStart}
                  onChange={(e) => setExpStart(e.target.value)}
                />
                <div className="flex gap-2">
                  <Input
                    placeholder={t("profile.toYearPlaceholder")}
                    type="number"
                    value={expEnd}
                    onChange={(e) => setExpEnd(e.target.value)}
                  />
                  <Button type="submit" isLoading={isAddingExp}>
                    +
                  </Button>
                </div>
              </form>
            </>
          )}
        </Card>

        {myOffers.length > 0 && (
          <Card id="player-offers-section" className="p-5 lg:col-span-2">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profile.myOffersHeading")}
            </h3>
            <div className="space-y-2">
              {myOffers.map((o) => (
                <div key={o.id} className="rounded-md border border-line bg-surface-raised px-3 py-2 text-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-text-primary">
                        {o.team_name} {o.years ? `· ${o.years}${t("profile.yearsSuffix")}` : ""}
                      </p>
                      {o.salary_details && (
                        <p className="mt-0.5 text-xs text-text-muted">💰 {o.salary_details}</p>
                      )}
                      {o.bonus_details && (
                        <p className="mt-0.5 text-xs text-text-muted">🎁 {o.bonus_details}</p>
                      )}
                    </div>
                    {o.status === "pending" ? (
                      <div className="flex shrink-0 items-center gap-2">
                        <Button
                          onClick={() => handleRespondOffer(o.id, true)}
                          isLoading={respondingOfferId === o.id}
                        >
                          {t("profile.accept")}
                        </Button>
                        <button
                          onClick={() => handleRespondOffer(o.id, false)}
                          className="text-xs text-status-injured hover:underline"
                        >
                          {t("profile.reject")}
                        </button>
                      </div>
                    ) : (
                      <span
                        className={`shrink-0 rounded-full border px-2 py-0.5 text-xs ${
                          o.status === "accepted"
                            ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                            : "border-status-injured/40 bg-status-injured/15 text-status-injured"
                        }`}
                      >
                        {o.status === "accepted" ? t("profile.accepted") : t("profile.rejected")}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {myStaffOffers.length > 0 && (
          <Card id="team-offers-section" className="p-5 lg:col-span-2">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profile.teamOffersHeading")}
            </h3>
            <div className="space-y-2">
              {myStaffOffers.map((o) => (
                <div key={o.id} className="rounded-md border border-line bg-surface-raised px-3 py-2 text-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-text-primary">
                        {o.team_name} {o.role_title ? `· ${o.role_title}` : ""}
                        {o.season ? ` · ${o.season}` : ""}
                      </p>
                      {o.new_role && (
                        <p className="mt-0.5 text-xs text-chalk">
                          {t("profile.newRolePrefix")}{STAFF_OFFER_ROLE_LABELS[o.new_role] || o.new_role}
                        </p>
                      )}
                      <p className="mt-0.5 text-xs text-text-muted">{t("profile.fromPrefix")}{o.sender_name}</p>
                      {o.incentive_details && (
                        <p className="mt-0.5 text-xs text-text-muted">🎁 {o.incentive_details}</p>
                      )}
                      {o.message && <p className="mt-0.5 text-xs text-text-muted">"{o.message}"</p>}
                    </div>
                    {o.status === "pending" ? (
                      <div className="flex shrink-0 items-center gap-2">
                        <Button
                          onClick={() => handleRespondStaffOffer(o.id, true)}
                          isLoading={respondingStaffOfferId === o.id}
                        >
                          {t("profile.accept")}
                        </Button>
                        <button
                          onClick={() => handleRespondStaffOffer(o.id, false)}
                          className="text-xs text-status-injured hover:underline"
                        >
                          {t("profile.reject")}
                        </button>
                      </div>
                    ) : (
                      <span
                        className={`shrink-0 rounded-full border px-2 py-0.5 text-xs ${
                          o.status === "accepted"
                            ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                            : "border-status-injured/40 bg-status-injured/15 text-status-injured"
                        }`}
                      >
                        {o.status === "accepted" ? t("profile.accepted") : t("profile.rejected")}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {myTeamMemberships.length > 0 && (
          <Card className="p-5 lg:col-span-2">
            <h3 className="mb-1 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profile.myTeamsHeading")}
            </h3>
            <p className="mb-3 text-xs text-text-muted">
              {t("profile.myTeamsDescription")}
            </p>
            <div className="space-y-2">
              {myTeamMemberships.map((m) => (
                <div
                  key={m.team_id}
                  className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2 text-sm"
                >
                  <div>
                    <p className="text-text-primary">{m.team_name}</p>
                    {m.role_title && <p className="text-xs text-text-muted">{m.role_title}</p>}
                  </div>
                  <button
                    onClick={() => setLeaveTarget(m)}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("profile.leave")}
                  </button>
                </div>
              ))}
            </div>
          </Card>
        )}

        {(myTeamRequests.length > 0 || myPlayerRequests.length > 0) && (
          <Card className="p-5 lg:col-span-2">
            <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profile.myRequestsHeading")}
            </h3>
            <div className="space-y-2">
              {myTeamRequests.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2 text-sm"
                >
                  <div>
                    <p className="text-text-primary">{r.team_name}</p>
                    <p className="text-xs text-text-muted">
                      {t("profile.teamRequestType")}{new Date(r.expires_at).toLocaleDateString("el-GR")}
                    </p>
                  </div>
                  <span
                    className={`rounded-full border px-2 py-0.5 text-xs ${
                      r.status === "accepted"
                        ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                        : r.status === "rejected"
                        ? "border-status-injured/40 bg-status-injured/15 text-status-injured"
                        : r.status === "expired"
                        ? "border-line text-text-muted"
                        : "border-status-doubtful/40 bg-status-doubtful/15 text-status-doubtful"
                    }`}
                  >
                    {r.status === "pending"
                      ? t("profile.statusPending")
                      : r.status === "accepted"
                      ? t("profile.accepted")
                      : r.status === "rejected"
                      ? t("profile.rejected")
                      : t("profile.statusExpired")}
                  </span>
                </div>
              ))}
              {myPlayerRequests.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2 text-sm"
                >
                  <div>
                    <p className="text-text-primary">{r.team_name}</p>
                    <p className="text-xs text-text-muted">
                      {t("profile.playerRequestType")}{new Date(r.expires_at).toLocaleDateString("el-GR")}
                    </p>
                  </div>
                  <span
                    className={`rounded-full border px-2 py-0.5 text-xs ${
                      r.status === "accepted"
                        ? "border-status-fit/40 bg-status-fit/15 text-status-fit"
                        : r.status === "rejected"
                        ? "border-status-injured/40 bg-status-injured/15 text-status-injured"
                        : r.status === "expired"
                        ? "border-line text-text-muted"
                        : "border-status-doubtful/40 bg-status-doubtful/15 text-status-doubtful"
                    }`}
                  >
                    {r.status === "pending"
                      ? t("profile.statusPending")
                      : r.status === "accepted"
                      ? t("profile.accepted")
                      : r.status === "rejected"
                      ? t("profile.rejected")
                      : t("profile.statusExpired")}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Password */}
        <Card corners className="p-5 lg:col-span-2">
          <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">
            {t("profile.changePasswordHeading")}
          </h3>
          <form onSubmit={handlePasswordSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Input
              label={t("profile.currentPassword")}
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
            <Input
              label={t("profile.newPassword")}
              type="password"
              required
              minLength={8}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
            <Input
              label={t("profile.confirmPassword")}
              type="password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            <div className="sm:col-span-3 flex justify-end">
              <Button type="submit" isLoading={isSavingPassword}>
                {t("profile.changePasswordHeading")}
              </Button>
            </div>
          </form>
        </Card>
      </div>

      <ConfirmDialog
        isOpen={!!leaveTarget}
        onClose={() => setLeaveTarget(null)}
        onConfirm={handleLeaveTeam}
        title={t("profile.leaveTeamTitle")}
        message={
          leaveTarget
            ? `${t("profile.leaveTeamConfirmPrefix")}${leaveTarget.team_name}${t("profile.leaveTeamConfirmSuffix")}`
            : ""
        }
        confirmLabel={t("profile.leave")}
        isLoading={isLeavingTeam}
      />
    </AppLayout>
  );
}
