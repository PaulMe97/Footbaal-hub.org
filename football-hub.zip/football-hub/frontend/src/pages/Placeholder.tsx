import { AppLayout } from "../components/layout/AppLayout";
import { EmptyState } from "../components/ui/EmptyState";
import { useLanguage } from "../context/LanguageContext";

export default function Placeholder({ title }: { title: string }) {
  const { t } = useLanguage();
  return (
    <AppLayout title={title}>
      <EmptyState
        title={`${title}${t("placeholder.comingSoonSuffix")}`}
        description={t("placeholder.description")}
      />
    </AppLayout>
  );
}
