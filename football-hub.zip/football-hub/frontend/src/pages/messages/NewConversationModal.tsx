import { useEffect, useMemo, useState } from "react";

import { extractErrorMessage } from "../../api/client";
import { listClubPeople } from "../../api/groupMessages";
import type { ClubPerson } from "../../api/groupMessages";
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";

export function NewConversationModal({
  isOpen,
  onClose,
  onStartDirect,
  onCreateGroup,
}: {
  isOpen: boolean;
  onClose: () => void;
  onStartDirect: (userId: string) => Promise<void>;
  onCreateGroup: (userIds: string[], name?: string) => Promise<void>;
}) {
  const { t } = useLanguage();
  const toast = useToast();
  const [people, setPeople] = useState<ClubPerson[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [groupName, setGroupName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setSelectedIds(new Set());
    setSearchQuery("");
    setGroupName("");
    setIsLoading(true);
    listClubPeople()
      .then(setPeople)
      .catch((err) => toast.show(extractErrorMessage(err), "error"))
      .finally(() => setIsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  const filteredPeople = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return people;
    return people.filter(
      (p) => (p.full_name || "").toLowerCase().includes(q) || p.username.toLowerCase().includes(q)
    );
  }, [people, searchQuery]);

  const groupedByTeam = useMemo(() => {
    const map = new Map<string, { teamName: string; people: ClubPerson[] }>();
    const seenUserIds = new Set<string>();
    for (const p of filteredPeople) {
      if (seenUserIds.has(p.id)) continue;
      seenUserIds.add(p.id);
      if (!map.has(p.team_id)) map.set(p.team_id, { teamName: p.team_name, people: [] });
      map.get(p.team_id)?.people.push(p);
    }
    return Array.from(map.values());
  }, [filteredPeople]);

  function toggleSelect(userId: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(userId)) next.delete(userId);
      else next.add(userId);
      return next;
    });
  }

  async function handleSubmit() {
    if (selectedIds.size === 0) return;
    setIsSubmitting(true);
    try {
      if (selectedIds.size === 1) {
        await onStartDirect(Array.from(selectedIds)[0]);
      } else {
        await onCreateGroup(Array.from(selectedIds), groupName.trim() || undefined);
      }
      onClose();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t("messages.newConversationTitle")}>
      <div className="space-y-3">
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t("messages.searchPeoplePlaceholder")}
        />
        {isLoading ? (
          <p className="py-6 text-center text-sm text-text-muted">{t("settings.loading")}</p>
        ) : groupedByTeam.length === 0 ? (
          <p className="py-6 text-center text-sm text-text-muted">{t("messages.noClubPeopleFound")}</p>
        ) : (
          <div className="max-h-72 space-y-4 overflow-y-auto">
            {groupedByTeam.map((group) => (
              <div key={group.teamName}>
                <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-text-muted">
                  {group.teamName}
                </p>
                <div className="space-y-1">
                  {group.people.map((p) => (
                    <label
                      key={p.id}
                      className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-surface-raised"
                    >
                      <input
                        type="checkbox"
                        checked={selectedIds.has(p.id)}
                        onChange={() => toggleSelect(p.id)}
                        className="accent-chalk"
                      />
                      <span className="text-text-primary">{p.full_name || p.username}</span>
                      <span className="text-xs text-text-muted">@{p.username}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {selectedIds.size > 1 && (
          <Input
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            placeholder={t("messages.groupNamePlaceholder")}
          />
        )}

        <div className="flex justify-end gap-2 border-t border-line pt-3">
          <Button type="button" variant="secondary" onClick={onClose}>
            {t("common.cancel")}
          </Button>
          <Button
            type="button"
            onClick={handleSubmit}
            isLoading={isSubmitting}
            disabled={selectedIds.size === 0}
          >
            {selectedIds.size > 1 ? t("messages.startGroupButton") : t("messages.startConversationButton")}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
