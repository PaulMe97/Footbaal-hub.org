import { useEffect, useState } from "react";

import { addCrmComment, deleteCrmTopic, getCrmTopic, updateCrmTopic } from "../../api/crm";
import type { CrmTopicDetail } from "../../api/crm";
import { extractErrorMessage, mediaUrl } from "../../api/client";
import { Button } from "../../components/ui/Button";
import { Spinner } from "../../components/ui/EmptyState";
import { Select, Textarea } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";

export function CrmTopicModal({
  topicId,
  onClose,
  onChanged,
}: {
  topicId: string | null;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const { t } = useLanguage();
  const CATEGORY_LABELS: Record<string, string> = {
    general: t("crm.categoryGeneral"),
    stadium: t("crm.categoryStadium"),
    parents: t("crm.categoryParents"),
    event: t("crm.categoryEvent"),
    other: t("crm.categoryOther"),
  };
  const PRIORITY_LABELS: Record<string, string> = {
    urgent: t("crm.priorityUrgentEmoji"),
    normal: t("crm.priorityNormal"),
    low: t("crm.priorityLow"),
  };
  const STATUS_LABELS: Record<string, string> = {
    open: t("crm.statusOpen"),
    in_progress: t("crm.statusInProgress"),
    resolved: t("crm.statusResolved"),
  };
  const [topic, setTopic] = useState<CrmTopicDetail | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [isCommenting, setIsCommenting] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  async function load() {
    if (!topicId) return;
    setIsLoading(true);
    try {
      const data = await getCrmTopic(topicId);
      setTopic(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topicId]);

  async function handleAddComment() {
    if (!topicId || !newComment.trim()) return;
    setIsCommenting(true);
    try {
      const updated = await addCrmComment(topicId, newComment.trim());
      setTopic(updated);
      setNewComment("");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsCommenting(false);
    }
  }

  async function handleStatusChange(status: string) {
    if (!topicId) return;
    setIsUpdating(true);
    try {
      await updateCrmTopic(topicId, { status });
      await load();
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUpdating(false);
    }
  }

  async function handlePriorityChange(priority: string) {
    if (!topicId) return;
    setIsUpdating(true);
    try {
      await updateCrmTopic(topicId, { priority });
      await load();
      onChanged();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUpdating(false);
    }
  }

  async function handleDelete() {
    if (!topicId) return;
    setIsDeleting(true);
    try {
      await deleteCrmTopic(topicId);
      toast.show(t("crm.topicDeleted"), "success");
      setShowDelete(false);
      onChanged();
      onClose();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  return (
    <Modal isOpen={!!topicId} onClose={onClose} title={topic ? topic.title : t("crm.topicLabel")} wide>
      {isLoading || !topic ? (
        <Spinner />
      ) : (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2 text-xs text-text-muted">
            <span className="rounded-full border border-line px-2 py-0.5">{topic.team_name}</span>
            <span className="rounded-full border border-line px-2 py-0.5">
              {CATEGORY_LABELS[topic.category] || topic.category}
            </span>
            {topic.is_expired && (
              <span className="rounded-full border border-status-injured/40 bg-status-injured/10 px-2 py-0.5 text-status-injured">
                {t("crm.expiredBadge")}
              </span>
            )}
            <span>
              {t("crm.createdByPrefix")}
              {topic.created_by_name} · {new Date(topic.created_at).toLocaleDateString("el-GR")}
            </span>
          </div>

          {topic.description && <p className="text-sm text-text-primary">{topic.description}</p>}

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Select
              label={t("crm.status")}
              value={topic.status}
              onChange={(e) => handleStatusChange(e.target.value)}
              disabled={isUpdating}
            >
              {Object.entries(STATUS_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
            <Select
              label={t("crm.priority")}
              value={topic.priority}
              onChange={(e) => handlePriorityChange(e.target.value)}
              disabled={isUpdating}
            >
              {Object.entries(PRIORITY_LABELS).map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </Select>
          </div>

          <div className="border-t border-line pt-4">
            <h4 className="mb-3 font-display text-xs uppercase tracking-wide text-text-muted">
              {t("crm.commentsHeading")} ({topic.comments.length})
            </h4>
            <div className="mb-3 max-h-64 space-y-2 overflow-y-auto pr-1">
              {topic.comments.length === 0 ? (
                <p className="text-sm text-text-muted">{t("crm.noCommentsYet")}</p>
              ) : (
                topic.comments.map((c) => (
                  <div key={c.id} className="flex gap-2.5">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-xs text-text-muted">
                      {c.author_avatar ? (
                        <img src={mediaUrl(c.author_avatar)} alt="" className="h-full w-full object-cover" />
                      ) : (
                        (c.author_name || "?").charAt(0).toUpperCase()
                      )}
                    </div>
                    <div className="min-w-0 flex-1 rounded-md border border-line bg-surface-raised px-3 py-2">
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-text-primary">{c.author_name}</p>
                        <p className="text-[11px] text-text-muted">
                          {new Date(c.created_at).toLocaleDateString("el-GR")}
                        </p>
                      </div>
                      <p className="mt-1 text-sm text-text-primary">{c.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="flex items-end gap-2">
              <Textarea
                label={t("crm.newComment")}
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="flex-1"
              />
              <Button type="button" onClick={handleAddComment} isLoading={isCommenting} disabled={!newComment.trim()}>
                {t("crm.send")}
              </Button>
            </div>
          </div>

          <div className="flex justify-end border-t border-line pt-4">
            <button onClick={() => setShowDelete(true)} className="text-xs text-status-injured hover:underline">
              {t("crm.deleteTopicTitle")}
            </button>
          </div>
        </div>
      )}

      <ConfirmDialog
        isOpen={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title={t("crm.deleteTopicTitle")}
        message={topic ? `${t("crm.deleteConfirmPrefix")}${topic.title}${t("crm.deleteConfirmSuffix")}` : ""}
        isLoading={isDeleting}
      />
    </Modal>
  );
}
