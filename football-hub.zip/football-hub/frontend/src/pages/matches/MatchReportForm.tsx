import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { Textarea } from "../../components/ui/Input";
import { QuickSuggestions, appendSuggestion } from "../../components/QuickSuggestions";
import { useQuickSuggestions } from "../../utils/quickSuggestions";
import type { Match } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export interface MatchReportValues {
  general_description: string;
  team_performance_notes: string;
  opponent_analysis: string;
  coach_notes: string;
}

export function MatchReportForm({
  match,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  match: Match;
  onSubmit: (values: MatchReportValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const { t } = useLanguage();
  const [values, setValues] = useState<MatchReportValues>({
    general_description: match.general_description ?? "",
    team_performance_notes: match.team_performance_notes ?? "",
    opponent_analysis: match.opponent_analysis ?? "",
    coach_notes: match.coach_notes ?? "",
  });

  function set<K extends keyof MatchReportValues>(key: K, value: MatchReportValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  const generalDescriptionSuggestions = useQuickSuggestions("matchGeneralDescription");
  const teamPerformanceSuggestions = useQuickSuggestions("matchTeamPerformance");
  const opponentAnalysisSuggestions = useQuickSuggestions("matchOpponentAnalysis");
  const coachNotesSuggestions = useQuickSuggestions("matchCoachNotes");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Textarea
          label={t("matchReportForm.generalDescription")}
          value={values.general_description}
          onChange={(e) => set("general_description", e.target.value)}
          placeholder={t("matchReportForm.generalDescriptionPlaceholder")}
        />
        <QuickSuggestions
          suggestions={generalDescriptionSuggestions}
          onSelect={(s) => set("general_description", appendSuggestion(values.general_description, s))}
        />
      </div>
      <div>
        <Textarea
          label={t("matchReportForm.teamPerformance")}
          value={values.team_performance_notes}
          onChange={(e) => set("team_performance_notes", e.target.value)}
        />
        <QuickSuggestions
          suggestions={teamPerformanceSuggestions}
          onSelect={(s) => set("team_performance_notes", appendSuggestion(values.team_performance_notes, s))}
        />
      </div>
      <div>
        <Textarea
          label={t("matchReportForm.opponentAnalysis")}
          value={values.opponent_analysis}
          onChange={(e) => set("opponent_analysis", e.target.value)}
        />
        <QuickSuggestions
          suggestions={opponentAnalysisSuggestions}
          onSelect={(s) => set("opponent_analysis", appendSuggestion(values.opponent_analysis, s))}
        />
      </div>
      <div>
        <Textarea
          label={t("matchReportForm.coachNotes")}
          value={values.coach_notes}
          onChange={(e) => set("coach_notes", e.target.value)}
        />
        <QuickSuggestions
          suggestions={coachNotesSuggestions}
          onSelect={(s) => set("coach_notes", appendSuggestion(values.coach_notes, s))}
        />
      </div>
      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {t("matchReportForm.saveReport")}
        </Button>
      </div>
    </form>
  );
}
