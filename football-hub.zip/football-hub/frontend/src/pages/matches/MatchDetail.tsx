import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import { generateMatchAISummary, listMatchAIReports } from "../../api/ai";
import { extractErrorMessage } from "../../api/client";
import {
  bulkUpsertMatchPlayers,
  deleteMatch,
  downloadMatchRatingPdf,
  getMatch,
  listMatchPlayers,
  updateMatch,
  updateMatchReport,
  type MatchPlayerBulkEntry,
} from "../../api/matches";
import { listPlayers } from "../../api/players";
import { listTeams } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { Spinner } from "../../components/ui/EmptyState";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { Select } from "../../components/ui/Input";
import { useToast } from "../../components/ui/Toast";
import type { AIReport, Match, MatchPlayerPerformance, MatchStatus, Player, Team } from "../../types";
import { MATCH_STATUS_LABELS } from "../../types";
import { MatchForm, matchFormToPayload, type MatchFormValues } from "./MatchForm";
import { MatchReportForm, type MatchReportValues } from "./MatchReportForm";
import { useLanguage } from "../../context/LanguageContext";

interface RowState {
  is_starting: boolean;
  minutes_played: number | null;
  goals: number;
  assists: number;
  yellow_cards: number;
  red_cards: number;
  rating: number | null;
  is_mvp: boolean;
}

const DEFAULT_ROW: RowState = {
  is_starting: false,
  minutes_played: null,
  goals: 0,
  assists: 0,
  yellow_cards: 0,
  red_cards: 0,
  rating: null,
  is_mvp: false,
};

function buildInitialRows(
  players: Player[],
  performances: MatchPlayerPerformance[]
): Record<string, RowState> {
  const rows: Record<string, RowState> = {};
  const perfByPlayer = new Map(performances.map((p) => [p.player_id, p]));
  for (const player of players) {
    const perf = perfByPlayer.get(player.id);
    rows[player.id] = perf
      ? {
          is_starting: perf.is_starting,
          minutes_played: perf.minutes_played ?? null,
          goals: perf.goals,
          assists: perf.assists,
          yellow_cards: perf.yellow_cards,
          red_cards: perf.red_cards,
          rating: perf.rating ?? null,
          is_mvp: perf.is_mvp,
        }
      : { ...DEFAULT_ROW };
  }
  return rows;
}

export default function MatchDetail() {
  const { matchId } = useParams<{ matchId: string }>();
  const navigate = useNavigate();
  const toast = useToast();
  const { t } = useLanguage();

  const [match, setMatch] = useState<Match | null>(null);
  const [performances, setPerformances] = useState<MatchPlayerPerformance[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [rosterTeamId, setRosterTeamId] = useState<string>("");
  const [roster, setRoster] = useState<Player[]>([]);
  const [rows, setRows] = useState<Record<string, RowState>>({});
  const [isSavingRatings, setIsSavingRatings] = useState(false);

  const [showEditMatch, setShowEditMatch] = useState(false);
  const [showEditReport, setShowEditReport] = useState(false);
  const [showDeleteMatch, setShowDeleteMatch] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [aiReports, setAiReports] = useState<AIReport[]>([]);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  async function loadRoster(teamId: string, perfs: MatchPlayerPerformance[]) {
    if (!teamId) {
      setRoster([]);
      setRows({});
      return;
    }
    try {
      const players = await listPlayers({ team_id: teamId });
      setRoster(players);
      setRows(buildInitialRows(players, perfs));
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  async function load() {
    if (!matchId) return;
    setIsLoading(true);
    try {
      const [m, perfs, teamsData, reports] = await Promise.all([
        getMatch(matchId),
        listMatchPlayers(matchId),
        listTeams(),
        listMatchAIReports(matchId),
      ]);
      setMatch(m);
      setPerformances(perfs);
      setTeams(teamsData);
      setAiReports(reports);

      const defaultTeamId = m.home_team_id || m.away_team_id || "";
      setRosterTeamId(defaultTeamId);
      await loadRoster(defaultTeamId, perfs);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matchId]);

  function handleRosterTeamChange(teamId: string) {
    setRosterTeamId(teamId);
    loadRoster(teamId, performances);
  }

  function rowFor(playerId: string): RowState {
    return rows[playerId] ?? DEFAULT_ROW;
  }

  function updateRow(playerId: string, patch: Partial<RowState>) {
    setRows((prev) => ({ ...prev, [playerId]: { ...(prev[playerId] ?? DEFAULT_ROW), ...patch } }));
  }

  function setMvp(playerId: string) {
    setRows((prev) => {
      const next: Record<string, RowState> = {};
      for (const [id, row] of Object.entries(prev)) {
        next[id] = { ...row, is_mvp: id === playerId };
      }
      return next;
    });
  }

  async function handleUpdateMatch(values: MatchFormValues) {
    if (!matchId) return;
    setIsSubmitting(true);
    try {
      const updated = await updateMatch(matchId, matchFormToPayload(values));
      setMatch(updated);
      toast.show(t("dashboard.changesSaved"), "success");
      setShowEditMatch(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleUpdateReport(values: MatchReportValues) {
    if (!matchId) return;
    setIsSubmitting(true);
    try {
      const updated = await updateMatchReport(matchId, values);
      setMatch(updated);
      toast.show(t("matchDetail.reportSaved"), "success");
      setShowEditReport(false);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleGenerateAISummary() {
    if (!matchId) return;
    setIsGeneratingAI(true);
    try {
      const report = await generateMatchAISummary(matchId);
      setAiReports((prev) => [report, ...prev]);
      toast.show(t("matchDetail.aiSummaryGenerated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsGeneratingAI(false);
    }
  }

  async function handleExportPdf() {
    if (!matchId || !match) return;
    setIsExportingPdf(true);
    try {
      await downloadMatchRatingPdf(matchId, `match-rating-${match.date}.pdf`);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExportingPdf(false);
    }
  }

  async function handleSaveRatings() {
    if (!matchId || roster.length === 0) return;
    setIsSavingRatings(true);
    try {
      const entries: MatchPlayerBulkEntry[] = roster.map((p) => {
        const r = rowFor(p.id);
        return {
          player_id: p.id,
          is_starting: r.is_starting,
          position_played: p.position ?? null,
          minutes_played: r.minutes_played,
          goals: r.goals,
          assists: r.assists,
          yellow_cards: r.yellow_cards,
          red_cards: r.red_cards,
          fouls: 0,
          rating: r.rating,
          coach_rating: null,
          is_mvp: r.is_mvp,
          notes: null,
        };
      });
      const perfs = await bulkUpsertMatchPlayers(matchId, entries);
      setPerformances(perfs);
      setRows(buildInitialRows(roster, perfs));
      toast.show(t("matchDetail.ratingsSaved"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingRatings(false);
    }
  }

  async function handleDeleteMatch() {
    if (!matchId) return;
    setIsDeleting(true);
    try {
      await deleteMatch(matchId);
      toast.show(t("matchDetail.matchDeleted"), "success");
      navigate("/matches");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
      setIsDeleting(false);
    }
  }

  if (isLoading || !match) {
    return (
      <AppLayout title={t("matchDetail.loadingTitle")}>
        <Spinner />
      </AppLayout>
    );
  }

  return (
    <AppLayout title={`${match.home_team_name || "—"} vs ${match.away_team_name || "—"}`}>
      <Link to="/matches" className="mb-4 inline-block text-sm text-text-muted hover:text-chalk">
        {t("matchDetail.backToAll")}
      </Link>

      <Card corners className="mb-6 p-6">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="flex-1 text-center sm:text-left">
            <p className="font-display text-xl text-text-primary">{match.home_team_name || "—"}</p>
          </div>
          <div className="flex flex-col items-center gap-1">
            {match.status === "finished" ? (
              <p className="font-display text-3xl text-chalk">
                {match.home_score ?? "-"} : {match.away_score ?? "-"}
              </p>
            ) : (
              <p className="font-display text-xl text-text-muted">vs</p>
            )}
            <Badge>{MATCH_STATUS_LABELS[match.status as MatchStatus]}</Badge>
          </div>
          <div className="flex-1 text-center sm:text-right">
            <p className="font-display text-xl text-text-primary">{match.away_team_name || "—"}</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-1 border-t border-line pt-4 text-sm text-text-muted sm:justify-start">
          <span>{new Date(match.date).toLocaleDateString("el-GR")}</span>
          {match.time && <span>{match.time}</span>}
          {match.stadium && <span>{match.stadium}</span>}
          {match.competition && <span>{match.competition}</span>}
          {match.season && <span>{match.season}</span>}
        </div>
        <div className="mt-4 flex flex-wrap justify-center gap-2 sm:justify-start">
          <Button variant="secondary" onClick={() => setShowEditMatch(true)}>
            {t("matchDetail.editDetails")}
          </Button>
          <Button variant="secondary" onClick={handleExportPdf} isLoading={isExportingPdf}>
            📄 Export to PDF
          </Button>
          <Button variant="danger" onClick={() => setShowDeleteMatch(true)}>
            {t("common.delete")}
          </Button>
        </div>
      </Card>

      <Card className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
            Match Report
          </h3>
          <Button variant="ghost" onClick={() => setShowEditReport(true)}>
            {t("common.edit")}
          </Button>
        </div>
        {!match.general_description &&
        !match.team_performance_notes &&
        !match.opponent_analysis &&
        !match.coach_notes ? (
          <p className="text-sm text-text-muted">
            {t("matchDetail.noReportYet")}
          </p>
        ) : (
          <div className="grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
            {match.general_description && (
              <ReportBlock label={t("matchDetail.generalDescLabel")} text={match.general_description} />
            )}
            {match.team_performance_notes && (
              <ReportBlock label={t("matchReportForm.teamPerformance")} text={match.team_performance_notes} />
            )}
            {match.opponent_analysis && (
              <ReportBlock label={t("matchReportForm.opponentAnalysis")} text={match.opponent_analysis} />
            )}
            {match.coach_notes && <ReportBlock label={t("matchReportForm.coachNotes")} text={match.coach_notes} />}
          </div>
        )}
      </Card>

      <Card className="mt-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-3">
          <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
            {t("matchDetail.ratingsHeading")}
          </h3>
          <div className="flex items-center gap-2">
            <Select
              value={rosterTeamId}
              onChange={(e) => handleRosterTeamChange(e.target.value)}
              className="w-52"
            >
              <option value="">{t("matchDetail.selectRosterTeam")}</option>
              {teams.map((teamOpt) => (
                <option key={teamOpt.id} value={teamOpt.id}>
                  {teamOpt.name}
                </option>
              ))}
            </Select>
            <Button onClick={handleSaveRatings} isLoading={isSavingRatings} disabled={roster.length === 0}>
              {t("matchDetail.saveRatings")}
            </Button>
          </div>
        </div>

        {!rosterTeamId ? (
          <p className="p-6 text-center text-sm text-text-muted">
            {t("matchDetail.selectTeamPrompt")}
          </p>
        ) : roster.length === 0 ? (
          <p className="p-6 text-center text-sm text-text-muted">
            {t("matchDetail.noPlayersInTeam")}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase text-text-muted">
                  <th className="px-3 py-2">{t("matchDetail.playerLabel")}</th>
                  <th className="px-2 py-2 text-center">{t("matchPlayerForm.starting")}</th>
                  <th className="px-2 py-2 text-center">{t("matchDetail.minutesAbbrev")}</th>
                  <th className="px-2 py-2 text-center">{t("performance.goals")}</th>
                  <th className="px-2 py-2 text-center">{t("performance.assists")}</th>
                  <th className="px-2 py-2 text-center">🟨</th>
                  <th className="px-2 py-2 text-center">🟥</th>
                  <th className="px-2 py-2 text-center">Rating</th>
                  <th className="px-2 py-2 text-center">★ MVP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {roster.map((p) => {
                  const r = rowFor(p.id);
                  return (
                    <tr key={p.id} className="hover:bg-surface-raised">
                      <td className="px-3 py-2">
                        <Link to={`/players/${p.id}`} className="text-text-primary hover:text-chalk">
                          {p.player_number != null ? `#${p.player_number} ` : ""}
                          {p.first_name} {p.last_name}
                        </Link>
                        {p.position && <span className="ml-1 text-xs text-text-muted">{p.position}</span>}
                      </td>
                      <td className="px-2 py-2 text-center">
                        <input
                          type="checkbox"
                          checked={r.is_starting}
                          onChange={(e) => updateRow(p.id, { is_starting: e.target.checked })}
                          className="h-4 w-4 accent-chalk"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          max={120}
                          value={r.minutes_played ?? ""}
                          onChange={(e) =>
                            updateRow(p.id, {
                              minutes_played: e.target.value === "" ? null : Number(e.target.value),
                            })
                          }
                          className="w-16 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          value={r.goals}
                          onChange={(e) => updateRow(p.id, { goals: Number(e.target.value || 0) })}
                          className="w-14 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          value={r.assists}
                          onChange={(e) => updateRow(p.id, { assists: Number(e.target.value || 0) })}
                          className="w-14 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          max={2}
                          value={r.yellow_cards}
                          onChange={(e) => updateRow(p.id, { yellow_cards: Number(e.target.value || 0) })}
                          className="w-12 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          max={1}
                          value={r.red_cards}
                          onChange={(e) => updateRow(p.id, { red_cards: Number(e.target.value || 0) })}
                          className="w-12 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2">
                        <input
                          type="number"
                          min={0}
                          max={10}
                          step={0.5}
                          value={r.rating ?? ""}
                          onChange={(e) =>
                            updateRow(p.id, { rating: e.target.value === "" ? null : Number(e.target.value) })
                          }
                          className="w-16 rounded-md border border-line bg-surface px-2 py-1 text-center text-xs font-mono text-chalk focus:border-chalk focus:outline-none"
                        />
                      </td>
                      <td className="px-2 py-2 text-center">
                        <input
                          type="radio"
                          name="mvp"
                          checked={r.is_mvp}
                          onChange={() => setMvp(p.id)}
                          className="h-4 w-4 accent-chalk"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="mt-6 p-5">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
            AI Match Summary
          </h3>
          <Button onClick={handleGenerateAISummary} isLoading={isGeneratingAI} variant="secondary">
            ✨ Generate AI Match Summary
          </Button>
        </div>
        {aiReports.length === 0 ? (
          <p className="text-sm text-text-muted">
            {t("matchDetail.noAiSummaryYet")}{" "}
            <Link to="/settings" className="text-chalk hover:underline">
              {t("settings.title")}
            </Link>
            .
          </p>
        ) : (
          <div className="max-h-96 space-y-4 overflow-y-auto">
            {aiReports.map((r) => (
              <div key={r.id} className="rounded-md border border-line bg-surface-raised p-3">
                <p className="mb-1 text-xs text-text-muted">
                  {new Date(r.created_at).toLocaleString("el-GR")}
                  {r.model_used ? ` · ${r.model_used}` : ""}
                </p>
                <p className="whitespace-pre-wrap text-sm text-text-primary">{r.content}</p>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Modal isOpen={showEditMatch} onClose={() => setShowEditMatch(false)} title={t("matchDetail.editMatchModalTitle")} wide>
        <MatchForm
          match={match}
          teams={teams}
          onSubmit={handleUpdateMatch}
          onCancel={() => setShowEditMatch(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <Modal isOpen={showEditReport} onClose={() => setShowEditReport(false)} title="Match Report" wide>
        <MatchReportForm
          match={match}
          onSubmit={handleUpdateReport}
          onCancel={() => setShowEditReport(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={showDeleteMatch}
        onClose={() => setShowDeleteMatch(false)}
        onConfirm={handleDeleteMatch}
        title={t("matchDetail.deleteMatchTitle")}
        message={t("matchDetail.deleteConfirmMessage")}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}

function ReportBlock({ label, text }: { label: string; text: string }) {
  return (
    <div>
      <p className="text-xs uppercase text-text-muted">{label}</p>
      <p className="mt-1 whitespace-pre-wrap text-text-primary">{text}</p>
    </div>
  );
}
