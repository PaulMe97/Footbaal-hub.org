import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { DateField } from "../../components/ui/DateField";
import { Input, Select } from "../../components/ui/Input";
import type { Match, MatchStatus, Team } from "../../types";
import { MATCH_STATUS_LABELS } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

const EXTERNAL = "__external__";

export interface MatchFormValues {
  home_team_id: string;
  home_team_name_external: string;
  away_team_id: string;
  away_team_name_external: string;
  date: string;
  time: string;
  stadium: string;
  competition: string;
  season: string;
  status: MatchStatus;
  home_score: string;
  away_score: string;
}

function toFormValues(match?: Match | null, presetTeamId?: string): MatchFormValues {
  return {
    home_team_id: match?.home_team_id ?? presetTeamId ?? "",
    home_team_name_external: match?.home_team_name_external ?? "",
    away_team_id: match?.away_team_id ?? "",
    away_team_name_external: match?.away_team_name_external ?? "",
    date: match?.date?.slice(0, 10) ?? new Date().toISOString().slice(0, 10),
    time: match?.time ?? "",
    stadium: match?.stadium ?? "",
    competition: match?.competition ?? "",
    season: match?.season ?? "",
    status: match?.status ?? "scheduled",
    home_score: match?.home_score != null ? String(match.home_score) : "",
    away_score: match?.away_score != null ? String(match.away_score) : "",
  };
}

export function matchFormToPayload(values: MatchFormValues) {
  return {
    home_team_id: values.home_team_id === EXTERNAL || !values.home_team_id ? null : values.home_team_id,
    home_team_name_external: values.home_team_id === EXTERNAL ? values.home_team_name_external : null,
    away_team_id: values.away_team_id === EXTERNAL || !values.away_team_id ? null : values.away_team_id,
    away_team_name_external: values.away_team_id === EXTERNAL ? values.away_team_name_external : null,
    date: values.date,
    time: values.time || null,
    stadium: values.stadium || null,
    competition: values.competition || null,
    season: values.season || null,
    status: values.status,
    home_score: values.home_score !== "" ? Number(values.home_score) : null,
    away_score: values.away_score !== "" ? Number(values.away_score) : null,
  };
}

function TeamSelect({
  label,
  teams,
  teamId,
  externalName,
  onTeamChange,
  onExternalChange,
}: {
  label: string;
  teams: Team[];
  teamId: string;
  externalName: string;
  onTeamChange: (v: string) => void;
  onExternalChange: (v: string) => void;
}) {
  const isExternal = teamId === EXTERNAL;
  const { t } = useLanguage();
  return (
    <div className="space-y-2">
      <Select label={label} value={teamId} onChange={(e) => onTeamChange(e.target.value)}>
        <option value="">{t("crm.selectTeam")}</option>
        {teams.map((teamOpt) => (
          <option key={teamOpt.id} value={teamOpt.id}>
            {teamOpt.name}
          </option>
        ))}
        <option value={EXTERNAL}>{t("matchForm.otherTeamExternal")}</option>
      </Select>
      {isExternal && (
        <Input
          placeholder={t("matchForm.opponentName")}
          value={externalName}
          onChange={(e) => onExternalChange(e.target.value)}
        />
      )}
    </div>
  );
}

export function MatchForm({
  match,
  teams,
  presetTeamId,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  match?: Match | null;
  teams: Team[];
  presetTeamId?: string;
  onSubmit: (values: MatchFormValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const [values, setValues] = useState<MatchFormValues>(toFormValues(match, presetTeamId));
  const { t } = useLanguage();

  function set<K extends keyof MatchFormValues>(key: K, value: MatchFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <TeamSelect
          label={t("matchForm.homeTeam")}
          teams={teams}
          teamId={values.home_team_id}
          externalName={values.home_team_name_external}
          onTeamChange={(v) => set("home_team_id", v)}
          onExternalChange={(v) => set("home_team_name_external", v)}
        />
        <TeamSelect
          label={t("matchForm.awayTeam")}
          teams={teams}
          teamId={values.away_team_id}
          externalName={values.away_team_name_external}
          onTeamChange={(v) => set("away_team_id", v)}
          onExternalChange={(v) => set("away_team_name_external", v)}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <DateField
          label={t("matchForm.dateRequired")}
          required
          value={values.date}
          onChange={(iso) => set("date", iso)}
        />
        <Input label={t("calendar.time")} type="time" value={values.time} onChange={(e) => set("time", e.target.value)} />
        <Select
          label={t("players.status")}
          value={values.status}
          onChange={(e) => set("status", e.target.value as MatchStatus)}
        >
          {Object.entries(MATCH_STATUS_LABELS).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input label={t("teamDetail.stadiumLabel")} value={values.stadium} onChange={(e) => set("stadium", e.target.value)} />
        <Input
          label={t("matchForm.competition")}
          value={values.competition}
          onChange={(e) => set("competition", e.target.value)}
        />
      </div>

      <Input label="Season" placeholder="2025-2026" value={values.season} onChange={(e) => set("season", e.target.value)} />

      {values.status === "finished" && (
        <div className="grid grid-cols-2 gap-4 rounded-md border border-line bg-surface-raised p-3">
          <Input
            label={t("matchForm.homeScore")}
            type="number"
            value={values.home_score}
            onChange={(e) => set("home_score", e.target.value)}
          />
          <Input
            label={t("matchForm.awayScore")}
            type="number"
            value={values.away_score}
            onChange={(e) => set("away_score", e.target.value)}
          />
        </div>
      )}

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {match ? t("common.save") : t("common.create")}
        </Button>
      </div>
    </form>
  );
}
