import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

import { listCalendarEvents } from "../../api/calendar";
import { extractErrorMessage } from "../../api/client";
import { createMatch, deleteMatch, listMatches } from "../../api/matches";
import { listTeams } from "../../api/teams";
import { AppLayout } from "../../components/layout/AppLayout";
import { TeamPickerGrid } from "../../components/TeamPickerGrid";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState, Spinner } from "../../components/ui/EmptyState";
import { Select } from "../../components/ui/Input";
import { ConfirmDialog, Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import { useLanguage } from "../../context/LanguageContext";
import type { Match, MatchStatus, Team } from "../../types";
import { MATCH_STATUS_LABELS } from "../../types";
import { MatchForm, matchFormToPayload, type MatchFormValues } from "./MatchForm";

const statusClass: Record<MatchStatus, string> = {
  scheduled: "border-line text-text-muted",
  live: "border-status-injured/40 bg-status-injured/15 text-status-injured",
  finished: "border-status-fit/40 bg-status-fit/15 text-status-fit",
  postponed: "border-status-doubtful/40 bg-status-doubtful/15 text-status-doubtful",
  cancelled: "border-status-unavailable/40 text-status-unavailable",
};

export default function MatchesList() {
  const { t } = useLanguage();
  const [searchParams, setSearchParams] = useSearchParams();
  const teamIdFilter = searchParams.get("team_id") || "";

  const [matches, setMatches] = useState<Match[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [status, setStatus] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Match | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const toast = useToast();

  useEffect(() => {
    listTeams().catch(() => []).then((t) => setTeams(t || []));
  }, []);

  useEffect(() => {
    if (searchParams.get("create") === "1") {
      setShowCreate(true);
      const next = new URLSearchParams(searchParams);
      next.delete("create");
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setIsLoading(true);
    try {
      const data = await listMatches({ team_id: teamIdFilter || undefined, status: status || undefined });
      setMatches(data);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teamIdFilter, status]);

  async function handleCreate(values: MatchFormValues) {
    setIsSubmitting(true);
    try {
      const relevantTeamId =
        values.home_team_id && values.home_team_id !== "__external__"
          ? values.home_team_id
          : values.away_team_id && values.away_team_id !== "__external__"
          ? values.away_team_id
          : "";
      if (relevantTeamId) {
        const existing = await listCalendarEvents({
          team_id: relevantTeamId,
          start: values.date,
          end: values.date,
        });
        if (existing.length > 0) {
          const names = existing.map((e) => e.title).join(", ");
          const proceed = window.confirm(
            `${t("matches.conflictPrefix")}${names}${t("matches.conflictSuffix")}`
          );
          if (!proceed) {
            setIsSubmitting(false);
            return;
          }
        }
      }
      await createMatch(matchFormToPayload(values));
      toast.show(t("matches.created"), "success");
      setShowCreate(false);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteMatch(deleteTarget.id);
      toast.show(t("matches.deleted"), "success");
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsDeleting(false);
    }
  }

  const selectedTeam = teams.find((t) => t.id === teamIdFilter);

  return (
    <AppLayout title={t("matches.title")}>
      {teamIdFilter && (
        <button
          onClick={() => setSearchParams({})}
          className="mb-3 text-xs text-chalk hover:underline"
        >
          {t("matches.backToTeams")}
        </button>
      )}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
          {teamIdFilter && selectedTeam && (
            <h2 className="font-display text-lg text-text-primary">{selectedTeam.name}</h2>
          )}
          {teamIdFilter && (
            <Select value={status} onChange={(e) => setStatus(e.target.value)} className="sm:w-48">
              <option value="">{t("matches.allStatuses")}</option>
              {Object.entries(MATCH_STATUS_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          )}
        </div>
        <Button onClick={() => setShowCreate(true)}>{t("matches.newMatch")}</Button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : !teamIdFilter ? (
        teams.length === 0 ? (
          <EmptyState
            title={t("matches.noTeamsYet")}
            description={t("matches.noTeamsDescription")}
            action={
              <Link to="/teams">
                <Button>{t("matches.goToTeams")}</Button>
              </Link>
            }
          />
        ) : (
          <TeamPickerGrid teams={teams} onSelect={(id) => setSearchParams({ team_id: id })} />
        )
      ) : matches.length === 0 ? (
        <EmptyState
          title={t("matches.noMatchesYet")}
          description={t("matches.noMatchesDescription")}
          action={<Button onClick={() => setShowCreate(true)}>{t("matches.newMatch")}</Button>}
        />
      ) : (
        <Card>
          <div className="divide-y divide-line">
            {matches.map((m) => (
              <Link
                key={m.id}
                to={`/matches/${m.id}`}
                className="flex items-center justify-between px-4 py-3 text-sm hover:bg-surface-raised"
              >
                <div>
                  <p className="text-text-primary">
                    {m.home_team_name || "—"} <span className="text-text-muted">vs</span>{" "}
                    {m.away_team_name || "—"}
                  </p>
                  <p className="text-xs text-text-muted">
                    {new Date(m.date).toLocaleDateString("el-GR")}
                    {m.time ? ` · ${m.time}` : ""}
                    {m.competition ? ` · ${m.competition}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {m.status === "finished" && (
                    <span className="font-mono text-sm text-text-primary">
                      {m.home_score ?? "-"} : {m.away_score ?? "-"}
                    </span>
                  )}
                  <Badge className={statusClass[m.status]}>{MATCH_STATUS_LABELS[m.status]}</Badge>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      setDeleteTarget(m);
                    }}
                    className="text-xs text-status-injured hover:underline"
                  >
                    {t("common.delete")}
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      )}

      <Modal isOpen={showCreate} onClose={() => setShowCreate(false)} title={t("matches.newMatchModalTitle")} wide>
        <MatchForm
          teams={teams}
          presetTeamId={teamIdFilter || undefined}
          onSubmit={handleCreate}
          onCancel={() => setShowCreate(false)}
          isSubmitting={isSubmitting}
        />
      </Modal>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={t("matches.deleteMatchTitle")}
        message={t("matches.deleteConfirmMessage")}
        isLoading={isDeleting}
      />
    </AppLayout>
  );
}
