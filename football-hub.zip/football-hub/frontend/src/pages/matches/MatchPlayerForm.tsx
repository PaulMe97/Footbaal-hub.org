import { FormEvent, useState } from "react";

import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Input";
import { POSITIONS } from "../../types";
import type { MatchPlayerPerformance, Player, PlayerPosition } from "../../types";
import { useLanguage } from "../../context/LanguageContext";

export interface MatchPlayerFormValues {
  player_id: string;
  is_starting: boolean;
  position_played: PlayerPosition | "";
  minutes_played: string;
  goals: string;
  assists: string;
  yellow_cards: string;
  red_cards: string;
  fouls: string;
  rating: string;
  coach_rating: string;
  notes: string;
}

function toFormValues(perf?: MatchPlayerPerformance | null): MatchPlayerFormValues {
  return {
    player_id: perf?.player_id ?? "",
    is_starting: perf?.is_starting ?? true,
    position_played: perf?.position_played ?? "",
    minutes_played: perf?.minutes_played != null ? String(perf.minutes_played) : "",
    goals: String(perf?.goals ?? 0),
    assists: String(perf?.assists ?? 0),
    yellow_cards: String(perf?.yellow_cards ?? 0),
    red_cards: String(perf?.red_cards ?? 0),
    fouls: String(perf?.fouls ?? 0),
    rating: perf?.rating != null ? String(perf.rating) : "",
    coach_rating: perf?.coach_rating != null ? String(perf.coach_rating) : "",
    notes: perf?.notes ?? "",
  };
}

export function matchPlayerFormToPayload(values: MatchPlayerFormValues) {
  return {
    player_id: values.player_id,
    is_starting: values.is_starting,
    position_played: values.position_played || null,
    minutes_played: values.minutes_played ? Number(values.minutes_played) : null,
    goals: Number(values.goals || 0),
    assists: Number(values.assists || 0),
    yellow_cards: Number(values.yellow_cards || 0),
    red_cards: Number(values.red_cards || 0),
    fouls: Number(values.fouls || 0),
    rating: values.rating ? Number(values.rating) : null,
    coach_rating: values.coach_rating ? Number(values.coach_rating) : null,
    notes: values.notes || null,
  };
}

export function MatchPlayerForm({
  perf,
  availablePlayers,
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  perf?: MatchPlayerPerformance | null;
  availablePlayers: Player[];
  onSubmit: (values: MatchPlayerFormValues) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}) {
  const [values, setValues] = useState<MatchPlayerFormValues>(toFormValues(perf));
  const { t } = useLanguage();

  function set<K extends keyof MatchPlayerFormValues>(key: K, value: MatchPlayerFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {!perf && (
        <Select
          label={t("matchPlayerForm.playerRequired")}
          required
          value={values.player_id}
          onChange={(e) => set("player_id", e.target.value)}
        >
          <option value="">{t("matchPlayerForm.selectPlayer")}</option>
          {availablePlayers.map((p) => (
            <option key={p.id} value={p.id}>
              {p.first_name} {p.last_name}
              {p.player_number != null ? ` (#${p.player_number})` : ""}
            </option>
          ))}
        </Select>
      )}

      <div className="grid grid-cols-3 gap-4">
        <Select
          label={t("matchPlayerForm.participation")}
          value={values.is_starting ? "starting" : "sub"}
          onChange={(e) => set("is_starting", e.target.value === "starting")}
        >
          <option value="starting">{t("matchPlayerForm.starting")}</option>
          <option value="sub">{t("matchPlayerForm.substitute")}</option>
        </Select>
        <Select
          label={t("matchPlayerForm.positionInMatch")}
          value={values.position_played}
          onChange={(e) => set("position_played", e.target.value as PlayerPosition | "")}
        >
          <option value="">—</option>
          {POSITIONS.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </Select>
        <Input
          label={t("matchPlayerForm.minutesPlayed")}
          type="number"
          value={values.minutes_played}
          onChange={(e) => set("minutes_played", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-5 gap-3">
        <Input label={t("performance.goals")} type="number" value={values.goals} onChange={(e) => set("goals", e.target.value)} />
        <Input
          label={t("performance.assists")}
          type="number"
          value={values.assists}
          onChange={(e) => set("assists", e.target.value)}
        />
        <Input
          label={t("playerStatsForm.yellowCards")}
          type="number"
          value={values.yellow_cards}
          onChange={(e) => set("yellow_cards", e.target.value)}
        />
        <Input
          label={t("playerStatsForm.redCards")}
          type="number"
          value={values.red_cards}
          onChange={(e) => set("red_cards", e.target.value)}
        />
        <Input label={t("matchPlayerForm.fouls")} type="number" value={values.fouls} onChange={(e) => set("fouls", e.target.value)} />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label={t("matchPlayerForm.rating")}
          type="number"
          step="0.1"
          value={values.rating}
          onChange={(e) => set("rating", e.target.value)}
        />
        <Input
          label={t("matchPlayerForm.coachRating")}
          type="number"
          step="0.1"
          value={values.coach_rating}
          onChange={(e) => set("coach_rating", e.target.value)}
        />
      </div>

      <Textarea
        label={t("calendar.notes")}
        placeholder={t("matchPlayerForm.notesPlaceholder")}
        value={values.notes}
        onChange={(e) => set("notes", e.target.value)}
      />

      <div className="flex justify-end gap-2 pt-2">
        <Button type="button" variant="secondary" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" isLoading={isSubmitting}>
          {t("common.save")}
        </Button>
      </div>
    </form>
  );
}
