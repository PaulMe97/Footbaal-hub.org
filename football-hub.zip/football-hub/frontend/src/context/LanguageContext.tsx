import { createContext, useContext, useEffect, useState, ReactNode } from "react";

import { Language, translations } from "../i18n/translations";
import { setStoredLanguage } from "../i18n/languageStore";

interface LanguageContextValue {
  language: Language;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

function getInitialLanguage(): Language {
  const stored = localStorage.getItem("fh_language");
  if (stored === "en" || stored === "el") return stored;
  return "el";
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(getInitialLanguage);

  useEffect(() => {
    localStorage.setItem("fh_language", language);
    document.documentElement.setAttribute("lang", language);
    setStoredLanguage(language);
  }, [language]);

  function toggleLanguage() {
    setLanguage((l) => (l === "el" ? "en" : "el"));
  }

  function t(key: string): string {
    // Λείπον κλειδί στη σελίδα που ζητήθηκε -> fallback στα ελληνικά (δεν
    // έχει μεταφραστεί ακόμα η συγκεκριμένη σελίδα) -> τελικό fallback το
    // ίδιο το κλειδί, ώστε να είναι εμφανές στη διάρκεια της ανάπτυξης.
    return translations[language][key] ?? translations.el[key] ?? key;
  }

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>{children}</LanguageContext.Provider>
  );
}

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider");
  return ctx;
}
