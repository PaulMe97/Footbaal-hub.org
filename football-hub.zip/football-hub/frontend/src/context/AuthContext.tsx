import { createContext, useContext, useEffect, useState, ReactNode } from "react";

import { fetchMe, login as apiLogin } from "../api/auth";
import type { User } from "../types";

interface AuthContextValue {
  user: User | null;
  isLoading: boolean;
  login: (usernameOrEmail: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (user: User) => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("fh_token");
    if (!token) {
      setIsLoading(false);
      return;
    }
    fetchMe()
      .then((u) => setUser(u))
      .catch(() => {
        localStorage.removeItem("fh_token");
        localStorage.removeItem("fh_user");
      })
      .finally(() => setIsLoading(false));
  }, []);

  async function login(usernameOrEmail: string, password: string) {
    const res = await apiLogin(usernameOrEmail, password);
    localStorage.setItem("fh_token", res.access_token);
    localStorage.setItem("fh_user", JSON.stringify(res.user));
    localStorage.setItem("fh_login_at", new Date().toISOString());
    setUser(res.user);
  }

  function logout() {
    localStorage.removeItem("fh_token");
    localStorage.removeItem("fh_user");
    localStorage.removeItem("fh_login_at");
    setUser(null);
  }

  function updateUser(updated: User) {
    localStorage.setItem("fh_user", JSON.stringify(updated));
    setUser(updated);
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
