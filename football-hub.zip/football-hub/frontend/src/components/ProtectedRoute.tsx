import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext";
import { Spinner } from "./ui/EmptyState";

export function ProtectedRoute({
  children,
  blockedRoles = [],
}: {
  children: ReactNode;
  /** Ρόλοι που ΔΕΝ επιτρέπεται να δουν αυτή τη σελίδα — ανακατευθύνονται στο Dashboard. */
  blockedRoles?: string[];
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-void">
        <Spinner />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (blockedRoles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
