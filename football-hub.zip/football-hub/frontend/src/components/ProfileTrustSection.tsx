import { FormEvent, useEffect, useRef, useState } from "react";

import { extractErrorMessage } from "../api/client";
import { updateLinkedIn } from "../api/profile";
import { deleteMyDocument, getMyVerificationStatus, uploadVerificationDocument } from "../api/verification";
import type { VerificationDocumentItem, VerificationStatus } from "../api/verification";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../context/LanguageContext";
import { VERIFICATION_DOCUMENT_TYPE_LABELS, VERIFICATION_LEVEL_INFO } from "../types";
import { Button } from "./ui/Button";
import { Card } from "./ui/Card";
import { Input, Select } from "./ui/Input";
import { useToast } from "./ui/Toast";

const ALL_DOCUMENT_TYPES = Object.keys(VERIFICATION_DOCUMENT_TYPE_LABELS);
const CLUB_LEADERSHIP_ROLES = ["president", "technical_director"];

function DocumentStatusBadge({
  status,
  autoVerified,
  t,
}: {
  status: string;
  autoVerified?: boolean;
  t: (key: string) => string;
}) {
  if (status === "approved" && autoVerified) {
    return (
      <span className="rounded-full bg-chalk/15 px-2 py-0.5 text-xs text-chalk">
        {t("profileTrust.autoVerifiedBadge")}
      </span>
    );
  }
  if (status === "approved") {
    return (
      <span className="rounded-full bg-status-fit/15 px-2 py-0.5 text-xs text-status-fit">
        {t("profileTrust.documentApproved")}
      </span>
    );
  }
  if (status === "rejected") {
    return (
      <span className="rounded-full bg-status-injured/15 px-2 py-0.5 text-xs text-status-injured">
        {t("profileTrust.documentRejected")}
      </span>
    );
  }
  return (
    <span className="rounded-full bg-status-doubtful/15 px-2 py-0.5 text-xs text-status-doubtful">
      {t("profileTrust.documentPending")}
    </span>
  );
}

export function ProfileTrustSection() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [linkedinUrl, setLinkedinUrl] = useState(user?.linkedin_url || "");
  const [showLinkedin, setShowLinkedin] = useState(user?.show_linkedin || false);
  const [isSavingLinkedin, setIsSavingLinkedin] = useState(false);

  const [status, setStatus] = useState<VerificationStatus | null>(null);
  const isClubLeadership = !!user?.role && CLUB_LEADERSHIP_ROLES.includes(user.role);
  const DOCUMENT_TYPES = isClubLeadership
    ? ALL_DOCUMENT_TYPES
    : ALL_DOCUMENT_TYPES.filter((d) => d !== "club_registration");
  const [docType, setDocType] = useState(ALL_DOCUMENT_TYPES[0]);
  const [consent, setConsent] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  async function loadStatus() {
    try {
      const data = await getMyVerificationStatus();
      setStatus(data);
      if (user && (data.verification_level !== user.verification_level || data.club_verified !== user.club_verified)) {
        updateUser({ ...user, verification_level: data.verification_level, club_verified: data.club_verified });
      }
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  useEffect(() => {
    if (user?.role === "player") return;
    loadStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSaveLinkedin(e: FormEvent) {
    e.preventDefault();
    setIsSavingLinkedin(true);
    try {
      const updated = await updateLinkedIn(linkedinUrl, showLinkedin);
      updateUser(updated);
      toast.show(t("profileTrust.linkedinUpdated"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSavingLinkedin(false);
    }
  }

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!consent) {
      toast.show(t("profileTrust.consentRequired"), "error");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    setIsUploading(true);
    try {
      const uploaded = await uploadVerificationDocument(docType, file, consent);
      if (uploaded.auto_verified) {
        toast.show(
          docType === "club_registration" ? t("profileTrust.clubAutoVerifiedToast") : t("profileTrust.autoVerifiedToast"),
          "success"
        );
      } else {
        toast.show(t("profileTrust.documentUploaded"), "success");
      }
      loadStatus();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleDelete(doc: VerificationDocumentItem) {
    try {
      await deleteMyDocument(doc.id);
      toast.show(t("profileTrust.documentDeleted"), "success");
      loadStatus();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    }
  }

  if (!user) return null;

  return (
    <>
      {/* LinkedIn */}
      <Card className="p-5">
        <h3 className="mb-3 font-display text-sm uppercase tracking-wide text-text-muted">LinkedIn</h3>
        <form onSubmit={handleSaveLinkedin} className="space-y-3">
          <Input
            label={t("profileTrust.linkedinProfileLink")}
            placeholder="https://www.linkedin.com/in/..."
            value={linkedinUrl}
            onChange={(e) => setLinkedinUrl(e.target.value)}
          />
          <label className="flex items-center gap-2 text-sm text-text-primary">
            <input
              type="checkbox"
              checked={showLinkedin}
              onChange={(e) => setShowLinkedin(e.target.checked)}
              className="h-4 w-4 accent-chalk"
            />
            {t("profileTrust.showInScouting")}
          </label>
          <Button type="submit" isLoading={isSavingLinkedin}>
            {t("common.save")}
          </Button>
        </form>
      </Card>

      {/* Verification */}
      {user.role !== "player" && status && (
        <Card corners className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">
              {t("profileTrust.trustVerification")}
            </h3>
            <span
              className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs ${VERIFICATION_LEVEL_INFO[status.verification_level].color}`}
            >
              <span className={`h-2 w-2 rounded-full ${VERIFICATION_LEVEL_INFO[status.verification_level].dot}`} />
              {VERIFICATION_LEVEL_INFO[status.verification_level].label}
            </span>
          </div>
          {isClubLeadership && (
            <p
              className={`mb-3 rounded-md border px-3 py-2 text-xs ${
                user.club_verified
                  ? "border-status-fit/30 bg-status-fit/10 text-status-fit"
                  : "border-status-doubtful/30 bg-status-doubtful/10 text-status-doubtful"
              }`}
            >
              {user.club_verified
                ? t("profileTrust.clubVerifiedBanner")
                : t("profileTrust.clubNotVerifiedBanner")}
            </p>
          )}
          <p className="mb-3 text-xs text-text-muted">
            {t("profileTrust.uploadDocsIntro")}{" "}
            <span className="text-text-primary">{status.max_simultaneous_teams}</span>.
          </p>

          {status.documents.length > 0 && (
            <div className="mb-4 space-y-1.5">
              {status.documents.map((d) => (
                <div
                  key={d.id}
                  className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-1.5 text-sm"
                >
                  <div>
                    <span className="text-text-primary">{VERIFICATION_DOCUMENT_TYPE_LABELS[d.document_type]}</span>
                    {d.rejection_reason && (
                      <p className="text-xs text-status-injured">{t("profileTrust.reasonPrefix")}{d.rejection_reason}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <DocumentStatusBadge status={d.status} autoVerified={d.auto_verified} t={t} />
                    {d.status !== "approved" && (
                      <button
                        onClick={() => handleDelete(d)}
                        className="text-xs text-status-injured hover:underline"
                      >
                        {t("common.delete")}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-2 rounded-md border border-line bg-surface-raised p-3">
            <Select label={t("profileTrust.documentType")} value={docType} onChange={(e) => setDocType(e.target.value)}>
              {DOCUMENT_TYPES.map((docTypeOption) => (
                <option key={docTypeOption} value={docTypeOption}>
                  {VERIFICATION_DOCUMENT_TYPE_LABELS[docTypeOption]}
                </option>
              ))}
            </Select>
            <label className="flex items-start gap-2 text-xs text-text-muted">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-0.5 h-3.5 w-3.5 accent-chalk"
              />
              <span>{t("profileTrust.consentText")}</span>
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,application/pdf"
              onChange={handleUpload}
              disabled={isUploading}
              className="w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-text-primary file:mr-3 file:rounded-md file:border-0 file:bg-surface-raised file:px-3 file:py-1.5 file:text-xs file:text-text-primary disabled:opacity-50"
            />
          </div>
        </Card>
      )}
    </>
  );
}
