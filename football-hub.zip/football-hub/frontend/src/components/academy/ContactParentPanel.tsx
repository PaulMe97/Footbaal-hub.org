import { useState } from "react";

import type { AcademyPlayerDetail, AcademyPlayerSummary } from "../../api/academy";
import { useLanguage } from "../../context/LanguageContext";
import { buildMessageTemplates, copyToClipboard, normalizePhone, viberChatLink } from "../../utils/academyMessages";
import { useToast } from "../ui/Toast";

export function ContactParentPanel({
  player,
  dueDay,
}: {
  player: AcademyPlayerSummary | AcademyPlayerDetail;
  dueDay: number;
}) {
  const toast = useToast();
  const { t } = useLanguage();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!player.parent_phone) {
    return (
      <p className="text-xs text-text-muted">{t("contactParent.noPhoneOnFile")}</p>
    );
  }

  const templates = buildMessageTemplates(player, dueDay);

  async function handleCopy(text: string, idx: number) {
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedIndex(idx);
      setTimeout(() => setCopiedIndex(null), 2000);
    } else {
      toast.show(t("contactParent.copyFailed"), "error");
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between rounded-md border border-line bg-surface-raised px-3 py-2">
        <div>
          <p className="text-xs text-text-muted">{t("contactParent.parentPhone")}</p>
          <p className="text-sm text-text-primary">
            {player.parent_name ? `${player.parent_name} · ` : ""}
            {normalizePhone(player.parent_phone)}
          </p>
        </div>
        <a
          href={viberChatLink(player.parent_phone)}
          className="rounded-md bg-chalk px-3 py-1.5 text-xs font-medium text-void hover:opacity-90"
        >
          {t("contactParent.viberButton")}
        </a>
      </div>

      {templates.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-medium text-text-muted">{t("contactParent.readyMessages")}</p>
          {templates.map((template, idx) => (
            <div key={idx} className="rounded-md border border-line bg-surface-raised p-2.5">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="text-xs font-medium text-chalk">{template.label}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(template.text, idx)}
                    className="text-[11px] text-text-muted hover:text-text-primary"
                  >
                    {copiedIndex === idx ? t("contactParent.copied") : t("contactParent.copy")}
                  </button>
                  <a
                    href={viberChatLink(player.parent_phone!, template.text)}
                    className="text-[11px] text-chalk hover:underline"
                  >
                    {t("contactParent.send")}
                  </a>
                </div>
              </div>
              <p className="text-xs text-text-muted">{template.text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
