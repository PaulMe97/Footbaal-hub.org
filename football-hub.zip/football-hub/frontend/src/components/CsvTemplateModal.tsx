import { Modal } from "./ui/Modal";
import { Button } from "./ui/Button";
import { useLanguage } from "../context/LanguageContext";

interface TemplateField {
  labelKey: string;
  example: string;
  required: "yes" | "no" | "alt";
  noteKey?: string;
}

const FIELDS: TemplateField[] = [
  { labelKey: "csvTemplate.fieldFirstName", example: "Γιάννης", required: "yes" },
  { labelKey: "csvTemplate.fieldLastName", example: "Παπαδόπουλος", required: "yes" },
  { labelKey: "csvTemplate.fieldFullName", example: "Γιάννης Παπαδόπουλος", required: "alt", noteKey: "csvTemplate.noteFullNameAlt" },
  { labelKey: "csvTemplate.fieldNumber", example: "10", required: "no" },
  { labelKey: "csvTemplate.fieldPosition", example: "Επιθετικός", required: "no", noteKey: "csvTemplate.notePositionValues" },
  { labelKey: "csvTemplate.fieldDob", example: "2000-05-15", required: "no", noteKey: "csvTemplate.noteDateFormat" },
  { labelKey: "csvTemplate.fieldAge", example: "24", required: "no", noteKey: "csvTemplate.noteAgeAlt" },
  { labelKey: "csvTemplate.fieldNationality", example: "Ελλάδα", required: "no" },
  { labelKey: "csvTemplate.fieldFoot", example: "Δεξί", required: "no", noteKey: "csvTemplate.noteFootValues" },
  { labelKey: "csvTemplate.fieldHeight", example: "180", required: "no" },
  { labelKey: "csvTemplate.fieldWeight", example: "75", required: "no" },
  { labelKey: "csvTemplate.fieldPhone", example: "6912345678", required: "no" },
  { labelKey: "csvTemplate.fieldEmail", example: "giannis@email.com", required: "no" },
];

const SAMPLE_HEADERS = [
  "Όνομα",
  "Επώνυμο",
  "Νούμερο",
  "Θέση",
  "Ημερομηνία Γέννησης",
  "Εθνικότητα",
  "Πόδι",
  "Ύψος",
  "Βάρος",
  "Τηλέφωνο",
  "Email",
];
const SAMPLE_ROWS = [
  ["Γιάννης", "Παπαδόπουλος", "10", "Επιθετικός", "2000-05-15", "Ελλάδα", "Δεξί", "180", "75", "6912345678", "giannis@email.com"],
  ["Νίκος", "Ιωάννου", "4", "Κεντρικός Αμυντικός", "1998-11-02", "Ελλάδα", "Αριστερό", "185", "80", "", ""],
];

function downloadSampleCsv() {
  const csvLines = [SAMPLE_HEADERS.join(","), ...SAMPLE_ROWS.map((row) => row.join(","))];
  const csvContent = "\uFEFF" + csvLines.join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "player_import_template.csv";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function CsvTemplateModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { t } = useLanguage();

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t("csvTemplate.modalTitle")} wide>
      <p className="mb-4 text-sm text-text-muted">{t("csvTemplate.intro")}</p>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line text-xs uppercase tracking-wide text-text-muted">
              <th className="pb-2 pr-3">{t("csvTemplate.colField")}</th>
              <th className="pb-2 pr-3">{t("csvTemplate.colExample")}</th>
              <th className="pb-2 pr-3">{t("csvTemplate.colRequired")}</th>
              <th className="pb-2">{t("csvTemplate.colNotes")}</th>
            </tr>
          </thead>
          <tbody>
            {FIELDS.map((field) => (
              <tr key={field.labelKey} className="border-b border-line last:border-0">
                <td className="py-2 pr-3 text-text-primary">{t(field.labelKey)}</td>
                <td className="py-2 pr-3 font-mono text-xs text-text-muted">{field.example}</td>
                <td className="py-2 pr-3">
                  {field.required === "yes" ? (
                    <span className="rounded-full border border-chalk/40 bg-chalk/10 px-2 py-0.5 text-[10px] text-chalk">
                      {t("csvTemplate.yes")}
                    </span>
                  ) : field.required === "alt" ? (
                    <span className="rounded-full border border-line px-2 py-0.5 text-[10px] text-text-muted">
                      {t("csvTemplate.alternative")}
                    </span>
                  ) : (
                    <span className="text-xs text-text-muted">{t("csvTemplate.no")}</span>
                  )}
                </td>
                <td className="py-2 text-xs text-text-muted">{field.noteKey ? t(field.noteKey) : ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex justify-end">
        <Button variant="secondary" onClick={downloadSampleCsv}>
          {t("csvTemplate.downloadSample")}
        </Button>
      </div>
    </Modal>
  );
}
