import { mediaUrl } from "../api/client";
import type { LeagueTier, Team } from "../types";
import { LEAGUE_TIER_LABELS } from "../types";
import { Card } from "./ui/Card";

export function TeamPickerGrid({ teams, onSelect }: { teams: Team[]; onSelect: (teamId: string) => void }) {
  const sorted = [...teams].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {sorted.map((team) => (
        <button key={team.id} onClick={() => onSelect(team.id)} className="text-left">
          <Card corners className="flex flex-col p-5 transition-colors hover:border-chalk">
            <div className="flex items-start gap-3">
              <div
                className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-line bg-surface-raised font-display text-sm"
                style={{ borderColor: team.primary_color || undefined }}
              >
                {team.logo_path ? (
                  <img src={mediaUrl(team.logo_path)} alt="" className="h-full w-full object-cover" />
                ) : (
                  team.name.slice(0, 2).toUpperCase()
                )}
              </div>
              <div className="min-w-0">
                <p className="font-display text-base text-text-primary">{team.name}</p>
                <p className="truncate text-xs text-text-muted">
                  {[team.category, team.league_level_name, team.season].filter(Boolean).join(" · ") || "—"}
                </p>
                <div className="mt-1 flex flex-wrap items-center gap-1.5">
                  {team.league_tier && (
                    <span className="rounded-full border border-chalk/40 bg-chalk/10 px-2 py-0.5 text-[10px] text-chalk">
                      {LEAGUE_TIER_LABELS[team.league_tier as LeagueTier] || team.league_tier}
                    </span>
                  )}
                  {team.federation_name && (
                    <span className="truncate text-[10px] text-text-muted">{team.federation_name}</span>
                  )}
                </div>
              </div>
            </div>
            <div className="mt-4 border-t border-line pt-3 text-sm text-text-muted">
              <span className="font-mono text-text-primary">{team.player_count}</span> παίκτες
            </div>
          </Card>
        </button>
      ))}
    </div>
  );
}
