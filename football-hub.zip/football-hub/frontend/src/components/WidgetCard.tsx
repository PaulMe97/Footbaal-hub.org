import type { ReactNode } from "react";

import { Card } from "./ui/Card";
import { useContextMenu } from "./ui/ContextMenu";
import { useLanguage } from "../context/LanguageContext";

export function WidgetCard({
  id,
  title,
  icon,
  onHide,
  onRefresh,
  headerAction,
  children,
  className = "",
}: {
  id: string;
  title: string;
  icon?: string;
  onHide: (id: string) => void;
  onRefresh?: () => void;
  headerAction?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const { t } = useLanguage();
  const menu = useContextMenu();

  return (
    <Card
      corners
      className={`p-4 ${className}`}
      onContextMenu={(e) =>
        menu.open(e, [
          {
            heading: title,
            items: [
              ...(onRefresh ? [{ label: t("dashboard.refresh"), onClick: onRefresh }] : []),
              { label: t("dashboard.hideWidget"), onClick: () => onHide(id), danger: true },
            ],
          },
        ])
      }
    >
      <div className="mb-2 flex items-center justify-between">
        <h3 className="font-display text-xs uppercase tracking-wide text-text-muted">
          {icon} {title}
        </h3>
        {headerAction}
      </div>
      {children}
      {menu.render()}
    </Card>
  );
}
