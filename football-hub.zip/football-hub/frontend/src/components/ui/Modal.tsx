import { ReactNode, useEffect } from "react";
import { createPortal } from "react-dom";

import { useLanguage } from "../../context/LanguageContext";

export function Modal({
  isOpen,
  onClose,
  title,
  children,
  wide = false,
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  const { t } = useLanguage();
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    if (isOpen) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-void/80 backdrop-blur-sm p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-[85vh] overflow-y-auto rounded-lg border border-line bg-surface shadow-2xl`}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <h2 className="font-display text-lg text-text-primary">{title}</h2>
          <button
            onClick={onClose}
            aria-label={t("modal.close")}
            className="rounded-md p-1 text-text-muted hover:bg-surface-raised hover:text-text-primary"
          >
            ✕
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>,
    document.body
  );
}

export function ConfirmDialog({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel,
  isLoading = false,
}: {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  isLoading?: boolean;
}) {
  const { t } = useLanguage();
  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <p className="text-sm text-text-muted">{message}</p>
      <div className="mt-5 flex justify-end gap-2">
        <button
          onClick={onClose}
          className="rounded-md border border-line px-4 py-2 text-sm text-text-primary hover:bg-surface-raised"
        >
          {t("common.cancel")}
        </button>
        <button
          onClick={onConfirm}
          disabled={isLoading}
          className="rounded-md border border-status-injured/40 bg-status-injured/15 px-4 py-2 text-sm text-status-injured hover:bg-status-injured/25 disabled:opacity-50"
        >
          {isLoading ? t("modal.deletingEllipsis") : confirmLabel ?? t("common.delete")}
        </button>
      </div>
    </Modal>
  );
}
