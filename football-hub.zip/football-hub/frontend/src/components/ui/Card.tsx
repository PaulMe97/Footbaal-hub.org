import { HTMLAttributes, ReactNode } from "react";

export function Card({
  className = "",
  children,
  corners = false,
  ...props
}: HTMLAttributes<HTMLDivElement> & { corners?: boolean }) {
  return (
    <div
      className={`rounded-lg border border-line bg-surface ${corners ? "corner-card" : ""} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-line px-4 py-3">
      <h3 className="font-display text-sm uppercase tracking-wide text-text-muted">{title}</h3>
      {action}
    </div>
  );
}
