import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

export interface ContextMenuItem {
  label: string;
  onClick: () => void;
  danger?: boolean;
  disabled?: boolean;
}

export interface ContextMenuSection {
  heading?: string;
  items: ContextMenuItem[];
}

interface ContextMenuState {
  x: number;
  y: number;
  sections: ContextMenuSection[];
}

/**
 * Hook: returns [menuState, open(e, sections), close, MenuPortal]
 * Usage:
 *   const menu = useContextMenu();
 *   <div onContextMenu={(e) => menu.open(e, [{ items: [...] }])}>...</div>
 *   {menu.render()}
 */
export function useContextMenu() {
  const [state, setState] = useState<ContextMenuState | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  function open(e: { preventDefault: () => void; clientX: number; clientY: number }, sections: ContextMenuSection[]) {
    e.preventDefault();
    setState({ x: e.clientX, y: e.clientY, sections });
  }

  function close() {
    setState(null);
  }

  useEffect(() => {
    if (!state) return;
    function onDocClick(ev: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(ev.target as Node)) {
        close();
      }
    }
    function onKey(ev: KeyboardEvent) {
      if (ev.key === "Escape") close();
    }
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  function render() {
    if (!state) return null;
    const width = 220;
    const x = Math.min(state.x, window.innerWidth - width - 8);
    const y = Math.min(state.y, window.innerHeight - 8);
    return createPortal(
      <div
        ref={menuRef}
        style={{ left: x, top: y }}
        className="fixed z-50 w-56 rounded-md border border-line bg-surface-raised py-1 shadow-2xl"
      >
        {state.sections.map((section, si) => (
          <div key={si} className={si > 0 ? "border-t border-line" : ""}>
            {section.heading && (
              <p className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-wide text-text-muted">
                {section.heading}
              </p>
            )}
            {section.items.map((item, ii) => (
              <button
                key={ii}
                disabled={item.disabled}
                onClick={() => {
                  item.onClick();
                  close();
                }}
                className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-void disabled:cursor-not-allowed disabled:opacity-40 ${
                  item.danger ? "text-status-injured" : "text-text-primary"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </div>,
      document.body
    );
  }

  return { open, close, render, isOpen: !!state };
}
