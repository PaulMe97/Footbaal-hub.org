import type { ReactNode } from "react";

import type { PlayerStatus } from "../../types";
import { STATUS_LABELS } from "../../types";

const statusColorMap: Record<PlayerStatus, string> = {
  fit: "bg-status-fit/15 text-status-fit border-status-fit/40",
  injured: "bg-status-injured/15 text-status-injured border-status-injured/40",
  doubtful: "bg-status-doubtful/15 text-status-doubtful border-status-doubtful/40",
  suspended: "bg-status-suspended/15 text-status-suspended border-status-suspended/40",
  unavailable: "bg-status-unavailable/15 text-status-unavailable border-status-unavailable/40",
};

export function StatusBadge({ status }: { status?: PlayerStatus | null }) {
  if (!status) return null;
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${statusColorMap[status]}`}
    >
      {STATUS_LABELS[status]}
    </span>
  );
}

export function Badge({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border border-line bg-surface-raised px-2.5 py-0.5 text-xs text-text-muted ${className}`}
    >
      {children}
    </span>
  );
}
