import { useEffect, useRef, useState } from "react";

import { useLanguage } from "../../context/LanguageContext";

const fieldBase =
  "w-full rounded-md bg-surface border border-line px-3 py-2 text-sm text-text-primary placeholder:text-text-muted/60 focus:border-chalk focus:outline-none transition-colors";

const WEEKDAY_LABELS_EL = ["Δε", "Τρ", "Τε", "Πε", "Πα", "Σα", "Κυ"];
const WEEKDAY_LABELS_EN = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
const MONTH_LABELS_EL = [
  "Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος",
  "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος",
];
const MONTH_LABELS_EN = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

/** ISO (YYYY-MM-DD) -> εμφανιζόμενο κείμενο (DD/MM/YYYY). */
function isoToDisplay(iso: string): string {
  if (!iso) return "";
  const parts = iso.split("-");
  if (parts.length !== 3) return "";
  const [y, m, d] = parts;
  if (!y || !m || !d) return "";
  return `${d}/${m}/${y}`;
}

/** Δέχεται ό,τι πληκτρολόγησε ο χρήστης (DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY)
 * και επιστρέφει ISO (YYYY-MM-DD) — ή null αν δεν είναι έγκυρη ημερομηνία. */
function displayToIso(display: string): string | null {
  const match = display.trim().match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/);
  if (!match) return null;
  const [, dRaw, mRaw, yRaw] = match;
  const day = Number(dRaw);
  const month = Number(mRaw);
  const year = Number(yRaw);
  if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1000 || year > 9999) return null;
  // Έλεγχος ότι η μέρα υπάρχει πραγματικά σε αυτόν τον μήνα/έτος (π.χ. όχι 31 Φεβρουαρίου).
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day > daysInMonth) return null;
  return `${yRaw}-${pad2(month)}-${pad2(day)}`;
}

export function DateField({
  label,
  value,
  onChange,
  required,
  min,
  max,
  placeholder,
  hint,
  className = "",
}: {
  label?: string;
  value: string;
  onChange: (isoDate: string) => void;
  required?: boolean;
  min?: string;
  max?: string;
  placeholder?: string;
  hint?: string;
  className?: string;
}) {
  const { language } = useLanguage();
  const weekdayLabels = language === "el" ? WEEKDAY_LABELS_EL : WEEKDAY_LABELS_EN;
  const monthLabels = language === "el" ? MONTH_LABELS_EL : MONTH_LABELS_EN;

  const [textValue, setTextValue] = useState(isoToDisplay(value));
  const [isOpen, setIsOpen] = useState(false);
  const today = new Date();
  const initialView = value ? new Date(value + "T00:00:00") : today;
  const [viewMonth, setViewMonth] = useState(initialView.getMonth());
  const [viewYear, setViewYear] = useState(initialView.getFullYear());
  const wrapperRef = useRef<HTMLDivElement>(null);

  // Συγχρονισμός με εξωτερικές αλλαγές του value (π.χ. reset φόρμας).
  useEffect(() => {
    setTextValue(isoToDisplay(value));
    if (value) {
      const d = new Date(value + "T00:00:00");
      if (!isNaN(d.getTime())) {
        setViewMonth(d.getMonth());
        setViewYear(d.getFullYear());
      }
    }
  }, [value]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [isOpen]);

  function handleTextChange(raw: string) {
    setTextValue(raw);
    const iso = displayToIso(raw);
    if (iso) onChange(iso);
    else if (raw.trim() === "") onChange("");
  }

  function handlePickDay(day: number) {
    const iso = `${viewYear}-${pad2(viewMonth + 1)}-${pad2(day)}`;
    onChange(iso);
    setTextValue(isoToDisplay(iso));
    setIsOpen(false);
  }

  function shiftMonth(delta: number) {
    let m = viewMonth + delta;
    let y = viewYear;
    if (m < 0) {
      m = 11;
      y -= 1;
    } else if (m > 11) {
      m = 0;
      y += 1;
    }
    setViewMonth(m);
    setViewYear(y);
  }

  const firstOfMonth = new Date(viewYear, viewMonth, 1);
  // Ελληνικό ημερολόγιο: εβδομάδα ξεκινά Δευτέρα. getDay(): 0=Κυρ..6=Σαβ.
  const leadingBlanks = (firstOfMonth.getDay() + 6) % 7;
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array(leadingBlanks).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const selectedIso = value || "";
  const minDate = min ? new Date(min + "T00:00:00") : null;
  const maxDate = max ? new Date(max + "T00:00:00") : null;

  const yearOptions: number[] = [];
  const centerYear = today.getFullYear();
  for (let y = centerYear + 5; y >= centerYear - 100; y--) yearOptions.push(y);

  return (
    <div ref={wrapperRef} className={`relative ${className}`}>
      {label && <span className="mb-1.5 block text-xs font-medium text-text-muted">{label}</span>}
      <div className="relative">
        <input
          type="text"
          className={fieldBase}
          value={textValue}
          onChange={(e) => handleTextChange(e.target.value)}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder || "DD/MM/YYYY"}
          required={required}
        />
        <button
          type="button"
          onClick={() => setIsOpen((v) => !v)}
          className="absolute inset-y-0 right-0 flex w-9 items-center justify-center text-text-muted hover:text-chalk"
          tabIndex={-1}
        >
          📅
        </button>
      </div>
      {hint && <span className="mt-1 block text-xs text-text-muted">{hint}</span>}

      {isOpen && (
        <div className="absolute z-30 mt-1 w-72 rounded-lg border border-line bg-surface p-3 shadow-2xl">
          <div className="mb-2 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => shiftMonth(-1)}
              className="rounded px-2 py-1 text-text-muted hover:bg-surface-raised hover:text-chalk"
            >
              ‹
            </button>
            <div className="flex flex-1 items-center justify-center gap-1.5">
              <span className="text-sm text-text-primary">{monthLabels[viewMonth]}</span>
              <select
                value={viewYear}
                onChange={(e) => setViewYear(Number(e.target.value))}
                className="rounded border border-line bg-surface px-1 py-0.5 text-xs text-text-primary"
              >
                {yearOptions.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => shiftMonth(1)}
              className="rounded px-2 py-1 text-text-muted hover:bg-surface-raised hover:text-chalk"
            >
              ›
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-text-muted">
            {weekdayLabels.map((w) => (
              <span key={w}>{w}</span>
            ))}
          </div>
          <div className="mt-1 grid grid-cols-7 gap-1">
            {cells.map((day, i) => {
              if (day === null) return <span key={i} />;
              const cellIso = `${viewYear}-${pad2(viewMonth + 1)}-${pad2(day)}`;
              const cellDate = new Date(viewYear, viewMonth, day);
              const isDisabled = (!!minDate && cellDate < minDate) || (!!maxDate && cellDate > maxDate);
              const isSelected = cellIso === selectedIso;
              const isToday =
                day === today.getDate() && viewMonth === today.getMonth() && viewYear === today.getFullYear();
              return (
                <button
                  key={i}
                  type="button"
                  disabled={isDisabled}
                  onClick={() => handlePickDay(day)}
                  className={`rounded py-1 text-xs transition-colors ${
                    isSelected
                      ? "bg-chalk text-void"
                      : isDisabled
                        ? "cursor-not-allowed text-text-muted/30"
                        : isToday
                          ? "border border-chalk text-chalk hover:bg-chalk/10"
                          : "text-text-primary hover:bg-surface-raised"
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
