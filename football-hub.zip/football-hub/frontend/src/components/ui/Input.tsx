import { InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

interface FieldWrapProps {
  label?: string;
  hint?: string;
}

const fieldBase =
  "w-full rounded-md bg-surface border border-line px-3 py-2 text-sm text-text-primary placeholder:text-text-muted/60 focus:border-chalk focus:outline-none transition-colors";

export function Input({
  label,
  hint,
  className = "",
  ...props
}: FieldWrapProps & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      {label && <span className="mb-1.5 block text-xs font-medium text-text-muted">{label}</span>}
      <input className={`${fieldBase} ${className}`} {...props} />
      {hint && <span className="mt-1 block text-xs text-text-muted">{hint}</span>}
    </label>
  );
}

export function Textarea({
  label,
  hint,
  className = "",
  ...props
}: FieldWrapProps & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <label className="block">
      {label && <span className="mb-1.5 block text-xs font-medium text-text-muted">{label}</span>}
      <textarea className={`${fieldBase} min-h-[90px] resize-y ${className}`} {...props} />
      {hint && <span className="mt-1 block text-xs text-text-muted">{hint}</span>}
    </label>
  );
}

export function Select({
  label,
  hint,
  className = "",
  children,
  ...props
}: FieldWrapProps & SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <label className="block">
      {label && <span className="mb-1.5 block text-xs font-medium text-text-muted">{label}</span>}
      <select className={`${fieldBase} ${className}`} {...props}>
        {children}
      </select>
      {hint && <span className="mt-1 block text-xs text-text-muted">{hint}</span>}
    </label>
  );
}
