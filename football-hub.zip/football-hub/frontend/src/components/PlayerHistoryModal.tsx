import { useEffect, useState } from "react";

import { extractErrorMessage } from "../api/client";
import { listAbsences } from "../api/absences";
import type { PlayerAbsenceItem } from "../api/absences";
import { getPlayerMatchHistory, listPlayerInjuries } from "../api/players";
import type { MatchHistoryEntry } from "../api/players";
import { ABSENCE_REASON_INFO } from "../types";
import type { Injury } from "../types";
import { useLanguage } from "../context/LanguageContext";
import { Modal } from "./ui/Modal";
import { Spinner } from "./ui/EmptyState";
import { useToast } from "./ui/Toast";

interface TimelineEntry {
  date: string;
  icon: string;
  color: string;
  title: string;
  detail: string;
}

export function PlayerHistoryModal({
  playerId,
  playerName,
  isOpen,
  onClose,
}: {
  playerId: string | null;
  playerName?: string;
  isOpen: boolean;
  onClose: () => void;
}) {
  const { t } = useLanguage();
  const toast = useToast();
  const [absences, setAbsences] = useState<PlayerAbsenceItem[]>([]);
  const [injuries, setInjuries] = useState<Injury[]>([]);
  const [matches, setMatches] = useState<MatchHistoryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isOpen || !playerId) return;
    setIsLoading(true);
    Promise.all([
      listAbsences({ player_id: playerId }),
      listPlayerInjuries(playerId),
      getPlayerMatchHistory(playerId),
    ])
      .then(([a, i, m]) => {
        setAbsences(a);
        setInjuries(i);
        setMatches(m);
      })
      .catch((err) => toast.show(extractErrorMessage(err), "error"))
      .finally(() => setIsLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, playerId]);

  const timeline: TimelineEntry[] = [];
  for (const a of absences) {
    const info = ABSENCE_REASON_INFO[a.reason];
    timeline.push({
      date: a.start_date,
      icon: info?.icon || "📋",
      color: info?.color || "text-text-muted border-line bg-surface-raised",
      title: info?.label || a.reason,
      detail: a.end_date ? `${a.start_date} → ${a.end_date}` : a.start_date,
    });
  }
  for (const inj of injuries) {
    timeline.push({
      date: inj.injury_date || inj.created_at,
      icon: "🩹",
      color: "text-status-injured border-status-injured/40 bg-status-injured/10",
      title: inj.injury_type || t("playerHistory.injuriesSection"),
      detail: inj.expected_return ? `${inj.injury_date} → ${inj.expected_return}` : inj.injury_date || "",
    });
  }
  for (const m of matches) {
    timeline.push({
      date: m.date,
      icon: "⚽",
      color: "text-chalk border-chalk/40 bg-chalk/10",
      title: `${t("playerHistory.matchVsPrefix")}${m.opponent || "—"}`,
      detail: `${m.goals}⚽ ${m.assists}🅰${m.rating ? ` · ${m.rating.toFixed(1)}⭐` : ""}`,
    });
  }
  timeline.sort((a, b) => (a.date < b.date ? 1 : -1));

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`${t("playerHistory.title")}${playerName ? ` — ${playerName}` : ""}`} wide>
      {isLoading ? (
        <Spinner />
      ) : timeline.length === 0 ? (
        <p className="text-sm text-text-muted">{t("playerHistory.noEntriesYet")}</p>
      ) : (
        <div className="max-h-[28rem] space-y-3 overflow-y-auto pr-1">
          {timeline.map((entry, i) => (
            <div key={i} className="flex items-start gap-3">
              <span
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-sm ${entry.color}`}
              >
                {entry.icon}
              </span>
              <div className="min-w-0 flex-1 border-b border-line pb-3 last:border-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm text-text-primary">{entry.title}</p>
                  <span className="shrink-0 text-xs text-text-muted">{entry.date}</span>
                </div>
                {entry.detail && <p className="text-xs text-text-muted">{entry.detail}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
