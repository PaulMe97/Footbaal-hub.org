import { useState } from "react";

import { extractErrorMessage } from "../api/client";
import { sendStaffAssignmentOffer } from "../api/staffOffers";
import { Button } from "./ui/Button";
import { Input, Select, Textarea } from "./ui/Input";
import { Modal } from "./ui/Modal";
import { useToast } from "./ui/Toast";
import type { Team } from "../types";
import { useLanguage } from "../context/LanguageContext";

export function StaffOfferModal({
  target,
  myTeams,
  onClose,
  onSent,
}: {
  target: { user_id: string; full_name: string } | null;
  myTeams: Team[];
  onClose: () => void;
  onSent?: () => void;
}) {
  const { t } = useLanguage();
  const toast = useToast();
  const [teamId, setTeamId] = useState("");
  const [roleTitle, setRoleTitle] = useState("");
  const [newRole, setNewRole] = useState("");
  const [season, setSeason] = useState("");
  const [incentive, setIncentive] = useState("");
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);

  const NEW_ROLE_OPTIONS = [
    { value: "technical_director", label: t("crm.roleTechnicalDirector") },
    { value: "head_coach", label: t("crm.roleHeadCoach") },
    { value: "assistant_coach", label: t("crm.roleAssistantCoach") },
    { value: "fitness_coach", label: t("crm.roleFitnessCoach") },
    { value: "analyst", label: t("crm.roleAnalyst") },
    { value: "scout", label: "Scout" },
  ];

  function reset() {
    setTeamId("");
    setRoleTitle("");
    setNewRole("");
    setSeason("");
    setIncentive("");
    setMessage("");
  }

  async function handleSend() {
    if (!target || !teamId) return;
    setIsSending(true);
    try {
      await sendStaffAssignmentOffer(teamId, {
        recipient_user_id: target.user_id,
        role_title: roleTitle || undefined,
        new_role: newRole || undefined,
        season: season || undefined,
        incentive_details: incentive || undefined,
        message: message || undefined,
      });
      toast.show(t("staff.offerSentToast"), "success");
      reset();
      onClose();
      onSent?.();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSending(false);
    }
  }

  return (
    <Modal isOpen={!!target} onClose={onClose} title={t("staff.newOfferModalTitle")}>
      {target && (
        <div className="space-y-4">
          <p className="text-sm text-text-muted">
            {t("staff.offerToPrefix")}
            <span className="text-text-primary">{target.full_name}</span>
            {t("staff.offerIntroSuffix")}
          </p>
          <Select label={t("crm.team")} value={teamId} onChange={(e) => setTeamId(e.target.value)}>
            <option value="">{t("crm.selectTeam")}</option>
            {myTeams.map((teamOpt) => (
              <option key={teamOpt.id} value={teamOpt.id}>
                {teamOpt.name}
              </option>
            ))}
          </Select>
          <Input
            label={t("staff.roleTitleOptional")}
            placeholder={t("staff.roleTitlePlaceholder")}
            value={roleTitle}
            onChange={(e) => setRoleTitle(e.target.value)}
          />
          <Select
            label={t("staff.accountRoleChangeOptional")}
            value={newRole}
            onChange={(e) => setNewRole(e.target.value)}
          >
            <option value="">{t("staff.noRoleChange")}</option>
            {NEW_ROLE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </Select>
          <Input
            label={t("staff.seasonOptional")}
            placeholder="2026-2027"
            value={season}
            onChange={(e) => setSeason(e.target.value)}
          />
          <Textarea
            label={t("staff.incentiveOptional")}
            placeholder={t("staff.incentivePlaceholder")}
            value={incentive}
            onChange={(e) => setIncentive(e.target.value)}
          />
          <Textarea label={t("staff.messageOptional")} value={message} onChange={(e) => setMessage(e.target.value)} />
          <div className="flex justify-end gap-2">
            <Button type="button" variant="secondary" onClick={onClose}>
              {t("common.cancel")}
            </Button>
            <Button type="button" onClick={handleSend} isLoading={isSending} disabled={!teamId}>
              {t("staff.sendOffer")}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
}
