import type { VideoAnnotationItem } from "../../api/videoAnalysis";

export type DrawTool =
  | "select"
  | "circle"
  | "arrow"
  | "line"
  | "rectangle"
  | "freehand"
  | "spotlight"
  | "text";

export interface Point {
  x: number;
  y: number;
}

/** Ένα σχήμα υπό σχεδίαση (draft) — πριν αποθηκευτεί ως annotation. */
export interface DraftShape {
  tool: DrawTool;
  start: Point;
  current: Point;
  points?: Point[];
  color: string;
}

function renderShape(
  shapeType: string,
  data: Record<string, unknown>,
  color: string,
  strokeWidth: number,
  key: string | number,
  maskId?: string
) {
  switch (shapeType) {
    case "circle": {
      const cx = Number(data.cx) * 100;
      const cy = Number(data.cy) * 100;
      const r = Number(data.r) * 100;
      return (
        <circle
          key={key}
          cx={`${cx}%`}
          cy={`${cy}%`}
          r={`${r}%`}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          vectorEffect="non-scaling-stroke"
        />
      );
    }
    case "rectangle": {
      const x = Number(data.x) * 100;
      const y = Number(data.y) * 100;
      const w = Number(data.width) * 100;
      const h = Number(data.height) * 100;
      return (
        <rect
          key={key}
          x={`${x}%`}
          y={`${y}%`}
          width={`${w}%`}
          height={`${h}%`}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          vectorEffect="non-scaling-stroke"
        />
      );
    }
    case "line": {
      const x1 = Number(data.x1) * 100;
      const y1 = Number(data.y1) * 100;
      const x2 = Number(data.x2) * 100;
      const y2 = Number(data.y2) * 100;
      return (
        <line
          key={key}
          x1={`${x1}%`}
          y1={`${y1}%`}
          x2={`${x2}%`}
          y2={`${y2}%`}
          stroke={color}
          strokeWidth={strokeWidth}
          vectorEffect="non-scaling-stroke"
        />
      );
    }
    case "arrow": {
      const x1 = Number(data.x1) * 100;
      const y1 = Number(data.y1) * 100;
      const x2 = Number(data.x2) * 100;
      const y2 = Number(data.y2) * 100;
      const markerId = `arrowhead-${key}`;
      return (
        <g key={key}>
          <defs>
            <marker
              id={markerId}
              markerWidth="8"
              markerHeight="8"
              refX="6"
              refY="4"
              orient="auto"
              markerUnits="strokeWidth"
            >
              <path d="M0,0 L8,4 L0,8 Z" fill={color} />
            </marker>
          </defs>
          <line
            x1={`${x1}%`}
            y1={`${y1}%`}
            x2={`${x2}%`}
            y2={`${y2}%`}
            stroke={color}
            strokeWidth={strokeWidth}
            vectorEffect="non-scaling-stroke"
            markerEnd={`url(#${markerId})`}
          />
        </g>
      );
    }
    case "freehand": {
      const points = (data.points as Point[]) || [];
      const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x * 100} ${p.y * 100}`).join(" ");
      return (
        <path
          key={key}
          d={path}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
        />
      );
    }
    case "text": {
      const x = Number(data.x) * 100;
      const y = Number(data.y) * 100;
      return (
        <text key={key} x={`${x}%`} y={`${y}%`} fill={color} fontSize="4%" fontWeight="bold" style={{ paintOrder: "stroke" }} stroke="#00000099" strokeWidth={3}>
          {String(data.text || "")}
        </text>
      );
    }
    case "spotlight": {
      const cx = Number(data.cx) * 100;
      const cy = Number(data.cy) * 100;
      const r = Number(data.r) * 100;
      return (
        <g key={key}>
          <mask id={maskId}>
            <rect x="0" y="0" width="100%" height="100%" fill="white" />
            <circle cx={`${cx}%`} cy={`${cy}%`} r={`${r}%`} fill="black" />
          </mask>
          <rect x="0" y="0" width="100%" height="100%" fill="black" opacity={0.65} mask={`url(#${maskId})`} />
        </g>
      );
    }
    default:
      return null;
  }
}

export function AnnotationOverlay({
  annotations,
  currentTime,
  draft,
}: {
  annotations: VideoAnnotationItem[];
  currentTime: number;
  draft: DraftShape | null;
}) {
  const visible = annotations.filter((a) => currentTime >= a.start_time && currentTime <= a.end_time);

  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
    >
      {visible.map((a) =>
        renderShape(a.shape_type, a.shape_data, (a.shape_data.color as string) || "#FFD400", 1, a.id, `mask-${a.id}`)
      )}
      {draft &&
        (() => {
          const data = draftToShapeData(draft);
          return data ? renderShape(draft.tool, data, draft.color, 1, "draft", "mask-draft") : null;
        })()}
    </svg>
  );
}

/** Μετατρέπει ένα DraftShape (υπό σχεδίαση, ζευγάρι start/current σημείων)
 * στο ίδιο shape_data format που αποθηκεύεται/επιστρέφεται από το backend
 * — ώστε το draft preview να ζωγραφίζεται με την ΙΔΙΑ λογική renderShape. */
export function draftToShapeData(draft: DraftShape): Record<string, unknown> | null {
  const { tool, start, current, points, color } = draft;
  switch (tool) {
    case "circle":
    case "spotlight": {
      const r = Math.hypot(current.x - start.x, current.y - start.y);
      return { cx: start.x, cy: start.y, r, color };
    }
    case "rectangle": {
      const x = Math.min(start.x, current.x);
      const y = Math.min(start.y, current.y);
      const width = Math.abs(current.x - start.x);
      const height = Math.abs(current.y - start.y);
      return { x, y, width, height, color };
    }
    case "line":
    case "arrow":
      return { x1: start.x, y1: start.y, x2: current.x, y2: current.y, color };
    case "freehand":
      return { points: points || [start, current], color };
    default:
      return null;
  }
}
