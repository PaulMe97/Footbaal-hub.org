import { useEffect, useState } from "react";

import { extractErrorMessage } from "../api/client";
import { getPendingRenewals, respondToRenewal } from "../api/renewals";
import type { RenewalRequestItem } from "../api/renewals";
import { useAuth } from "../context/AuthContext";
import { Button } from "./ui/Button";
import { Textarea } from "./ui/Input";
import { Modal } from "./ui/Modal";
import { useToast } from "./ui/Toast";
import { useLanguage } from "../context/LanguageContext";

export function RenewalPrompt() {
  const { user } = useAuth();
  const toast = useToast();
  const { t } = useLanguage();
  const [queue, setQueue] = useState<RenewalRequestItem[]>([]);
  const [checked, setChecked] = useState(false);
  const [showHoldReason, setShowHoldReason] = useState(false);
  const [holdReason, setHoldReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!user || checked) return;
    setChecked(true);
    getPendingRenewals()
      .then((data) => setQueue(data))
      .catch(() => {
        /* σιωπηλή αποτυχία — δεν μπλοκάρουμε τη σύνδεση για αυτό */
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const current = queue[0];

  async function handleDecision(decision: "accept" | "hold" | "reject") {
    if (!current) return;
    if (decision === "hold" && !showHoldReason) {
      setShowHoldReason(true);
      return;
    }
    if (decision === "hold" && !holdReason.trim()) {
      toast.show(t("renewalPrompt.writeShortReason"), "error");
      return;
    }
    setIsSubmitting(true);
    try {
      await respondToRenewal(current.id, decision, decision === "hold" ? holdReason.trim() : undefined);
      setQueue((prev) => prev.slice(1));
      setShowHoldReason(false);
      setHoldReason("");
      toast.show(t("renewalPrompt.responseRecorded"), "success");
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSubmitting(false);
    }
  }

  if (!current) return null;

  return (
    <Modal isOpen={true} onClose={() => {}} title={t("renewalPrompt.title")}>
      <div className="space-y-4">
        <p className="text-sm text-text-primary">
          {t("renewalPrompt.continuePrefix")}<span className="font-semibold text-chalk">{current.team_name}</span>{" "}
          {t("renewalPrompt.continueMiddle")}<span className="font-semibold">{current.next_season}</span>{t("renewalPrompt.continueSuffix")}
        </p>
        <p className="text-xs text-text-muted">
          {t("renewalPrompt.currentSeasonPrefix")}{current.current_season}{t("renewalPrompt.currentSeasonSuffix")}
        </p>

        {showHoldReason && (
          <Textarea
            label={t("renewalPrompt.reasonLabel")}
            value={holdReason}
            onChange={(e) => setHoldReason(e.target.value)}
            autoFocus
          />
        )}

        <div className="flex flex-col gap-2 sm:flex-row">
          <Button onClick={() => handleDecision("accept")} isLoading={isSubmitting} className="flex-1">
            {t("renewalPrompt.accept")}
          </Button>
          <Button
            variant="secondary"
            onClick={() => handleDecision("hold")}
            isLoading={isSubmitting}
            className="flex-1"
          >
            {t("renewalPrompt.hold")}
          </Button>
          <Button
            variant="danger"
            onClick={() => handleDecision("reject")}
            isLoading={isSubmitting}
            className="flex-1"
          >
            {t("renewalPrompt.reject")}
          </Button>
        </div>
        {showHoldReason && (
          <p className="text-xs text-text-muted">
            {t("renewalPrompt.holdHint")}
          </p>
        )}
      </div>
    </Modal>
  );
}
