export function AttributeBar({
  label,
  value,
  onChange,
  readOnly = false,
}: {
  label: string;
  value: number;
  onChange?: (value: number) => void;
  readOnly?: boolean;
}) {
  const segments = Array.from({ length: 10 }, (_, i) => i + 1);
  return (
    <div className="flex items-center gap-3 py-1">
      <span className="w-40 shrink-0 truncate text-sm text-text-primary">{label}</span>
      <div className="flex flex-1 gap-1">
        {segments.map((n) => (
          <button
            key={n}
            type="button"
            disabled={readOnly}
            onClick={() => onChange?.(n)}
            title={`${n}/10`}
            className={`h-3 flex-1 rounded-sm transition-colors ${
              readOnly ? "cursor-default" : "cursor-pointer hover:opacity-80"
            } ${n <= value ? "bg-chalk" : "bg-line"}`}
          />
        ))}
      </div>
      <span className="w-10 shrink-0 text-right font-mono text-sm text-text-primary">
        {value > 0 ? `${value}/10` : "—"}
      </span>
    </div>
  );
}
