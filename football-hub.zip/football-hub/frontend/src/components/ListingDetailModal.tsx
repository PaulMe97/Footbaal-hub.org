import type { TeamListingItem } from "../api/listings";
import { FootballPitchPositions } from "./FootballPitchPositions";
import { Button } from "./ui/Button";
import { Modal } from "./ui/Modal";
import { useLanguage } from "../context/LanguageContext";

export function ListingDetailModal({
  listing,
  onClose,
  onApply,
  isApplying = false,
  hasApplied = false,
}: {
  listing: TeamListingItem | null;
  onClose: () => void;
  onApply?: () => void;
  isApplying?: boolean;
  hasApplied?: boolean;
}) {
  const { t } = useLanguage();

  const roleLabels: Record<string, string> = {
    technical_director: t("scouting.roleTechnicalDirector"),
    head_coach: t("scouting.roleHeadCoach"),
    assistant_coach: t("scouting.roleAssistantCoach"),
    fitness_coach: t("scouting.roleFitnessCoach"),
    analyst: t("scouting.roleAnalyst"),
    scout: "Scout",
  };

  const title = listing
    ? listing.listing_type === "staff"
      ? t("scouting.lookingForStaff")
      : t("scouting.lookingForPlayer")
    : "";

  return (
    <Modal isOpen={!!listing} onClose={onClose} title={title}>
      {listing && (
        <div className="space-y-4">
          <div>
            <p className="text-sm text-text-primary">
              {listing.listing_type === "staff"
                ? listing.role_needed.map((r) => roleLabels[r] || r).join(", ") || t("scouting.staffFallback")
                : `${t("scouting.positionPrefix")}${listing.position_needed.join(", ") || t("scouting.anyOption")}`}
            </p>
            <p className="mt-1 text-xs text-text-muted">
              {listing.team_name}
              {listing.listing_type === "staff" && listing.season ? ` · ${listing.season}` : ""}
              {listing.listing_type === "staff" && listing.employment_type
                ? ` · ${listing.employment_type === "paid" ? t("scouting.employed") : t("scouting.practice")}`
                : ""}
              {listing.listing_type === "player" && (listing.min_age || listing.max_age)
                ? `${t("scouting.agePrefix")}${listing.min_age || "0"}-${listing.max_age || "+"}`
                : ""}
            </p>
          </div>

          {listing.listing_type === "player" && listing.position_needed.length > 0 && (
            <FootballPitchPositions positions={listing.position_needed} />
          )}

          {listing.target_federation_names.length > 0 && (
            <p className="text-xs text-text-muted">
              {t("teamListings.targetRegionsPrefix")}
              {listing.target_federation_names.join(", ")}
            </p>
          )}

          {listing.expires_at && (
            <p className="text-xs text-text-muted">
              {t("teamListings.expiresPrefixShort")}
              {new Date(listing.expires_at).toLocaleDateString("el-GR")}
            </p>
          )}

          {listing.description && (
            <p className="whitespace-pre-wrap text-sm text-text-muted">{listing.description}</p>
          )}

          {onApply && (
            <div className="flex justify-end pt-2">
              <Button onClick={onApply} isLoading={isApplying} disabled={hasApplied}>
                {hasApplied ? t("scouting.applicationSentBadge") : t("scouting.applyButton")}
              </Button>
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
