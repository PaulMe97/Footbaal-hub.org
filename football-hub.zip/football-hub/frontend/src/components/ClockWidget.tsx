import { useEffect, useState } from "react";

import { Card } from "./ui/Card";
import { useLanguage } from "../context/LanguageContext";

function formatSessionDuration(loginAtIso: string, hoursLabel: string, minutesLabel: string, justNowLabel: string): string {
  const loginAt = new Date(loginAtIso).getTime();
  const now = Date.now();
  const totalMinutes = Math.max(0, Math.floor((now - loginAt) / 60000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0 && minutes === 0) return justNowLabel;
  if (hours === 0) return `${minutes}${minutesLabel}`;
  return `${hours}${hoursLabel} ${minutes}${minutesLabel}`;
}

export function ClockWidget() {
  const { t, language } = useLanguage();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const locale = language === "el" ? "el-GR" : "en-US";
  const timeStr = now.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const loginAt = localStorage.getItem("fh_login_at");

  return (
    <Card corners className="flex flex-col items-center gap-1 bg-surface-raised p-4">
      <p className="font-mono text-3xl tabular-nums text-chalk">{timeStr}</p>
      <p className="text-xs capitalize text-text-muted">{dateStr}</p>
      {loginAt && (
        <p className="mt-1 text-[11px] text-text-muted">
          {t("clockWidget.sessionDurationLabel")}{" "}
          {formatSessionDuration(loginAt, t("clockWidget.hoursShort"), t("clockWidget.minutesShort"), t("clockWidget.justNow"))}
        </p>
      )}
    </Card>
  );
}
