import { FormEvent, useState } from "react";
import { useLocation } from "react-router-dom";

import { sendMelieMessage } from "../../api/melie";
import type { MelieChatMessage } from "../../api/melie";
import { extractErrorMessage } from "../../api/client";
import { useLanguage } from "../../context/LanguageContext";
import { useToast } from "../ui/Toast";

// Αντιστοιχίζει το τρέχον pathname σε section key — χρησιμοποιείται ΚΑΙ ως
// context key για το backend (βλ. routers/melie.py SECTION_INFO). Ελέγχει
// τα πιο συγκεκριμένα prefixes πρώτα.
function getSectionKey(pathname: string): string {
  const prefixMap: [string, string][] = [
    ["/teams", "teams"],
    ["/players", "players"],
    ["/matches", "matches"],
    ["/trainings", "trainings"],
    ["/calendar", "calendar"],
    ["/tactical-board", "tacticalBoard"],
    ["/reports", "reports"],
    ["/scouting", "scouting"],
    ["/messages", "messages"],
    ["/staff", "staff"],
    ["/academy", "academy"],
    ["/crm", "crm"],
    ["/notifications", "notifications"],
    ["/settings", "settings"],
    ["/profile", "profile"],
    ["/performance", "performance"],
  ];
  for (const [prefix, key] of prefixMap) {
    if (pathname.startsWith(prefix)) return key;
  }
  if (pathname === "/") return "dashboard";
  return "general";
}

export function MelieWidget() {
  const location = useLocation();
  const { t, language } = useLanguage();
  const toast = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<MelieChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);

  const sectionKey = getSectionKey(location.pathname);

  function handleOpen() {
    setIsOpen(true);
    if (messages.length === 0) {
      setMessages([{ role: "assistant", content: t("melie.welcomeMessage") }]);
    }
  }

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || isSending) return;
    const nextMessages: MelieChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setIsSending(true);
    try {
      const res = await sendMelieMessage(sectionKey, language, text, nextMessages);
      setMessages((prev) => [...prev, { role: "assistant", content: res.reply }]);
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsSending(false);
    }
  }

  return (
    <>
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-40 flex h-[28rem] w-80 max-w-[90vw] flex-col overflow-hidden rounded-lg border border-line bg-surface shadow-2xl">
          <div className="flex items-center justify-between border-b border-line bg-surface-raised px-4 py-3">
            <div>
              <p className="font-display text-sm text-text-primary">{t("melie.title")}</p>
              <p className="text-[11px] text-text-muted">{t("melie.subtitle")}</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              aria-label={t("modal.close")}
              className="rounded-md p-1 text-text-muted hover:bg-void hover:text-text-primary"
            >
              ✕
            </button>
          </div>

          <div className="flex-1 space-y-2 overflow-y-auto p-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] rounded-lg px-3 py-2 text-xs ${
                    m.role === "user"
                      ? "bg-chalk/15 text-text-primary"
                      : "bg-surface-raised text-text-primary"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {isSending && (
              <div className="flex justify-start">
                <div className="max-w-[85%] rounded-lg bg-surface-raised px-3 py-2 text-xs text-text-muted">
                  {t("melie.thinking")}
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSend} className="flex items-center gap-2 border-t border-line p-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t("melie.inputPlaceholder")}
              disabled={isSending}
              className="flex-1 rounded-md border border-line bg-surface-raised px-3 py-1.5 text-xs text-text-primary placeholder:text-text-muted focus:border-chalk focus:outline-none disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isSending || !input.trim()}
              className="rounded-md bg-chalk px-3 py-1.5 text-xs text-void disabled:opacity-50"
            >
              {t("melie.send")}
            </button>
          </form>
        </div>
      )}

      <button
        onClick={() => (isOpen ? setIsOpen(false) : handleOpen())}
        aria-label={t("melie.openAriaLabel")}
        className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full border border-chalk/40 bg-surface text-lg shadow-lg hover:border-chalk"
      >
        {isOpen ? "✕" : "💬"}
      </button>
    </>
  );
}
