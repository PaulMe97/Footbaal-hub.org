import { useEffect, useState } from "react";

import { getAdminContact } from "../../api/auth";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";

export function LeadershipApprovalBanner() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [emails, setEmails] = useState<string[]>([]);

  const needsApproval =
    !!user && ["president", "technical_director"].includes(user.role) && !user.leadership_approved;

  useEffect(() => {
    if (!needsApproval) return;
    getAdminContact()
      .then((res) => setEmails(res.emails))
      .catch(() => {
        /* σιωπηλή αποτυχία — το banner δείχνει το μήνυμα χωρίς email */
      });
  }, [needsApproval]);

  if (!needsApproval) return null;

  return (
    <div className="border-b border-status-doubtful/40 bg-status-doubtful/10 px-6 py-2.5">
      <p className="text-sm text-status-doubtful">
        <span className="font-semibold">{t("leadershipApproval.bannerTitle")}</span>{" "}
        {t("leadershipApproval.bannerBody")}{" "}
        {emails.length > 0 && <span className="font-semibold">{emails.join(", ")}</span>}
      </p>
    </div>
  );
}
