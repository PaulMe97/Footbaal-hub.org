import { DragEvent, useEffect, useMemo, useState } from "react";
import { Link, NavLink } from "react-router-dom";

import { getUnreadMessageCount } from "../../api/messages";
import { getGroupUnreadCount } from "../../api/groupMessages";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { useTheme } from "../../context/ThemeContext";

interface NavItem {
  to: string;
  labelKey: string;
  icon: string;
  disabled?: boolean;
  hiddenForRoles?: string[];
}

const items: NavItem[] = [
  { to: "/", labelKey: "nav.dashboard", icon: "◧" },
  { to: "/teams", labelKey: "nav.teams", icon: "▦" },
  { to: "/players", labelKey: "nav.players", icon: "☰" },
  { to: "/absences", labelKey: "nav.absences", icon: "🩹" },
  { to: "/matches", labelKey: "nav.matches", icon: "◎" },
  { to: "/trainings", labelKey: "nav.trainings", icon: "◈", hiddenForRoles: ["player"] },
  { to: "/calendar", labelKey: "nav.calendar", icon: "▤", hiddenForRoles: ["player"] },
  { to: "/tactical-board", labelKey: "nav.tacticalBoard", icon: "⛶", hiddenForRoles: ["player"] },
  { to: "/reports", labelKey: "nav.reports", icon: "▧", disabled: true, hiddenForRoles: ["player"] },
  { to: "/scouting", labelKey: "nav.scoutingHub", icon: "🌍" },
  { to: "/scout-reports", labelKey: "nav.scoutReports", icon: "📋", hiddenForRoles: ["player", "fitness_coach"] },
  { to: "/video-editing", labelKey: "nav.videoEditing", icon: "🎬", hiddenForRoles: ["player"] },
  { to: "/messages", labelKey: "nav.messages", icon: "💬" },
  { to: "/staff", labelKey: "nav.staff", icon: "👥", hiddenForRoles: ["player"] },
  {
    to: "/academy",
    labelKey: "nav.academy",
    icon: "🎓",
    hiddenForRoles: ["player", "assistant_coach", "fitness_coach", "analyst", "scout"],
  },
  { to: "/performance", labelKey: "nav.performance", icon: "📈" },
  {
    to: "/admin/users",
    labelKey: "nav.userManagement",
    icon: "🛡",
    hiddenForRoles: [
      "president",
      "technical_director",
      "head_coach",
      "assistant_coach",
      "fitness_coach",
      "analyst",
      "scout",
      "player",
    ],
  },
  { to: "/settings", labelKey: "nav.settings", icon: "⚙" },
];

const ORDER_STORAGE_KEY = "fh_sidebar_order_v1";

function loadCustomOrder(): string[] | null {
  try {
    const raw = localStorage.getItem(ORDER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveCustomOrder(order: string[]) {
  try {
    localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(order));
  } catch {
    /* localStorage μπορεί να μην είναι διαθέσιμο (π.χ. private browsing) —
       η αναδιάταξη απλά δεν θα επιμείνει, όχι κρίσιμο σφάλμα. */
  }
}

export function Sidebar() {
  const { theme, toggleTheme } = useTheme();
  const { language, toggleLanguage, t } = useLanguage();
  const { user } = useAuth();
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [isLocked, setIsLocked] = useState(true);
  const [customOrder, setCustomOrder] = useState<string[] | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  useEffect(() => {
    setCustomOrder(loadCustomOrder());
  }, []);

  const visibleItems = items.filter((item) => !user || !item.hiddenForRoles?.includes(user.role));

  // Εφαρμόζει την αποθηκευμένη, προσαρμοσμένη σειρά (αν υπάρχει) — στοιχεία
  // που δεν βρίσκονται ακόμα σε αυτήν (π.χ. νέο μενού που προστέθηκε αργότερα)
  // διατηρούν τη φυσική τους σχετική σειρά στο τέλος (Array.sort είναι
  // σταθερό).
  const orderedItems = useMemo(() => {
    if (!customOrder) return visibleItems;
    const rank = new Map(customOrder.map((path, idx) => [path, idx]));
    return [...visibleItems].sort((a, b) => {
      const ai = rank.has(a.to) ? (rank.get(a.to) as number) : Number.MAX_SAFE_INTEGER;
      const bi = rank.has(b.to) ? (rank.get(b.to) as number) : Number.MAX_SAFE_INTEGER;
      return ai - bi;
    });
  }, [visibleItems, customOrder]);

  useEffect(() => {
    function refresh() {
      Promise.all([getUnreadMessageCount(), getGroupUnreadCount()])
        .then(([direct, group]) => setUnreadMessages(direct + group))
        .catch(() => {
          /* σιωπηλή αποτυχία */
        });
    }
    refresh();
    const interval = setInterval(refresh, 60000);
    return () => clearInterval(interval);
  }, []);

  function handleDragStart(index: number) {
    setDragIndex(index);
  }

  function handleDragOver(e: DragEvent<HTMLDivElement>, index: number) {
    if (dragIndex === null || dragIndex === index) return;
    e.preventDefault();
  }

  function handleDrop(index: number) {
    if (dragIndex === null || dragIndex === index) return;
    const reordered = [...orderedItems];
    const [moved] = reordered.splice(dragIndex, 1);
    reordered.splice(index, 0, moved);
    const newOrder = reordered.map((i) => i.to);
    setCustomOrder(newOrder);
    saveCustomOrder(newOrder);
    setDragIndex(null);
  }

  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-line bg-surface md:flex">
      <Link to="/" className="flex items-center gap-2 border-b border-line px-5 py-5 hover:bg-surface-raised">
        <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-chalk">
          <span className="font-display text-sm text-chalk">FH</span>
        </div>
        <span className="font-display text-lg tracking-wide text-text-primary">FootballHub</span>
      </Link>

      {/* signature: yard-line tick strip */}
      <div className="h-2 bg-pitch-lines" />

      <div className="flex items-center justify-between px-3 pt-3">
        <span className="text-[10px] uppercase tracking-wide text-text-muted">
          {isLocked ? t("nav.menuLabel") : t("nav.dragToReorder")}
        </span>
        <button
          onClick={() => {
            setIsLocked((l) => !l);
            setDragIndex(null);
          }}
          title={isLocked ? t("nav.unlockTooltip") : t("nav.lockTooltip")}
          className="flex h-6 w-6 items-center justify-center rounded text-sm text-text-muted hover:bg-surface-raised hover:text-chalk"
        >
          {isLocked ? "🔒" : "🔓"}
        </button>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-2">
        {orderedItems.map((item, index) =>
          item.disabled ? (
            <div
              key={item.to}
              draggable={!isLocked}
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={() => handleDrop(index)}
              className={`flex items-center justify-between rounded-md px-3 py-2 text-sm text-text-muted/40 ${
                !isLocked ? "cursor-grab border border-dashed border-line" : "cursor-not-allowed"
              }`}
              title={t("nav.comingSoonTooltip")}
            >
              <span className="flex items-center gap-3">
                {!isLocked && <span className="text-text-muted">⠿</span>}
                <span className="w-4 text-center">{item.icon}</span>
                {t(item.labelKey)}
              </span>
              <span className="text-[10px] uppercase tracking-wide">{t("nav.comingSoon")}</span>
            </div>
          ) : (
            <div
              key={item.to}
              draggable={!isLocked}
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={() => handleDrop(index)}
              className={!isLocked ? "border border-dashed border-line rounded-md" : ""}
            >
              <NavLink
                to={item.to}
                end={item.to === "/"}
                onClick={(e) => {
                  if (!isLocked) e.preventDefault();
                }}
                className={({ isActive }) =>
                  `flex items-center justify-between gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                    !isLocked
                      ? "cursor-grab text-text-muted"
                      : isActive
                        ? "bg-pitch-dark/40 text-chalk border-l-2 border-chalk"
                        : "text-text-muted hover:bg-surface-raised hover:text-text-primary"
                  }`
                }
              >
                <span className="flex items-center gap-3">
                  {!isLocked && <span className="text-text-muted">⠿</span>}
                  <span className="w-4 text-center">{item.icon}</span>
                  {t(item.labelKey)}
                </span>
                {isLocked && item.to === "/messages" && unreadMessages > 0 && (
                  <span className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-chalk px-1 text-[10px] font-semibold text-void">
                    {unreadMessages > 9 ? "9+" : unreadMessages}
                  </span>
                )}
              </NavLink>
            </div>
          )
        )}
      </nav>

      <div className="mx-3 mb-2 flex gap-2">
        <button
          onClick={toggleTheme}
          className="flex flex-1 items-center justify-center gap-2 rounded-md border border-line px-3 py-2 text-xs text-text-muted hover:border-chalk hover:text-text-primary"
        >
          {theme === "dark" ? `☀ ${t("theme.lightMode")}` : `🌙 ${t("theme.darkMode")}`}
        </button>
        <button
          onClick={toggleLanguage}
          title={language === "el" ? t("language.toggleToEnglish") : t("language.toggleToGreek")}
          className="flex items-center justify-center rounded-md border border-line px-3 py-2 text-xs font-semibold text-text-muted hover:border-chalk hover:text-text-primary"
        >
          {language === "el" ? "EN" : "GR"}
        </button>
      </div>

      <div className="border-t border-line px-5 py-4 text-xs text-text-muted">{t("nav.footerTagline")}</div>
    </aside>
  );
}
