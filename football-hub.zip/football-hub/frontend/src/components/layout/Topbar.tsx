import { useState } from "react";
import { Link } from "react-router-dom";

import { mediaUrl } from "../../api/client";
import { useAuth } from "../../context/AuthContext";
import { useLanguage } from "../../context/LanguageContext";
import { NotificationBell } from "./NotificationBell";
import { TopbarClock } from "./TopbarClock";

export function Topbar({ title }: { title: string }) {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="flex items-center justify-between border-b border-line bg-surface px-6 py-4">
      <h1 className="font-display text-xl text-text-primary">{title}</h1>
      <div className="flex items-center gap-3">
        <TopbarClock />
        {user?.role !== "player" && (
          <Link
            to="/crm"
            title="CRM"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-text-muted hover:border-chalk hover:text-chalk"
          >
            📇
          </Link>
        )}
        <NotificationBell />
        <div className="relative">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-surface-raised"
          >
            <span className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-pitch-dark font-display text-sm text-chalk">
              {user?.avatar_path ? (
                <img src={mediaUrl(user.avatar_path)} alt="" className="h-full w-full object-cover" />
              ) : (
                (user?.full_name || user?.username || "?").charAt(0).toUpperCase()
              )}
            </span>
            <span className="hidden text-sm text-text-primary sm:block">
              {user?.full_name || user?.username}
            </span>
          </button>
          {menuOpen && (
            <div className="absolute right-0 z-20 mt-2 w-52 rounded-md border border-line bg-surface-raised py-1 shadow-xl">
              <div className="border-b border-line px-3 py-2 text-xs text-text-muted">
                {user?.email}
              </div>
              <Link
                to="/profile"
                onClick={() => setMenuOpen(false)}
                className="block w-full px-3 py-2 text-left text-sm text-text-primary hover:bg-void"
              >
                {t("topbar.myProfile")}
              </Link>
              <button
                onClick={logout}
                className="w-full px-3 py-2 text-left text-sm text-status-injured hover:bg-void"
              >
                {t("topbar.logout")}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
