import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

import {
  getUnreadCount,
  listNotifications,
  markNotificationRead,
} from "../../api/notifications";
import type { AppNotification } from "../../types";
import { NOTIFICATION_COLORS, NOTIFICATION_ICONS, URGENT_NOTIFICATION_TYPES } from "../../types";
import { notificationLink } from "../../utils/notificationLink";
import { useLanguage } from "../../context/LanguageContext";

export function NotificationBell() {
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [recent, setRecent] = useState<AppNotification[]>([]);
  const wrapperRef = useRef<HTMLDivElement>(null);

  async function refreshCount() {
    try {
      const count = await getUnreadCount();
      setUnreadCount(count);
    } catch {
      /* σιωπηλή αποτυχία — το bell απλά δεν δείχνει badge */
    }
  }

  useEffect(() => {
    refreshCount();
    const interval = setInterval(refreshCount, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  async function toggleOpen() {
    const next = !isOpen;
    setIsOpen(next);
    if (next) {
      try {
        const data = await listNotifications();
        setRecent(data.slice(0, 6));
      } catch {
        /* σιωπηλή αποτυχία */
      }
    }
  }

  async function handleItemClick(n: AppNotification) {
    if (!n.is_read) {
      try {
        await markNotificationRead(n.id);
        setRecent((prev) => prev.map((x) => (x.id === n.id ? { ...x, is_read: true } : x)));
        setUnreadCount((c) => Math.max(0, c - 1));
      } catch {
        /* σιωπηλή αποτυχία */
      }
    }
    setIsOpen(false);
  }

  return (
    <div ref={wrapperRef} className="relative">
      <button
        onClick={toggleOpen}
        className="relative flex h-9 w-9 items-center justify-center rounded-md text-text-muted hover:bg-surface-raised hover:text-text-primary"
        title={t("notificationBell.title")}
      >
        <span className="text-lg">🔔</span>
        {unreadCount > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-status-injured px-1 text-[10px] font-semibold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 z-30 mt-2 w-80 rounded-md border border-line bg-surface-raised shadow-2xl">
          <div className="flex items-center justify-between border-b border-line px-3 py-2">
            <span className="text-xs uppercase tracking-wide text-text-muted">{t("notificationBell.title")}</span>
            <Link to="/notifications" onClick={() => setIsOpen(false)} className="text-xs text-chalk hover:underline">
              {t("notificationBell.all")}
            </Link>
          </div>
          {recent.length === 0 ? (
            <p className="px-3 py-6 text-center text-xs text-text-muted">{t("notificationBell.noNotifications")}</p>
          ) : (
            <div className="max-h-80 divide-y divide-line overflow-y-auto">
              {recent.map((n) => {
                const link = notificationLink(n);
                const isUrgent = URGENT_NOTIFICATION_TYPES.includes(n.type);
                const content = (
                  <div className={`flex items-start gap-2 px-3 py-2 text-xs ${!n.is_read ? "bg-void/40" : ""}`}>
                    <span className={NOTIFICATION_COLORS[n.type]}>{NOTIFICATION_ICONS[n.type]}</span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        {isUrgent && (
                          <span className="rounded-full border border-status-injured/40 bg-status-injured/15 px-1.5 py-px text-[9px] font-semibold uppercase text-status-injured">
                            Urgent
                          </span>
                        )}
                        <p className={`truncate ${n.is_read ? "text-text-muted" : "text-text-primary"}`}>{n.title}</p>
                      </div>
                      <p className="text-[10px] text-text-muted">
                        {new Date(n.created_at).toLocaleDateString("el-GR")}
                      </p>
                    </div>
                    {!n.is_read && <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-chalk" />}
                  </div>
                );
                return link ? (
                  <Link key={n.id} to={link} onClick={() => handleItemClick(n)} className="block hover:bg-void/30">
                    {content}
                  </Link>
                ) : (
                  <div key={n.id} onClick={() => handleItemClick(n)} className="cursor-pointer hover:bg-void/30">
                    {content}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
