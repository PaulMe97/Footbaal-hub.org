import type { ReactNode } from "react";

import { MelieWidget } from "../melie/MelieWidget";
import { LeadershipApprovalBanner } from "./LeadershipApprovalBanner";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";

export function AppLayout({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="flex h-screen bg-void">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Topbar title={title} />
        <LeadershipApprovalBanner />
        <main className="flex-1 overflow-y-auto px-6 py-6">{children}</main>
      </div>
      <MelieWidget />
    </div>
  );
}
