import { useEffect, useState } from "react";

import { useLanguage } from "../../context/LanguageContext";

export function TopbarClock() {
  const { language } = useLanguage();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const locale = language === "el" ? "el-GR" : "en-US";
  const timeStr = now.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  return (
    <div
      className="flex h-9 items-center gap-1.5 rounded-full border border-line px-3 text-xs text-text-muted"
      title={dateStr}
    >
      <span>🕐</span>
      <span className="font-mono tabular-nums text-text-primary">{timeStr}</span>
    </div>
  );
}
