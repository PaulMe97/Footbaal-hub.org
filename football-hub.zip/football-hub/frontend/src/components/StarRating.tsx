export function StarRating({
  value,
  onChange,
  readOnly = false,
  size = "text-2xl",
}: {
  value: number;
  onChange?: (value: number) => void;
  readOnly?: boolean;
  size?: string;
}) {
  const stars = [1, 2, 3, 4, 5];
  return (
    <div className={`flex gap-1 ${size}`}>
      {stars.map((n) => (
        <button
          key={n}
          type="button"
          disabled={readOnly}
          onClick={() => onChange?.(n)}
          className={`leading-none transition-transform ${
            readOnly ? "cursor-default" : "cursor-pointer hover:scale-110"
          } ${n <= value ? "text-amber-400" : "text-line"}`}
          aria-label={`${n} / 5`}
        >
          {n <= value ? "★" : "☆"}
        </button>
      ))}
    </div>
  );
}
