export function QuickSuggestions({
  suggestions,
  onSelect,
}: {
  suggestions: string[];
  onSelect: (text: string) => void;
}) {
  if (suggestions.length === 0) return null;
  return (
    <div className="-mt-2 mb-1 flex flex-wrap gap-1.5">
      {suggestions.map((s, i) => (
        <button
          key={i}
          type="button"
          onClick={() => onSelect(s)}
          className="rounded-full border border-line px-2.5 py-1 text-left text-[11px] leading-snug text-text-muted transition-colors hover:border-chalk hover:text-chalk"
        >
          {s}
        </button>
      ))}
    </div>
  );
}

/** Εισάγει μια έτοιμη πρόταση στο τέλος του υπάρχοντος κειμένου ενός πεδίου
 * (ή το αντικαθιστά αν είναι κενό) — κοινή λογική για όλα τα πεδία που
 * χρησιμοποιούν QuickSuggestions. */
export function appendSuggestion(current: string, suggestion: string): string {
  const trimmed = current.trim();
  if (!trimmed) return suggestion;
  const needsSpace = /[.!;]$/.test(trimmed);
  return `${trimmed}${needsSpace ? " " : ". "}${suggestion}`;
}
