import { useState } from "react";

import { extractErrorMessage } from "../api/client";
import { useToast } from "./ui/Toast";

export function ExportMenu({
  onExportExcel,
  onExportPdf,
  label = "⬇ Εξαγωγή",
}: {
  onExportExcel: () => Promise<void>;
  onExportPdf: () => Promise<void>;
  label?: string;
}) {
  const toast = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  async function handle(fn: () => Promise<void>) {
    setIsOpen(false);
    setIsExporting(true);
    try {
      await fn();
    } catch (err) {
      toast.show(extractErrorMessage(err), "error");
    } finally {
      setIsExporting(false);
    }
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen((s) => !s)}
        disabled={isExporting}
        className="rounded-md border border-line px-3 py-1.5 text-xs text-text-primary hover:border-chalk disabled:opacity-50"
      >
        {isExporting ? "..." : label}
      </button>
      {isOpen && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 z-20 mt-1 w-40 rounded-md border border-line bg-surface-raised py-1 shadow-lg">
            <button
              onClick={() => handle(onExportExcel)}
              className="block w-full px-3 py-2 text-left text-xs text-text-primary hover:bg-surface"
            >
              📊 Excel (.xlsx)
            </button>
            <button
              onClick={() => handle(onExportPdf)}
              className="block w-full px-3 py-2 text-left text-xs text-text-primary hover:bg-surface"
            >
              📄 PDF
            </button>
          </div>
        </>
      )}
    </div>
  );
}
