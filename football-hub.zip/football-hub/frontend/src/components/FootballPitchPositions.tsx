import type { PlayerPosition } from "../types";

const POSITION_COORDS: Record<PlayerPosition, { x: number; y: number }> = {
  GK: { x: 50, y: 92 },
  CB: { x: 50, y: 78 },
  LB: { x: 15, y: 76 },
  RB: { x: 85, y: 76 },
  LWB: { x: 8, y: 58 },
  RWB: { x: 92, y: 58 },
  DM: { x: 50, y: 60 },
  CM: { x: 50, y: 45 },
  AM: { x: 50, y: 30 },
  LW: { x: 14, y: 16 },
  RW: { x: 86, y: 16 },
  ST: { x: 50, y: 7 },
};

export function FootballPitchPositions({ positions }: { positions: string[] }) {
  const highlighted = new Set(positions);

  return (
    <svg viewBox="0 0 100 130" className="w-full max-w-[220px] mx-auto">
      {/* Γήπεδο */}
      <rect x="2" y="2" width="96" height="126" rx="2" fill="none" className="stroke-line" strokeWidth="1" />
      {/* Κεντρική γραμμή */}
      <line x1="2" y1="65" x2="98" y2="65" className="stroke-line" strokeWidth="1" />
      {/* Κεντρικός κύκλος */}
      <circle cx="50" cy="65" r="10" fill="none" className="stroke-line" strokeWidth="1" />
      <circle cx="50" cy="65" r="0.8" className="fill-line" />
      {/* Κάτω περιοχή (δική μας εστία) */}
      <rect x="25" y="106" width="50" height="22" fill="none" className="stroke-line" strokeWidth="1" />
      <rect x="37" y="118" width="26" height="10" fill="none" className="stroke-line" strokeWidth="1" />
      {/* Πάνω περιοχή (αντίπαλη εστία) */}
      <rect x="25" y="2" width="50" height="22" fill="none" className="stroke-line" strokeWidth="1" />
      <rect x="37" y="2" width="26" height="10" fill="none" className="stroke-line" strokeWidth="1" />

      {(Object.keys(POSITION_COORDS) as PlayerPosition[]).map((pos) => {
        const { x, y } = POSITION_COORDS[pos];
        const isActive = highlighted.has(pos);
        return (
          <g key={pos}>
            <circle
              cx={x}
              cy={y}
              r={isActive ? 7 : 5}
              className={isActive ? "fill-chalk" : "fill-surface-raised stroke-line"}
              strokeWidth={isActive ? 0 : 1}
            />
            <text
              x={x}
              y={y + 2}
              textAnchor="middle"
              fontSize={isActive ? "4.5" : "3.5"}
              fontWeight={isActive ? "bold" : "normal"}
              className={isActive ? "fill-void" : "fill-text-muted"}
            >
              {pos}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
